# 🎯 Dashboard KSeF - Kluczowe Pola (PODSUMOWANIE)

## 📊 TABELA GŁÓWNA - 12 KOLUMN KRYTYCZNYCH

| # | Pole | Typ danych | Przykład | Priorytet | Opis |
|---|------|------------|----------|-----------|------|
| 1 | **checkbox** | boolean | ☑️ | CRITICAL | Multi-select do operacji masowych |
| 2 | **status_ksef** | enum | 🟢 Aktywna | CRITICAL | active / cancelled / corrected |
| 3 | **numer_ksef** | string | 1234567890-20241201-ABC123 | HIGH | Unikalny identyfikator KSeF |
| 4 | **numer_wlasny** | string | FV/2024/12/001 | HIGH | Numer nadany przez firmę |
| 5 | **kontrahent** | object | Firma XYZ<br/>NIP: 5252344078 | CRITICAL | Nazwa + NIP (+ badge VIP) |
| 6 | **data_wystawienia** | date | 01.12.2024 | HIGH | Data wystawienia faktury |
| 7 | **termin_platnosci** | date + int | 15.12.2024<br/>(14 dni) | CRITICAL | Data + dni pozostało/po terminie |
| 8 | **kwota_netto** | decimal | 10 000,00 PLN | HIGH | Wartość netto |
| 9 | **vat** | decimal + % | 2 300,00 PLN<br/>(23%) | CRITICAL | Kwota VAT + stawka |
| 10 | **kwota_brutto** | decimal | 12 300,00 PLN | CRITICAL | Wartość brutto (bold) |
| 11 | **status_platnosci** | enum + icon | ✅ Zapłacona | CRITICAL | paid / pending / overdue |
| 12 | **akcje** | buttons | 👁️ 📥 📊 | HIGH | Podgląd / XML / Księguj |

## 🔢 METRYKI GÓRNEGO PANELU - 4 WSKAŹNIKI

| Metryka | Format | Przykład | Częstotliwość odświeżania |
|---------|--------|----------|---------------------------|
| **Faktury dziś** | liczba + trend | 127 ↑+12% | Co 1 min |
| **VAT do rozliczenia** | kwota + termin | 234 567 PLN<br/>Termin: 25.12.2024 | Co 5 min |
| **Alerty KSeF** | liczba + severity | 3 🔴 | Real-time |
| **Ostatnia synchronizacja** | czas względny + status | 2 min temu ✅ | Co 10 sek |

## 🔍 FILTRY PODSTAWOWE - 6 KATEGORII

| Filtr | Typ | Opcje | Domyślnie |
|-------|-----|-------|-----------|
| **Okres** | select | Dziś / Tydzień / Miesiąc / Kwartał / Własny | Miesiąc |
| **Status KSeF** | checkbox | ☑️ Aktywne / ☐ Anulowane / ☑️ Korekty | Aktywne + Korekty |
| **Typ faktury** | radio | ⚪ Wszystkie / ⚪ Zakupowe / ⚪ Sprzedażowe | Wszystkie |
| **Status płatności** | checkbox | ☑️ Zapłacone / ☑️ Oczekujące / ☐ Przeterminowane | Wszystkie |
| **Kontrahent** | search + select | Nazwa / NIP / Tylko VIP | - |
| **Kwota brutto** | range | Min - Max PLN | 0 - ∞ |

## 💰 PODSUMOWANIE VAT - 3 KARTY

### KARTA 1: VAT należny (sprzedaż)
| Okres | Pole | Typ |
|-------|------|-----|
| Bieżący miesiąc | 145 230,00 PLN | decimal + trend |
| Poprzedni miesiąc | 132 100,00 PLN | decimal |
| Kwartał | 412 330,00 PLN | decimal (bold) |

### KARTA 2: VAT naliczony (zakup)  
| Okres | Pole | Typ |
|-------|------|-----|
| Bieżący miesiąc | 89 450,00 PLN | decimal + trend |
| Poprzedni miesiąc | 76 200,00 PLN | decimal |
| Kwartał | 241 850,00 PLN | decimal (bold) |

### KARTA 3: Do zapłaty
| Pole | Wartość | Status |
|------|---------|--------|
| Kwota | 55 780,00 PLN | text-2xl font-bold |
| Termin | 25.12.2024 | date + dni pozostało |
| Status deklaracji | Szkic | badge (draft/confirmed/paid) |

## 📈 STATUS PŁATNOŚCI - PROGRESS BARS

| Status | Liczba | Wartość | Procent | Kolor | Dodatkowe info |
|--------|--------|---------|---------|-------|----------------|
| **Zapłacone** | 234 | 567 890 PLN | 67% | 🟢 green-600 | - |
| **Oczekujące** | 89 | 234 567 PLN | 25% | 🟡 yellow-600 | Śr. czas: 12 dni |
| **Przeterminowane** | 28 | 67 890 PLN | 8% | 🔴 red-600 | Najstarsze: 47 dni |

## 🚨 ALERTY - 7 TYPÓW

| Typ | Severity | Ikona | Przykład komunikatu | Akcja |
|-----|----------|-------|---------------------|-------|
| **NOWA_FAKTURA** | info | 🔵 | "Nowa faktura FV/2024/12/123 w KSeF" | Podgląd |
| **BLAD_PARSOWANIA** | warning | 🟡 | "Problem z XML faktury ABC123" | Debug |
| **TERMIN_PLATNOSCI** | warning | 🟡 | "Zbliża się termin płatności (3 dni)" | Przypomnienie |
| **PRZETERMINOWANE** | danger | 🔴 | "Faktura FV/2024/11/089 po terminie (14 dni)" | Monit |
| **BLAD_SYNCHRONIZACJI** | danger | 🔴 | "Błąd API KSeF: Sesja wygasła" | Ponów |
| **DUPLIKAT** | warning | 🟡 | "Możliwy duplikat faktury XYZ" | Sprawdź |
| **WYSOKA_KWOTA** | info | 🔵 | "Faktura > 50 000 PLN wymaga akceptacji" | Zatwierdź |

## ⚡ AKCJE MASOWE - 5 OPERACJI

| Akcja | Ikona | Opis | Warunek | Rezultat |
|-------|-------|------|---------|----------|
| **Eksport Excel** | 📊 | Export zaznaczonych do .xlsx | Min. 1 zaznaczona | Plik XLSX |
| **Oznacz jako zapłacone** | ✅ | Zmień status płatności | Status != paid | Update DB |
| **Księguj pakietowo** | 📝 | Przenieś do systemu FK | Status != booked | API call |
| **Generuj JPK_V7M** | 📄 | Utwórz plik JPK | Okres zamknięty | XML file |
| **Wyślij przypomnienia** | 📧 | Email do kontrahentów | Status = overdue | Email queue |

## 📱 WIDOK MOBILNY - TOP 5 PRIORYTETÓW

| Priorytet | Element | Format mobilny |
|-----------|---------|----------------|
| 1 | **Badge nowych faktur** | Liczba w czerwonym kółku (sticky top) |
| 2 | **VAT do zapłaty** | Duża kwota + termin (card) |
| 3 | **Lista ostatnich 10** | Uproszczona (kontrahent + kwota) |
| 4 | **Filtry szybkie** | 3 buttony (Dziś/Tydzień/Miesiąc) |
| 5 | **Przycisk synchronizacji** | FAB (floating action button) |

## 🔐 ROLE I UPRAWNIENIA

| Rola | Dostęp | Może | Nie może |
|------|--------|------|----------|
| **ADMIN** | Pełny | Wszystko | - |
| **KSIĘGOWY** | Edycja | Księgować, eksportować, edytować | Usuwać, zmieniać ustawienia |
| **POMOCNIK** | Odczyt | Przeglądać, filtrować, eksportować | Edytować, księgować |
| **KLIENT** | Ograniczony | Tylko swoje faktury | Widzieć inne firmy |

## 📊 KPI DLA ZARZĄDU BIURA

| KPI | Wzór | Cel | Alert jeśli |
|-----|------|-----|-------------|
| **Czas przetworzenia** | Δ(księgowanie - synchronizacja) | < 24h | > 48h |
| **Procent automatyzacji** | (auto_booked / total) × 100% | > 80% | < 60% |
| **Średni czas reakcji** | AVG(first_action - sync_time) | < 4h | > 8h |
| **Wskaźnik błędów** | (errors / total) × 100% | < 2% | > 5% |
| **Terminowość płatności** | (paid_on_time / total_paid) × 100% | > 90% | < 70% |

## 🎨 KOLORYSTYKA STATUSÓW

```css
/* Faktury */
.active    { background: #D1FAE5; color: #065F46; }  /* Zielony */
.cancelled { background: #FEE2E2; color: #991B1B; }  /* Czerwony */  
.corrected { background: #FEF3C7; color: #92400E; }  /* Żółty */

/* Płatności */
.paid      { border-left: 4px solid #10B981; }  /* Zielony */
.pending   { border-left: 4px solid #F59E0B; }  /* Żółty */
.overdue   { border-left: 4px solid #EF4444; }  /* Czerwony */

/* Alerty */
.info      { background: #EFF6FF; }  /* Niebieski jasny */
.warning   { background: #FEF3C7; }  /* Żółty jasny */
.danger    { background: #FEE2E2; }  /* Czerwony jasny */
```

## ⌨️ SKRÓTY KLAWISZOWE

| Skrót | Akcja |
|-------|-------|
| `Ctrl+F` | Focus na wyszukiwanie |
| `Ctrl+N` | Nowa synchronizacja |
| `Ctrl+E` | Eksport do Excel |
| `Ctrl+S` | Zapisz filtry |
| `Space` | Zaznacz/odznacz wiersz |
| `Ctrl+A` | Zaznacz wszystkie |
| `Esc` | Anuluj/zamknij modal |

---

**Wersja:** 1.0.0  
**Data:** 2024-12-01  
**Projekt:** PunchlineROI - Robot Zwiadowca  
**Dla:** Biura Rachunkowe w Polsce  
**Deadline KSeF:** Luty 2026 (16 miesięcy przewagi)
