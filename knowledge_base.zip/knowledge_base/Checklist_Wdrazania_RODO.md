# CHECKLIST WDRAŻANIA RODO I DOKUMENTÓW PRAWNYCH

**PunchlineROI – Robot-Zwiadowca KSeF**

Data: 8 grudnia 2025 | Wersja: 1.0

---

## I. DOKUMENTY PRAWNE ✅

### Opublikowane i Dostępne:

- [x] **Polityka Prywatności** (punchlineroi.com/polityka-prywatnosci)
  - Zawiera wszystkie informacje wymagane art. 13-14 RODO
  - Jasne informacje o celach przetwarzania
  - Okresy przechowywania danych
  - Prawa osób, których dane dotyczą
  - Informacje o podwykonawcach

- [x] **Regulamin Serwisu** (punchlineroi.com/regulamin)
  - Warunki świadczenia usług (art. 8 ustawy o usługach drogą elektroniczną)
  - Plany subskrypcji i opłaty
  - Procedury reklamacyjne (14-dniowy termin)
  - Ograniczenia odpowiedzialności
  - Zasady zawieszenia i zamknięcia konta

- [x] **Umowa Powierzenia Przetwarzania Danych (DPA)** (art. 28 RODO)
  - Zawiera art. 28 ust. 3-4 RODO
  - Role Administrator / Procesor
  - Obowiązki bezpieczeństwa (art. 32 RODO)
  - Procedury obsługi incydentów
  - Prawa osób, których dane dotyczą
  - Zarządzanie podwykonawcami

- [x] **Informacja o Cookies** (na stronie głównej)
  - Baner cookies z 3 opcjami (Zaakceptuj wszystkie, Odrzuć, Dostosuj)
  - Opis rodzajów cookies (niezbędne, analityczne, marketingowe)
  - Link do pełnej polityki cookies

### Status: **GOTOWE DO PUBLIKACJI** 🟢

---

## II. STRONA INTERNETOWA – WYMAGANE ELEMENTY

### Sekcja Informacyjna (Header / Footer):

- [ ] **Link do Polityki Prywatności** (każda strona)
  - Lokalizacja: Footer, widoczny link
  - Tekst: "Polityka Prywatności"
  - Format: Легко dostępny, nie wymaga scrollowania

- [ ] **Link do Regulaminu** (każda strona)
  - Lokalizacja: Footer
  - Tekst: "Regulamin Serwisu"

- [ ] **Dane Kontaktowe Administrator**
  - Email: Impact@punchlineroi.com
  - Telefon: +31 68 4816844
  - Godziny wsparcia: Pon-Pt 9:00-17:00 CET

- [ ] **Baner Cookies**
  - Wymagany na każdej stronie
  - Cztery przyciski: [Zaakceptuj wszystkie] [Odrzuć wszystkie] [Dostosuj] [?]
  - Tekst musi być: Krótki, prosty, informacyjny

- [ ] **Formularz Kontaktowy / Zgłoszenie Problemu**
  - Dla zgłaszania reklamacji
  - Dla żądań dostępu do danych (art. 15 RODO)
  - Dla wycofania zgody na cookies

### Sekcja Formularza Rejestracji:

- [ ] **Akceptacja Regulaminu** (checkbox obowiązkowy)
  - Tekst: "Akceptuję Regulamin Serwisu"
  - Musi być odznaczony **domyślnie** (opt-in, nie opt-out)
  - Link do pełnego tekstu Regulaminu

- [ ] **Akceptacja Polityki Prywatności** (checkbox obowiązkowy)
  - Tekst: "Zapoznałem się z Polityką Prywatności"
  - Link do pełnego tekstu

- [ ] **Zgoda na Przetwarzanie Danych** (checkbox obowiązkowy)
  - Tekst: "Wyrażam zgodę na przetwarzanie moich danych osobowych w celu realizacji usługi"
  - Jasne informacje co to znaczy

- [ ] **Zgoda na Newsletter** (checkbox OPCJONALNY)
  - Tekst: "Chcę otrzymywać informacje o nowych funkcjach i promocjach"
  - **Musi być odznaczony domyślnie** (true opt-in)
  - Łatwy sposób rezygnacji (link w każdym emailu)

### Status: **WYMAGANE PRZED WDROŻENIEM** 🔴

---

## III. BEZPIECZEŃSTWO TECHNICZNE

### Infrastruktura:

- [x] **SSL/TLS**
  - Certyfikat SSL válny (co najmniej do 2026)
  - TLS 1.2+ wymagane dla wszystkich połączeń
  - Sprawdzenie: https://www.ssllabs.com/ssltest/

- [x] **Szyfrowanie Danych**
  - AES-256 dla danych w spoczynku (bazy danych)
  - TLS 1.2+ dla danych w transmisji
  - Backupy szyfrowane

- [x] **Hosting**
  - Google Cloud Platform (eu-region preferowany)
  - Neon Inc. (PostgreSQL)
  - Oba dostawcy mają certyfikaty ISO 27001 / SOC 2 Type II

- [x] **Autentyfikacja**
  - Login/Hasło wymagane
  - Wielofaktorowe uwierzytelnianie (MFA) dla administratorów
  - Sesje z timeout (30 minut inaktywności)

- [x] **Ochrona przed Atakami**
  - Web Application Firewall (WAF)
  - Ochrona DDoS
  - Skanowanie podatności (co 3 miesiące)
  - Penetration testing (co 6 miesięcy)

### Status: **WDROŻONE** 🟢

---

## IV. PROCEDURY WEWNĘTRZNE

### Zarządzanie Dostępem:

- [ ] **Dokument: Procedura Zarządzania Dostępem**
  - Kto ma dostęp do jakich danych
  - Procedure przydzielania dostępu
  - Procedura usuwania dostępu (off-boarding)
  - Zasada least privilege ("need-to-know")

- [ ] **Umowy o Poufności (NDA)**
  - Wszystkie osoby zatrudnione: Pracownicy, Podwykonawcy, Konsultanci
  - Tekst: Zobowiązanie do ochrony poufności danych

- [ ] **Szkolenia RODO**
  - Szkolenie dla wszystkich pracowników (min. raz rocznie)
  - Zaświadczenie o ukończeniu
  - Dokumentacja uczestnictwa

### Incident Management:

- [ ] **Procedura Obsługi Incydentów Bezpieczeństwa**
  - Kto powiadamia (osoba odpowiedzialna)
  - Czasowniki: Powiadomienie Admina (max 24h), UODO (72h)
  - Szablonów emaili
  - Rejestr incydentów (Google Sheet lub CRM)

- [ ] **Procedura Obsługi Żądań RODO**
  - Żądanie dostępu (art. 15) – odpowiedź w 30 dni
  - Żądanie usunięcia (art. 17) – operacja w 30 dni
  - Żądanie sprostowania (art. 16) – na bieżąco
  - Szablon odpowiedzi dla każdego żądania

- [ ] **Procedura Obsługi Reklamacji**
  - Formularz reklamacji online
  - Email: Impact@punchlineroi.com
  - Termin odpowiedzi: 14 dni
  - Szablon odpowiedzi

### Status: **WYMAGANE PRZED PEŁNYM WDROŻENIEM** 🔴

---

## V. DOKUMENTACJA (REJESTR CZYNNOŚCI PRZETWARZANIA)

### Art. 30 RODO – Rejestr Czynności:

- [ ] **Dokument: Rejestr Czynności Przetwarzania**
  - Nazwa i cel operacji (np. "Realizacja usługi KSeF")
  - Kategorie danych (np. "PESEL, NIP, dane bankowe")
  - Kategorie osób (właściciele firm, pracownicy)
  - Podwykonawcy (Google Cloud, Stripe, Twilio)
  - Okresy przechowywania (7 lat dla danych podatkowych)
  - Środki bezpieczeństwa (szyfrowanie, backupy)
  - Lokalizacja danych (Google Cloud – eu-region)

- [ ] **Dokument: DPIA (Data Protection Impact Assessment)**
  - Jeśli przetwarzanie stanowi wysokie ryzyko
  - Dotyczy: Dostęp do KSeF, przetwarzanie PESEL/NIP
  - Zawiera: Opis zagrożeń, środki zaradcze, ryzyko pozostałe
  - Wymagane: Opcjonalnie (dla podwyższonego ryzyka)

### Status: **WYMAGANE W CIĄGU 2 TYGODNI** 🟡

---

## VI. ZARZĄDZANIE PODWYKONAWCAMI

### Lista Podwykonawców (Aktualnie Zatwierdzone):

- [x] **Google Cloud Platform**
  - Rola: Hosting aplikacji (Cloud Run)
  - Lokalizacja: USA (eu-region możliwe)
  - Transfer: DPF / SCC
  - DPA: https://cloud.google.com/terms/data-processing-addendum

- [x] **Neon Inc.**
  - Rola: Hosting bazy danych PostgreSQL
  - Lokalizacja: Ukraina/UE
  - Transfer: SCC
  - DPA: Wymagane

- [x] **Stripe Payments Europe Ltd.**
  - Rola: Przetwarzanie płatności
  - Lokalizacja: Irlandia
  - Transfer: Brak (EU-based)
  - DPA: https://stripe.com/nl/legal/supplierdpa

- [x] **Twilio SendGrid**
  - Rola: Wysyłka emaili
  - Lokalizacja: USA
  - Transfer: DPF / SCC
  - DPA: https://www.sendgrid.com/resource/general-data-protection-regulation/

- [x] **Netlify Inc.**
  - Rola: Hosting strony www
  - Lokalizacja: USA
  - Transfer: SCC / DPF
  - DPA: https://www.netlify.com/legal/

### Procedura Zatwierdzania Nowych Podwykonawców:

- [ ] **Krok 1:** Otrzymanie wniosku od pracownika (nowy tool/usługa)
- [ ] **Krok 2:** Pobranie DPA od dostawcy (Data Processing Agreement)
- [ ] **Krok 3:** Przegląd DPA (wymogi art. 28 RODO)
- [ ] **Krok 4:** Powiadomienie Klientów (30 dni przed wprowadzeniem)
- [ ] **Krok 5:** Dokumentacja w Rejestrze Czynności
- [ ] **Krok 6:** Zatwierdzenie / Wdrożenie

### Status: **WDROŻONE** 🟢

---

## VII. TRANSFER DANYCH DO USA

### Aktualne Mechanizmy:

- [x] **EU-US Data Privacy Framework (DPF)**
  - Używane dla: Google, Stripe, Netlify (jeśli certyfikowani)
  - Weryfikacja: https://www.dataprivacyframework.gov/
  - Monitoring: Sprawdzenie statusu certyfikacji co 6 miesięcy

- [x] **Standard Contractual Clauses (SCC) – Art. 46 RODO**
  - Backup dla dostawców niecertyfikowanych DPF
  - Transfer Impact Assessment (TIA) wymagana
  - Przechowywane umowy DPA

### Procedura TIA (Transfer Impact Assessment):

- [ ] **Dokument: TIA dla każdego dostawcy w USA**
  - Opis transferu (jakie dane, gdzie, po co)
  - Ocena prawa USA (warunki dostępu przez władze)
  - Ocena ryzyka: Czy władzę mogą dostać dane?
  - Dodatkowe zabezpieczenia (szyfrowanie, minimalizacja)
  - Konkluzja: Transfer bezpieczny?

### Prawo Użytkownika do Sprzeciwu:

- [ ] **Informacja w Polityce Prywatności**
  - "Użytkownik może sprzeciwić się transferom do USA"
  - Procedura: Email na Impact@punchlineroi.com
  - Alternatywa: Hosting wyłącznie w UE (możliwe za dodatkową opłatę)

### Status: **WDROŻONE (TIA WYMAGANA)** 🟡

---

## VIII. RAPORTOWANIE I AUDYTY

### Wewnętrzne Audyty:

- [ ] **Co 6 Miesięcy: Przegląd Bezpieczeństwa**
  - Testy penetracyjne
  - Skanowanie podatności
  - Przegląd procedur
  - Raport: Odkryte problemy + plan naprawy

- [ ] **Co Roku: Pełny Audyt RODO**
  - Zgodność z art. 30 RODO (Rejestr Czynności)
  - Bezpieczeństwo (art. 32 RODO)
  - Prawa osób, których dane dotyczą
  - Incydenty i żądania
  - Raport zarządowy

### Raportowanie dla Klientów:

- [ ] **Coroczny Raport dla Klientów** (opcjonalnie)
  - Liczba incydentów bezpieczeństwa: 0
  - Liczba żądań dostępu RODO: X
  - Liczba reklamacji: X
  - Durchgeführte audits: Dokumenty

### Status: **WYMAGANE W CIĄGU 3 MIESIĘCY** 🟡

---

## IX. KOMUNIKACJA Z KLIENTAMI

### Newsletter / Informacje o Zmianach:

- [x] **Template Emaila: Zmiana Polityki Prywatności**
  - Zawiera: Która klauzula się zmienia, dlaczego, kiedy wchodzi w życie
  - Wysyłany: Min. 30 dni przed zmianą
  - CTA: Link do nowej polityki

- [x] **Template Emaila: Incident Bezpieczeństwa**
  - Zawiera: Co się stało, które dane dotyczą, jakie kroki podjęliśmy
  - Wysyłany: Max 24 godziny od zauważenia problemu
  - Tone: Przejrzysty, bez okrywania

### Status: **GOTOWE** 🟢

---

## X. ZGODNOŚĆ Z POLSKIM PRAWEM

### Ustawa o Ochronie Konkurencji i Konsumentów:

- [x] **Klauzule Abuzywne (Art. 385¹ KC)**
  - Przegląd Regulaminu i umów
  - Brak niedozwolonych klauzul (nieograniczona odpowiedzialność itp.)
  - Wymóg: Jasna, zrozumiała dla laika

### Ustawa o Usługach Drogą Elektronicznej:

- [x] **Wymogi Art. 8 i Art. 11**
  - Dostęp do Regulaminu **przed** zawarciem umowy
  - Możliwość utrwalenia Regulaminu (print, save PDF)
  - Dane Administratora Serwisu (email, telefon)

### Ustawa o Prawach Konsumenta:

- [x] **Prawo Zwrotu (Art. 27 ustawy)**
  - 14 dni od zawarcia umowy
  - Nie dotyczy jeśli usługa już świadczona
  - Procedura: Email + zwrot pieniędzy w 14 dni

- [ ] **Procedura Reklamacyjna (Art. 7a ustawy)**
  - Termin: 14 dni dla réklamacji (wymagana lub nie – zależy od umowy)
  - Procedura: Wniosek na Impact@punchlineroi.com
  - Odpowiedź: 14 dni od wniosku

### Status: **WIĘKSZOŚĆ WDROŻONA** 🟢

---

## XI. CHECKLIST WDRAŻANIA – PODSUMOWANIE

### PILNE (Przed Pełnym Wdrożeniem) 🔴

- [ ] Opublikować wszystkie dokumenty na stronie (Polityka, Regulamin, Cookies)
- [ ] Wdrożyć baner cookies (4 przyciski)
- [ ] Zmodyfikować formularz rejestracji (3 checkboxy)
- [ ] Uaktualny Procedurę Zarządzania Dostępem
- [ ] Przygotować szablony emaili (incydenty, reklamacje, RODO)

**Czas: 2-3 tygodnie**

### WAŻNE (W Ciągu Miesiąca) 🟡

- [ ] Stworzyć Rejestr Czynności Przetwarzania (Art. 30 RODO)
- [ ] Przeprowadzić DPIA (jeśli wymagane)
- [ ] Przygotować TIA dla transferów do USA
- [ ] Zorganizować szkolenia RODO dla pracowników
- [ ] Ustawić monitoring incydentów

**Czas: 3-4 tygodnie**

### WAŻNE (W Ciągu Kwartału) 🟡

- [ ] Przeprowadzić wewnętrzny audyt bezpieczeństwa
- [ ] Zaktualizować procedury (incident, żądania RODO)
- [ ] Przygotować komunikację dla klientów

**Czas: 2-3 miesiące**

---

## XII. BUDŻET WDRAŻANIA

| Element | Koszt | Opis |
|---|---|---|
| **Dokumenty Prawne (już gotowe)** | €0 | Stworzone powyżej |
| **Baner Cookies (tool)** | €0-200 | Cookiebot, Osano lub własne rozwiązanie |
| **SSL/TLS** | €0 | Już wdrożone (Let's Encrypt lub płatne) |
| **Audyt Bezpieczeństwa (penetration test)** | €1,500-3,000 | Jeden raz co 6 miesięcy |
| **Szkolenia RODO** | €0-500 | Online lub zewnętrzne |
| **Konsultacja Prawnika (opcjonalnie)** | €500-1,500 | Review dokumentów |
| **Monitoring / Insurance** | €0-1,000 | Cyber liability insurance |
| **RAZEM (Minimal)** | **€0-500** | Baner cookies |
| **RAZEM (Rekomendowany)** | **€2,000-5,000** | Audyt + szkolenia + konsultacja |

---

## XIII. KONTAKTY I ODPOWIEDZIALNOŚĆ

**Osoba odpowiedzialna za RODO / Privacy:**
- Imię: Lachezar Mihaylov
- Rola: Właściciel / CTO
- Email: Impact@punchlineroi.com
- Telefon: +31 68 4816844

**Osoba odpowiedzialna za Bezpieczeństwo:**
- Lachezar Mihaylov (tymczasowo)
- Wymagane: Wyznaczenie dedykowanej osoby w przyszłości

**Osoba odpowiedzialna za Wsparcie Klienta:**
- Email: Impact@punchlineroi.com
- Godziny: Pon-Pt 9:00-17:00 CET

---

## DOKUMENTY ZAŁĄCZONE

1. ✅ Polityka Prywatności
2. ✅ Regulamin Serwisu
3. ✅ Umowa Powierzenia Przetwarzania Danych (DPA)
4. ✅ Checklist RODO (ten dokument)

---

**Przygotowano: 8 grudnia 2025**

**Status: GOTOWE DO WDROŻENIA** 🟢

**Następny krok: Publikacja i testowanie na stage'ingu**