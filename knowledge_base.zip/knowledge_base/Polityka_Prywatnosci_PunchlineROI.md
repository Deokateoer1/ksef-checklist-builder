# POLITYKA PRYWATNOŚCI

**PunchlineROI** | Robot-Zwiadowca KSeF

---

## 1. ADMINISTRATOR DANYCH OSOBOWYCH

**Administratorem danych osobowych jest:**

- **Nazwa podmiotu:** PunchlineROI
- **Osoba odpowiedzialna:** Lachezar Mihaylov
- **Siedzieba:** Rivierdijk 414A, 3372 BV Hardinxveld-Giessendam, Holandia
- **NIP:** 7011287658 (Polska)
- **REGON:** 543317943 (Polska)
- **Telefon:** +31 68 4816844
- **Email:** Impact@punchlineroi.com
- **Strona internetowa:** punchlineroi.com

**Inspektor Ochrony Danych Osobowych (IOD):** Brak powołanego inspektora (nie wymagany dla danych ze usług B2B). Możliwość wyznaczenia na żądanie.

---

## 2. CELE I PODSTAWY PRAWNE PRZETWARZANIA DANYCH OSOBOWYCH

Dane osobowe przetwarzane są w następujących celach:

### 2.1. Realizacja usługi – Robot-Zwiadowca KSeF i Kalkulator ROI
- **Podstawa prawna:** Art. 6 ust. 1 lit. b) RODO – wykonanie umowy o świadczenie usług
- **Zakres:** Pozyskiwanie danych z Krajowego Systemu e-Faktur (KSeF), przetwarzanie danych takich jak: numery PESEL/NIP kontrahentów, nazwy i adresy osób kontaktowych, dane bankowe do autoryzacji
- **Okres przechowywania:** Przez czas trwania umowy oraz 7 lat po jej rozwiązaniu (wymóg prawa podatkowego i cywilnego)

### 2.2. Płatności i rozliczenia
- **Podstawa prawna:** Art. 6 ust. 1 lit. b) RODO – wykonanie umowy oraz Art. 6 ust. 1 lit. c) RODO – obowiązki prawne w zakresie podatków VAT
- **Zakres:** Przetwarzanie danych identyfikacyjnych, adresu, informacji o subskrypcji, danych do wystawienia faktury
- **Okres przechowywania:** 7 lat od końca roku obrachunkowego (wymóg ustawy o podatku od towarów i usług oraz Kodeksu cywilnego)

### 2.3. Komunikacja i obsługa klienta
- **Podstawa prawna:** Art. 6 ust. 1 lit. b) RODO – wykonanie umowy; Art. 6 ust. 1 lit. a) RODO – zgoda na otrzymywanie informacji handlowych (jeśli wyrażona)
- **Zakres:** Wysyłanie potwierdzenia zawarcia umowy, raporty z systemu, wiadomości dotyczące awarii lub aktualizacji
- **Okres przechowywania:** Przez czas trwania umowy, następnie 1 rok (historia obsługi)

### 2.4. Newsletter i informacje marketingowe
- **Podstawa prawna:** Art. 6 ust. 1 lit. a) RODO – wyraźna zgoda użytkownika
- **Warunki:** Zgoda jest **dobrowolna, świadoma, wyraźna i udzielona poprzez aktywny przycisk** (opt-in). Każdy email zawiera link do rezygnacji
- **Okres przechowywania:** Do momentu anulowania subskrypcji

### 2.5. Analityka i doskonalenie usługi
- **Podstawa prawna:** Art. 6 ust. 1 lit. a) RODO – zgoda; Art. 6 ust. 1 lit. f) RODO – prawnie uzasadniony interes
- **Zakres:** Przetwarzanie danych anonimowych i pseudonimowych dotyczące: sposobu korzystania z aplikacji, funkcji najczęściej używanych, typowych błędów
- **Okres przechowywania:** Dane zaanonimizowane przechowywane przez czas nieograniczony; dane przed anonimizacją 1 rok

### 2.6. Bezpieczeństwo i zapobieganie oszustwom
- **Podstawa prawna:** Art. 6 ust. 1 lit. f) RODO – prawnie uzasadniony interes
- **Zakres:** Analiza logów dostępu, detektowanie nieautoryzowanych prób dostępu, zabezpieczenie przed zagrożeniami
- **Okres przechowywania:** 90 dni (logi technicze)

### 2.7. Zgodność z prawem i wymogi organów publicznych
- **Podstawa prawna:** Art. 6 ust. 1 lit. c) RODO – obowiązek prawny
- **Zakres:** Ujawnianie danych na żądanie organów egzekucyjnych, sądów, KAS
- **Okres przechowywania:** Zgodnie z wymaganiami przepisów

---

## 3. KATEGORIE PRZETWARZANYCH DANYCH OSOBOWYCH

Administratorem mogą być przetwarzane następujące kategorie danych osobowych:

1. **Dane identyfikacyjne:** imię, nazwisko, PESEL (dla osób prowadzących JDG), email, numer telefonu
2. **Dane identyfikacyjne przedsiębiorstwa:** NIP, REGON, nazwa firmy, adres siedziby
3. **Dane bankowe:** numer rachunku bankowego, informacje do autoryzacji w KSeF
4. **Dane kontaktowe:** adresy email, numery telefonów
5. **Dane z KSeF:** Numery PESEL/NIP kontrahentów, nazwy firm, dane dostępu do systemu
6. **Dane techniczne:** Adresy IP, informacje o przeglądarce, pliki cookies, dane analityczne
7. **Historia transakcji:** Data, kwota, opis przeprowadzonej operacji

---

## 4. ODBIORCY DANYCH OSOBOWYCH (PODMIOTY PRZETWARZAJĄCE)

Dane osobowe mogą być udostępnianie następującym podmiotom trzecim, pełniącym rolę procesorów (podmiotów przetwarzających):

| Nazwa Podmiotu | Funkcja | Lokalizacja | Transfer Danych | Status RODO |
|---|---|---|---|---|
| **Neon Inc.** | Hosting bazy danych PostgreSQL | Ukraina/UE | Transfer do UE na SCC | Procesor |
| **Google Cloud Platform** | Hosting aplikacji Cloud Run | USA (eu-region możliwe) | DPF / SCC (TIA) | Procesor |
| **Netlify Inc.** | Hosting strony www | USA | SCC / DPF | Procesor |
| **Stripe Payments Europe Ltd.** | Obsługa płatności | Irlandia/Luksemburg | Brak transferu poza UE | Procesor |
| **Twilio SendGrid** | Wysyłka emaili | USA | DPF / SCC (TIA) | Procesor |
| **Google Analytics** | Analityka ruchu (opcjonalnie) | USA | DPF / SCC (TIA) | Procesor |

**Umowy Powierzenia:** Wszystkie podmioty przetwarzające są związane formalną umową powierzenia przetwarzania danych (DPA – Data Processing Agreement) zgodną z art. 28 RODO, zawierającą gwarancje w zakresie ochrony danych i zgodności z RODO.

**Transfery do USA:** W celu transferu danych do Stanów Zjednoczonych stosujemy:
- **EU-US Data Privacy Framework (DPF)** – dla certyfikowanych dostawców (Google, Stripe, Netlify)
- **Standard Contractual Clauses (SCC)** – jako instrument zabezpieczający z obowiązkową Transfer Impact Assessment (TIA)
- Stały monitoring zmian w prawie transferu danych

---

## 5. TWOJE PRAWA W ODNIESIENIU DO DANYCH OSOBOWYCH

Zgodnie z RODO, posiadasz następujące prawa:

### 5.1. Prawo dostępu (Art. 15 RODO)
Masz prawo żądać od Administratora dostępu do Twoich danych osobowych oraz otrzymać kopię tych danych w strukturyzowanym, powszechnie używanym formacie elektronicznym.

**Procedura:** Wyślij wniosek na adres Impact@punchlineroi.com z tytułem „Wniosek o dostęp do danych" oraz dowodem tożsamości. Administrator odpowie w ciągu **30 dni**.

### 5.2. Prawo do sprostowania (Art. 16 RODO)
Masz prawo do sprostowania nieprawidłowych lub niekompletnych danych na Twój wniosek.

### 5.3. Prawo do usunięcia – Prawo do bycia zapomnianym (Art. 17 RODO)
Masz prawo żądać usunięcia Twoich danych w przypadkach, gdy:
- Dane są już niepotrzebne do celów, w których zostały zebrane
- Wycofasz zgodę na przetwarzanie
- Sprzeciwisz się przetwarzaniu na podstawie art. 6 ust. 1 lit. f) RODO
- Przetwarzanie narusza prawo

**Ograniczenia:** Prawo to nie ma zastosowania, gdy dane są wymagane prawem (np. do celów księgowych przez 7 lat).

### 5.4. Prawo do ograniczenia przetwarzania (Art. 18 RODO)
Możesz żądać ograniczenia przetwarzania danych (wstrzymania, ale bez usunięcia) w przypadkach kwestionowania dokładności danych lub sprzeciwu wobec przetwarzania.

### 5.5. Prawo do przenoszenia danych (Art. 20 RODO)
Masz prawo otrzymać swoje dane w strukturyzowanym, powszechnie używanym, czytelnym dla urządzenia formacie oraz prawo do transmisji tych danych innemu administratorowi (w zakresie możliwości technicznej).

### 5.6. Prawo do sprzeciwu (Art. 21 RODO)
Masz prawo sprzeciwić się przetwarzaniu danych na podstawie art. 6 ust. 1 lit. f) RODO (prawnie uzasadniony interes) lub do przetwarzania w celach marketingowych.

### 5.7. Prawo do wyrażenia sprzeciwu automatycznemu podejmowaniu decyzji (Art. 22 RODO)
Masz prawo nie być przedmiotem decyzji opartej wyłącznie na zautomatyzowanym przetwarzaniu, włącznie z profilowaniem.

**Procedura realizacji praw:** Wszelkie żądania realizacji praw należy kierować na adres: **Impact@punchlineroi.com**. Administrator potwierdzi otrzymanie w ciągu 5 dni roboczych i udzieli odpowiedzi w ciągu **30 dni** (możliwe przedłużenie do 60 dni przy licznych żądaniach).

---

## 6. BEZPIECZEŃSTWO DANYCH OSOBOWYCH

Administrator wdraża odpowiednie środki techniczne i organizacyjne do ochrony danych osobowych, zgodnie z art. 32 RODO:

### 6.1. Środki techniczne
- **Szyfrowanie:** AES-256 dla danych w spoczynku; TLS 1.2+ dla danych w transmisji
- **Autoryzacja wielopoziomowa (MFA):** Wymagana dla dostępu do panelu klienta
- **Skanowanie podatności:** Regularne testy penetracyjne i audyty bezpieczeństwa
- **Kopie zapasowe:** Codzienne backupy z przechowywaniem geograficznie zdywersyfikowanym
- **Monitoring:** 24/7 monitoring dostępów i anomalii
- **Izolacja danych:** Dane klientów izolowane w odrębnych bazach danych

### 6.2. Środki organizacyjne
- **Dostęp oparty na zasadzie „need-to-know":** Pracownicy mają dostęp tylko do danych niezbędnych do wykonywania ich funkcji
- **Umowy o poufności:** Wszyscy pracownicy podpisują umowę o ochronie danych
- **Procedury bezpieczeństwa:** Dokumentacja procedur obsługi incydentów, zarządzania dostępu, szkolenia pracowników
- **Incydenty bezpieczeństwa:** Raportowanie incydentów UODO w ciągu **72 godzin** od ich wykrycia
- **Ocena wpływu (DPIA):** Przeprowadzana dla operacji stanowiących wysokie ryzyko

---

## 7. PLIKI COOKIES I TECHNOLOGIE ŚLEDZĄCE

### 7.1. Rodzaje cookies stosowanych
1. **Cookies niezbędne (essential):** Umożliwiające funkcjonowanie strony (autoryzacja, bezpieczeństwo) – **nie wymagają zgody**
2. **Cookies analityczne (analytics):** Do analizy ruchu (Google Analytics) – **wymagają zgody**
3. **Cookies marketingowe:** Do kampanii reklamowych – **wymagają zgody**

### 7.2. Baner cookies
Na stronie umieszczony jest baner informujący o cookies z wyraźnymi opcjami:
- Zaakceptuj wszystkie
- Odrzuć wszystkie
- Dostosuj preferencje

**Zgoda musi być wyrażona aktywnie** – samo kliknięcie „X" nie stanowi zgody.

### 7.3. Prawo do wycofania zgody
Możesz wycofać zgodę na cookies w każdej chwili poprzez zmianę ustawień w sekcji „Preferencje cookies" strony lub usunięcie cookies z przeglądarki.

---

## 8. OKRES PRZECHOWYWANIA DANYCH

| Kategoria Danych | Okres Przechowywania | Podstawa Prawna |
|---|---|---|
| Dane konta użytkownika | Czas trwania umowy + 30 dni | RODO art. 17 |
| Dane do realizacji umowy | Czas trwania umowy + 7 lat | Kodeks cywilny, ustawa VAT |
| Dane do fakturowania | 7 lat od konca roku obrachunkowego | Ustawa o VAT, Kodeks cywilny |
| Logi dostępu / techniczne | 90 dni | RODO art. 32 |
| Dane analityczne (anonimowe) | Nieograniczony | RODO art. 11 |
| Dane z KSeF | 7 lat (wymóg archiwizacji) | Ustawa o KSeF |
| Historia komunikacji (support) | 1 rok | RODO art. 5 ust. 1 lit. e) |

---

## 9. ZMIANY W POLITYCE PRYWATNOŚCI

Administrator zastrzega sobie prawo do aktualizacji niniejszej Polityki w związku ze zmianami przepisów RODO, wymogów technicznych lub zakresu usług. 

**O zmianach Administrator poinformuje:**
- Poprzez publikację nowej wersji na stronie punchlineroi.com
- Poprzez email na adres podany w rejestracji (dla zmian istotnych)
- Z wyprzedzeniem co najmniej 14 dni

Dalsze korzystanie z usługi po opublikowaniu zmian oznacza ich akceptację.

---

## 10. KONTAKT W SPRAWACH OCHRONY DANYCH

W przypadku pytań dotyczących Polityki Prywatności lub ochrony danych osobowych prosimy o kontakt:

- **Email:** Impact@punchlineroi.com
- **Adres:** Rivierdijk 414A, 3372 BV Hardinxveld-Giessendam, Holandia
- **Telefon:** +31 68 4816844
- **Czas odpowiedzi:** 5 dni roboczych

---

## 11. PRAWO DO WNIESIENIA SKARGI DO UODO

Jeśli uważasz, że przetwarzanie Twoich danych narusza Twoją prywatność, masz prawo wnieść skargę do Urzędu Ochrony Danych Osobowych (UODO):

- **Nazwa:** Urząd Ochrony Danych Osobowych
- **Adres:** ul. Stawki 2, 00-193 Warszawa
- **Email:** kancelaria@uodo.gov.pl
- **Telefon:** +48 22 531 03 00
- **Strona:** www.uodo.gov.pl

Prawo do skargi nie wyłącza możliwości dochodzenia roszczeń w drodze sądowej.

---

**Data ostatniej aktualizacji: 8 grudnia 2025**

**Wersja: 1.0 (FINALNA – ZGODNA Z RODO I WYMOGAMI UE 2025)**