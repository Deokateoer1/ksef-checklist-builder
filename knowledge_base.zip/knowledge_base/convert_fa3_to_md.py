import pdfplumber
import re
import os

BASE_DIR = r"D:\Ollama_VScode\knowledge_base\logic"

INPUTS = [
    ("fa_3_brochure.pdf", "fa_3_brochure.md"),
]

def clean_text(text: str) -> str:
    text = re.sub(r"\n\s*\d+\s*\n", "\n", text)
    return text.strip()

for pdf_name, md_name in INPUTS:
    pdf_path = os.path.join(BASE_DIR, pdf_name)
    md_path = os.path.join(BASE_DIR, md_name)

    print(f"[INFO] Przetwarzam: {pdf_path}")
    if not os.path.exists(pdf_path):
        print(f"[ERROR] Brak pliku: {pdf_path}")
        continue

    with pdfplumber.open(pdf_path) as pdf:
        chunks = []
        for page in pdf.pages:
            t = page.extract_text()
            if t:
                chunks.append(clean_text(t))

    with open(md_path, "w", encoding="utf-8") as f:
        f.write("\n\n---\n\n".join(chunks))

    print("[OK] ->", md_path)
