Podręcznik
KSeF 2.0
Cz. I
Rozpoczęcie korzystania z KSeF
Stan prawny na dzień: 1 lutego 2026 r.
Warszawa, wrzesień 2025 r.
1

---

Spis treści
Słownik pojęć ............................................................................................................................................................. 4
Wstęp ............................................................................................................................................................................ 5
1. Podstawowe informacje na temat KSeF ...................................................................................................... 8
1.1. Co to jest i do czego służy KSeF? ............................................................................................................ 8
1.2. Jak sprawnie przygotować się do KSeF? ............................................................................................11
2. Uwierzytelnienie w KSeF ................................................................................................................................24
2.1. Podpis Zaufany i Węzeł krajowy (login.gov) .....................................................................................29
2.2. Kwalifikowany podpis elektroniczny ..................................................................................................30
2.3. Kwalifikowana pieczęć elektroniczna .................................................................................................32
2.4. Token ..............................................................................................................................................................33
2.4.1. Co to jest token i do czego służy? .................................................................................................33
2.4.2. Okres ważności tokena ....................................................................................................................34
2.4.3. Kto może wygenerować token? ....................................................................................................34
2.4.4. Zasady bezpieczeństwa przy posługiwaniu się tokenem ....................................................36
2.4.5. Ile tokenów może być wygenerowanych? .................................................................................36
2.4.6. Uzyskanie tokena w Aplikacji Podatnika KSeF lub w aplikacjach komercyjnych ........36
2.4.7. Token a zmiana zakresu uprawnień ............................................................................................37
2.4.8. Działania na tokenach ......................................................................................................................39
2.5. Certyfikat KSeF ..........................................................................................................................................40
2.5.1. Co to jest i do czego będzie służył certyfikat KSeF? ..............................................................40
2.5.2. Uzyskanie certyfikatu KSeF w Module Certyfikatów i Uprawnień ..................................41
2.5.3. Okres ważności certyfikatu KSeF ................................................................................................42
2.5.4. Certyfikat dla osoby fizycznej lub podmiotu ............................................................................44
2.5.5. Bezpieczeństwo posługiwania się certyfikatami KSeF .........................................................44
2.5.6. Limity dotyczące certyfikatów KSeF ..........................................................................................45
2.5.7. Certyfikat KSeF a zakres uprawnień ...........................................................................................48
2.5.8. Działania na certyfikatach KSeF ..................................................................................................49
2

---

2.5.9. Certyfikaty KSeF a tokeny ..............................................................................................................50
3. Uprawnienia do korzystania z KSeF ............................................................................................................51
3.1. Rodzaje uprawnień do korzystania z KSeF .......................................................................................51
3.2. Nadawanie uprawnień do korzystania z KSeF? ...............................................................................55
3.2.1. Podatnicy będący osobami fizycznymi .......................................................................................55
3.2.2. Podatnicy niebędący osobami fizycznymi .................................................................................56
3.2.3. Zawiadomienie ZAW-FA.................................................................................................................57
3.3. Modele uprawnień w KSeF .....................................................................................................................69
3.3.1. Standardowy model uprawnień ....................................................................................................69
3.3.2. Model uprawnień wykorzystujący identyfikator wewnętrzny jednostki ......................77
3.3.3. Uprawnienia dedykowane JST ......................................................................................................89
3.3.4. Uprawnienia dedykowane GV.......................................................................................................89
3.3.5. Modele uprawnień dedykowane komornikowi sądowemu oraz organowi
egzekucyjnemu ...............................................................................................................................................89
3.3.6. Model uprawnień dedykowany przedstawicielowi podatkowemu..................................90
3.3.7. Model uprawnień umożliwiający wystawianie faktur VAT RR oraz faktur VAT RR
KOREKTA.........................................................................................................................................................90
Spis grafik ..................................................................................................................................................................91
Spis przykładów ......................................................................................................................................................92
Spis schematów .......................................................................................................................................................94
Spis tabel ....................................................................................................................................................................95
3

---

Słownik pojęć
Ilekroć w poniższym dokumencie jest mowa o:
a) API KSeF – rozumie się przez to Interfejs Programowania Aplikacji systemu KSeF (ang.
Application Programming Interface).
b) API KSeF 2.0 – rozumie się przez to API KSeF w wersji, która zostanie wdrożona na
środowisku produkcyjnym z dniem 1 lutego 2026 r.
c) BIP MF – rozumie się przez to Biuletyn Informacji Publicznej Ministra Finansów.
d) GV – rozumie się przez to grupę VAT, o której mowa w art. 15a ustawy z dnia 11 marca
2004 r. o podatku od towarów i usług (Dz. U. z 2025 r. poz. 775 ze zm.).
e) JST – rozumie się przez to jednostkę samorządu terytorialnego.
f) KSeF - rozumie się przez to Krajowy System e-Faktur, o którym mowa w art. 106nd ust. 2
ustawy z dnia 11 marca 2004 r. o podatku od towarów i usług (Dz. U. z 2025 r. poz. 775 ze
zm.).
g) MF – rozumie się przez to h) MPP – rozumie się przez to mechanizm podzielonej płatności, o którym mowa w art. 108a
ustawy z dnia 11 marca 2004 r. o podatku od towarów i usług (Dz. U. z 2025 r. poz. 775 ze
zm.).
i) PEF – rozumie się przez to Platformę Elektronicznego Fakturowania, o której mowa w
ustawie z dnia 9 listopada 2018 r. o elektronicznym fakturowaniu w zamówieniach
publicznych, koncesjach na roboty budowlane lub usługi oraz partnerstwie publiczno-
prywatnym (Dz.U. z 2020 r. poz. 1666 ze zm.).
j) Rozporządzeniu w sprawie korzystania z KSeF – rozumie się przez to projekt
rozporządzenia Ministra Finansów i Gospodarki w sprawie korzystania z Krajowego
System e-Faktur 1.
k) Rozporządzeniu w sprawie wyłączeń z KSeF – rozumie się przez to projekt rozporządzenia
Ministra Finansów i Gospodarki w sprawie przypadków, w których nie ma obowiązku
wystawiania faktur ustrukturyzowanych2.
1 Proces legislacyjny w toku: https://legislacja.rcl.gov.pl/projekt/12379252.
2 Proces legislacyjny w toku: https://legislacja.rcl.gov.pl/projekt/12376354.
4

---

l) Systemie – rozumie się przez to Krajowy System e-Faktur, o którym mowa w art. 106nd
ust. 2 ustawy z dnia 11 marca 2004 r. o podatku od towarów i usług (Dz. U. z 2025 r. poz.
775 ze zm.).
m) Ustawie - rozumie się przez to ustawę z dnia 11 marca 2004 r. o podatku od towarów i
usług (Dz. U. z 2025 r. poz. 775 ze zm.).
n) Ustawie OP – rozumie się przez to ustawę z dnia 29 sierpnia 1997 r. Ordynacja Podatkowa
(Dz. U. z 2025 r. poz. 111 ze zm.).
Wstęp
KSeF to platforma służąca w szczególności do wystawiania, przesyłania, otrzymywania i
przechowywania faktur ustrukturyzowanych. Już od 1 lutego 2026 r. wystawianie faktur w tym
systemie stanie się obowiązkowe dla podatników, którzy w 2024 r. osiągnęli wartość sprzedaży
powyżej 200 mln zł, a od 1 kwietnia 2026 r. obowiązek ten obejmie pozostałych podatników.
Od 1 lutego 2026 r. wszyscy podatnicy będą również zobowiązani do odbierania faktur przy
użyciu KSeF3.
Wdrożenie obowiązkowego KSeF w Polsce stanowi istotny krok w rozwoju cyfryzacji.
Znacząco zmienia bowiem rozumienie pojęcia „wystawienie faktury”. Dotychczas faktura
utożsamiana była zwykle z dokumentem fizycznym (papierowym) lub plikiem pdf wysyłanym
kontrahentowi za pośrednictwem skrzynki elektronicznej. Wraz z wejściem obowiązkowego
KSeF, fakturą będzie określony zestaw danych cyfrowych. W KSeF stosowany jest jednolity,
ustrukturyzowany wzór faktury. Każda pozycja faktury ma w nim swoje określone miejsce,
dzięki czemu rozumienie jej zapisów po stronie sprzedawcy jak i nabywcy zawsze będzie
spójne. Plik XML przesłany do KSeF przez sprzedawcę, po jego przetworzeniu w systemie i
nadaniu numeru KSeF stanie się pełnoprawną fakturą, którą w systemie otrzyma nabywca.
Dokumentów nie trzeba będzie drukować ani ręcznie wprowadzać do systemów. Zredukowana
zostanie tym samym liczba pomyłek, która miała miejsce podczas wpisywania danych do
programów finansowo-księgowych. Brak konieczności przenoszenia danych z faktur do
systemów to także realna oszczędność czasu w wypełnianiu obowiązków związanych z
prowadzeniem ewidencji podatkowych.
3 W przypadkach określonych w art. 106gb ust. 4 ustawy fakturę należy przekazać nabywcy w sposób z
nim uzgodniony (np. gdy nabywcą będzie podatnik nieposiadający w Polsce siedziby ani stałego miejsca
prowadzenia działalności gospodarczej lub konsument).
5

---

Dzięki wdrożeniu KSeF nastąpi zwiększenie szybkości wymiany danych w kontaktach między
kontrahentami – wystawiona faktura będzie udostępniona odbiorcy praktycznie w czasie
rzeczywistym. Warto również zaznaczyć, że w KSeF faktura będzie przechowywana przez
okres 10 lat od końca roku, w którym została wystawiona. Nie ma możliwości, aby faktura
wystawiona w KSeF zaginęła, zatem nie będzie konieczne, tak jak ma to miejsce obecnie,
wystawianie duplikatów faktur. W każdej bowiem chwili sprzedawca lub nabywca będzie mógł
uwierzytelnić się w systemie i pobrać daną fakturę. Działanie danej osoby lub podmiotu w KSeF
wymaga uwierzytelnienia w systemie oraz posiadania odpowiednich uprawnień. Wpłynie to
pozytywnie na zwiększenie pewności obrotu gospodarczego. Nabywca będzie miał bowiem
gwarancję, że faktura została wystawiona przez podmiot uprawniony.
Powszechne e-fakturowanie to jednak nie tylko korzyści o charakterze biznesowym. KSeF
niesie za sobą również pozytywne zmiany w obszarze podatkowym. W szczególności warto
zwrócić uwagę na skrócenie podstawowego terminu zwrotu VAT z 60 na 40 dni. Dostęp do
faktur podatnika przez administrację (w uzasadnionych okolicznościach) pozwoli usprawnić i
przyspieszyć proces weryfikacji zasadności zwrotów VAT w urzędach skarbowych. Zmniejszy
się liczba czynności sprawdzających oraz kontroli prowadzonych przez administrację
skarbową. Obowiązki podatkowe oraz sprawozdawcze zostaną znacząco uproszczone, na
przykład w obszarze rozliczania faktur korygujących (z uwagi na brak konieczności posiadania
dokumentacji potwierdzającej uzgodnienie z nabywcą obniżenia podstawy opodatkowania) czy
braku obowiązku składania plików JPK_FA na żądanie organów podatkowych w odniesieniu do
faktur znajdujących się w KSeF.
Sprawne wdrożenie KSeF to wyzwanie zarówno dla przedsiębiorców, biur rachunkowych,
dostawców programów finansowo-księgowych jak i dla administracji. Odpowiadając na
potrzeby rynku wynikające z konieczności przygotowania się do obowiązkowego e-
fakturowania, MF udostępnia Podręcznik KSeF 2.0 stanowiący kompendium wiedzy i zestaw
praktycznych informacji na temat KSeF.
Podręcznik KSeF 2.0 składa się z czterech części. W ramach:
• I części – omówione zostały podstawowe informacje na temat systemu, kluczowe daty
związane z wdrożeniem KSeF, kroki jakie należy podjąć w celu skutecznego wdrożenia
KSeF w firmie, metody uwierzytelnienia w systemie oraz szczegółowe wyjaśnienia
dotyczące istniejącego w KSeF modelu uprawnień;
• II części – zaprezentowane zostały kluczowe funkcjonalności KSeF dotyczące procesu
wystawiania, otrzymywania e-Faktur oraz dostępu do nich, kroki jakie należy podjąć,
aby fakturze został nadany numer KSeF, zalecenia dotyczące prawidłowego
6

---

wypełniania struktury FA(3) oraz aspekty techniczne związane z wysyłką faktur do
KSeF 2.0;
• III części – omówione zostały dodatkowe funkcjonalności systemu tj. wystawianie i
przesyłanie do KSeF faktur z załącznikiem, przesyłanie do KSeF faktur w trybie
OFFLINE, zasady wystawiania faktur VAT RR w systemie, procedura
samofakturowania, generowanie zbiorczego identyfikatora oraz zgłaszanie faktur
scamowych;
• IV części – przedstawione zostały zagadnienia związane wystawianiem i
otrzymywaniem faktur w JST i GV, wystawianiem faktur w ramach egzekucji oraz
faktur w zamówieniach publicznych.
Dodatkowo, stawiając na pierwszym miejscu zapewnienie odpowiedniego poziomu dostępu do
informacji na temat KSeF, MF stale rozwija treści dotyczące KSeF 2.0 zawarte na stronie
ksef.podatki.gov.pl. Dostępna jest także broszura informacyjna dotycząca struktury logicznej
FA(3).
Od 1 stycznia 2025 r. funkcjonuje dedykowana infolinia KAS, w ramach której można uzyskać
szybką pomoc w razie pojawienia się wątpliwości merytorycznych lub technicznych w zakresie
KSeF. Konsultanci infolinii udzielają informacji telefonicznej oraz odpowiadają na pytania
zadane poprzez formularz kontaktowy. Dostępna jest również opcja chat. Więcej informacji
dostępnych jest na stronie: Infolinia KAS do spraw KSeF. MF zachęca do korzystania z usług
infolinii.
7

---

1. Podstawowe informacje na temat KSeF
1.1. Co to jest i do czego służy KSeF?
WAŻNE
KSeF jest systemem teleinformatycznym prowadzonym przez Szefa KAS, który jest
jednocześnie administratorem danych w nim zawartych.
KSeF to platforma posiadająca wiele funkcjonalności4. Można je podzielić na kilka grup.
I grupę stanowią funkcjonalności związane z uwierzytelnieniem oraz uprawnieniami do
korzystania z KSeF.
Zalicza się do nich w szczególności:
• nadawanie uprawnień (podatnik może wyznaczyć osobę fizyczną lub podmiot, który
będzie w jego imieniu np. wystawiał faktury),
• odbieranie uprawnień (podatnik może odebrać uprawnienie np. do wystawiania faktur
osobie fizycznej lub podmiotowi, któremu wcześniej to uprawnienie nadał),
• weryfikację uprawnień (system weryfikuje czy osoba, która pracuje w systemie np.
przesyła plik XML e-Faktury do KSeF, posiada uprawnienie do wystawiania faktur w
imieniu danego podatnika),
• uwierzytelnienie w systemie (to potwierdzenie tożsamości danej osoby fizycznej lub
podmiotu w KSeF np. za pomocą kwalifikowanego podpisu elektronicznego lub
certyfikatu KSeF),
• powiadamianie podmiotów korzystających z KSeF o:
o nadaniu uprawnień do korzystania z KSeF,
o odebraniu uprawnień do korzystania z KSeF,
W przypadku złożenia zawiadomienia ZAW-FA przez podatnika niebędącego osobą
fizyczną np. przez spółkę, w celu nadania lub odebrania uprawnień do korzystania z
KSeF osobie fizycznej, wysyłana jest wiadomość na adres e-mail podatnika i osoby
fizycznej, wskazany w treści zawiadomienia, potwierdzająca nadanie lub odebranie
uprawnień.
• informowanie o braku uprawnień do korzystania z KSeF (brak uprawnienia np. do
wystawiania faktur jest przesłanką odrzucenia pliku XML przez KSeF).
4 Funkcjonalności KSeF określa art. 106nd ust. 2-4 ustawy.
8

---

II grupę stanowią funkcjonalności związane z obsługą e-Faktur.
Zalicza się do nich w szczególności:
• wystawianie faktur ustrukturyzowanych,
WAŻNE
Warunkiem niezbędnym do korzystania z KSeF przez podatnika jest posiadanie
identyfikatora podatkowego NIP.
• oznaczanie faktur ustrukturyzowanych numerem identyfikującym, przydzielonym w
KSeF (przesłanka niezbędna dla uznania, że dany dokument stanowi fakturę
ustrukturyzowaną i został przyjęty w systemie),
• informowanie podmiotów korzystających z KSeF o numerze identyfikującym fakturę
ustrukturyzowaną przydzielonym w KSeF oraz dacie i czasie jego przydzielenia
(informacja istotna między innymi z punktu widzenia nabywcy, gdyż data przydzielenia
numeru KSeF, to co do zasady data otrzymania e-Faktury),
• informowanie podmiotów korzystających z KSeF o:
o dacie i czasie wystawienia faktury ustrukturyzowanej,
o dacie i czasie odrzucenia faktury w przypadku jej niezgodności ze wzorem
faktury ustrukturyzowanej (niezgodność ze wzorem jest przesłanką odrzucenia
pliku przez KSeF),
o braku możliwości wystawienia faktury ustrukturyzowanej - w przypadku
niedostępności lub awarii KSeF,
• otrzymywanie faktur ustrukturyzowanych (po przesłaniu przez sprzedawcę pliku XML
do KSeF i nadaniu fakturze numeru KSeF, otrzyma ją w systemie m.in. nabywca, którego
identyfikator podatkowy NIP został wskazany w tej fakturze),
• dostęp do faktur ustrukturyzowanych (podatnik oraz osoby i podmioty przez niego
uprawnione posiadają m.in. dostęp do faktur sprzedażowych, zakupowych oraz faktur,
w których występuje jako podmiot trzeci lub podmiot upoważniony),
• przechowywanie faktur ustrukturyzowanych (faktury będą przechowywane w KSeF
przez 10 lat, licząc od końca roku, w którym zostały wystawione).
9

---

III grupę stanowią dodatkowe funkcjonalności KSeF.
Zalicza się do nich w szczególności:
• przyjmowanie faktur wystawionych w trybach OFFLINE, o których mowa w art. 106nda
ust. 1 ustawy (tryb offline24), art. 106nf ust. 1 ustawy (tryb awaryjny) i art. 106nh ust. 1
ustawy (tryb offline – niedostępność KSeF),
• wystawianie faktur VAT RR i faktur VAT RR KOREKTA przy użyciu KSeF,
przyjmowanie faktur VAT RR i faktur VAT RR KOREKTA wystawionych w trybie
offline24 oraz odpowiednio m.in. ich otrzymywanie, przechowywanie, oznaczanie
numerem KSeF,
• weryfikację danych z faktur ustrukturyzowanych używanych poza KSeF (w przypadku
faktur wystawianych np. na rzecz podatników nieposiadających siedziby i stałego
miejsca prowadzenia działalności gospodarczej w Polsce, faktura będzie wystawiana w
KSeF, ale dodatkowo powinna być udostępniona nabywcy w sposób z nim uzgodniony
(np. przekazana w postaci papierowej), oraz powinna być opatrzona kodem QR, który
umożliwi nabywcy weryfikację czy dokument został wprowadzony do KSeF oraz czy
dane wynikające z faktury otrzymanej poza KSeF są zbieżne z danymi przesłanymi do
systemu przez sprzedawcę),
• analizę i kontrolę prawidłowości danych z faktur ustrukturyzowanych (w
uzasadnionych przypadkach pracownicy administracji skarbowej będą mogli uzyskać
dostęp do e-Faktur w celu zweryfikowania poprawności wystawianych/otrzymanych
przez podatników dokumentów; będzie to jednak poprzedzone złożeniem wniosku o
dostęp przez uprawnionego pracownika oraz akceptacją przełożonego wraz z
podaniem celu dostępu; dostęp do danych nastąpi w szczególności w toku czynności
kontrolnych, sprawdzających, w trakcie postępowania podatkowego oraz w celu
prowadzenia działalności analitycznej KAS),
• przydzielanie identyfikatora zbiorczego dla co najmniej dwóch faktur
ustrukturyzowanych wystawianych przez podatnika (identyfikator zbiorczy będzie
wykorzystywany np. podczas jednej płatności za kilka faktur ustrukturyzowanych,
dokonywanej pomiędzy podatnikami VAT czynnymi).
Szczegóły dotyczące poszczególnych funkcjonalności systemu, zostaną przedstawione bliżej w
dalszych częściach Podręcznika KSeF 2.0.
10

---

1.2. Jak sprawnie przygotować się do KSeF?
Proces wdrożenia KSeF w firmie ma charakter wieloetapowy i należy podejść do niego z kilku
stron. Istotne będzie tu zarówno zdobycie wiedzy merytorycznej, aby mieć świadomość
nadchodzących zmian prawnych, jak również przygotowanie się od strony technicznej,
związanej z korzystaniem z odpowiedniego oprogramowania finansowo-księgowego.
Wszystko to wpłynie na funkcjonujące obecnie wewnętrzne procesy biznesowe związane z
wystawianiem i otrzymywaniem faktur, jak również procesy zewnętrzne odnoszące się w
szczególności do współpracy z kontrahentami.
Zaplanowanie z odpowiednim wyprzedzeniem działań związanych z wdrożeniem
obligatoryjnego KSeF pozwoli przedsiębiorcom przygotować się do tego procesu kompleksowo
i sprawnie wejść w realizację nowego obowiązku.
WAŻNE
W procesie przygotowań do obowiązkowego KSeF należy wyróżnić kilka kluczowych obszarów
i działań, które należy wykonać:
KROK 1. Zapoznanie się z przepisami. Sprawdzenie terminu obowiązkowego KSeF.
KROK 2. Weryfikacja i dostosowanie procesów wewnętrznych związanych z wystawianiem i
otrzymywaniem faktur w firmie.
KROK 3. Wybór narzędzia do wystawiania faktur, które zapewni obsługę faktur w KSeF.
KROK 4. Podjęcie decyzji co do sposobu uwierzytelnienia się w KSeF.
KROK 5. Wyznaczenie osób, które będą upoważnione do wystawiania i dostępu do faktur w
imieniu podatnika. Nadanie im odpowiednich uprawnień w systemie.
KROK 6. Zabezpieczenie się na wypadek nieprzewidzianych sytuacji – zapoznanie się z trybami
OFFLINE i pobór certyfikatu KSeF.
KROK 7. Testowanie KSeF 2.0.
KROK 8. Śledzenie na bieżąco strony MF i KSeF. Przekazanie niezbędnych informacji swoim
pracownikom.
Poniżej znajduje się szczegółowy opis zagadnień, składających się na każdy z wymienionych
kroków. Sposób działań podatnika lub kolejność wykonywanych działań może oczywiście
różnić się nieznacznie od specyfiki działalności podatnika czy obecnego sposobu wystawiania
faktur w firmie. Inaczej przygotowania będą wyglądały bowiem u podatnika, który wystawia
11

---

aktualnie faktury papierowo, inaczej u podatnika, który już dziś korzysta z dostępnego na rynku
programu finansowo-księgowego, a inaczej u podatnika, który korzysta z KSeF w modelu
fakultatywnym.
KROK 1 Zapoznanie się z przepisami. Sprawdzenie terminu
obowiązkowego KSeF.
Kluczowe w tym obszarze będzie zapoznanie się przez przedsiębiorcę z terminami wdrożenia
oraz zakresem obowiązkowego KSeF. Konieczne będzie sprawdzenie katalogu wyłączeń z
obowiązku wystawiania w KSeF faktur dokumentujących niektóre transakcje.
Podstawą funkcjonowania obowiązkowego KSeF są:
• Ustawa z dnia 16 czerwca 2023 r. o zmianie ustawy o podatku od towarów i usług oraz
niektórych innych ustaw (Dz. U. z 2023 r. poz. 1598 ze zm.) zwana dalej „ustawą KSeF”,
• Ustawa z dnia 9 maja 2024 r. zmieniająca ustawę o zmianie ustawy o podatku od
towarów i usług oraz niektórych innych ustaw (Dz. U. z 2024 r. poz. 852),
• Ustawa z dnia 5 sierpnia 2025 r. o zmianie ustawy o podatku od towarów i usług oraz
ustawy o zmianie ustawy o podatku od towarów i usług oraz niektórych innych ustaw
(Dz. U. z 2025 r. poz. 1203) zwana dalej „ustawą KSeF2”.
Terminy obowiązkowego KSeF
Od 1 stycznia 2022 r. KSeF został wdrożony jako rozwiązanie dobrowolne. Od tego momentu
podatnicy mieli możliwość wystawiania faktur ustrukturyzowanych w ramach tego systemu.
Od 1 lutego 2026 r. wystawianie faktur w KSeF stanie się obowiązkowe dla podatników,
których wartość sprzedaży (wraz z kwotą podatku) przekroczyła w 2024 r. 200 mln zł, a od 1
kwietnia 2026 r. dla pozostałych podatników5.
Dodatkowo, do końca 2026 r. obowiązek wystawiania faktur w KSeF nie będzie dotyczył
podatników, u których łączna wartość sprzedaży (wraz z podatkiem) udokumentowana
fakturami elektronicznymi lub fakturami w postaci papierowej, wystawionymi w danym
miesiącu będzie mniejsza lub równa 10 000 zł. Jeśli natomiast nastąpiłoby przekroczenie limitu
5 Art. 145l ustawy wchodzący w życie z dniem 1 lutego 2026 r., dodawany ustawą KSeF2.
12

---

10 000 zł – wówczas obowiązek wystawiania faktur w KSeF wystąpi począwszy od faktury
którą przekroczono limit 10 000 zł6.
Powyższe odroczenia będą dotyczyć obowiązku wystawiania, a nie otrzymywania faktur w
KSeF. Od 1 lutego 2026 r. co do zasady wszyscy podatnicy będą odbierali faktury przy użyciu
KSeF.
Szczegółowy harmonogram wdrożenia KSeF przedstawia poniższa tabela.
Tabela 1. Harmonogram wdrożenia KSeF.
DATA WYDARZENIE
Wdrożenie wersji fakultatywnej systemu (KSeF 1.0).
1 stycznia 2022 r.
Publikacja struktury logicznej FA(3) na ePUAP.
25 czerwca 2025 r.
Publikacja dokumentacji technicznej dla API KSeF 2.0.
30 czerwca 2025 r.
Udostępnienie środowiska testowego API KSeF 2.0.
30 września 2025 r.
Możliwość pobierania certyfikatów KSeF7.
Od 1 listopada 2025 r.
Udostępnienie wersji testowej Aplikacji Podatnika KSeF 2.0.
3 listopada 2025 r.
Możliwość składania zgłoszenia o zamiarze wystawiania i
przesyłania do KSeF faktur z załącznikiem w e-Urzędzie
Od 1 stycznia 2026 r.
Skarbowym8.
Wdrożenie wersji obligatoryjnej systemu (KSeF 2.0).
Wystawianie faktur w KSeF obowiązkowe dla podatników,
którzy przekroczyli w 2024 r. wartość sprzedaży 200 mln zł.
Od 1 lutego 2026 r. Obowiązkowe otrzymywanie faktur w KSeF dla wszystkich
podatników (z wyjątkiem podmiotów, którzy otrzymują faktury
w sposób uzgodniony).
Obowiązywanie struktury logicznej FA(3).
6 Art. 145m ustawy wchodzący w życie z dniem 1 lutego 2026 r., dodawany ustawą KSeF2.
7 Art. 17b ustawy KSeF, dodawany ustawą KSeF2.
8 Art. 17a ustawy KSeF, dodawany ustawą KSeF2.
13

---

Możliwość wystawiania i przesyłania do KSeF faktur z
załącznikiem (po uprzednim zgłoszeniu tego zamiaru w e-
Urzędzie Skarbowym)9.
Możliwość wykorzystywania certyfikatów KSeF do
uwierzytelniania w systemie (certyfikat typu 1) oraz do
wystawiania faktur w trybie OFFLINE (certyfikat typu 2).
Wystawianie faktur w KSeF obowiązkowe dla podatników, u
których wartość sprzedaży w 2024 r. była równa lub niższa 200
mln zł.
Od 1 kwietnia 2026 r.
Możliwość wystawiania faktur VAT RR i faktur VAT RR
KOREKTA w KSeF10.
Możliwość wystawiania faktur elektronicznych lub faktur w
postaci papierowej przez podatników obowiązanych do
wystawiania faktur ustrukturyzowanych, jeżeli łączna wartość
sprzedaży wraz z kwotą podatku u tych podatników
udokumentowana tymi fakturami wystawionymi w danym
miesiącu jest mniejsza lub równa 10 000 zł.
Do 31 grudnia 2026 r.
Wyłączenie z obowiązku wystawiania w KSeF:
a) faktur wystawianych przy zastosowaniu kas rejestrujących,
b) paragonów fiskalnych uznanych za faktury wystawione zgodnie
z art. 106e ust. 5 pkt 3 ustawy11.
Brak możliwości wystawiania faktur przy użyciu kas
rejestrujących i uznawania za faktury uproszczone paragonów
fiskalnych z NIP nabywcy.
Obowiązek podawania numeru KSeF/ zbiorczego identyfikatora
podczas dokonywania płatności pomiędzy podatnikami VAT
Od 1 stycznia 2027 r.
czynnymi oraz w przelewach realizowanych w ramach
mechanizmu podzielonej płatności12.
Możliwe stosowanie sankcji za niedopełnienie obowiązków
KSeF13.
9 Art. 106gba ust. 1 ustawy wchodzący w życie z dniem 1 lutego 2026 r., dodawany ustawą KSeF2.
10 Art. 17c ustawy KSeF, dodawany ustawą KSeF2.
11 Art. 145n ustawy wchodzący w życie z dniem 1 lutego 2026 r., dodawany ustawą KSeF2.
12 Art. 17 ustawy KSeF w brzmieniu nadanym ustawą KSeF2.
13 Art. 23 pkt 4 ustawy KSeF w brzmieniu nadanym ustawą KSeF2.
14

---

Wyłączenia z obowiązkowego KSeF
KSeF z założenia będzie powszechnym systemem e-fakturowania. Obowiązek wystawiania
faktur w KSeF będzie dotyczył docelowo wszystkich podatników (czynnych i zwolnionych),
którzy zobowiązani do wystawiania faktur na podstawie polskich przepisów.
Istnieje jednak katalog wyłączeń z obowiązku wystawiania faktur w tym systemie, które
wynikają ze specyfiki danej transakcji, statusu sprzedawcy lub statusu nabywcy14.
Pierwsza grupa wyłączeń z obowiązku wystawiania faktur w KSeF wynika ze statusu stron
transakcji. Wyłączeniem objęte będzie wystawianie faktur:
• przez podatników, którzy nie posiadają siedziby działalności gospodarczej ani stałego
miejsca prowadzenia działalności gospodarczej na terytorium Polski,
• przez podatników, którzy nie posiadają siedziby działalności gospodarczej na
terytorium kraju, ale posiadają stałe miejsce prowadzenia działalności gospodarczej na
terytorium Polski, przy czym to stałe miejsce prowadzenia działalności nie uczestniczy
w dostawie towarów lub świadczeniu usług, dla których wystawiono fakturę,
• na rzecz osoby fizycznej nieprowadzącej działalności gospodarczej (konsumenta).
WAŻNE
Pomimo braku obowiązku, podatnicy będą mogli wystawiać wyżej wymienione faktury
dobrowolnie w KSeF.
Drugą grupę stanowią wyłączenia dotyczące konkretnych rodzajów transakcji. Są to przypadki
wystawiania faktur przez podatników korzystających z następujących procedur szczególnych
tj.
• procedura OSS nieunijna15,
• procedura importu IOSS16,
• procedura świadczenia usług międzynarodowego okazjonalnego przewozu drogowego
osób17.
14 Art. 106ga ust. 2 ustawy wchodzący w życie z dniem 1 lutego 2026 r.
15 Procedura szczególna, o której mowa w dziale XII w rozdziale 7 ustawy.
16 Procedura szczególna, o której mowa w dziale XII w rozdziale 9 ustawy.
17 Procedura szczególna, o której mowa w dziale XII w rozdziale 7a ustawy.
15

---

Przyczyną wyłączenia ww. transakcji z obligatoryjnego KSeF są względy techniczne, w tym
fakt, że podatnicy na cele ww. procedur posługują się innymi numerami identyfikacyjnymi niż
standardowy identyfikator podatkowy NIP.
WAŻNE
W powyższych przypadkach nie jest możliwe dobrowolne wystawianie faktur
dokumentujących ww. czynności w KSeF.
Trzecią grupę wyłączeń z KSeF stanowią czynności wymienione w rozporządzeniu w sprawie
wyłączeń z KSeF18. Należy do nich w szczególności:
• świadczenie usług przejazdu autostradą płatną, udokumentowanych fakturami w
formie biletu jednorazowego,
• świadczenie usług przewozu osób na dowolną odległość m.in. kolejami, taborem
samochodowym, statkami pełnomorskimi, środkami transportu żeglugi śródlądowej i
przybrzeżnej, promami, samolotami i śmigłowcami, udokumentowanych fakturami w
formie biletu jednorazowego,
• świadczenie usług zwolnionych na podstawie art. 43 ust. 1 pkt 7, 37–41 ustawy o
podatku od towarów i usług, udokumentowanych fakturami lub innymi dowodami,
• dostawa towarów i świadczenie usług udokumentowanych fakturami wystawianymi
przez nabywcę w ramach procedury samofakturowania jeżeli:
• nabywca nie jest zidentyfikowany na potrzeby danej czynności za pomocą
polskiego NIP,
• sprzedawca nie jest zidentyfikowany na potrzeby danej czynności za pomocą
polskiego NIP.
WAŻNE
W przypadku wewnątrzwspólnotowej dostawy towarów, nabywca zidentyfikowany na
potrzeby danej czynności za pomocą numeru VAT UE nadanego w innym kraju unijnym niż
Polska, będzie mógł dobrowolnie wystawić fakturę ustrukturyzowaną w ramach
samofakturowania.
Weryfikacja zakresu obowiązkowego KSeF jest potrzebna między innymi w celu określenia, czy
wszystkie faktury wystawiane przez podatnika będą musiały być wystawiane w tym systemie.
Jeśli bowiem wystąpią transakcje wyłączone z obowiązkowego KSeF, które nie będą mogły być
18 Proces legislacyjny w toku: https://legislacja.rcl.gov.pl/projekt/12376354.
16

---

fakturowane w systemie (nawet dobrowolnie), wówczas należy zapewnić równoległe procesy
wystawiania faktur zarówno w KSeF (tam, gdzie wystąpi obowiązek) oraz poza KSeF (tam,
gdzie wystąpi wyłączenie bezwarunkowe).
Weryfikacja i dostosowanie procesów wewnętrznych
KROK 2
związanych z wystawianiem i otrzymywaniem faktur w
firmie.
W ramach realizacji kolejnego etapu działań związanych z wdrożeniem KSeF, należy
przeprowadzić audyt obowiązujących w danej firmie procesów wewnętrznych, dotyczących
wystawiania i otrzymywania faktur. Można zrobić to samodzielnie lub wyznaczyć osobę bądź
zespół osób, który będzie nadzorował przygotowania do KSeF w firmie.
Należy sprawdzić zatem:
• Jakiego rodzaju faktury są wystawiane? Jakie specyficzne dane są zawierane na
fakturach i czy mają one swoje odpowiedniki w strukturze logicznej e-Faktury?
W KSeF możliwe jest wystawienie zarówno faktury podstawowej, faktury zaliczkowej, faktury
rozliczającej, faktury uproszczonej, faktury korygującej, faktury korygującej fakturę zaliczkową
oraz faktury korygującej fakturę rozliczającą.
Każdy z wymienionych rodzajów dokumentów ma inne cechy charakterystyczne np. w fakturze
zaliczkowej podaje się dodatkowo dane dotyczące zamówienia, a w fakturze korygującej dane
dotyczące faktury korygowanej.
Niektóre firmy zawierają na fakturach dane specyficzne dla ich branży, których podanie na
fakturze nie jest wymagane ustawą. Przykładowo podmioty z branży transportowej mogą
uwzględniać na fakturze za wykonane usługi dane przewoźnika i adres miejsca wysyłki, a
dostawcy mediów dane dotyczące numerów licznika czy adresu punktu poboru. Konieczna jest
więc weryfikacja sposobu obsługi takich różnych scenariuszy w strukturze logicznej FA(3).
Analiza opisanych kwestii pomoże przedsiębiorcom, w jednym z następnych etapów, wybrać
także optymalne narzędzie do wystawiania e-Faktur.
• Czy poza fakturą podatnik przekazuje kontrahentom inne dokumenty np. załączniki?
Często przekazaniu faktury towarzyszą również inne dokumenty tj. specyfikacje, umowy,
protokoły odbioru. W KSeF będą obsługiwane załączniki do faktur, ale wyłącznie dotyczące
17

---

czynności o złożonej liczbie danych w zakresie jednostek miary i ilości (liczby) dostarczanych
towarów lub wykonywanych usług lub cen jednostkowych netto. Funkcjonalność została
zaprojektowana w szczególności z myślą o dostawcach mediów i usług telekomunikacyjnych,
choć zakres branż nie został ograniczony. Załącznik będzie integralną, ustrukturyzowaną
częścią faktury (pliku XML). Innego rodzaju załączniki, np. w postaci plików pdf czy zdjęć nie
będą przyjmowane przez system. Przedsiębiorca powinien więc rozważyć alternatywne
sposoby przekazania załączników, których KSeF nie będzie obsługiwał.
Należy pamiętać również, że w KSeF nie jest możliwe wystawienie faktury pro forma, dowodu
wewnętrznego, noty uznaniowej, noty obciążeniowej ani rachunku w rozumieniu ustawy OP.
Jeżeli podatnik w ramach swojej działalności tworzy takie dokumenty, ich wystawienie i
przekazanie odbiorcy nastąpi poza KSeF.
• Czy podatnik współpracuje z kontrahentami zagranicznymi lub będzie wystawiał
faktury na rzecz konsumentów (dobrowolnie w KSeF)?
Generalną zasadą jest, że nabywca będzie otrzymywał faktury przy użyciu KSeF.
Trzeba jednak pamiętać, że w ustawowo określonych przypadkach, poza wystawieniem faktury
w KSeF, wystąpi obowiązek przekazania faktury nabywcy w sposób uzgodniony. Będzie to
dotyczyło np. sytuacji, gdy nabywcą będzie podatnik zagraniczny nieposiadający siedziby
działalności gospodarczej ani stałego miejsca prowadzenia działalności gospodarczej (który
zwykle nie posiada dostępu do KSeF z uwagi na brak polskiego identyfikatora podatkowego
NIP) lub gdy dobrowolnie wystawiana w KSeF będzie faktura na rzecz konsumenta.
Powyższe zasady mogą wpłynąć na zapisy w regulaminach i umowach, które wiążą podatnika z
kontrahentami. Warto zweryfikować ich zapisy.
W zakresie porównania zapisów umów cywilnoprawnych z zapisami przepisów prawa
podatkowego, MF zwraca uwagę, iż rozwiązania przyjęte w ustawie nakierowane są na
zabezpieczenie celów podatkowych (zapewnienie stabilności Budżetu Państwa). KSeF jest
jednym z narzędzi, który wywiera również skutki w zakresie transakcji handlowych. System ten
wprowadza elektroniczny model faktury oraz zapewnia przy jego użyciu wystawienie i
otrzymanie tego dokumentu. Skutki prawne wynikające z tego systemu nie muszą mieć wpływu
na zapisy umów cywilnoprawnych i odwrotnie. Jednakże dla zapewnienia spójności zapisów
umów z regulacjami ustawowymi wskazana jest aktualizacja treści tych dokumentów (umów),
które mają znaczenie dla zawieranych transakcji.
• Czy podatnik wystawia faktury samodzielnie czy korzysta z usług biura rachunkowego?
18

---

Jeśli podatnik będzie współpracował z biurem rachunkowym, należy rozważyć tu kilka
możliwych opcji, które będą różnić się zakresem odpowiedzialności stron (podatnika i biura
rachunkowego):
o Opcja pierwsza - podatnik korzysta z programu zintegrowanego z API KSeF 2.0.
Wystawia faktury w KSeF samodzielnie lub z udziałem swoich pracowników.
Otrzymuje również faktury zakupowe przy użyciu KSeF. Są one weryfikowane i
zatwierdzane merytorycznie pod kątem prawa do odliczenia podatku naliczonego i
kosztów w podatku dochodowym przez pracownika firmy. Faktury sprzedażowe i
zakupowe są przekazywane w uzgodniony sposób i w określonych terminach do
biura rachunkowego celem przygotowania rozliczeń podatkowych przez biuro.
Biuro rachunkowe w tym modelu nie bierze udziału w wystawianiu faktur w KSeF
ani w ich pobieraniu z systemu.
o Opcja druga - podatnik korzysta z programu zintegrowanego z API KSeF 2.0.
Wystawia faktury w KSeF samodzielnie lub z udziałem swoich pracowników.
Otrzymuje również faktury zakupowe przy użyciu KSeF. Podatnik nadał jednak
uprawnienie do dostępu do faktur na rzecz biura rachunkowego. Biuro rachunkowe
pobiera więc z KSeF faktury sprzedażowe i zakupowe danego podatnika, księguje je
oraz przygotowuje rozliczenia podatkowe. Biuro rachunkowe w tym modelu nie
bierze udziału w wystawianiu faktur w KSeF, lecz w ich pobieraniu z systemu.
o Opcja trzecia - podatnik nie posiada programu zintegrowanego z API KSeF 2.0.
Podatnik nadał jednak uprawnienie do wystawiania faktur oraz do dostępu do
faktur na rzecz biura rachunkowego. Biuro rachunkowe z udziałem swoich
pracowników wystawia faktury podatnika w KSeF. Pobiera z systemu również
faktury sprzedażowe i zakupowe danego podatnika, księguje je oraz przygotowuje
rozliczenia podatkowe.
• Jak wygląda obieg dokumentów w firmie?
Jeśli przedsiębiorca samodzielnie będzie wystawiał faktury w KSeF i je pobierał oraz
księgował, powinien dokonać przeglądu osób odpowiedzialnych za procesy fakturowe w firmie.
Warto sprawdzić kto wystawia, a kto akceptuje i sprawdza poprawność faktur zakupowych.
Kto finalnie uwzględnia je w podatku naliczonym w zakresie VAT oraz w kosztach w podatku
dochodowym? Jaką ścieżkę pokonuje faktura sprzedażowa i zakupowa do momentu jej
zaksięgowania i zapłaty? Jakie działy w firmie będą potrzebować dostępu do faktur?
Odpowiedzi na te pytania będą potrzebne do zaplanowania procesów związanych z nadaniem
uprawnień do korzystania z KSeF swoim pracownikom.
19

---

Wybór narzędzia do wystawiania faktur, które
KROK 3
zapewni obsługę faktur w KSeF.
Jeżeli podatnik jest małym przedsiębiorcą i wystawia obecnie faktury papierowo bądź
elektronicznie przy użyciu ogólnodostępnych edytorów tekstu (Word, Excel) – powinien
zwrócić uwagę na bezpłatne aplikacje do obsługi KSeF, które oferuje MF, a które zostaną
dostosowane do wymogów KSeF 2.0 (Aplikacja Podatnika KSeF, e-mikrofirma, Aplikacja
Mobilna KSeF). Aplikacja Podatnika KSeF w wersji 2.0 na środowisku testowym będzie
dostępna już w listopadzie 2025 r. Podatnik może też wybrać dowolny, dostępny na rynku
program do wystawiania i otrzymywania faktur ustrukturyzowanych zintegrowany z API KSeF
2.0, który spełni jego oczekiwania i potrzeby.
Jeśli przedsiębiorca wystawia już faktury elektronicznie przy użyciu dostępnej na rynku
aplikacji do fakturowania – powinien sprawdzić czy dostawca danego programu planuje
dostosować ją do wymogów KSeF 2.0.
W przypadku podatników wystawiających już dobrowolnie faktury w KSeF, kluczowe będzie
upewnienie się, że dostawca danego programu zaktualizuje swoje narzędzie na dzień 1 lutego
2026 r. i podatnik będzie mógł nadal go wykorzystywać w okresie obligatoryjnego KSeF 2.0.
Podjęcie decyzji co do sposobu
KROK 4
uwierzytelnienia się w KSeF.
Pomocne informacje w zakresie metod uwierzytelnienia są zawarte w niniejszym podręczniku,
w rozdziale drugim. Kluczowa w ramach tego etapu przygotowań jest ocena, które z opisanych
metod najbardziej odpowiadają danemu przedsiębiorcy, biorąc pod uwagę zarówno aspekty
praktyczne jak i kosztowe. Należy pamiętać, że bezpłatną metodą logowania do KSeF jest
Podpis Zaufany (dla osób fizycznych) wykorzystywany m.in. w Aplikacji Podatnika KSeF.
Podatnik może również wybrać kwalifikowany podpis elektroniczny lub kwalifikowaną pieczęć
elektroniczną (w zależności od formy prawnej).
20

---

Warto zapoznać się także z zaletami nowej metody uwierzytelnienia w systemie, szczególnie
polecanej przez MF, jaką są certyfikaty KSeF. Informacje na ten temat można znaleźć w
rozdziale: 2.5. Certyfikat KSeF.
Wyznaczenie osób, które będą upoważnione do
KROK 5
wystawiania i dostępu do faktur w imieniu podatnika.
Nadanie im odpowiednich uprawnień w systemie.
Jeżeli podatnik prowadzi działalność gospodarczą jako osoba fizyczna, może korzystać z KSeF
w pełnym zakresie m.in. wystawiać i odbierać faktury, nadawać i odbierać uprawnienia. Może
również nadać uprawnienia np. swojemu pracownikowi do wystawiania faktur w KSeF. Zrobi to
elektronicznie np. w Aplikacji Podatnika KSeF.
Jeśli podatnik nie jest osobą fizyczną, czyli np. prowadzi działalność w formie spółki, powinien
pamiętać o złożeniu zawiadomienia ZAW-FA (jeżeli nie posiada kwalifikowanej pieczęci
elektronicznej). W zawiadomieniu wyznaczy osobę fizyczną, która w jego imieniu będzie
korzystała z KSeF (może to być np. prezes spółki czy dyrektor finansowy lub inny pracownik).
Ta osoba będzie też mogła nadawać elektronicznie - w imieniu spółki - uprawnienia w KSeF
innym osobom fizycznym lub podmiotom.
Nadając uprawnienia swoim pracownikom trzeba wziąć pod uwagę:
• Kompetencje i zakres odpowiedzialności poszczególnych pracowników:
o Kto z pracowników będzie wystawiał faktury sprzedażowe?
o Kto będzie zatwierdzał formalnie faktury zakupowe?
o Kto zajmuje się tworzeniem rozliczeń podatkowych, w tym JPK_VAT z
deklaracją?
• Czy są inne osoby, które powinny mieć np. dostęp do wystawianych i otrzymywanych
faktur np. dział reklamacji, dział zamówień, logistyka?
• Ich potencjalne nieobecności i zaplanowane urlopy, aby procesy związane z
fakturowaniem miały charakter nieprzerwany (zastępowalność osób).
• Zmiany kadrowe, w tym planowane odejścia z pracy (np. w związku z przejściem
pracownika na emeryturę).
21

---

Zabezpieczenie się na wypadek nieprzewidzianych
KROK 6
sytuacji – zapoznanie się z trybami OFFLINE i pobór
certyfikatu KSeF.
W KSeF poza trybem ONLINE, zostały zaprojektowane odpowiednie tryby postępowania
(OFFLINE) na wypadek niektórych sytuacji:
• Tryb offline24 – który można stosować bez ograniczeń, wprowadzony szczególnie z
myślą o potencjalnych problemach z dostępem do sieci Internet, które mogłyby
wpłynąć na ciągłość wystawiania faktur w KSeF,
• Tryb offline – niedostępność KSeF (na wypadek zaplanowanych prac serwisowych w
systemie),
• Tryb awaryjny – ogłoszona w BIP MF oraz oprogramowaniu interfejsowym awaria
KSeF.
Fakturę w ww. trzech trybach OFFLINE:
• Wystawia się zgodnie ze wzorem e-Faktury FA(3),
• Przesyła się do KSeF w terminie 1 dnia roboczego (w przypadku prac serwisowych lub
trybu offline24) bądź 7 dni roboczych (w przypadku trybu awaryjnego),
• W ustawowo określonych przypadkach wydaje się nabywcy (np. zagranicznemu)
wizualizację faktury opatrzoną kodami QR.
Ponadto, istnieje również procedura tzw. awarii całkowitej, ogłaszanej w środkach społecznego
przekazu, w przypadku której faktury będą wystawiane całkowicie poza KSeF i nie będą do
niego dosyłane. Szczegóły powyższych rozwiązań zostały zaprezentowanie w cz. III
Podręcznika KSeF 2.0.
Przed wejściem w życie obligatoryjnego KSeF, podatnicy powinni zapoznać się z tymi
procedurami i zastanowić się jak będą je wdrażać od strony praktycznej. Czy dostawca danego
programu zapewnia obsługę trybu OFFLINE? Czy pracownicy firmy będą wiedzieli, jak należy
postąpić w przypadku wystąpienia wskazanych okoliczności? Opracowanie odpowiednich
procedur w tym z zakresie pomoże z pewnością zachować ciągłość procesu wystawiania faktur.
22

---

Nie należy również zapomnieć o pobraniu (wspomnianego już wcześniej) certyfikatu KSeF.
Będzie on wymagany w przypadku wystawiania faktur w trybie OFFLINE.
KROK 7
Testowanie KSeF 2.0.
Warto rozpocząć korzystanie z wersji testowej KSeF 2.0 jeszcze przed uruchomieniem
produkcyjnym systemu tj. przed 1 lutego 2026 r.
Środowisko testowe API KSeF 2.0 zostanie uruchomione 30 września 2025 r. Od listopada
2025 r. przedsiębiorcy będą mogli natomiast sprawdzić, jak działa Aplikacja Podatnika KSeF
2.0 w nowej odsłonie - tj. uwierzytelnić się, nadawać testowo uprawnienia, wystawiać i
otrzymywać testowe „faktury”.
Jeśli podatnik będzie korzystał z innych dostępnych na rynku aplikacji do wystawiania faktur,
zintegrowanych z API KSeF 2.0, powinien zweryfikować u swojego dostawcy oprogramowania
czy zapewnia on możliwość wcześniejszego testowania systemu. Zalecane jest bowiem
sprawdzenie jak działa dane narzędzie jeszcze przed 1 lutego 2026 r., aby zaznajomić się z
nowymi funkcjonalnościami i pewnie poruszać się w nim w okresie, gdy KSeF stanie się
obowiązkowy. Warto zaangażować w proces testowania KSeF swoich pracowników. Dzięki
temu podatnik będzie w stanie ocenić czy narzędzie, z którego korzysta spełnia jego
oczekiwania. W razie zauważenia błędów związanych z wystawianiem i otrzymywaniem faktur
testowych – należy zgłaszać je dostawcy oprogramowania, aby mógł szybko je usunąć.
Kluczowe jest upewnienie się, że program finansowo-księgowy działa poprawnie.
Śledzenie na bieżąco strony MF i KSeF. Przekazanie
KROK 8
niezbędnych informacji swoim pracownikom.
Ostatnim, ale równie ważnym krokiem przygotowań do wdrożenia KSeF w firmie jest
odpowiednia komunikacja. W ramach realizacji tego kroku pożądane jest:
• śledzenie na bieżąco strony KSeF (https://ksef.podatki.gov.pl/), na której Ministerstwo
Finansów publikuje materiały związane z KSeF,
23

---

• przekazywanie pracownikom najważniejszych informacji na temat KSeF i wyjaśnienie
im jak wpłynie on na ich codzienną pracę,
• zapewnienie pracownikom szkoleń,
• sprawdzanie stron internetowych izby administracji skarbowej oraz urzędu
skarbowego w celu uzyskania informacji na temat kolejnych szkoleń organizowanych
przez • w razie wątpliwości - zadawanie pytań korzystając z usług Infolinii KAS do spraw KSeF -
https://ksef.podatki.gov.pl/kontakt-zadzwon-lub-napisz/ - można zadzwonić, zadać
pytanie przez formularz kontaktowy lub wykorzystać opcję chat.
W celu skoordynowania całego procesu można wyznaczyć osoby, które będą te działania
nadzorowały. Będą wówczas odpowiadały za to, ile zadań zostało już zrealizowanych, a jakie
obszary wymagają jeszcze uwagi. Działania związane z wdrożeniem KSeF w firmie warto
podjąć już teraz i nie odkładać ich na później. Zaopiekowanie się wszystkimi opisanymi wyżej
zagadnieniami pozwoli przedsiębiorcy wejść sprawnie w obowiązkowy KSeF i zapewni
prawidłowe wywiązanie się przez niego z nowych obowiązków podatkowych.
2. Uwierzytelnienie w KSeF
Aby korzystać z KSeF użytkownik nie musi zakładać konta w systemie. Korzystanie z KSeF
wymaga jednak weryfikacji posiadanych uprawnień oraz uwierzytelnienia się w systemie.
Uwierzytelnienie to potwierdzenie tożsamości danej osoby fizycznej lub podmiotu próbującego
uzyskać dostęp do systemu. Dzięki temu mechanizmowi wykonywane w systemie działania nie
są anonimowe, a sprzedawca i nabywca mają pewność, że faktury są wystawiane wyłącznie
przez osoby lub podmioty do tego uprawnione.
Uwierzytelnienie podmiotów korzystających z KSeF wymaga użycia jednej z poniższych metod,
określonych w rozporządzeniu w sprawie korzystania z KSeF19:
• Podpisu Zaufanego, a od 1 kwietnia 2026 r. środka identyfikacji elektronicznej
wydanego w systemie identyfikacji elektronicznej przyłączonym do węzła krajowego
identyfikacji elektronicznej, o którym mowa w art. 21a ust. 1 pkt 2 lit. a ustawy o
usługach zaufania oraz identyfikacji elektronicznej20 (tzw. Węzeł krajowy – SSO), albo
19 Proces legislacyjny w toku: https://legislacja.rcl.gov.pl/projekt/12379252.
20 Ustawa z dnia 5 września 2016 r. o usługach zaufania oraz identyfikacji elektronicznej (Dz. U. z 2024 r.
poz. 1725).
24

---

• danych weryfikowanych za pomocą kwalifikowanego podpisu elektronicznego, jeżeli te
dane pozwalają na identyfikację i uwierzytelnienie wymagane w celu realizacji usługi
online, albo
• danych weryfikowanych za pomocą kwalifikowanej pieczęci elektronicznej, jeżeli te
dane pozwalają na identyfikację i uwierzytelnienie wymagane w celu realizacji usługi
online, albo
• certyfikatu KSeF wytworzonego po uwierzytelnieniu się podatnika lub podmiotu
uprawnionego w sposób, o którym mowa wyżej,
– oraz weryfikacji posiadanych uprawnień.
Do końca 2026 r. do uwierzytelniania się KSeF będzie można wykorzystać tzw. token tj.
wygenerowany w systemie ciąg znaków alfanumerycznych (z wyłączeniem znaków
interpunkcyjnych), przypisany do podatnika lub podmiotu uprawnionego i jego uprawnień.
Metody uwierzytelnienia w podziale na formę prawną podmiotu
Metoda uwierzytelnienia w KSeF zależy od formy prawnej podmiotu.
W przypadku osób fizycznych uwierzytelnienie w systemie może nastąpić przy użyciu:
• Podpisu Zaufanego, a od 1 kwietnia 2026 r. przy użyciu Węzła krajowego (SSO),
• kwalifikowanego podpisu elektronicznego,
• tokena (metoda dostępna do końca 2026 r.),
• certyfikatu KSeF.
Podmioty niebędące osobą fizyczną mogą uwierzytelnić się w systemie przy użyciu:
• kwalifikowanej pieczęci elektronicznej,
• tokena (metoda dostępna do końca 2026 r.),
• certyfikatu KSeF.
Tabela 2. Metody uwierzytelnienia w KSeF w podziale na formę prawną podmiotu.
METODA UWIERZYTELNIENIA OSOBA PODMIOT NIEBĘDĄCY
W KSeF FIZYCZNA OSOBĄ FIZYCZNĄ
Podpis Zaufany /
TAK NIE
Węzeł krajowy (od 1 kwietnia 2026 r.)
TAK NIE
Podpis kwalifikowany
25

---

Pieczęć kwalifikowana NIE TAK
Token (do 31 grudnia 2026 r.) TAK TAK
Certyfikat KSeF TAK TAK
Szczególnym przypadkiem jest uwierzytelnienie się w KSeF osoby fizycznej w kontekście
podmiotu niebędącego osobą fizyczną (np. osoba fizyczna uprawniona przez spółkę z.o.o.
uwierzytelnia się w kontekście tej spółki). Taka osoba fizyczna wykorzystuje metody
uwierzytelnienia dedykowane osobom fizycznym (tj. Podpis Zaufany/Węzeł krajowy,
kwalifikowany podpis elektroniczny, token, certyfikat KSeF).
Pojęcie „kontekstu uwierzytelnienia”
Każde nawiązanie sesji odbywa się w określonym kontekście logowania. Oznacza to, że
podczas uwierzytelnienia w KSeF należy zadeklarować identyfikator w imieniu, którego
uwierzytelniony użytkownik będzie wykonywał działania w KSeF.
Kontekstem uwierzytelnienia może być w szczególności:
• identyfikator podatkowy NIP podmiotu (np. NIP jednoosobowej działalności
gospodarczej, spółki, JST, GV),
• unikalny identyfikator zakładu (oddziału) osoby prawnej lub innej wyodrębnionej
jednostki wewnętrznej podatnika (tzw. identyfikator wewnętrzny/IDWew),
• identyfikator złożony NIP-VAT UE (w przypadku samofakturowania z podmiotem z
UE),
• identyfikator brokera Peppol.
Po uwierzytelnieniu w systemie w kontekście danego podmiotu aktywne stają się uprawnienia
właściwe dla danego kontekstu logowania. Uwierzytelniona osoba lub podmiot może posiadać
różne uprawnienia w ramach różnych kontekstów. Jeżeli podczas logowania zostanie wskazany
określony identyfikator podmiotu np. NIP (kontekst), w ramach którego użytkownik nie
posiada żadnych uprawnień, wówczas nie będzie on mógł uwierzytelnić się w systemie w
kontekście tego podmiotu.
Kontekst uwierzytelnienia to identyfikator podmiotu, wskazywany na etapie uwierzytelnienia
w systemie. W imieniu tego podmiotu wykonywane są określone działania w KSeF.
26

---

Przykładowo, w sytuacji, gdy w KSeF uwierzytelnia się:
• osoba fizyczna lub podmiot, którzy będą wykonywali działania w systemie w swoim
imieniu – jako kontekst uwierzytelnienia podają swój identyfikator podatkowy NIP (np.
osoba prowadząca jednoosobową działalność gospodarczą lub spółka posługująca się
pieczęcią kwalifikowana),
• osoba fizyczna, która będzie wykonywała działania w systemie w imieniu innego
podmiotu, jako kontekst uwierzytelnienia podaje identyfikator podatkowy NIP tego
podmiotu (np. osoba fizyczna uwierzytelniająca się w systemie w imieniu spółki poda
NIP spółki jako kontekst uwierzytelnienia),
• nabywca (podatnik VAT czynny) wystawiający faktury w ramach samofakturowania -
jako kontekst uwierzytelnienia podaje swój identyfikator podatkowy NIP (również, gdy
fakturę wystawiać będzie osoba lub podmiot uprawniony przez tego nabywcę),
• przedstawiciel podatkowy – jako kontekst uwierzytelnienia podaje swój identyfikator
podatkowy NIP, również, gdy fakturę wystawiać będzie np. osoba uprawniona przez
tego przedstawiciela podatkowego,
• komornik sądowy lub organ egzekucyjny - jako kontekst uwierzytelnienia podaje swój
identyfikator podatkowy NIP, również, gdy fakturę wystawiać będzie np. osoba
uprawniona przez tego komornika lub przez ten organ egzekucyjny,
• osoba fizyczna, która będzie wykonywała działania w systemie w imieniu członka GV -
jako kontekst uwierzytelnienia podaje identyfikator podatkowy NIP członka GV,
• osoba fizyczna, która będzie wykonywała działania w systemie w imieniu jednostki
podrzędnej JST - jako kontekst uwierzytelnienia podaje identyfikator podatkowy NIP
jednostki podrzędnej JST,
• osoba fizyczna, która będzie wykonywała działania w systemie w imieniu jednostki
wewnętrznej podatnika - jako kontekst uwierzytelnienia podaje identyfikator
wewnętrzny danej jednostki.
Przykład 1. Metody oraz kontekst uwierzytelnienia w przypadku jednoosobowej działalności gospodarczej.
Jan Kowalski (NIP 9999999999, PESEL 11111111116)) prowadzi jednoosobową działalność
gospodarczą. Faktury w KSeF wystawia samodzielnie. Jan Kowalski posiada kwalifikowany
podpis elektroniczny z identyfikatorem podatkowym NIP. Posiada także Podpis Zaufany.
Chcąc uwierzytelnić się w KSeF w celu wystawienia faktury, w której jest sprzedawcą, Jan
Kowalski powinien uwierzytelnić się w systemie w kontekście swojego NIP 9999999999.
Podczas uwierzytelnienia w KSeF może użyć swojego podpisu kwalifikowanego z NIP lub
Podpisu Zaufanego z PESEL.
27

---

Przykład 2. Metody uwierzytelnienia oraz kontekst uwierzytelnienia w przypadku jednoosobowej działalności
gospodarczej.
Jan Kowalski (NIP 9999999999) prowadzi jednoosobową działalność gospodarczą. Faktury w
KSeF w jego imieniu wystawia pracownik Anna Nowak (PESEL 11111111116), która posiada
kwalifikowany podpis elektroniczny z identyfikatorem podatkowym PESEL.
Chcąc uwierzytelnić się w KSeF w celu wystawienia faktury w imieniu jednoosobowej
działalności, Anna Nowak powinna uwierzytelnić się w systemie w kontekście NIP
9999999999. Podczas uwierzytelnienia w KSeF może użyć swojego podpisu kwalifikowanego z
numerem PESEL 11111111116.
Przykład 3. Metody uwierzytelnienia oraz kontekst uwierzytelnienia w przypadku podmiotu niebędącego osobą
fizyczną.
Spółka jawna X (NIP 9999999999) posiada kwalifikowaną pieczęć elektroniczną. Pieczęcią
kwalifikowaną w celu wystawiania faktur, dostępu do faktur, nadawania uprawnień i
odbierania uprawnień w imieniu spółki posługują się wyłącznie wyznaczeni pracownicy spółki.
Podczas uwierzytelnienia się w systemie pieczęcią kwalifikowaną spółki, pracownicy powinni
podać jako kontekst uwierzytelnienia NIP spółki (9999999999).
Przykład 4. Metody uwierzytelnienia oraz kontekst uwierzytelnienia w przypadku podmiotu niebędącego osobą
fizyczną.
Księgowej Annie Nowak (NIP 1111111111), posiadającej podpis kwalifikowany z
identyfikatorem podatkowym NIP, zostały nadane w KSeF przez:
• spółkę jawną X (NIP 9999999999) - uprawnienia do wystawiania faktur i do dostępu do
faktur,
• spółkę z o.o. Y (NIP 8888888888) - uprawnienia do nadawania i odbierania uprawnień,
• spółkę cywilną Z (NIP 7777777777) - uprawnienia do wystawiania faktur i do dostępu
do faktur, uprawnienia do nadawania i odbierania uprawnień.
Księgowa Anna Nowak chcąc uwierzytelnić się w KSeF:
• w celu wystawiania faktur i dostępu do faktur spółki jawnej X – powinna uwierzytelnić
się w KSeF w kontekście NIP spółki jawnej X (NIP 9999999999),
• w celu nadawania i odbierania uprawnień w imieniu spółki z o.o. Y – powinna
uwierzytelnić się w KSeF w kontekście spółki z o.o. Y (NIP 8888888888),
• w celu wystawiania faktur i dostępu do faktur spółki cywilnej Z oraz nadawania i
odbierania uprawnień w jej imieniu – powinna uwierzytelnić się w KSeF w kontekście
spółki cywilnej Z (NIP 7777777777).
28

---

Podczas uwierzytelnienia w KSeF w kontekście spółek X, Y, Z księgowa Anna Nowak może użyć
swojego podpisu kwalifikowanego.
Przykład 5. Metody uwierzytelnienia oraz kontekst uwierzytelnienia w przypadku samofakturowania.
Spółka cywilna X (NIP 9999999999) dokonuje sprzedaży na rzecz osoby fizycznej Y
prowadzącej jednoosobową działalność gospodarczą (NIP 3333333333). Strony mają zawartą
umowę o samofakturowaniu. Spółka X w związku z tym nadała podatnikowi Y uprawnienie w
KSeF do samofakturowania. Podatnik Y uwierzytelniając się w KSeF np. własnym podpisem
kwalifikowanym, w celu wystawiania faktur w ramach samofakturowania powinien podać jako
kontekst uwierzytelnienia własny NIP (3333333333).
Przykład 6. Metody uwierzytelnienia oraz kontekst uwierzytelnienia w przypadku samofakturowania z
podmiotem UE.
Podatnik podatku od wartości dodanej (spółka niemiecka – posiadająca numer VAT UE
DE271569167) otrzymał od polskiego podatnika (NIP 9999999999) uprawnienie do
samofakturowania jako podmiot unijny, na dane unikalne powiązane z certyfikatem
kwalifikowanej pieczęci elektronicznej wydanej na terytorium Niemiec, która nie zawiera
identyfikatora podatkowego NIP. Spółka niemiecka uwierzytelniając się w KSeF celem
wystawienia faktury w ramach samofakturowania wskaże kontekst uwierzytelnienia w postaci
identyfikatora złożonego 9999999999-DE271569167 oraz użyje zagranicznej pieczęci
kwalifikowanej.
Przykład 7. Metody uwierzytelnienia oraz kontekst uwierzytelnienia w przypadku jednostek wewnętrznych.
Spółka z o.o. (NIP 9999999999) po uwierzytelnieniu się w systemie wygenerowała
identyfikator wewnętrzny tzw. IDWew (9999999999-11118) dla oddziału spółki. Wyznaczyła
następnie osobę fizyczną (PESEL 11111111116), która będzie wykonywała działania w
systemie w imieniu oddziału spółki (tj. administratora jednostki wewnętrznej). Administrator
jednostki wewnętrznej chce nadać uprawnienia do wystawania faktur oraz do dostępu do
faktur pracownikowi oddziału spółki (w ramach jednostki wewnętrznej). W związku z tym
administrator uwierzytelnia się w KSeF swoim Podpisem Zaufanym w kontekście
identyfikatora wewnętrznego 9999999999-11118.
2.1. Podpis Zaufany i Węzeł krajowy (login.gov)
Podpis Zaufany to środek identyfikacji elektronicznej. Jest to bezpłatne narzędzie służące do
potwierdzania tożsamości w systemach elektronicznych administracji oraz podpisywania
dokumentów. Wykorzystywany jest do kontaktów z administracją publiczną (urzędami,
ministerstwami).
29

---

Podpis Zaufany może założyć każdy, kto posiada numer PESEL oraz pełną bądź ograniczoną
zdolność do czynności prawnych. Profil Zaufany jest ważny przez 3 lata. Istnieje możliwość
przedłużenia jego ważności.
WAŻNE
Nie wolno udostępniać nikomu swojego podpisu (analogicznie jak nie przekazuje się nikomu
swojego dowodu osobistego ani danych do logowania w bankowości elektronicznej).
Kompendium wiedzy na temat Podpisu Zaufanego jest dostępne na stronie:
https://www.biznes.gov.pl/pl/portal/0074.
Od 1 kwietnia 2026 r. w KSeF zapewniona zostanie możliwość uwierzytelnienia się za pomocą
Węzła krajowego (login.gov). W ramach Węzła krajowego dostępne będą następujące metody
uwierzytelnienia:
• Podpis Zaufany,
• Aplikacja mObywatel,
• Logowanie za pomocą bankowości elektronicznej,
• E-Dowód.
Rozwiązanie to będzie wykorzystywane w bezpłatnych narzędziach do e-fakturowania,
udostępnianych przez MF. Uwierzytelnienie Węzłem krajowym możliwe będzie między innymi
w Aplikacji Podatnika KSeF.
2.2. Kwalifikowany podpis elektroniczny
Jedną z metod uwierzytelnienia się w systemie dedykowaną dla osób fizycznych jest
kwalifikowany podpis elektroniczny. Podpis kwalifikowany to podpis elektroniczny, który ma
taką samą moc prawną jak własnoręczny podpis. Jest poświadczony certyfikatem
kwalifikowanym, który pozwala na weryfikację tożsamości osoby posługującej się tym
podpisem.
WAŻNE
Podpisu kwalifikowanego może używać wyłącznie osoba fizyczna, do której certyfikat jest
przyporządkowany. Nie wolno udostępniać narzędzia do składania podpisu (karty
kryptograficznej) osobom trzecim.
Więcej informacji na temat funkcjonalności podpisu kwalifikowanego oraz zasad jego
uzyskania można znaleźć pod adresem: https://www.biznes.gov.pl/pl/portal/0075.
30

---

KSeF akceptuje uwierzytelnienie podpisem kwalifikowanym, który posiada identyfikator
podatkowy NIP lub PESEL jak również podpisem kwalifikowanym, który nie posiada
identyfikatora podatkowego NIP ani numeru PESEL.
W przypadku kwalifikowanych podpisów zawierających identyfikator podatkowy NIP lub
PESEL, którymi posługuje się podatnik (np. jednoosobowa działalność gospodarcza) lub osoba
uprawniona przez podatnika (np. osoba fizyczna, której spółka nadała uprawnienia w KSeF) nie
są wymagane żadne dodatkowe formalności, aby uwierzytelnienie w systemie takim podpisem
było skuteczne.
Na rynku funkcjonują także certyfikaty kwalifikowane, które nie zawierają identyfikatora
podatkowego NIP ani PESEL. Nie wyklucza to jednak uwierzytelnienia w KSeF i weryfikacji
posiadanych uprawnień po użyciu podpisu weryfikowanego takim certyfikatem. W zależności
jednak od przypadku należy wówczas:
• zgłosić dane unikalne powiązane z certyfikatem kwalifikowanego podpisu
elektronicznego, należącego do podatnika (osoby fizycznej) – w zawiadomieniu ZAW-
FA,
• zgłosić dane unikalne powiązane z certyfikatem kwalifikowanego podpisu
elektronicznego, należącego do osoby fizycznej (wskazanej w cz. C zawiadomienia
ZAW-FA) uprawnionej przez podatnika lub podmiotu niebędącego osobą fizyczną – w
zawiadomieniu ZAW-FA,
• zgłosić dane unikalne powiązane z certyfikatem kwalifikowanego podpisu
elektronicznego, należącego do osoby fizycznej uprawnionej przez podatnika– w
sposób elektroniczny, przy użyciu narzędzi komercyjnych zintegrowanych z API KSeF
2.0 lub przy użyciu Aplikacji Podatnika KSeF.
WAŻNE
Dane unikalne powiązane z certyfikatem kwalifikowanego podpisu elektronicznego (zwane
również „odciskiem palca podpisu”) to unikalny, cyfrowy identyfikator, wyznaczany z danego
certyfikatu, po zastosowaniu funkcji skrótu kryptograficznego opartej na algorytmie SHA-256.
Składa się z 64 znaków z przedziału od „0” do „9” oraz od „a” do „f”.
Po wprowadzeniu przez urzędnika danych z zawiadomienia ZAW-FA do systemu, a w
przypadku zgłoszenia danych unikalnych podpisu elektronicznie (po przetworzeniu ich w
systemie), możliwe będzie uwierzytelnienie się w KSeF przy użyciu podpisu niezawierającego
identyfikatora podatkowego NIP ani numeru PESEL.
31

---

Przykład 8. Zgłoszenie danych unikalnych powiązanych z certyfikatem kwalifikowanego podpisu
elektronicznego.
Spółka z siedzibą we Francji jest zarejestrowana jako podatnik VAT czynny w związku z
dokonywaną na terytorium Polski sprzedażą. Spółka nie posiada w Polsce siedziby, ale posiada
stałe miejsce prowadzenia działalności gospodarczej, które uczestniczy w dostawach towarów
i świadczeniu usług, dla których wystawiane są faktury. Tym samym podlega obowiązkowi
wystawiania faktur w KSeF i musi uwierzytelnić się w związku z tym w systemie. W imieniu
spółki w KSeF działać będzie (tj. wystawiać faktury, mieć do nich dostęp, nadawać i odbierać
uprawnienia) osoba fizyczna – księgowa (obywatelka Francji), która nie posiada identyfikatora
podatkowego NIP ani PESEL. Posiada kwalifikowany podpis elektroniczny wydany na
terytorium Francji, który także nie zawiera identyfikatora podatkowego NIP ani PESEL.
Spółka nie posiada kwalifikowanej pieczęci elektronicznej. Spółka w celu umożliwienia
księgowej uwierzytelnienia w KSeF oraz korzystania z KSeF w kontekście spółki, może złożyć
zawiadomienie ZAW-FA, wskazując w szczególności w cz. C dane osoby fizycznej (księgowej)
uprawnionej do korzystania z KSeF oraz dane unikalne powiązane z certyfikatem
kwalifikowanym jej podpisu elektronicznego w cz. D.
2.3. Kwalifikowana pieczęć elektroniczna
Jedną z metod uwierzytelnienia się w systemie dedykowaną dla podmiotów niebędących
osobami fizycznymi jest kwalifikowana pieczęć elektroniczna. Pieczęć kwalifikowana to
odpowiednik podpisu elektronicznego, ale reprezentujący organizację. Można go porównać do
pieczątki firmowej, zawierającej dane przedsiębiorstwa, z tą różnicą jednak, że pieczęć
elektroniczna ma postać cyfrową.
Kwalifikowana pieczęć elektroniczna używana w KSeF powinna zawierać identyfikator w
postaci NIP podatnika. Warto w tym miejscu zaznaczyć, że w momencie posługiwania się
pieczęcią kwalifikowaną przez danego pracownika firmy np. w przypadku wystawienia faktury,
w KSeF znajdą się dane właściciela pieczęci, czyli np. spółki, a nie konkretnej osoby, która tej
pieczęci używa.
Podobnie jak ma to miejsce w przypadku kwalifikowanych certyfikatów podpisów
elektronicznych bez atrybutu NIP i bez numeru PESEL, na rynku występują także
kwalifikowane certyfikaty pieczęci elektronicznej niezawierające numeru identyfikacji
podatkowej (NIP). Nie wyklucza to jednak uwierzytelnienia w KSeF i weryfikacji posiadanych
uprawnień w związku z użyciem takiej pieczęci.
32

---

W zależności jednak od przypadku należy wówczas:
• zgłosić dane unikalne powiązane z certyfikatem kwalifikowanej pieczęci elektronicznej,
należącej do podatnika (niebędącego osobą fizyczną) – w zawiadomieniu ZAW-FA,
• zgłosić dane unikalne powiązane z certyfikatem kwalifikowanej pieczęci elektronicznej,
należącej do podmiotu uprawnionego przez podatnika– w sposób elektroniczny, przy
użyciu narzędzi komercyjnych zintegrowanych z API KSeF2.0 lub przy użyciu Aplikacji
Podatnika KSeF.
WAŻNE
Dane unikalne powiązane z certyfikatem kwalifikowanej pieczęci elektronicznej (zwane
również „odciskiem palca pieczęci”) to unikalny, cyfrowy identyfikator, wyznaczany z danego
certyfikatu, po zastosowaniu funkcji skrótu kryptograficznego opartej na algorytmie SHA-256.
Składa się z 64 znaków z przedziału od „0” do „9” oraz od „a” do „f”.
Po wprowadzeniu przez urzędnika danych z zawiadomienia ZAW-FA do systemu, a w
przypadku zgłoszenia danych unikalnych pieczęci elektronicznej w sposób elektroniczny, po
przetworzeniu ich w systemie, możliwe będzie uwierzytelnienie się w KSeF przy użyciu pieczęci
niezawierającej identyfikatora podatkowego NIP.
Przykład 9. Zgłoszenie danych unikalnych powiązanych z certyfikatem kwalifikowanej pieczęci elektronicznej.
Spółka niemiecka jest zarejestrowana w Polsce jako podatnik VAT czynny w związku z
dokonywaną na terytorium kraju sprzedażą. Spółka nie posiada w Polsce siedziby ani stałego
miejsca prowadzenia działalności gospodarczej, w związku z czym nie jest zobowiązana do
wystawiania faktur w KSeF. Spółka chce jednak wystawiać faktury w KSeF dobrowolnie, w
związku z czym potrzebuje uwierzytelnić się w systemie. Posiada kwalifikowaną pieczęć
elektroniczną, wydaną na terytorium Niemiec, która nie zawiera polskiego identyfikatora
podatkowego NIP spółki.
Spółka w celu uwierzytelnienia się w KSeF kwalifikowaną pieczęcią elektroniczną oraz
korzystania z KSeF, może złożyć zawiadomienie ZAW-FA, wskazując w szczególności w cz. B
swoje dane jako podatnika oraz dane unikalne powiązane z certyfikatem kwalifikowanej
pieczęci elektronicznej w cz. D. Nie wypełnia w tym przypadku cz. B zawiadomienia.
2.4. Token
2.4.1. Co to jest token i do czego służy?
Token jest to wygenerowanym przez KSeF, po uwierzytelnieniu się podatnika lub podmiotu
uprawnionego w systemie (Podpisem Zaufanym, podpisem kwalifikowanym lub pieczęcią
33

---

kwalifikowaną), ciągiem znaków alfanumerycznych (z wyłączeniem znaków interpunkcyjnych),
przypisanym do podatnika lub podmiotu uprawnionego i jego uprawnień.
Token może być wykorzystywany do przyspieszenia i ułatwienia procesu logowania się do
KSeF. Zamiast każdorazowego uwierzytelniania się w KSeF np. podpisem kwalifikowanym,
podatnik może wygenerować token i wykorzystywać go do uwierzytelniania w aplikacjach
komercyjnych zintegrowanych z KSeF. Uwierzytelnienie tokenem w KSeF 2.0 jest możliwe w
ramach sesji interaktywnej jak i wsadowej.
2.4.2. Okres ważności tokena
KSeF nie określa czasu w jakim token jest ważny. Wygenerowany token pozostaje ważny do
czasu jego unieważnienia przez użytkownika.
WAŻNE
Możliwość generowania i wykorzystywania tokenów wygaśnie z końcem 2026 r. 21
2.4.3. Kto może wygenerować token?
Token może być wygenerowany zarówno dla osoby fizycznej jak i dla podmiotu niebędącego
osobą fizyczną (np. spółki). Jeżeli dana osoba fizyczna uwierzytelni się w systemie np. podpisem
kwalifikowanym i wygeneruje token na swoje dane i uprawnienia tj. na osobę fizyczną, to po
uwierzytelnieniu się tym tokenem będzie widoczna w systemie jako konkretna osoba fizyczna.
Jeżeli natomiast podmiot niebędący osobą fizyczną np. spółka, uwierzytelni się w systemie
pieczęcią kwalifikowaną i wygeneruje token z posiadanymi przez nią uprawnieniami, to
działając w systemie, po uwierzytelnieniu się tym tokenem będzie widoczny w systemie jako
spółka, a nie konkretna osoba fizyczna.
Wygenerowanie tokena możliwe jest po uwierzytelnieniu się osoby fizycznej lub podmiotu w
kontekście identyfikatora podatkowego NIP lub identyfikatora wewnętrznego.
Przykład 10. Sposób generowania tokenów i zarządzania tokenami w spółce.
Spółka jawna (NIP 9999999999) uwierzytelniła się w KSeF za pomocą kwalifikowanej pieczęci
elektronicznej, zawierającej NIP podatnika. Spółka działa na terenie całego kraju, poprzez
swoich przedstawiciel handlowych. Faktury sprzedażowe wystawiane są zawsze przez
wyznaczonego przedstawiciela obsługującego dany rejon. W związku z powyższym spółka
wygenerowała w KSeF sześć tokenów, a w każdym z nich zapisała wyłącznie uprawnienie do
21 Projektowany § 13 ust. 1 rozporządzenia w sprawie korzystania z KSeF.
Proces legislacyjny w toku: https://legislacja.rcl.gov.pl/projekt/12379252.
34

---

wystawiania faktur spółki. W celu sprawowania kontroli nad procesem wystawiania faktur w
firmie przyjęła zasadę, że jeden token będzie wykorzystywany wyłącznie przez jednego
przedstawiciela handlowego.
Spółka nadała tokenom następujące nazwy:
• Nazwa pierwszego tokena: „Przedstawiciel handlowy – rejon 1”,
• Nazwa drugiego tokena: „Przedstawiciel handlowy – rejon 2”,
• Nazwa trzeciego tokena: „Przedstawiciel handlowy – rejon 3”,
• Nazwa czwartego tokena: „Przedstawiciel handlowy – rejon 4”,
• Nazwa piątego tokena: „Przedstawiciel handlowy – rejon 5”,
• Nazwa szóstego tokena: „Przedstawiciel handlowy - rejon 6”.
Spółka udostępniła wygenerowane tokeny poszczególnym przedstawicielom handlowym. W
opisanej sytuacji, w przypadku, gdy fakturę w imieniu spółki jawnej, po uwierzytelnieniu się w
KSeF tokenem o nazwie” Przedstawiciel handlowy – rejon 2”, wystawi przedstawiciel handlowy
obsługujący ten rejon 2, w KSeF widoczne będą dane spółki, a nie konkretnej osoby fizycznej.
Jedynie spółka będzie w posiadaniu informacji, który przedstawiciel był odpowiedzialny za
wystawienie faktury, z uwagi na przyjętą wewnętrzną politykę zarządzania wygenerowanymi
tokenami.
Przykład 11. Sposób generowania tokenów i zarządzania tokenami przez osoby fizyczne i spółki.
Spółka akcyjna (NIP 9999999999) działa na terenie całego kraju, poprzez swoich
przedstawicieli handlowych. Faktury sprzedażowe wystawiane są zawsze przez wyznaczonego
przedstawiciela handlowego obsługującego dany rejon. Spółka nie posiada pieczęci
kwalifikowanej. W związku z powyższym prezes spółki akcyjnej (posiadający najszerszy zakres
uprawnień, nadany w wyniku złożenia zawiadomienia ZAW-FA) uwierzytelnił się w KSeF
swoim Podpisem Zaufanym w kontekście NIP spółki (9999999999) i nadał uprawnienia do
wystawiania faktur w imieniu spółki wszystkim przedstawicielom handlowym (na ich nr PESEL).
Następnie każdy przedstawiciel handlowy uwierzytelnił się Podpisem Zaufanym w KSeF w
kontekście NIP spółki (9999999999) i wygenerował sobie (na swój nr PESEL) token.
Finalnie przedstawiciele handlowi wygenerowali następujące tokeny:
• Nazwa pierwszego tokena: „Przedstawiciel handlowy 1”,
• Nazwa drugiego tokena: „Przedstawiciel handlowy 2”,
• Nazwa trzeciego tokena: „Przedstawiciel handlowy 3”,
• Nazwa czwartego tokena: „Przedstawiciel handlowy 4”,
• Nazwa piątego tokena: „Przedstawiciel handlowy 5”,
35

---

• Nazwa szóstego tokena: „Przedstawiciel handlowy 6”.
W opisanej sytuacji, gdy przedstawiciel handlowy obsługujący dany rejon uwierzytelni się w
KSeF swoim tokenem o nazwie ”Przedstawiciel handlowy 2”, w kontekście spółki i wystawi w
jej imieniu fakturę, w KSeF widoczne będą dane tej konkretnej osoby fizycznej, do której był
przypisany token. Pod żadnym pozorem przedstawiciel obsługujący dany rejon nie powinien
udostępniać swojego tokena przedstawicielowi handlowemu obsługującemu inny rejon.
2.4.4. Zasady bezpieczeństwa przy posługiwaniu się tokenem
Token to bezpieczna metoda uwierzytelniania przy zachowaniu podstawowego warunku, że
nie jest on ujawniany osobom postronnym. Niedopuszczalne jest generowanie tokenów przez
osobę fizyczną, a następnie przekazywanie ich innym użytkownikom (np. innym osobom
fizycznym) w celu wykorzystania ich przez te osoby podczas uwierzytelnienia w KSeF.
WAŻNE
Niedopuszczalne jest posługiwanie się tokenem przez osobę fizyczną, która nie wygenerowała
tego tokena.
2.4.5. Ile tokenów może być wygenerowanych?
Nie są przewidziane ograniczenia systemowe co do liczby posiadanych lub używanych
tokenów.
2.4.6. Uzyskanie tokena w Aplikacji Podatnika KSeF lub w aplikacjach komercyjnych
Wygenerowanie tokena może nastąpić w Aplikacji Podatnika KSeF lub przy użyciu
komercyjnych programów finansowo-księgowych zintegrowanych z API KSeF.
W celu wygenerowania tokena w Aplikacji Podatnika należy wykonać następujące działania:
• nawiązać sesję w KSeF przy użyciu Podpisu Zaufanego lub certyfikatu kwalifikowanego,
• wybrać w menu opcję Tokeny/Generuj token,
• wprowadzić nazwę własną tokena oraz uprawnienia, które mają być do niego
przypisane,
• użyć przycisku „Generuj token”, a następnie skopiować wygenerowany numer tokena.
WAŻNE
Ze względów bezpieczeństwa Aplikacja Podatkowa KSeF wyświetla wygenerowany token
(unikalny ciąg znaków) tylko jeden raz.
36

---

2.4.7. Token a zmiana zakresu uprawnień
Należy zaznaczyć, że osoba fizyczna lub podmiot, który posiada określony zakres uprawnień
np. uprawnienie do wystawiania faktur i dostępu do faktur, chcąc wygenerować sobie token:
• może wygenerować jeden token na wszystkie swoje uprawnienia,
• może wygenerować kilka tokenów, np. na każde uprawnienie inny token.
Decyzja co do zakresu uprawnień zapisanych w danym tokenie należy do osoby
fizycznej/podmiotu, który go generuje. Nie można jednak przypisać do tokena uprawnienia,
którym w momencie generowania nie dysponuje osoba lub podmiot uwierzytelniony w danym
kontekście.
Token wygenerowany we własnym kontekście można wykorzystywać wyłącznie do
uwierzytelnienia się w KSeF w tym kontekście. Token wygenerowany po uwierzytelnieniu się w
kontekście innej osoby lub innego podmiotu (od którego generujący token otrzymał
uprawnienia w KSeF) można wykorzystywać wyłącznie do uwierzytelnienia się w KSeF w tym
konkretnym kontekście.
Wygenerowane tokeny nie podlegają aktualizacji. Jeśli token został wygenerowany np. na
uprawnienie do wystawiania faktur, to nie można go zaktualizować i dodać do niego drugiego
uprawnienia np. do dostępu do faktur.
Odebranie uprawnień przypisanych do identyfikatora, na który został wygenerowany token
powoduje odebranie tych uprawnień przypisanych do tokena. W przypadku ponownego
nadania osobie lub podmiotowi odebranego uprawnienia, będzie ono znów funkcjonować w
powiązaniu z tokenem. System nie unieważnia jednak tokena, nawet w przypadku, gdy zostały
odebrane wszystkie uprawnienia, które były zapisane w tym tokenie. Odebranie wszystkich
uprawnień przypisanych do tokena powoduje wyłącznie brak możliwości uwierzytelnienia się
do systemu.
Przykład 12. Generowanie tokenów przez osobę fizyczną.
Jan Kowalski prowadzący jednoosobową działalność gospodarczą (NIP 9999999999)
uwierzytelnił się w KSeF podpisem kwalifikowanym, w swoim kontekście, a następnie
wygenerował na cały zakres posiadanych przez siebie uprawnień token. Jednocześnie Jan
Kowalski jest wspólnikiem w spółce X (NIP 1111111111), w ramach której jest osobą fizyczną
uprawnioną do wystawiania faktur w imieniu spółki. W związku z powyższym uwierzytelnił się
w KSeF i wygenerował drugi token, tym razem działając w kontekście spółki X.
37

---

Token wygenerowany przez Jana Kowalskiego:
• w kontekście własnego NIP 9999999999, umożliwia mu po uwierzytelnieniu się tym
tokenem we własnym kontekście, działanie w KSeF w pełnym zakresie, w tym
wystawianie faktur w których jest sprzedawcą, otrzymywanie faktur oraz nadawanie i
odbieranie uprawnień (zarządzanie uprawnieniami),
• w kontekście NIP 1111111111, należącego do spółki X, umożliwia mu po
uwierzytelnieniu się tym tokenem w kontekście spółki X, działanie w KSeF w zakresie
wystawiania faktur, w których spółka X będzie sprzedawcą.
Nie będzie możliwe uwierzytelnienie się w KSeF:
• w kontekście własnego NIP (9999999999) - tokenem wygenerowanym w kontekście
NIP spółki (1111111111 ),
• w kontekście NIP spółki (1111111111) - tokenem wygenerowanym we własnym
kontekście (9999999999).
Przykład 13. Wpływ zmiany zakresu posiadanych uprawnień na token.
Księgowa Anna Nowak (NIP 9999999999) prowadząca jednoosobową działalność
gospodarczą po uwierzytelnieniu się w KSeF we własnym kontekście podpisem
kwalifikowanym, zawierającym jej identyfikator podatkowy NIP, wygenerowała token.
Księgowa obsługuje kilka firm, które nadały jej w KSeF uprawnienia do wystawiania faktur, do
dostępu do faktur oraz uprawnienia do nadawania i odbierania uprawnień w KSeF:
• Firma X nadała Annie Nowak uprawnienie w KSeF do wystawiania faktur i do dostępu
do faktur,
• Firma Y nadała Annie Nowak uprawnienie w KSeF do nadawania i odbierania
uprawnień w KSeF,
• Firma Z nadała Annie Nowak uprawnienie w KSeF do wystawiania faktur i dostępu do
faktur.
W związku z powyższym, po uwierzytelnieniu się w systemie podpisem kwalifikowanym w ww.
kontekstach poszczególnych firm X, Y lub Z, Anna Nowak wygenerowała sobie tokeny i
zapisała w każdym z nich posiadane w ramach danej firmy uprawnienia (po jednym tokenie w
kontekście jednej firmy).
Po określonym czasie firma X nadała Annie Nowak dodatkowy zakres uprawnień, tj.
uprawnienie do nadawania i odbierania uprawnień w KSeF. Biorąc jednak pod uwagę, że
wygenerowanego wcześniej tokena nie można aktualizować, księgowa ma dwie możliwości:
38

---

• Uwierzytelnić się w kontekście firmy X i wygenerować nowy, dodatkowy token –
wyłącznie na uprawnienie do nadawania i odbierania uprawnień w KSeF, lub
• Uwierzytelnić się w kontekście firmy X, unieważnić token obejmujący dotychczasowy
zakres uprawnień (do wystawiania faktur i do dostępu do faktur) i wygenerować nowy
token na pełen zakres posiadanych uprawnień (do wystawiania faktur i do dostępu do
faktur oraz do nadawania i odbierania uprawnień w KSeF).
Jeżeli po określonym czasie firma Y odbierze Annie Nowak nadane wcześniej uprawnienia (do
nadawania i odbierania uprawnień w KSeF), wówczas token wygenerowany w kontekście firmy
Z nie utraci ważności, ale księgowa nie będzie mogła się tym tokenem uwierzytelnić kontekście
firmy Y (z uwagi na brak jakichkolwiek uprawnień).
Jeżeli po określonym czasie firma Z odbierze Annie Nowak nadane wcześniej uprawnienie w
KSeF do dostępu do faktur, wówczas token wygenerowany w kontekście firmy Z nie utraci
ważności, ale księgowa po uwierzytelnieniu się tym tokenem w kontekście firmy Z będzie
mogła wyłącznie wystawiać faktury (zgodnie z aktualnym zakresem uprawnień).
2.4.8. Działania na tokenach
API KSeF po wygenerowaniu tokena umożliwia pobranie listy tokenów oraz ich unieważnienie.
Pobranie listy wszystkich tokenów w danym kontekście dostępne będzie dla osoby lub
podmiotu posiadającego uprawnienia do przeglądania uprawnień lub nadawania i zmiany
uprawnień (zarządzania uprawnieniami).
Lista tokenów będzie zawierała dane tj.:
• ID tokena,
• Nazwa własna,
• Typ identyfikatora i identyfikator twórcy tokena,
• Status tokena,
• Data aktywacji tokena,
• Data ostatniego użycia tokena,
• Uprawnienia (lista).
Usługa API KSeF ma również możliwość unieważnienia tokena. Token może być unieważniony
przez osobę lub podmiot, który go wygenerował lub osobę z uprawnieniem do nadawania i
zmiany uprawnień (zarządzania uprawnieniami).
39

---

WAŻNE
W Aplikacji Podatnika KSeF nie będzie możliwe uwierzytelnienie się za pomocą tokena.
2.5. Certyfikat KSeF
2.5.1. Co to jest i do czego będzie służył certyfikat KSeF?
Certyfikat KSeF to cyfrowe narzędzie kryptograficzne potwierdzające tożsamość osoby lub
podmiotu, które jest wydawane przez Centrum Certyfikacji Ministerstwa Finansów. Posiadanie
takiego certyfikatu pozwoli na bezpieczne, wydajne i zautomatyzowane korzystanie z KSeF.
WAŻNE
Uwierzytelnienie certyfikatem KSeF lub wykorzystanie certyfikatu KSeF podczas wystawiania
faktur w trybie OFFLINE będzie możliwe od 1 lutego 2026 r.
Certyfikat będzie można wykorzystywać w narzędziach komercyjnych do wystawiania e-
Faktur, zintegrowanych z API KSeF 2.0. Nie będzie natomiast możliwości uwierzytelnienia się
certyfikatem w bezpłatnych narzędziach MF np. w Aplikacji Podatnika KSeF.
Certyfikaty KSeF będą dwojakiego rodzaju:
CERTYFIKAT TYPU 1 DO UWIERZYTELNIENIA
Certyfikat KSeF typu 1 przeznaczony będzie do uwierzytelniania się w systemie KSeF (jako
jedna z dopuszczalnych metod). Po uwierzytelnieniu się osoba lub podmiot będą mogli
wykonywać działania w systemie zgodnie z przypisanymi im w KSeF uprawnieniami.
Uwierzytelnienie certyfikatem KSeF będzie możliwe zarówno w sesji interaktywnej jak
również w sesji wsadowej.
Po zalogowaniu się certyfikatem KSeF będą brane pod uwagę uprawnienia powiązane z
identyfikatorem podatkowym (NIP, PESEL) zapisanym na tym certyfikacie. System będzie
również uwzględniał powiązanie identyfikatorów NIP i PESEL. Oznacza to, że osoba fizyczna
lub podmiot uwierzytelniony certyfikatem KSeF będą mogli działać w systemie w obrębie
uprawnień nadanych na oba ww. identyfikatory podatkowe (niezależnie, na który identyfikator
był wygenerowany certyfikat).
CERTYFIKAT TYPU 2 DO WYSTAWIANIA FAKTUR OFFLINE
Certyfikat KSeF typu 2 wymagany jest do oznaczenia faktury kodem umożliwiającym
potwierdzenie tożsamości wystawcy przy wystawianiu faktur w trybie OFFLINE (tj. w trybie
offline24, offline-niedostępność systemu, trybie awarii KSeF).
Potwierdzenie tożsamości wystawcy należy rozumieć tu jako:
• potwierdzenie tożsamości osoby, jeśli był on wydany na osobę fizyczną lub
40

---

• identyfikację konkretnego podmiotu np. spółki, jeśli był on wydany na podmiot inny niż
osoba fizyczna.
Certyfikaty KSeF zapewnią więc ciągłość procesu fakturowania niezależnie od okoliczności
zewnętrznych, z uwagi na ich wykorzystanie w przypadku faktur wystawianych OFFLINE.
WAŻNE
Certyfikaty KSeF obu typów będą generowane osobno. Nie będzie możliwe wygenerowanie
jednego certyfikatu KSeF obejmującego jednocześnie dwa zastosowania.
Dla ułatwienia rozróżnienia, certyfikaty obu typów będą miały w atrybucie CN (commonName)
dopisek „uwierzytelnianie” lub „offline”, zależnie od ich zastosowania.
Schemat 1. Rodzaje certyfikatu KSeF.
RODZAJE
CERTYFIKATU KSeF
TYP 1 (uwierzytelnianie) TYP 2 (offline)
Certyfikat jako środek uwierzytelnienia Certyfikat służący do wystawiania faktur
przy nawiązywaniu sesji interaktywnej w trybie OFFLINE - niezbędny do
lub wsadowej. opatrzenia faktury linkiem/kodem QR.
2.5.2. Uzyskanie certyfikatu KSeF w Module Certyfikatów i Uprawnień
WAŻNE
Podatnicy i osoby/podmioty przez nich uprawnione będą mogli występować o wydanie
certyfikatu KSeF od 1 listopada 2025 r.
Aby uzyskać certyfikat KSeF należy złożyć wniosek. Będzie to możliwe od 1 listopada 2025 r.
za pośrednictwem Modułu Certyfikatów i Uprawnień (MCU), który zostanie udostępniony w
domenie KSeF. MCU możliwi również nadawanie uprawnień użytkownikom przyszłego
systemu KSeF 2.0. Funkcjonalności MCU będą dostępne wyłącznie z poziomu przeglądarki, nie
będą dostępne z poziomu API.
41

---

O certyfikat KSeF bez dodatkowych warunków będą mogły/mogli wystąpić:
• osoby fizyczne zgłoszone w zawiadomieniu ZAW-FA,
• osoby fizyczne posiadające uprawnienia właścicielskie,
• podatnicy niebędący osobą fizyczną posiadający uprawnienia właścicielskie,
posługujący się pieczęcią elektroniczną do uwierzytelnienia w KSeF.
Konieczność ponownego nadania uprawnień w module MCU wystąpi w przypadku:
• osoby fizycznej, która nie została uprawniona na podstawie ZAW-FA w KSeF 1.0 do 31
października 2025 r.
• podmiotu, który otrzymał uprawnienia do KSeF do 31 października 2025 r.
Po ponownym nadaniu uprawnień w module MCU osoba fizyczna lub podmiot będą mogli
wystąpić o certyfikat KSeF a następnie go pobrać.
Aby wystąpić o wydanie certyfikatu trzeba będzie uwierzytelnić się w KSeF jako podatnik lub
osoba uprawniona np. za pomocą Podpisu zaufanego lub kwalifikowanego podpisu
elektronicznego lub kwalifikowanej pieczęci elektronicznej.
Generowanie certyfikatów w MCU jest rozwiązaniem tymczasowym przewidzianym na okres
od listopada 2025 r. do końca stycznia 2026 r. Od lutego 2026 r. funkcjonalność będzie
dostępna w KSeF 2.0 oraz w Aplikacji Podatnika KSeF 2.0. Uprawnienia nadane w MCU
zostaną przeniesione do KSeF 2.0, a więc i do Aplikacji Podatnika KSeF 2.0.
2.5.3. Okres ważności certyfikatu KSeF
Certyfikat KSeF będzie ważny nie dłużej niż 2 lata od:
• daty podanej we wniosku o wydanie certyfikatu KSeF lub
• od daty wydania certyfikatu KSeF (obsłużenia wniosku o wydanie certyfikatu KSeF),
jeśli we wniosku nie podano daty początkowej, od której ma być on ważny.
WAŻNE
Warto zadbać o wprowadzenie odpowiednich procedur zarządzania certyfikatami w firmie.
Należy również pamiętać o kontroli upływu terminów ważności certyfikatów KSeF i
wnioskowaniu o kolejny certyfikat przed utratą ważności poprzedniego.
42

---

Przykład 14. Określenie daty ważności certyfikatu KSeF (we wniosku wskazano datę początkową).
Podatnik 10 listopada 2025 r. występuje o wydanie certyfikatu KSeF (typu 1). Składa w tym
celu wniosek, w którym wskazuje, że datą początkową, od której ma być ważny certyfikat jest 1
lutego 2026 r. Wydanie certyfikatu nastąpiło 10 listopada 2025 r.
W związku ze wskazaniem przez podatnika we wniosku daty początkowej, od której ma być
ważny certyfikat KSeF, okres 2 lat będzie liczony od dnia 1 lutego 2026 r. , a nie od daty jego
wydania (10 listopada 2025 r.).
Przykład 15. Określenie daty ważności certyfikatu KSeF (we wniosku nie wskazano daty początkowej).
Podatnik 31 marca 2026 r. występuje o wydanie certyfikatu KSeF (typu 2). Składa w tym celu
wniosek, w którym nie wskazuje daty początkowej, od której ma być ważny certyfikat.
Obsłużenie wniosku nastąpiło 1 kwietnia 2026 r.
W związku z brakiem wskazania przez podatnika we wniosku daty początkowej, od której ma
być ważny certyfikat KSeF, okres 2 lat będzie liczony od daty wydania certyfikatu KSeF, czyli
od 1 kwietnia 2026 r.
Przykład 16. Określenie daty ważności certyfikatu KSeF (we wniosku nie wskazano daty początkowej).
Podatnik 15 lutego 2026 r. występuje o wydanie certyfikatu KSeF (typu 1). Składa w tym celu
wniosek, w którym wskazuje, że datą początkową, od której ma być ważny certyfikat jest 1
marca 2026 r. Wydanie certyfikatu nastąpiło 15 lutego 2026 r.
W związku ze wskazaniem przez podatnika we wniosku daty początkowej, od której ma być
ważny certyfikat KSeF, okres 2 lat będzie liczony od dnia 1 marca 2026 r. , a nie od daty jego
wydania (15 lutego 2026 r.). Warto przy tym zaznaczyć, że takiego certyfikatu nie da się użyć
przed datą początku jego ważności, tzn. uwierzytelnienie się nim nie będzie możliwe przed datą
i godziną wskazaną jako początek okresu ważności.
W kolejnym dniu, 16 lutego 2026 r. podatnik występuje o wydanie certyfikatu KSeF (typu 2).
Składa w tym celu wniosek, w którym nie wskazuje daty początkowej. Wydanie certyfikatu
nastąpiło 16 lutego 2026 r.
W związku z brakiem wskazania przez podatnika we wniosku daty początkowej, od której ma
być ważny certyfikat KSeF, okres 2 lat będzie liczony od daty jego wydania tj. dnia 16 listopada
2026 r.
43

---

2.5.4. Certyfikat dla osoby fizycznej lub podmiotu
Certyfikat KSeF będzie mógł być wydany osobie fizycznej identyfikowanej po numerze NIP (np.
jednoosobowa działalność gospodarcza) lub po numerze PESEL (np. pracownikowi firmy, pod
warunkiem, że będzie posiadała jakiekolwiek uprawnienie do korzystania z KSeF).
Ponadto, co istotne certyfikat będzie mógł być wydany podmiotowi niebędącemu osobą
fizyczną posiadającemu NIP np. spółce z o.o., po uwierzytelnieniu się za pomocą pieczęci
kwalifikowanej.
Sposób zarządzania certyfikatami w firmie może być kształtowany dowolnie w zależności od
potrzeb danej organizacji. Przykładowo, spółka po uwierzytelnieniu w KSeF pieczęcią
kwalifikowaną na NIP spółki, będzie mogła zawnioskować, a następnie pobrać wiele
certyfikatów wydanych na dane spółki (z uwzględnieniem funkcjonujących limitów dot. ilości
możliwych do wygenerowania certyfikatów KSeF), po czym udostępnić je swoim pracownikom.
W tej sytuacji, gdy fakturę wystawi osoba fizyczna posługująca się certyfikatem KSeF z
identyfikatorem podatkowym NIP spółki (wydanym na spółkę), w KSeF widoczne będą
wyłącznie dane spółki, a nie konkretnej osoby fizycznej, która fizycznie wystawiła tę fakturę.
Jeżeli natomiast certyfikaty zostaną wydane pracownikom spółki (na ich PESEL), to gdy fakturę
wystawi osoba uwierzytelniona takim certyfikatem, w KSeF widoczne będą dane tej osoby
fizycznej, która wystawiała tę fakturę, działając w imieniu spółki.
W przypadku osoby/podmiotu posiadającego kwalifikowany podpis/kwalifikowaną pieczęć
elektroniczną bez identyfikatora NIP i PESEL, certyfikat może być wydany na tzw. dane
unikalne powiązane z certyfikatem (tzw. odcisk palca podpisu) użytym do uwierzytelnienia.
2.5.5. Bezpieczeństwo posługiwania się certyfikatami KSeF
Certyfikaty KSeF są rodzajem elektronicznych poświadczeń tożsamości posiadacza, podobnie
jak certyfikaty kwalifikowane. Zawierają one dane osobowe wnioskującego lub dane podmiotu.
Z tego względu o certyfikat zawierający dane osoby fizycznej może wnioskować wyłącznie ta
osoba. I tylko ta osoba może go pobrać, a następnie się nim posługiwać.
WAŻNE
Niedopuszczalne jest udostępnienie certyfikatu KSeF wydanego na daną osobę fizyczną, innej
osobie fizycznej. Niedozwolone jest posłużenie się przez osobę fizyczną, certyfikatem KSeF
należącym do innej osoby fizycznej.
Jeśli chodzi o certyfikaty wydane na dane podmiotu np. spółki, to nie są one powiązane z
konkretnymi osobami, zatem odpowiedzialność za ich przekazywanie konkretnym
44

---

pracownikom i posługiwanie się nimi przy pracy w KSeF leży po stronie podmiotu. W takim
przypadku organizacja powinna zadbać o właściwą rejestrację i rozliczalność operacji
pobierania, przekazywania, wykorzystywania i unieważniania tych certyfikatów.
2.5.6. Limity dotyczące certyfikatów KSeF
Każdy uwierzytelniony użytkownik będzie miał możliwość wygenerowania:
• w przypadku osoby fizycznej, która posługuje się identyfikatorem podatkowym PESEL -
maksymalnie 2 aktywnych certyfikatów KSeF oraz 2 nowych - do użycia dopiero po
wygaśnięciu obecnego certyfikatu,
• w przypadku osoby fizycznej, która posługuje się identyfikatorem podatkowym NIP -
maksymalnie 100 certyfikatów wydanych na podstawie danych kwalifikowanego
certyfikatu podpisu oraz 100 nowych do użycia dopiero po wygaśnięciu aktualnych,
• w przypadku podmiotu niebędącego osobą fizyczną (identyfikator NIP) - co najwyżej
100 certyfikatów wydanych na podstawie danych kwalifikowanego certyfikatu pieczęci
oraz 100 nowych do użycia dopiero po wygaśnięciu aktualnych,
• w przypadku podmiotu, który uwierzytelnia się za pomocą certyfikatu, który nie
posiada identyfikatora NIP/PESEL (zgłoszony tzw. dane unikalne powiązane z
certyfikatem) - co najwyżej 2 aktywne oraz 2 nowe - do użycia dopiero po wygaśnięciu
obecnego certyfikatu.
Nowy certyfikat, o którym mowa wyżej będzie mógł być wydany na miesiąc przed upływem
okresu ważności najstarszego aktywnego certyfikatu.
Jak wskazano wyżej, w celu uzyskania nowego certyfikatu konieczne będzie uwierzytelnienie w
systemie (np. podpisem kwalifikowanym czy Podpisem Zaufanym). Podmiot/osoba
uwierzytelniona ważnym certyfikatem KSeF także będzie mogła wnioskować o wydanie
kolejnego certyfikatu.
Przykład 17. Sposób generowania certyfikatów KSeF i zarządzania certyfikatami w spółce.
Spółka z o. o. (NIP 9999999999) uwierzytelniła się w KSeF za pomocą kwalifikowanej pieczęci
elektronicznej, zawierającej NIP podatnika. Spółka jest siecią handlową, która posiada siedem
oddziałów zlokalizowanych w różnych częściach Polski. Faktury sprzedażowe wystawiane są
zawsze przez wyznaczonego pracownika danego oddziału (lub osobę ją zastępującą). W
związku z powyższym spółka zawnioskowała o wydanie certyfikatów KSeF typu 1. W celu
sprawowania kontroli nad procesem wystawiania faktur w firmie przyjęła zasadę, że jeden
certyfikat KSeF będzie wykorzystywany wyłącznie w ramach jednego oddziału.
45

---

Finalnie wydanych zostało siedem certyfikatów KSeF, z których każdy zawierał NIP spółki, ale
różniły się one między sobą nazwą własną:
• Nazwa pierwszego certyfikatu: „Certyfikat I – oddział A”
• Nazwa drugiego certyfikatu: „Certyfikat I – oddział B”
• Nazwa trzeciego certyfikatu: „Certyfikat I – oddział C”
• Nazwa czwartego certyfikatu: „Certyfikat I – oddział D”
• Nazwa piątego certyfikatu: „Certyfikat I – oddział E”
• Nazwa szóstego certyfikatu: „Certyfikat I – oddział F”
• Nazwa siódmego certyfikatu: „Certyfikat I – oddział G”.
Spółka udostępniła wydane certyfikaty wyznaczonym osobom. W opisanej sytuacji, w
przypadku, gdy np. fakturę w imieniu spółki z o. o. , po uwierzytelnieniu się w KSeF
certyfikatem o nazwie” Certyfikat I- oddział B” wystawi wyznaczony pracownik oddziału B lub
osoba, która ją zastępuje, w KSeF widoczne będą dane spółki, a nie konkretnej osoby fizycznej
(pracownika oddziału B).
Biorąc pod uwagę konieczność zapewnienia procesu wystawiania faktur w sposób ciągły,
również podczas potencjalnych problemów z siecią Internet czy na wypadek prac serwisowych
w KSeF, spółka zawnioskowała następnie o wydanie certyfikatów KSeF typu 2. W celu
sprawowania kontroli nad procesem wystawiania faktur w firmie, podobnie jak w przypadku
certyfikatów typu 2, przyjęła zasadę, że jeden certyfikat KSeF będzie wykorzystywany
wyłącznie w ramach jednego oddziału.
Finalnie wydanych zostało siedem certyfikatów KSeF, z których każdy zawierał NIP spółki, ale
różniły się one między sobą nazwą własną:
• Nazwa pierwszego certyfikatu: „Certyfikat II – oddział A”
• Nazwa drugiego certyfikatu: „Certyfikat II – oddział B”
• Nazwa trzeciego certyfikatu: „Certyfikat II – oddział C”
• Nazwa czwartego certyfikatu: „Certyfikat II – oddział D”
• Nazwa piątego certyfikatu: „Certyfikat II – oddział E”
• Nazwa szóstego certyfikatu: „Certyfikat II – oddział F”
• Nazwa siódmego certyfikatu: „Certyfikat II – oddział G”.
Spółka udostępniła wydane certyfikaty wyznaczonym osobom. W opisanej sytuacji, w
przypadku, gdy np. fakturę w trybie OFFLINE w imieniu spółki z o. o. będzie wystawiał
wyznaczony pracownik oddziału B, posłuży się certyfikatem spółki o nazwie „Certyfikat II -
oddział B”. Certyfikat wykorzysta do opatrzenia faktury kodem, dzięki czemu nabywca w
46

---

przypadku otrzymania faktury poza KSeF będzie miał możliwość weryfikacji czy fakturę w
trybie OFFLINE wystawiła osoba lub podmiot do tej czynności uprawniony.
Przykład 18. Sposób generowania certyfikatów KSeF i zarządzania certyfikatami w spółce.
Spółka cywilna (NIP 9999999999) prowadzi działalność usługową. Faktury sprzedażowe
wystawiane są zawsze przez pracownika działu księgowości (lub osobę ją zastępującą), którym
zostały nadane odpowiednie uprawnienia w KSeF. W związku z przyjętą wewnętrzną
procedurą, spółka przyjęła zasadę, iż nie będzie występować o wydanie certyfikatów na swoim
poziomie, lecz zrobią to bezpośrednio wyznaczeni pracownicy spółki. Tym samym księgowa
oraz osoba ją zastępująca uwierzytelnili się w KSeF za pomocą Podpisu Zaufanego, a następnie
zawnioskowali o wydanie certyfikatów KSeF obu typów (dla osoby fizycznej identyfikowanej
numerem PESEL).
W przypadku certyfikatów wydawanych na osoby fizyczne wykluczone jest ich udostępnianie
innym osobom fizycznym. W związku z powyższym księgowa jak również osoba ją zastępująca
będą posiadać odrębne, indywidualne certyfikaty KSeF, przypisane do konkretnej osoby
fizycznej. Finalnie wydane zostały cztery, następujące certyfikaty:
• Nazwa certyfikatu typu 1 dla księgowej: „Certyfikat I - Pracownik1”,
• Nazwa certyfikatu typu 2 dla księgowej: „Certyfikat II - Pracownik1”,
• Nazwa certyfikatu typu 1 dla osoby zastępującej: „Certyfikat I - Pracownik2”,
• Nazwa certyfikatu typu 2 dla osoby zastępującej: „Certyfikat II - Pracownik2”.
W opisanej sytuacji, w przypadku, gdy fakturę w imieniu spółki cywilnej po uwierzytelnieniu się
w KSeF certyfikatem o nazwie” „Certyfikat I- Pracownik1” wystawi księgowa, w KSeF widoczne
będą dane konkretnej osoby fizycznej (księgowej).
W przypadku, gdy fakturę w trybie OFFLINE w imieniu spółki wystawi księgowa, posłuży się
swoim certyfikatem o nazwie „Certyfikat II – Pracownik 1”. Certyfikat wykorzysta do
opatrzenia faktury kodem, dzięki czemu nabywca w przypadku otrzymania faktury poza KSeF
będzie miał możliwość weryfikacji czy fakturę w trybie OFFLINE wystawiła osoba lub podmiot
do tej czynności uprawniony.
Maksymalna liczba żądań wydania certyfikatów KSeF dla danego identyfikatora w okresie
ostatnich 30 dni nie może przekroczyć:
• 6 - dla certyfikatów indywidualnych wydawanych na numer PESEL,
• 300 - dla certyfikatów wydawanych na identyfikator podatkowy NIP,
47

---

• 6 - dla certyfikatów wydawanych na dane unikalne powiązane z certyfikatem
kwalifikowanego podpisu elektronicznego lub kwalifikowanej pieczęci elektronicznej.
Przykład 19. Działanie systemu przy przekroczeniu maksymalnej liczby żądań wydania certyfikatów KSeF.
Jak Kowalski (PESEL 11111111116), który nie prowadzi działalności gospodarczej, jest
pracownikiem firmy X, w której posiada uprawnienie do wystawiania faktur. 11 kwietnia 2026
r. uzyskał certyfikat KSeF (na numer PESEL), po czym go unieważnił. Czynności te powtórzył
jeszcze pięć razy w okresie 12-24 kwietnia 2026 r. Przy siódmej próbie uzyskania certyfikatu
KSeF, która miała miejsce 25 kwietnia 2026 r. , system zwrócił komunikat o przekroczeniu
dozwolonej liczbie złożonych żądań. Wnioskowanie o wydanie kolejnego certyfikatu będzie
więc możliwe najwcześniej po upływie 30 dni od dnia żądania wydania pierwszego certyfikatu
KSeF.
2.5.7. Certyfikat KSeF a zakres uprawnień
Certyfikaty KSeF to rozwiązanie elastyczne i dynamiczne. Dzięki nim proces wystawienia
faktury będzie szybki i prosty. Jeden certyfikat będzie można wykorzystać do pracy w różnych
kontekstach (tj. w ramach różnych podmiotów) i bez znaczenia dla jego ważności będą zmiany
w zakresie uprawnień posiadanych przez właściciela certyfikatu.
Uniemożliwienie użycia certyfikatu do uwierzytelnienia w systemie nastąpi jednak, gdy
odebrane zostaną wszystkie uprawnienia nadane na identyfikator (NIP lub PESEL) właściciela
certyfikatu.
Przykład 20. Wpływ zmiany zakresu posiadanych uprawnień na ważność certyfikatu KSeF.
Księgowa Anna Nowak (NIP 9999999999) prowadząca jednoosobową działalność
gospodarczą dysponuje certyfikatem KSeF typu 1 (do uwierzytelnienia), wydanym po
uwierzytelnieniu się w KSeF podpisem kwalifikowanym zawierającym jej identyfikator NIP.
Księgowa obsługuje kilka firm, które nadały jej uprawnienia w KSeF:
• Firma X nadała Annie Nowak uprawnienie w KSeF do wystawiania faktur i do dostępu
do faktur,
• Firma Y nadała Annie Nowak uprawnienie w KSeF do nadawania i odbierania
uprawnień w KSeF,
• Firma Z nadała Annie Nowak uprawnienie w KSeF do dostępu do faktur.
W związku z powyższym, po uwierzytelnieniu się w systemie certyfikatem KSeF w swoim
kontekście lub w kontekście firmy X, Y lub Z, Anna Nowak będzie mogła działać w KSeF w
obrębie posiadanych uprawnień.
48

---

Jeżeli po określonym czasie firma Z odbierze Annie Nowak uprawnienia, to posiadany przez nią
certyfikat KSeF nie ulegnie unieważnieniu. Podobnie będzie w przypadku, gdy Anna Nowak
zdobędzie za pewien czas nowego klienta – firmę N , która nada jej w KSeF np. uprawnienia do
wystawiania faktur i dostępu do faktur. Będzie ona mogła uwierzytelnić się w systemie przy
użyciu certyfikatu KSeF w kontekście firmy N i działać w zakresie posiadanych uprawnień.
Jeżeli jednak wszyscy klienci (firma X, Y, Z, N) odebraliby uprawnienia księgowej Annie Nowak,
wówczas będzie ona mogła uwierzytelnić się w systemie posiadanym certyfikatem KSeF
wyłącznie w swoim kontekście.
2.5.8. Działania na certyfikatach KSeF
Każda uwierzytelniona w systemie osoba fizyczna lub uwierzytelniony podmiot będzie mógł
wykonywać działania na swoich własnych certyfikatach. Możliwe będzie wyszukiwanie,
pobranie listy certyfikatów, pobranie aktywnych certyfikatów oraz ich unieważnienie. Nie
będzie możliwe wykonywanie jakichkolwiek operacji na certyfikatach należących do innych
osób fizycznych lub podmiotów.
Możliwe będzie wyszukanie i pobranie danych certyfikatu KSeF. Opcja ta dotyczy wyłącznie
certyfikatów wydanych uwierzytelnionemu użytkownikowi (osobie fizycznej/podmiotowi).
Użytkownik będzie mógł uzyskać informację na temat:
• numeru seryjnego certyfikatu,
• nazwy własnej,
• typu certyfikatu KSeF,
• identyfikatora podmiotu właściciela certyfikatu,
• nazwy właściciela certyfikatu,
• statusu,
• okresu ważności (od-do),
• daty ostatniego użycia.
API pozwoli również na wyszukiwanie certyfikatów KSeF według następujących kryteriów:
• numer seryjny certyfikatu,
• nazwa własna,
• typ certyfikatu KSeF,
• status (A – aktywny, Z-zablokowany, U – unieważniony, W-wygasły)
Status Z to status przejściowy pomiędzy statusem A - aktywny, a U – unieważniony.
• data wygaśnięcia.
49

---

Możliwe będzie także unieważnienie wcześniej wydanego certyfikatu. Aby wystąpić z takim
żądaniem konieczne będzie uwierzytelnienie się w systemie przy wykorzystaniu jednej z
dostępnych metod: Podpis Zaufany, podpis kwalifikowany, pieczęć kwalifikowana czy
certyfikat KSeF.
W przypadku unieważnienia certyfikatu KSeF typu 1, przy użyciu którego dana osoba lub
podmiot są aktualnie uwierzytelnieni w systemie, nastąpi przerwanie sesji.
2.5.9. Certyfikaty KSeF a tokeny
W okresie fakultatywnym jedną z metod uwierzytelnienia w systemie były tokeny.
Rozwiązanie to będzie funkcjonować do 31 grudnia 2026 r. 22
Od 1 lutego 2026 r. możliwe będzie korzystanie zarówno z certyfikatów KSeF jak i tokenów.
Docelowo od 1 stycznia 2027 r. z tych dwóch rozwiązań pozostaną wyłącznie certyfikaty KSeF.
Należy jednak zwrócić uwagę, że certyfikaty i tokeny nie są od strony funkcjonalnej
równoważne. Token zawiera w sobie uprawnienia podatnika, które są deklarowane w
momencie jego generowania. Certyfikaty KSeF nie są natomiast nośnikiem uprawnień.
Kluczowym założeniem certyfikatów KSeF (typ 1) będzie to, że stanowią one wyłącznie środek
uwierzytelnienia w systemie – podobnie jak np. podpis kwalifikowany.
Podsumowanie najważniejszych różnic oraz cech wspólnych tokenów i certyfikatów zawarto w
tabeli poniżej.
Tabela 3. Porównanie cech tokenów i certyfikatów KSeF.
CECHA TOKENA/CERTYFIKATU KSeF
TOKEN CERTYFIKAT KSeF
Czy można go wykorzystać do pracy w różnych NIE TAK
kontekstach?
Czy posiada okres ważności? NIE TAK
Czy istnieją ograniczenia co do ilości posiadanych NIE TAK
tokenów/certyfikatów KSeF?
Czy zawiera w sobie uprawnienia osoby TAK NIE
fizycznej/podmiotu generującego?
Czy jest możliwy do wygenerowania przez osobę TAK TAK
fizyczną?
22 Projektowany § 13 ust. 1 rozporządzenia w sprawie korzystania z KSeF.
Proces legislacyjny w toku: https://legislacja.rcl.gov.pl/projekt/12379252.
50

---

Czy jest możliwy do wygenerowania przez TAK TAK
podmiot niebędący osobą fizyczną?
Czy można się nim uwierzytelnić w sesji TAK TAK
interaktywnej? (dotyczy certyfikatu
typu 1)
Czy można się nim uwierzytelnić w sesji TAK TAK
wsadowej? (dotyczy certyfikatu
typu 1)
Czy jest unieważniany po zmianie zakresu NIE NIE
uprawnień osoby lub podmiotu, który go
wygenerował?
Czy można go unieważnić? TAK TAK
3. Uprawnienia do korzystania z KSeF
KSeF jest oparty na modelu poświadczeń, tzn., że wymagane jest uwierzytelnienie i autoryzacja
danej osoby lub podmiotu w systemie. Po uwierzytelnieniu się w systemie dana osoba lub
podmiot korzysta z KSeF w zakresie posiadanych przez siebie uprawnień.
3.1. Rodzaje uprawnień do korzystania z KSeF
Rozporządzenie w sprawie korzystania z KSeF23 określa precyzyjnie, kto dokładnie i w jakiej
roli występując (np. podatnika, osoby fizycznej wskazanej przez podatnika, przedstawiciela
członka GV, organu egzekucyjnego) może posiadać określony rodzaj uprawnienia.
Uprawnieniami do korzystania z KSeF, w myśl rozporządzenia są uprawnienia do:
• nadawania oraz odbierania uprawnień do korzystania z KSeF,
• wystawiania lub dostępu do faktur ustrukturyzowanych (ONLINE) i faktur, o których
mowa w art. 106nda ust. 1, art. 106nf ust. 1 i art. 106nh ust. 1 ustawy (tj. faktur
wystawianych w trybie OFFLINE),
• wystawiania faktur przez nabywcę towarów lub usług zgodnie z art. 106d ust. 1 ustawy
(w trybie samofakturowania),
• wystawiania faktur VAT RR i faktur VAT RR KOREKTA przy użyciu KSeF.
W oparciu o powyższe założenia prawne, stworzone zostały odpowiednie szczegółowe
uprawnienia systemowe, należą do nich w szczególności uprawnienia do:
• zarządzania uprawnieniami,
23 Proces legislacyjny w toku: https://legislacja.rcl.gov.pl/projekt/12379252.
51

---

• zarządzania jednostkami podrzędnymi,
• wystawiania faktur,
• dostępu do faktur,
• wystawiania faktur w trybie samofakturowania,
• wykonywania operacji egzekucyjnych,
• wystawiania faktur VAT RR,
• wystawiania faktur PEF,
• wykonywania operacji przedstawiciela podatkowego,
• zarządzania uprawnieniami w ramach podmiotu unijnego.
Ponadto w systemie wyróżnia się następujące uprawnienia techniczne do:
• przeglądania uprawnień (nadanych osobom fizycznym i podmiotom w kontekście
danego podatnika),
• przeglądania historii sesji (w kontekście danego podatnika np. w celu pobierania UPO).
Zarządzanie uprawnieniami
Uprawnienie do zarządzania uprawnieniami obejmuje nadawanie oraz odbieranie uprawnień
do korzystania z KSeF. Pozwala wyznaczać osoby lub podmioty, które będą korzystały z KSeF
w kontekście danego podatnika.
WAŻNE
Uprawnienie do zarządzania uprawnieniami (w tym do nadawania lub odbierania uprawnień do
korzystania z KSeF) jest jednym uprawnieniem. Nie jest możliwe nadanie uprawnienia
wyłącznie do nadawania uprawnień lub wyłącznie do odbierania uprawnień do korzystania z
KSeF. Ewentualny podział tych kompetencji w firmie, przedsiębiorca może wprowadzić
wyłącznie poprzez stworzenie odpowiednich procedur wewnętrznych.
Uprawnienie do zarządzania uprawnieniami posiada przypisane systemowo sam podatnik np.
jednoosobowa działalność gospodarcza, spółka, JST, GV. Może je również otrzymać np.:
• osoba fizyczna wskazana przez podatnika,
• osoba fizyczna wskazana przez osobę fizyczną zarządzającą uprawnieniami w ramach
danego podatnika.
W uprawnieniu do zarządzania uprawnieniami zawiera się także uprawnienie do
przeglądania uprawnień (nie musi być więc nadawane osobno).
52

---

Zarządzanie jednostkami podrzędnymi
Uprawnienie do zarządzania jednostkami podrzędnymi pozwala na nadawanie i odbieranie
uprawnień przedstawicielom (administratorom) poszczególnych jednostek podrzędnych JST,
członków GV oraz wydzielonych jednostek wewnętrznych działających w ramach danego
podatnika.
Uprawnienie do zarządzania jednostkami podrzędnymi posiada przypisane systemowo sam
podatnik np.:
• jednoosobowa działalność gospodarcza, spółka (tworząc jednostki wewnętrzne i
wyznaczając ich przedstawiciela (administratora)),
• JST, która posiada swoje jednostki podrzędne,
• GV, która składa się członków GV.
Uprawnienia te może posiadać także np. osoba fizyczna wskazana przez podatnika.
Wystawianie faktur
Uprawnienie do wystawiania faktur obejmuje zarówno wystawianie faktur
ustrukturyzowanych (ONLINE) jak i wystawianie faktur w trybie OFFLINE (tj. w trybie
offline24, w trybie offline – niedostępność KSeF oraz w trybie awaryjnym).
Uprawnienie do wystawiania faktur posiada (domyślnie) sam podatnik (w tym JST i GV).
Uprawnienie to może posiadać także np.:
• osoba fizyczna wskazana przez podatnika,
• osoba fizyczna wskazana przez osobę fizyczną zarządzającą uprawnieniami w ramach
danego podatnika,
• podmiot wskazany przez podatnika (np. biuro rachunkowe) oraz osoba fizyczna
wskazana przez ten podmiot,
• osoba fizyczna wskazana przez przedstawiciela (administratora) jednostki podrzędnej
JST, członka GV oraz jednostki wewnętrznej.
Dostęp do faktur
Uprawnienie do dostępu do faktur ustrukturyzowanych pozwala w szczególności na dostęp do
listy faktur danego podatnika oraz możliwość pobierania tych faktur z KSeF.
53

---

WAŻNE
Uprawnienie do wystawiania faktur oraz uprawnienie do dostępu do faktur w KSeF to dwa
odrębne uprawnienia od strony systemowej. Możliwe jest nadanie uprawnienia wyłącznie do
wystawiania faktur lub wyłącznie do dostępu do faktur. Uprawnienie do dostępu do faktur w
KSeF obejmuje dostęp do wszystkich faktur danego podatnika, w tym jego faktur
sprzedażowych jak i faktur zakupowych.
Wystawianie faktur w trybie samofakturowania
Uprawnienie do wystawiania faktur przez nabywcę towarów lub usług, zgodnie z art. 106d ust.
1 ustawy tj. w ramach procedury samofakturowania, posiada wskazany przez podatnika
nabywca towarów lub usług oraz podmioty uprawnione przez tego nabywcę do wystawiania
faktur ustrukturyzowanych. Tego typu faktury będą mogli wystawiać także np. pracownicy
nabywcy towarów lub usług, którym nadał on uprawnienie do wystawiania do faktur w KSeF.
Wykonywanie operacji egzekucyjnych
Wykonywanie operacji egzekucyjnych to uprawnienie które posiada komornik sądowy oraz
organ egzekucyjny. Uprawnienie to może otrzymać także osoba fizyczna bezpośrednio od
komornika lub organu egzekucyjnego bądź od osoby fizycznej uprawnionej do zarządzania
uprawnieniami w ich imieniu.
Wystawianie faktur VAT RR
Uprawnienie do wystawiania faktur VAT RR i faktur VAT RR KOREKTA przy użyciu KSeF
posiada nabywca produktów rolnych lub usług rolniczych (podatnik VAT czynny) wskazany
przez rolnika ryczałtowego. Tego typu faktury będą mogli wystawiać także np. pracownicy
nabywcy produktów rolnych lub usług rolniczych, którym nadał on uprawnienie do
wystawiania faktur w KSeF.
Szczegóły dotyczące zasad nadawania uprawnień do wystawiania faktur VAT RR i faktur VAT
RR KOREKTA przy użyciu KSeF zostały omówione kompleksowo w cz. III Podręcznika KSeF
2.0.
Wystawianie faktur PEF
Uprawnienie do wystawiania faktur PEF (tj. faktur w zamówieniach publicznych) jest
szczególnym rodzajem uprawnienia do wystawiania faktur. W tym bowiem przypadku
wystawcą jest dostawca usług Peppol, który po zarejestrowaniu się w KSeF i nadaniu mu przez
podatników odpowiednich uprawnień będzie przesyłał faktury ustrukturyzowane do KSeF w
imieniu tych podatników.
54

---

Wykonywanie operacji przedstawiciela podatkowego
Wykonywanie operacji przedstawiciela podatkowego jest szczególnym rodzajem uprawnienia
do wystawiania faktur w imieniu podatnika. Przedstawiciel posiada w KSeF uprawnienia
analogiczne jak sam podatnik. Podatnicy mogą nadać mu uprawnienie do wystawiania faktur
jako przedstawiciel podatkowy (wówczas jego dane w fakturze zostaną zawarte w elemencie
PodmiotUpowazniony). Przedstawiciel będzie miał także dostęp do tych faktur w KSeF.
Przedstawiciel może delegować to uprawnienie np. na osobę fizyczną.
3.2. Nadawanie uprawnień do korzystania z KSeF?
Zgodnie z art. 106nb ustawy z KSeF korzystają:
• podatnik (np. jednoosobowa działalność gospodarcza, spółka akcyjna, JST),
• podmioty wskazane przez podatnika (np. biuro rachunkowe),
• komornik, organ egzekucyjny oraz osoby fizyczne wskazane przez te podmioty,
• osoby fizyczne wskazane w zawiadomieniu (ZAW-FA),
• podmioty inne niż wymienione wyżej, wskazane przez osoby fizyczne korzystające z
KSeF, jeżeli prawo do wskazywania innego podmiotu wynika z uprawnień nadanych
tym osobom fizycznym.
Nadawanie lub odbieranie uprawnień do korzystania z KSeF odbywa się:
• papierowo lub elektronicznie - poprzez złożenie zawiadomienia ZAW-FA o nadaniu lub
odebraniu uprawnień do korzystania z KSeF (wyłącznie w określonych sytuacjach),
• elektronicznie - korzystając z :
o komercyjnych programów finansowo-księgowych, pod warunkiem, że zostały
one zintegrowane z API KSeF 2.0,
o za pomocą bezpłatnego narzędzia oferowanego przez Aplikacji Podatnika KSeF 2.0.
Decyzja o wyborze optymalnego narzędzia do zarządzania uprawnieniami należy do podatnika.
3.2.1. Podatnicy będący osobami fizycznymi
Podatnik będący osobą fizyczną nie musi dopełniać żadnych formalności ani nic zgłaszać do
urzędu skarbowego, aby uwierzytelnić się w KSeF. Uprawnienia do korzystania z KSeF są
przypisane do tej osoby automatycznie w KSeF, dlatego są one nazywane „uprawnieniami
właścicielskimi”.
55

---

WAŻNE
Uprawnienia właścicielskie w KSeF są to uprawnienia przypisywane automatycznie,
systemowo do identyfikatora podatkowego NIP podatnika. Obejmują w szczególności
uprawnienie do wystawiania faktur, dostępu do faktur, zarządzania uprawnieniami,
zarządzania jednostkami podrzędnymi oraz uprawnienia techniczne do przeglądania historii
sesji oraz przeglądania uprawnień. Uprawnień właściciela nie można odebrać.
Osoba fizyczna prowadząca działalność gospodarczą na gruncie ustawy o VAT może korzystać
z systemu uwierzytelniając się np. Podpisem Zaufanym lub kwalifikowanym podpisem
elektronicznym. Po uwierzytelnieniu się w systemie może korzystać z KSeF samodzielnie lub
nadawać uprawnienia do korzystania z KSeF innym osobom lub podmiotom. Odbywa się to w
sposób elektroniczny.
WAŻNE
Osoba fizyczna nie składa zawiadomienia ZAW-FA w celu wyznaczenia osoby fizycznej, która
w jej imieniu będzie korzystała z KSeF.
Jedynym wyjątkiem, w którym osobą składającą zawiadomienie ZAW-FA będzie osoba
fizyczna jest przypadek zgłoszenia przez nią danych unikalnych jej własnego podpisu
elektronicznego.
3.2.2. Podatnicy niebędący osobami fizycznymi
Podatnicy niebędący osobami fizycznymi (w szczególności spółki, JST, GV) lub podmioty
niebędące osobami fizycznymi (np. fundacje) posiadający elektroniczną pieczęć kwalifikowaną
nie muszą składać w urzędzie skarbowym żadnych dodatkowych dokumentów. Po
uwierzytelnieniu się w systemie taki podatnik ma już przypisany pełen zakres uprawnień
właścicielskich (przypisanych do identyfikatora podatkowego NIP podatnika).
W przypadku podatników i podmiotów nieposiadających możliwości uwierzytelnienia się za
pomocą kwalifikowanej pieczęci elektronicznej, nadawanie lub odbieranie uprawnień do
korzystania z KSeF jest dokonywane przez złożenie zawiadomienia o nadaniu lub odebraniu
uprawnień do korzystania z KSeF (ZAW-FA) do właściwego naczelnika urzędu skarbowego.
W przypadku organu egzekucyjnego, zawiadomienie jest składane obowiązkowo, niezależnie
czy podmiot ten posiada możliwość uwierzytelnienia się w systemie za pomocą kwalifikowanej
pieczęci elektronicznej.
56

---

Schemat 2. Nadawanie uprawnień poprzez zawiadomienie ZAW-FA.
FORMA PRAWNA PODATNIKA/PODMIOTU
PODATNIK/PODMIOT
PODATNIK OSOBA
NIEBĘDĄCY OSOBĄ ORGAN EGZEKUCYJNY
FIZYCZNA
FIZYCZNĄ
BRAK ZŁOŻENIA
CZY POSIADA
ZAWIADOMIENIA ZAW-FA
ELEKTRONICZNĄ
UPRAWNIENIA PIECZĘĆ
NADAWANE SĄ KWALIFIKOWANĄ?
ELEKTRONICZNIE
TAK NIE
BRAK ZŁOŻENIA
Z AWIADOMIENIA ZAW-FA
ZŁOŻENIE ZAWIADOMIENIA
ZAW-FA
UPRAWNIENIA NADAWANE SĄ
ELEKTRONICZNIE
3.2.3. Zawiadomienie ZAW-FA
Zawiadomienie ZAW-FA jest składane:
• papierowo – osobiście lub pocztą, lub
• elektronicznie – np. poprzez ePUAP bądź jako załącznik do pisma ogólnego w e-
Urzędzie Skarbowym (pamiętając, że w imieniu spółki zawiadomienie mogą podpisać
wyłącznie osoby uprawnione do jej reprezentacji w liczbie wymaganej dla danego
podmiotu).
57

---

Poprzez ZAW-FA, do korzystania z KSeF, może być uprawniona tylko jedna osoba fizyczna.
Dalsze uprawnienia osoba fizyczna wskazana w ZAW-FA może nadawać elektronicznie (np. za
pomocą Aplikacji Podatnika KSeF).
WAŻNE
Osobą uprawnioną w ZAW-FA może być dowolna osoba fizyczna wskazana przez podatnika
niebędącego osobą fizyczną/podmiot niebędący osobą fizyczną. Nie musi być to osoba fizyczna
reprezentująca dany podmiot (np. zgodnie z wpisem w KRS).
Wzór zawiadomienia o nadaniu lub odebraniu uprawnień do korzystania z KSeF w wersji ZAW-
FA(3) określa załącznik do rozporządzenia w sprawie korzystania z KSeF24.
WAŻNE
Zawiadomienie ZAW-FA może być złożone także w przypadku JST lub GV, jeśli podatnik ten
nie posiada możliwości uwierzytelnienia się za pomocą kwalifikowanej pieczęci elektronicznej.
Zawiadomienie ZAW-FA nie ma zastosowania do nadawania lub odbierania uprawnień do
korzystania z KSeF w przypadku:
• samorządowej jednostki budżetowej, samorządowego zakładu budżetowego, urzędu
gminy, starostwa powiatowego lub urzędu marszałkowskiego,
• członków GV,
• zakładu (oddziału) osoby prawnej bądź innej wyodrębnionej jednostki wewnętrznej
podatnika (zwanej w dalszej części dokumentu „jednostką wewnętrzną”).
W przypadku wskazania w zawiadomieniu ZAW-FA osoby fizycznej uprawnionej do
korzystania z KSeF w imieniu podatnika niebędącego osobą fizyczną lub podmiotu niebędącego
osobą fizyczną zostanie jej przypisany poniższy zakres uprawnień:
• zarządzanie uprawnieniami,
• wystawianie faktur,
• dostęp do faktur,
• zarządzanie jednostkami podrzędnymi,
24 Proces legislacyjny w toku: https://legislacja.rcl.gov.pl/projekt/12379252.
58

---

• operacje egzekucyjne (tylko dla podmiotów, które wskazały status „organ egzekucyjny”
w ZAW-FA).
Dodatkowo osoba fizyczna będzie posiadała uprawnienia techniczne do:
• przeglądania uprawnień,
• przeglądania historii sesji.
Zmiana osoby fizycznej uprawnionej w ZAW-FA na inną osobę fizyczną
W celu zmiany osoby fizycznej uprawnionej „A” na inną osobę fizyczną uprawnioną „B”, należy
najpierw złożyć ZAW-FA wskazując cel „2. odebranie uprawnień” (osobie fizycznej „A”), a
następnie złożyć kolejne zawiadomienie ZAW-FA, celem „1. nadanie uprawnień” (osobie
fizycznej „B”).
Zmiana osoby fizycznej uprawnionej „A” na osobę fizyczną uprawnioną „B” nie skutkuje
odebraniem uprawnień wszystkim osobom uprawnionym przez osobę fizyczną „A”.
Nie jest możliwe wskazanie w jednym zawiadomieniu ZAW-FA np. dwóch osób fizycznych
uprawnionych do korzystania z KSeF. Osoba wskazana w ZAW-FA może jednak nadawać
dalsze uprawnienia (kolejnym osobom) drogą elektroniczną w ramach systemu (np. poprzez
Aplikację Podatnika KSeF lub poprzez komercyjne programy za pośrednictwem API KSeF).
Potwierdzenie wprowadzenia danych z ZAW-FA do systemu
Aby uprawnienia nadawane za pośrednictwem zawiadomienia ZAW-FA zaczęły działać,
konieczne jest wprowadzenie ich do systemu przez pracownika właściwego urzędu
skarbowego. Pracownik w pierwszej kolejności zweryfikuje zawiadomienie pod względem
formalnym, w szczególności czy zostało ono podpisane przez odpowiednią liczbę osób
uprawnionych do reprezentacji. W razie uzasadnionych wątpliwości lub błędów w
wypełnionym zawiadomieniu pracownik urzędu skarbowego podejmie kontakt z podatnikiem
celem ich wyjaśnienia.
Zawiadomienie jest wprowadzane do systemu niezwłocznie po jego otrzymaniu.
W zawiadomieniu ZAW-FA znajdują się m.in. obowiązkowe pola, w których wskazuje się:
• adres e-mail podatnika lub podmiotu, który nadaje lub odbiera uprawnienia,
• adres e-mail osoby fizycznej uprawnionej, której są nadawane lub odbierane
uprawnienia.
Na wskazane wyżej adresy e-mail są wysyłane powiadomienia o nadaniu lub odebraniu
uprawnień (tj. po wprowadzeniu przez pracownika urzędu skarbowego danych z
59

---

zawiadomienia ZAW-FA do systemu). Poniżej znajduje się przykładowa wiadomość e-mail,
generowana przez system.
Przykład 21. Potwierdzenie (w formie e-mail) wprowadzenia danych z zawiadomienia ZAW-FA do systemu.
Przykład 22. Elementy potwierdzenia e-mail.
Powiadomienie e-mail składa się z następujących elementów:
1. – dane dotyczące daty złożenia zawiadomienia oraz numeru wniosku (nadanego przez
system),
60

---

2. – dane udzielającego uprawnienie: rodzaj podmiotu składającego zawiadomienie oraz jego
identyfikator podatkowy – są to dane wynikające ze złożonego zawiadomienia (część B:1 pole
nr 7 „rodzaj podmiotu” oraz pole nr 1 „identyfikator podatkowy NIP podatnika lub podmiotu”),
3. – dane uprawnionego: identyfikator podatkowy osoby uprawnionej – są to dane wynikające
ze złożonego zawiadomienia (część C:1 pole nr 12 „identyfikator podatkowy NIP/numer
PESEL”),
4. – zakres zawiadomienia wynikający ze złożonego zawiadomienia (część A, pole nr 6 „cel
złożenia formularza”),
5. – nazwa urzędu skarbowego – to nazwa właściwego urzędu skarbowego, do którego zostało
złożone zawiadomienie (nazwa wskazana w części A, pole nr 5 zawiadomienia „właściwy
naczelnik urzędu skarbowego”),
6. – informacja, że wiadomość e-mail została wygenerowana automatycznie wraz z
pouczeniem, aby na nią nie odpowiadać.
Zgłoszenie danych unikalnych podpisu przez osobę fizyczną na ZAW-FA
WAŻNE
Składającym zawiadomienie ZAW-FA może być osoba fizyczna, wyłącznie w jednym
przypadku, tj., gdy osoba ta chce zgłosić dane unikalne powiązane z jej kwalifikowanym
podpisem elektronicznym, niezawierającym numeru identyfikacji podatkowej (NIP) i numeru
PESEL.
W takiej sytuacji podatnik wymieniony w części „B” zawiadomienia ZAW-FA, wskaże w części
„A”, w polu 6, pozycję 4 „zgłoszenie danych unikalnych powiązanych z certyfikatem
kwalifikowanego podpisu elektronicznego lub kwalifikowanej pieczęci elektronicznej
podatnika”. Dane unikalne podpisu wskazuje w części „D” zawiadomienia ZAW-FA. Nie
wypełnia natomiast części „C” zawiadomienia, ponieważ nie jest to nadanie uprawnień innej
osobie fizycznej, lecz zgłoszenie danych unikalnych własnego podpisu.
W związku z powyższym, w mailu potwierdzającym wprowadzenie ZAW-FA do systemu przez
pracownika urzędu skarbowego, nie będą zawarte dane osoby uprawnionej.
61

---

Przykład 23. Potwierdzenie (w formie e-mail) wprowadzenia danych z zawiadomienia ZAW-FA do systemu.
Jak wypełnić zawiadomienie ZAW-FA?
Zawiadomienie ZAW-FA należy wypełnić w sposób dokładny i staranny. Aby zawiadomienie
zostało wypełnione prawidłowo należy stosować się do poniższych wskazówek.
Zawiadomienie wypełnia się dużymi, drukowanymi literami.
W przypadku niekompletnego uzupełnienia zawiadomienia lub wskazania w nim danych, które
budzą wątpliwości, pracownik urzędu skarbowego wprowadzający dane z zawiadomienia do
systemu, może podjąć kontakt z podatnikiem celem ich wyjaśnienia.
Grafika 1. Nagłówek oraz cz. A zawiadomienia ZAW-FA.
62

---

W zawiadomieniu ZAW-FA w pierwszej kolejności należy wskazać identyfikator podatkowy
NIP podatnika lub podmiotu w polu nr 1. Następnie w części „A” zawiadomienia „MIEJSCE I
CEL SKŁADANIA”:
• w polu nr 5 należy wskazać właściwego naczelnika urzędu skarbowego,
• w polu nr 6 należy podać cel złożenia formularza, zaznaczając właściwy kwadrat:
o 1 - „nadanie uprawnień” – przez które należy rozumieć wskazanie osoby
fizycznej uprawnionej do korzystania z KSeF. Wskazanie kolejnej osoby
fizycznej uprawnionej w części C jest możliwe dopiero po odebraniu uprawnień
osobie fizycznej uprzednio wskazanej. Dalsze uprawnienia (np. dla kolejnych
osób fizycznych) nadawane są już elektronicznie w KSeF; lub
o 2 – „odebranie uprawnień” – przez które należy rozumieć odebranie
uprawnień, które były nadane wcześniej za pośrednictwem ZAW-FA określonej
osobie fizycznej oraz odebranie uprawnień nadanych na dane unikalne
powiązane z certyfikatami, które zostały uprawnione przez tę osobę fizyczną w
kontekście podatnika, którego dotyczy ZAW-FA. Opcja 2 – „odebranie
uprawnień” nie dotyczy przypadku, gdy podatnik chce odebrać uprawnienia
wszystkim osobom uprawnionym w jego kontekście; lub
o 3 – „odebranie wszelkich nadanych uprawnień”, w takim przypadku nie
wypełnia się części C,
Odebranie wszelkich nadanych uprawnień oznacza:
 odebranie wszystkich uprawnień za wyjątkiem uprawnień właścicielskich,
niezależnie czy zostały nadane za pośrednictwem API KSeF (elektronicznie)
czy poprzez zawiadomienie ZAW-FA,
 odebranie uprawnień wszystkim osobom fizycznym i podmiotom, w tym
także osobom i podmiotom działającym w ramach jednostek podrzędnych
JST i członków GV,
 odwołanie wszystkich zgłoszonych danych unikalnych powiązanych z
certyfikatem kwalifikowanego podpisu elektronicznego jak i danych
unikalnych powiązanych z certyfikatem pieczęci kwalifikowanej
zgłoszonych za pośrednictwem API KSeF (elektronicznie) czy poprzez
zawiadomienie ZAW-FA,
 odebranie uprawnień osobom fizycznym i podmiotom uprawnionym w
jednostkach wewnętrznych działających w ramach danego podatnika.
63

---

WAŻNE
Decyzja o wyborze opcji 3 - „odebranie wszelkich nadanych uprawnień”
powinna być świadoma i przemyślana. Skutkiem zaznaczenia tej opcji jest
„wyczyszczenie” w systemie wszystkich funkcjonujących w ramach danego
podatnika uprawnień. Po tej operacji konieczne więc będzie zbudowanie
uprawnień w KSeF w danej firmie od początku.
o 4 – „zgłoszenie danych unikalnych powiązanych z certyfikatem
kwalifikowanego podpisu elektronicznego lub kwalifikowanej pieczęci
elektronicznej podatnika” – jest to opcja, którą należy zaznaczyć w przypadku
zgłaszania:
 danych unikalnych powiązanych z certyfikatem kwalifikowanego podpisu
elektronicznego, w przypadku, gdy ten certyfikat nie zawiera numeru
identyfikacji podatkowej (NIP) i numeru PESEL podatnika będącego osobą
fizyczną wymienioną w części B (tzw. odcisk palca certyfikatu podpisu
kwalifikowanego) lub
 danych unikalnych powiązanych z certyfikatem kwalifikowanej pieczęci
elektronicznej, w przypadku, gdy ten certyfikat nie zawiera numeru
identyfikacji podatkowej (NIP) podatnika, którą będzie się posługiwała
osoba działająca w imieniu podatnika niebędącego osobą fizyczną,
wymienionego w części B (tzw. odcisk palca pieczęci kwalifikowanej).
Dane unikalne wyznaczane są z certyfikatu po użyciu funkcji skrótu
kryptograficznego opartej na algorytmie SHA-256.
WAŻNE
Zgłoszenie danych unikalnych najczęściej będzie dotyczyło podatników
zagranicznych, którzy posiadają podpis kwalifikowany lub pieczęć
kwalifikowaną wydane w innym kraju (bez NIP i PESEL). Tacy podatnicy są
co do zasady wyłączeni z obowiązkowego KSeF, lecz mogą wystawiać
faktury w tym systemie dobrowolnie. Aby mogli uwierzytelnić się w
systemie podpisem zagranicznym/pieczęcią zagraniczną muszą zgłosić
jego/jej dane unikalne w zawiadomieniu ZAW-FA.
64

---

Grafika 2. Cz. B zawiadomienia ZAW-FA.
W części „B” zawiadomienia „DANE PODATNIKA LUB PODMIOTU, KTÓRY SKŁADA
ZAWIADOMIENIE”:
• w sekcji B.1 należy wskazać dane identyfikacyjne podatnika lub podmiotu, który składa
zawiadomienie tj.:
o rodzaj podmiotu w polu nr 7:
1 - podmiot niebędący osobą fizyczną (np. w przypadku spółki),
2 – organ egzekucyjny (w tym przypadku zaznacza się również kwadrat
„podmiot niebędący osobą fizyczną”),
3 - osoba fizyczna (wyłącznie w przypadku zgłaszania danych unikalnych
powiązanych z certyfikatem kwalifikowanego podpisu elektronicznego i
wyznaczonych z tego certyfikatu po zastosowaniu funkcji skrótu
kryptograficznego opartej na algorytmie SHA-256, w przypadku, gdy ten
certyfikat nie zawiera numeru identyfikacji podatkowej (NIP) lub numeru PESEL
podatnika będącego osobą fizyczną (zgłoszenie tzw. odcisku palca podpisu
kwalifikowanego)).
o w polu nr 8 w sekcji B:1 należy wskazać nazwę pełną podatnika lub podmiotu,
który składa zawiadomienie (dotyczy podatnika niebędącego osobą fizyczną lub
podmiotu niebędącego osobą fizyczną) lub jego nazwisko i pierwsze imię
(dotyczy podmiotu będącego osobą fizyczną),
• w sekcji B.2 wskazuje się dane kontaktowe podatnika lub podmiotu, który składa
zawiadomienie ZAW-FA:
o w polu nr 9 - numer telefonu (opcjonalnie),
o w polu nr 10 – adres e-mail (obowiązkowo); adres e-mail wypełnia się
obowiązkowo, ponieważ podatnik lub podmiot składający zawiadomienie na
65

---

podany adres e-mail otrzyma informację o nadaniu lub odebraniu uprawnień do
korzystania z KSeF.
Grafika 3. Cz. C zawiadomienia ZAW-FA.
W części „C” zawiadomienia:
• w sekcji C.1 należy wskazać dane identyfikacyjne osoby fizycznej uprawnionej do
korzystania z KSeF tj.:
o w polu nr 11 – zaznacza się właściwy rodzaj identyfikatora podatkowego:
• 1 - identyfikator podatkowy NIP, lub
• 2 - numer PESEL, lub
• 3 - brak identyfikatora (dotyczy nierezydenta, który nie posiada
identyfikatora podatkowego NIP ani numeru PESEL),
o w polu nr 12 - identyfikator podatkowy NIP lub numer PESEL (za wyjątkiem
przypadku, gdy w polu 11 zaznaczono „3. brak identyfikatora”),
o w polu nr 13 - nazwisko, a w polu nr 14 - pierwsze imię,
o w polu nr 15 - datę urodzenia, w polu nr 16 - rodzaj dokumentu,
potwierdzającego tożsamość, w polu nr17 - numer i serię dokumentu
potwierdzającego tożsamość oraz w polu nr 18 - kraj wydania dokumentu
potwierdzającego tożsamość.
Pola od nr 15 do nr 18 dotyczą nierezydenta, który nie posiada identyfikatora
podatkowego NIP ani numeru PESEL.
• w sekcji C.2 wskazuje się dane kontaktowe osoby fizycznej uprawnionej:
66

---

o w polu nr 19 - numer telefonu (opcjonalnie),
o w polu nr 20 - adres e-mail (obowiązkowo), ponieważ osoba fizyczna
uprawniona na ten adres otrzyma informację o nadaniu lub odebraniu jej
uprawnień do korzystania z KSeF.
Grafika 4. Cz. D zawiadomienia ZAW-FA.
Cz. D wypełnia się w przypadku zgłaszania danych unikalnych powiązanych z certyfikatem
kwalifikowanego podpisu elektronicznego lub kwalifikowanej pieczęci elektronicznej i
wyznaczonych z tego certyfikatu po użyciu funkcji skrótu kryptograficznego opartej na
algorytmie SHA-256, niezawierających numeru identyfikacji podatkowej (NIP) i numeru PESEL
(zgłoszenie tzw. odcisku palca podpisu kwalifikowanego lub pieczęci kwalifikowanej), gdy:
• w polu nr 6 zaznaczono „zgłoszenie danych unikalnych powiązanych z certyfikatem
kwalifikowanego podpisu elektronicznego lub kwalifikowanej pieczęci elektronicznej
podatnika”; w takim przypadku nie wypełnia się części C (ponieważ zgłoszenie danych
unikalnych dotyczy samego podatnika); albo
• w polu nr 6 zaznaczono „nadanie uprawnień”, a osoba uprawniona do korzystania z
KSeF wymieniona w części C nie posiada numeru identyfikacji podatkowej (NIP) i
numeru PESEL oraz posiada wyłącznie kwalifikowany podpis elektroniczny
niezawierający numeru identyfikacji podatkowej (NIP) i numeru PESEL, albo
• w polu nr 6 zaznaczono „nadanie uprawnień”, a osoba uprawniona do korzystania z
KSeF wymieniona w części C posiada wyłącznie kwalifikowany podpis elektroniczny
niezawierający numeru identyfikacji podatkowej (NIP) i numeru PESEL.
67

---

Grafika 5. Cz. E zawiadomienia ZAW-FA.
W części „E” zawiadomienia należy zawrzeć podpis podatnika lub podmiotu/osoby
reprezentującej. W przypadku pierwszej osoby podaje się:
▪ w polu nr 22 – nazwisko,
▪ w polu nr 23 – pierwsze imię,
▪ w polu nr 24 – stanowisko/funkcję,
▪ w polu nr 25 – podpis.
Dane i podpisy pozostałych osób uprawnionych do reprezentacji i ustanowienia osoby
uprawnionej do korzystania z KSeF podaje się odpowiednio w sekcjach od 2 do 4 (pola od nr 26
do nr 37).
W przypadku reprezentacji wieloosobowej (powyżej 4 osób) pozostałych uprawnionych do
reprezentowania i ustanowienia osoby uprawnionej do korzystania z KSeF należy wymienić w
dodatkowym formularzu ZAW-FA.
WAŻNE
Pełnomocnictwo ogólne (PPO-1) nie upoważnia pełnomocnika do podpisania zawiadomienia
ZAW-FA w imieniu podatnika.
Odebranie uprawnień osobie fizycznej wskazanej w zawiadomieniu ZAW-FA
Odebranie uprawnień osobie fizycznej wskazanej w zawiadomieniu ZAW-FA jest możliwe:
• poprzez ponowne złożenie zawiadomienia ZAW-FA, z celem złożenia w polu nr 6 –
„odebranie uprawnień” lub
68

---

• w przypadku gdy poza osobą fizyczną wskazaną w ZAW-FA uprawnienie do
zarządzania uprawnieniami w ramach danego podatnika miała jeszcze co najmniej
jedna osoba fizyczna (której uprawnienie nadała elektronicznie osoba fizyczna
wskazana w zawiadomieniu ZAW-FA) osoba ta może odebrać uprawnienie osobie
wskazanej w ZAW-FA.
Odebranie danej osobie fizycznej uprawnienia do zarządzania uprawnieniami nie powoduje
automatycznej utraty uprawnień nadanych innym osobom przez tę osobę.
Oznacza jednak także odebranie uprawnień nadanych na dane unikalne podpisów, które
zostały uprawnione przez tę osobę, w kontekście podatnika, którego dotyczy ZAW-FA.
3.3. Modele uprawnień w KSeF
W KSeF wyróżnia się kilka modeli uprawnień: model standardowy uprawnień, model
uprawnień dedykowany JST i GV, model uprawnień wykorzystujący identyfikator wewnętrzny
(tzw. IDWew), model uprawnień dotyczący samofakturowania w KSeF oraz dedykowany
podmiotom szczególnym takim jak przedstawiciel podatkowy, komornik sądowy i organ
egzekucyjny, model uprawnień umożliwiający wystawianie faktur PEF. Poniżej przedstawiono
kluczowe założenia poszczególnych modeli uprawnień wraz z praktycznymi przykładami
obrazującymi ich faktyczne funkcjonowanie.
3.3.1. Standardowy model uprawnień
Uprawnienia bezpośrednie
Standardowy model uprawnień w KSeF dotyczy podatnika (np. jednoosobowej działalności
gospodarczej lub spółki). Podatnik po uwierzytelnieniu się w KSeF w swoim kontekście, jak
wskazano wcześniej, posiada pełen zakres uprawnień właścicielskich. Może wystawiać faktury,
posiada do nich dostęp, może także nadawać i odbierać uprawnienia innym osobom lub
podmiotom, które będą działały w systemie w jego imieniu.
Podatnik może nadać osobie fizycznej m.in. uprawnienie do:
• zarządzania uprawnieniami (w tym zawiera się uprawnienie do przeglądania
uprawnień),
• wystawiania faktur,
• dostępu do faktur.
W przypadku gdy osoba fizyczna wskazana przez podatnika otrzymała uprawnienie do
zarządzania uprawnieniami, wówczas może delegować swoje uprawnienia na inne osoby
69

---

fizyczne lub podmioty (elektronicznie), będąc uwierzytelnioną w systemie w kontekście tego
podatnika.
Uprawnienia są przypisane zawsze do konkretnej osoby fizycznej bezpośrednio
identyfikowanej po numerze NIP lub numerze PESEL lub zarejestrowanych danych unikalnych
powiązanych z certyfikatem kwalifikowanego podpisu elektronicznego.
Przykład 24. Przykładowy przebieg procesu nadawania uprawnień w modelu standardowym.
OSOBA FIZYCZNA OSOBA FIZYCZNA
1 2
PODATNIK X
(KSIĘGOWA Y) (PRACOWNIK)
KSIĘGOWEJ „Y”
Opis procesu:
1 - podatnik X (osoba fizyczna prowadząca działalność gospodarczą) posiada pełen zakres
uprawnień do korzystania z KSeF tj. uprawnienia właścicielskie (w tym uprawnienie do
nadawania i odbierania uprawnień), uwierzytelnia się w KSeF podpisem kwalifikowanym,
nadaje uprawnienie do wystawiania faktur oraz do dostępu do faktur osobie fizycznej - swojej
księgowej Y;
2 - w związku z tym, że księgowej Y nie zostało nadane uprawnienie do nadawania i odbierania
uprawnień, nie może ona dalej nadawać uprawnień kolejnym osobom (np. swoim pracownikom)
do nadawania i odbierania uprawnień, wystawiania faktur w imieniu podatnika lub dostępu do
jego faktur – w imieniu podatnika X. Osoba fizyczna uprawniona przez podatnika (księgowa Y)
na podstawie otrzymanych uprawnień od podatnika X, po uwierzytelnieniu się w systemie w
kontekście podatnika X, może wyłącznie wystawiać faktury w imieniu tego podatnika oraz
posiadać dostęp do jego faktur.
Przykład 25. Przykładowy przebieg procesu nadawania uprawnień w modelu standardowym.
OSOBA FIZYCZNA
(PRACOWNIK 1)
OSOBA FIZYCZNA
PODATNIK X 1
(KSIĘGOWA Y) OSOBA FIZYCZNA
2 (PRACOWNIK 2)
70

---

Opis procesu:
1 - podatnik X (osoba fizyczna prowadząca działalność gospodarczą) posiada pełen zakres
uprawnień do korzystania z KSeF tj. uprawnień właścicielskich (w tym uprawnienie do
zarządzania uprawnieniami), uwierzytelnia się w KSeF podpisem kwalifikowanym, nadaje
uprawnienie do zarządzania uprawnieniami, wystawiania faktur oraz do dostępu do faktur
osobie fizycznej - swojej księgowej Y,
2 - w związku z tym, że księgowej Y zostało nadane m. in. uprawnienie do zarządzania
uprawnieniami, uwierzytelnia się ona w kontekście podatnika X i nadaje uprawnienia kolejnym
osobom fizycznym (swoim dwóm pracownikom) do wystawiania faktur w imieniu podatnika X i
dostępu do jego faktur; pracownicy, na podstawie posiadanych uprawnień, po uwierzytelnieniu
się w KSeF w kontekście podatnika X mogą wystawiać faktury w jego imieniu oraz posiadają
dostęp do jego faktur (nie mogą natomiast przekazać tych uprawnień kolejnym osobom,
ponieważ nie otrzymali uprawnienia do zarządzania uprawnieniami).
Przedstawione przykłady dotyczą tzw. bezpośredniego nadawania uprawnień.
WAŻNE
Uprawnienia nadawane bezpośrednio to uprawnienia nadawane przez osoby posiadające
uprawnienie do zarządzania uprawnieniami w kontekście danego podatnika. Podatnik nadaje
uprawnienie danej osobie fizycznej, następnie osoba ta, uwierzytelniona w kontekście
podatnika, deleguje te uprawnienia na kolejne osoby fizyczne.
Warto zaznaczyć, że w ramach nadawania uprawnień do wystawiania oraz/lub dostępu do
faktur, jeśli uprawnionym będzie podmiot z NIP, będzie możliwość zaznaczenia dodatkowej
opcji dającej podmiotowi uprawnionemu możliwość nadawania tzw. uprawnień pośrednich.
Funkcjonalność została opisana w kolejnych podrozdziałach Podręcznika KSeF 2.0.
Przykład 26. Przykładowy przebieg procesu nadawania uprawnień w modelu standardowym.
2 OSOBA FIZYCZNA
SPÓŁKA X 1 OSOBA FIZYCZNA (PRACOWNIK 1 )
(ZŁOŻENIE ZAW-FA) (PREZES SPÓŁKI X)
OSOBA FIZYCZNA
(PRACOWNIK 2)
71

---

Opis procesu:
1 - spółka X nie posiada pieczęci kwalifikowanej, składa zawiadomienie ZAW-FA wyznaczając
osobę fizyczną (prezesa spółki), która będzie w jej imieniu korzystała z KSeF,
2 , 3 - osoba fizyczna (prezes spółki X) uwierzytelnia się w KSeF podpisem kwalifikowanym w
kontekście spółki, nadaje uprawnienie do wystawiania faktur oraz do dostępu do faktur
osobom fizycznym – pracownikowi 1 oraz pracownikowi 2; pracownicy spółki X, na podstawie
posiadanych uprawnień, po uwierzytelnieniu się w KSeF w kontekście spółki mogą wystawiać
faktury w jej imieniu oraz posiadają dostęp do jej faktur (nie mogą natomiast przekazać tych
uprawnień kolejnym osobom, ponieważ nie otrzymali uprawnienia do zarządzania
uprawnieniami).
Przykład 27. Przykładowy przebieg procesu nadawania uprawnień w modelu standardowym.
OSOBA FIZYCZNA
OSOBA FIZYCZNA
(KSIĘGOWA 1)
SPÓŁKA X (DYREKTOR
FINANSOWY
OSOBA FIZYCZNA
SPÓŁKI X)
(KSIĘGOWA 2)
Opis procesu:
1 - spółka X posiada pieczęć kwalifikowaną, prezes spółki posługując się tą pieczęcią
kwalifikowaną nadaje osobie fizycznej (dyrektorowi finansowemu spółki X) uprawnienie do
zarządzania uprawnieniami, wystawiania faktur oraz do dostępu do faktur,
2 , 3 - osoba fizyczna (dyrektor finansowy spółki X) uwierzytelnia się w KSeF podpisem
kwalifikowanym w kontekście spółki, nadaje uprawnienie do zarządzania uprawnieniami,
wystawiania faktur oraz dostępu do faktur osobie fizycznej - księgowej 1 oraz uprawnienie do
dostępu do faktur - księgowej 2; księgowa 1 na podstawie posiadanych uprawnień, po
uwierzytelnieniu się w KSeF w kontekście spółki będzie mogła wystawiać faktury w imieniu
spółki oraz mieć dostęp do faktur spółki. Księgowa 2 będzie posiadała wyłącznie dostęp do
faktur spółki. Dodatkowo, księgowa 1 w razie potrzeby będzie mogła nadać uprawnienia np.
innym osobom fizycznym, w tym księgowej 2.
72

---

Uprawnienia dla podmiotu z NIP oraz uprawnienia pośrednie
Przy nadawaniu uprawnień w sposób bezpośredni, gdy identyfikatorem uprawnionego będzie
NIP, podatnik będzie miał możliwość zadeklarowania czy podmiot ten może delegować
uprawnienia na inne podmioty, czyli czy mogą być one nadawane w sposób pośredni.
Możliwość ta dotyczy wyłącznie uprawnienia do wystawiania faktur oraz uprawnienia do
dostępu do faktur. Jest szczególnie przydatna, gdy podatnik korzysta z usług biura
rachunkowego.
WAŻNE
Podmiot z NIP (np. biuro rachunkowe), który będzie nadawał uprawnienia w sposób pośredni
nie będzie uwierzytelniał się w tym celu w imieniu podatnika, lecz w swoim imieniu (w swoim
kontekście).
Nadając uprawnienie pośrednie, podmiot z NIP wskaże, czy osoba fizyczna uprawniona będzie
posiadała uprawnienie do pracy (wystawiania oraz/lub dostępu do faktur) w ramach wszystkich
podatników (tzw. partnerów) czy tylko wybranych.
Partnerem jest podatnik, który nadał podmiotowi z NIP uprawnienie do wystawiania faktur
oraz/lub uprawnienie do dostępu do faktur z opcją jego pośredniego przekazywania.
Jeden podmiot (np. jedno biuro rachunkowe) obsługuje bowiem zwykle wielu podatników, a
poszczególni pracownicy biura zajmują się konkretnymi podatnikami (a nie wszystkimi).
Dlatego też, jeśli podmiot z NIP posiada możliwość pośredniego przekazywania uprawnień, to
może następnie:
• nadać uprawnienie osobie fizycznej (np. swojemu pracownikowi) do wystawiania faktur
oraz/lub uprawnienie do dostępu do faktur w ramach konkretnego partnera,
• nadać uprawnienie osobie fizycznej (np. swojemu pracownikowi) do wystawiania faktur
oraz/lub dostępu do faktur w ramach wszystkich partnerów.
Osoba fizyczna wskazana przez podmiot z NIP, w ramach otrzymanych uprawnień pośrednich
może posiadać wyłącznie uprawnienia do:
• wystawiania faktur,
• dostępu do faktur.
Osoba fizyczna nie może jednak delegować swoich uprawnień na inne osoby lub podmioty.
Jeśli kilku partnerów nada danemu podmiotowi z NIP uprawnienie do wystawiania faktur
oraz/lub uprawnienie do dostępu do faktur z opcją pośredniego nadawania uprawnień, a
73

---

podmiot ten (np. biuro rachunkowe) nada uprawnienie osobie fizycznej do wystawiania faktur
oraz uprawnienie do dostępu do faktur tylko jednego spośród ww. partnerów, to ww. osoba
fizyczna będzie posiadała dostęp pośredni do faktur tego jednego partnera i będzie mogła
wystawiać faktury wyłącznie jednego partnera.
Jeśli kilku partnerów nada danemu podmiotowi z NIP uprawnienie do wystawiania faktur
oraz/lub dostępu do faktur z opcją pośredniego nadawania uprawnień, a podmiot ten (np. biuro
rachunkowe) nada uprawnienie osobie fizycznej do wystawiania faktur oraz uprawnienie do
dostępu do faktur wszystkich partnerów, to ww. osoba fizyczna będzie posiadała dostęp
pośredni do faktur wszystkich partnerów i będzie mogła wystawiać faktury wszystkich
partnerów.
Korzystanie z opisanego rozwiązania jest dobrowolne. Pozwala na wyeliminowanie
konieczności każdorazowej aktualizacji osób fizycznych uprawnionych do fakturowania, jeśli
podatnik korzysta z usług np. biura rachunkowego wystawiającego faktury w jego imieniu.
Wystarczy wówczas aktualizacja uprawnień nadanych przez samo biuro, a nie przez wszystkich
podatników, które wskazały to biuro jako uprawnione do wystawiania faktur lub do dostępu do
faktur w swoim imieniu.
Przykład 28. Przykładowy przebieg procesu nadawania uprawnień w ramach uprawnień pośrednich.
Etap 1. Nadanie uprawnień przez podatnika na rzecz podmiotu z NIP (biura rachunkowego)
PODATNIK X PODATNIK Y PODATNIK Z
1 2 3
BIURO RACHUNKOWE A
Opis procesu:
1 - podatnik X (spółka z o.o.) uwierzytelnia się w KSeF pieczęcią kwalifikowaną, posiada pełen
zakres uprawnień (w tym uprawnienie do zarządzania uprawnieniami), nadaje uprawnienie do
wystawiania faktur oraz uprawnienie do dostępu do faktur podmiotowi, którym jest biuro
rachunkowe A, wskazując przy tym, że biuro rachunkowe A może nadawać uprawnienia w
sposób pośredni,
74

---

2 - podatnik Y (spółka z o.o.) uwierzytelnia się w KSeF pieczęcią kwalifikowaną, posiada pełen
zakres uprawnień (w tym uprawnienie do zarządzania uprawnieniami), nadaje uprawnienie do
wystawiania faktur oraz uprawnienie do dostępu do faktur podmiotowi, którym jest biuro
rachunkowe A, wskazując przy tym, że biuro rachunkowe A może nadawać uprawnienia w
sposób pośredni,
3 - podatnik Z (spółka z o.o.) uwierzytelnia się w KSeF pieczęcią kwalifikowaną; posiada pełen
zakres uprawnień (w tym uprawnienie do zarządzania uprawnieniami), nadaje uprawnienie do
wystawiania faktur oraz uprawnienie do dostępu do faktur podmiotowi, którym jest biuro
rachunkowe A, wskazując przy tym, że biuro rachunkowe A może nadawać uprawnienia w
sposób pośredni.
Etap 2. Nadanie uprawnień przez podmiot z NIP osobom fizycznym (pracownikom biura)
BIURO RACHUNKOWE A
4 5 6
OSOBA FIZYCZNA 1 OSOBA FIZYCZNA 2 OSOBA FIZYCZNA 3
* OBSŁUGA PODATNIKA X * OBSŁUGA PODATNIKA Y * OBSŁUGA PODATNIKA Z
4 - biuro rachunkowe A uwierzytelnia się w KSeF we własnym kontekście i nadaje
uprawnienie do wystawiania faktur i dostępu do faktur podatnika X (wskazując jego
identyfikator podatkowy NIP) - swojemu pracownikowi (osobie fizycznej 1),
5 - biuro rachunkowe A uwierzytelnia się w KSeF we własnym kontekście i nadaje
uprawnienie do wystawiania faktur i dostępu do faktur podatnika Y (wskazując jego
identyfikator podatkowy NIP) - swojemu pracownikowi (osobie fizycznej 2);
6 - biuro rachunkowe A uwierzytelnia się w KSeF we własnym kontekście i nadaje
uprawnienie do wystawiania faktur i dostępu do faktur podatnika Z (wskazując jego
identyfikator podatkowy NIP) - swojemu pracownikowi (osobie fizycznej 3).
75

---

Wskutek powyższych działań:
• pierwszy z ww. pracowników (osoba fizyczna 1) po uwierzytelnieniu się w KSeF w
kontekście podatnika X, może wystawiać faktury, w których sprzedawcą będzie
podatnik X oraz posiadać dostęp do jego faktur,
• drugi z ww. pracowników (osoba fizyczna 2) po uwierzytelnieniu się w KSeF w
kontekście podatnika Y, może wystawiać faktury, w których sprzedawcą będzie
podatnik Y oraz posiadać dostęp do jego faktur,
• trzeci z ww. pracowników (osoba fizyczna 3) po uwierzytelnieniu się w KSeF w
kontekście podatnika Z, może wystawiać faktury, w których sprzedawcą będzie
podatnik Z oraz posiadać dostęp do jego faktur.
Dodatkowo każdy w ww. pracowników (osoba fizyczna 1, osoba fizyczna 2, osoba fizyczna 3) po
uwierzytelnieniu się w KSeF w kontekście biura rachunkowego A, może wystawiać faktury, w
których sprzedawcą będzie biuro rachunkowe A oraz posiadać dostęp do jego faktur o ile biuro
rachunkowe nadało swoim pracownikom takie uprawnienia.
Kolejność działań w nadawaniu uprawnień pośrednich oraz odebranie uprawnień
pośrednich
Jak wskazano wyżej, aby uprawnienia nadane pośrednio działały, konieczne jest istnienie
całego łańcucha uprawnień, czyli:
• partner powinien udzielić uprawnienia do wystawiania oraz/lub dostępu do faktur
podmiotowi z NIP (z możliwością przekazywania tych uprawnień na inne podmioty), a
• podmiot z NIP powinien nadać uprawnienie do wystawiania oraz/lub dostępu do faktur
osobie fizycznej (do pracy w kontekście danego partnera lub wszystkich partnerów).
Kwestia ta jest weryfikowana w chwili nawiązania sesji przez osobę uprawnioną.
Pozostaje bez znaczenia kolejność nadawania uprawnień w całym łańcuchu. Podmiot z NIP
może nadać najpierw uprawnienie osobie fizycznej do wystawiania oraz/lub dostępu do faktur
w imieniu danego partnera, a dopiero później sam otrzymać uprawnienia do wystawiania
oraz/lub dostępu do faktur (z opcją ich przekazywania) od tego partnera. W tym przypadku
uprawnienie takie będzie nadane osobie fizycznej, ale pozostaje nieaktywne. Stanie się
aktywne dopiero w chwili, w której podmiot z NIP otrzyma dane uprawnienie od partnera.
76

---

Jeżeli w przyszłości partner odbierze uprawnienia podmiotowi z NIP, skutkować to będzie
niemożnością obsługi tego partnera, przez wszystkie osoby uprawnione pośrednio przez ten
podmiot. Uprawnienia pośrednie pozostają nadane, lecz będą nieaktywne.
Przykład 29. Skutki odebrania uprawnień pośrednich.
W stanie faktycznym opisanym w przykładzie 28, podatnik X (spółka z o.o.) uwierzytelnia się w
KSeF pieczęcią kwalifikowaną, odbiera uprawnienie do wystawiania oraz do dostępu do faktur
podmiotowi z NIP, którym jest biuro rachunkowe A. W biurze rachunkowym A jako
uprawniony do wystawiania faktur i dostępu do faktur podatnika X wyznaczony był pracownik
(osoba fizyczna 1). Podatnik X odbierając uprawnienie do wystawiania oraz dostępu do faktur
biuru rachunkowemu A spowodował, że pracownik (osoba fizyczna 1) nie będzie mógł już
wystawiać ani mieć dostępu do faktur tego podatnika. Uprawnienia nadane przez biuro
rachunkowe A, pracownikowi (osobie fizycznej 1) nie zostaną odebrane, ale w związku z
„przerwaniem” łańcucha pozostaną nieaktywne.
3.3.2. Model uprawnień wykorzystujący identyfikator wewnętrzny jednostki
Rozporządzenie w sprawie korzystania z KSeF25 przewiduje, że uprawnienie do zarządzania
uprawnieniami, uprawienie do wystawiania faktur oraz uprawnienie do dostępu do faktur
posiada m.in. osoba fizyczna wskazana przez podatnika jako przedstawiciel zakładu (oddziału)
osoby prawnej lub innej wyodrębnionej jednostki wewnętrznej podatnika.
Dzięki powyższemu rozwiązaniu prawnemu podatnik, oprócz możliwości nadawania
uprawnień do wystawiania faktur i dostępu do faktur według standardowego modelu
uprawnień, będzie miał możliwość nadawania uprawnień do wystawiania faktur oraz do
dostępu do faktur w zakresie ograniczonym, odnoszącym się do danego zakładu (oddziału)
osoby prawnej lub innej wyodrębnionej jednostki wewnętrznej podatnika.
Podmioty, które uzyskają tego typu uprawnienia będą miały możliwość nadawania i odbierania
uprawnień do korzystania z KSeF poprzez wskazanie identyfikatora wewnętrznego (tzw.
IDWew).
25 Proces legislacyjny w toku: https://legislacja.rcl.gov.pl/projekt/12379252.
77

---

WAŻNE
Identyfikator wewnętrzny jest to unikalny identyfikator zakładu (oddziału) osoby prawnej bądź
innej wyodrębnionej jednostki wewnętrznej podatnika. Jest on utworzony zgodnie z zasadami
określonymi w specyfikacji oprogramowania interfejsowego. Składa się z identyfikatora
podatkowego (NIP) podatnika i ciągu znaków numerycznych, np. 1111111111-33334.
Podatnik w ramach posiadanych przez siebie uprawnień właścicielskich posiada miedzy innymi
uprawnienie do zarządzania jednostkami podrzędnymi (w tym modelu uprawnień jednostką
podrzędną będzie zakład (oddział) osoby prawnej bądź inna wyodrębniona jednostka
wewnętrzna podatnika, zwane w dalszej części dokumentu „jednostką wewnętrzną”). Podatnik
lub osoba fizyczna posiadająca uprawnienie do zarządzania uprawnieniami w imieniu podatnika
może delegować uprawnienie do zarządzania jednostkami podrzędnymi na inne osoby fizyczne.
Administrator jednostki wewnętrznej
Podatnik lub osoba fizyczna zarządzająca jednostkami podrzędnymi w imieniu podatnika mogą
wskazać osobę fizyczną będącą przedstawicielem jednostki wewnętrznej podatnika, zwaną
także administratorem jednostki wewnętrznej.
Administrator jednostki wewnętrznej może posiadać uprawnienie do:
• zarządzania uprawnieniami w ramach jednostki wewnętrznej,
• wystawiania faktur, w których w danych sprzedawcy (Podmiot1) znajdą się dane
podatnika, a w danych podmiotu trzeciego (Podmiot3) dane jednostki wewnętrznej (w
tym jej identyfikator wewnętrzny w polu IDWew),
• dostępu do faktur dotyczących podatnika, w których dodatkowo w danych podmiotu
trzeciego (Podmiot3) znajdą się dane jednostki wewnętrznej (w tym jej identyfikator
wewnętrzny w polu IDWew).
Osoba fizyczna wskazana przez administratora jednostki wewnętrznej
Administrator jednostki wewnętrznej może następnie wskazać osobę fizyczną, która będzie
korzystać z KSeF w ramach tej jednostki.
Osoba fizyczna wskazana przez administratora jednostki wewnętrznej może:
• wystawiać faktury, w których w danych sprzedawcy (Podmiot1) znajdą się dane
podatnika, a w danych podmiotu trzeciego (Podmiot3) dane jednostki wewnętrznej (w
tym jej identyfikator wewnętrzny w polu IDWew),
78

---

• posiadać dostęp do faktur dotyczących podatnika, w których dodatkowo w danych
podmiotu trzeciego (Podmiot3) znajdą się dane jednostki wewnętrznej (w tym jej
identyfikator wewnętrzny w polu IDWew).
Niezależnie od powyższego dostęp do faktur, w których wskazano dane jednostki wewnętrznej
będą miały też osoby uprawnione przez podatnika do dostępu do faktur w ramach
standardowego modelu uprawnień.
WAŻNE
Warunkiem poprawnego działania opisanego modelu uprawnień jest każdorazowe wskazanie
identyfikatora wewnętrznego danej jednostki wewnętrznej podatnika w strukturze FA(3) w
części Podmiot3/DaneIdentyfikacyjne w polu IDWew.
Przykład 30. Przykładowy przebieg procesu nadawania uprawnień z wykorzystaniem IDWew.
Stan faktyczny:
Sp. z o. o. posiada na terytorium Polski oddziały. Faktury wystawiane są w każdym oddziale – w
zakresie dokonanych przez dany oddział transakcji. Podatnikiem podatku VAT na gruncie art.
15 ustawy jest spółka, a nie poszczególne jej oddziały. Spółka uwierzytelniła się w KSeF
pieczęcią kwalifikowaną i wygenerowała identyfikatory wewnętrzne w KSeF dla
poszczególnych oddziałów (oddziału 1, oddziału 2, oddziału 3). Następnie nadała
administratorom jednostek wewnętrznych (oddziałów) osobom fizycznym – kierownikom
poszczególnych oddziałów uprawnienie do zarządzania uprawnieniami w ramach ich
oddziałów. W dalszej kolejności kierownicy wyznaczyli osoby fizyczne - pracowników swoich
oddziałów, jako osoby, które będą posiadały uprawnienie do wystawiania faktur i do dostępu
do faktur w ramach danego oddziału.
Działania opisane w powyższym stanie faktycznym można podzielić na dwa etapy:
Etap 1. Wygenerowanie identyfikatorów wewnętrznych dla oddziałów spółki
PODATNIK SP. Z O. O.
1 2 3
IDENTYFIKATOR IDENTYFIKATOR IDENTYFIKATOR
WEWNĘTRZNY WEWNĘTRZNY WEWNĘTRZNY
(ODDZIAŁ 1) (ODDZIAŁ 2) (ODDZIAŁ 3)
Opis procesu:
79

---

Podatnik (spółka z o. o.) uwierzytelnia się w KSeF kwalifikowaną pieczęcią elektroniczną, a
następnie:
1 - generuje identyfikator wewnętrzny dotyczący oddziału 1,
2 - generuje identyfikator wewnętrzny dotyczący oddziału 2,
3 - generuje identyfikator wewnętrzny dotyczący oddziału 3.
Etap 2. Wyznaczenie administratorów jednostek wewnętrznych oraz osób uprawnionych w
ramach jednostek wewnętrznych
PODATNIK SP. Z O.O.
1 2 3
ADMINISTRATOR ADMINISTRATOR ADMINISTRATOR
JEDNOSTKI JEDNOSTKI JEDNOSTKI
WEWNĘTRZNEJ WEWNĘTRZNEJ WEWNĘTRZNEJ
(KIEROWNIK ODDZIAŁU 1) (KIEROWNIK ODDZIAŁU 2) (KIEROWNIK ODDZIAŁU 3)
4 5 6
OSOBA FIZYCZNA OSOBA FIZYCZNA OSOBA FIZYCZNA
(PRACOWNIK ODDZIAŁU 1) (PRACOWNIK ODDZIAŁU 2) (PRACOWNIK ODDZIAŁU 3)
Opis procesu:
Podatnik (spółka z o.o.) uwierzytelnia się w KSeF kwalifikowaną pieczęcią elektroniczną, a
następnie:
1 - wyznacza osobę fizyczną (kierownika oddziału 1) jako administratora jednostki
wewnętrznej (oddziału 1),
2 - wyznacza osobę fizyczną (kierownika oddziału 2) jako administratora jednostki
wewnętrznej (oddziału 2),
80

---

3 - wyznacza osobę fizyczną (kierownika oddziału 3) jako administratora jednostki
wewnętrznej (oddziału 3),
4 - osoba fizyczna (kierownik oddziału 1) nadaje uprawnienie (z wykorzystaniem
identyfikatora wewnętrznego oddziału 1) osobie fizycznej (pracownikowi oddziału 1) do
wystawiania faktur oraz do dostępu do faktur oddziału 1,
5 - osoba fizyczna (kierownik oddziału 2) nadaje uprawnienie (z wykorzystaniem
identyfikatora wewnętrznego oddziału 2) osobie fizycznej (pracownikowi oddziału 2) do
wystawiania faktur oraz do dostępu do faktur w ramach oddziału 2,
6 - osoba fizyczna (kierownik oddziału 3) nadaje uprawnienie (z wykorzystaniem
identyfikatora wewnętrznego oddziału 3) osobie fizycznej (pracownikowi oddziału 3) do
wystawiania faktur oraz do dostępu do faktur w ramach oddziału 3.
WAŻNE
Wprowadzenie rozwiązania w postaci tzw. identyfikatora jednostki wewnętrznej umożliwia
m.in. ograniczenie nabywcy dostępu do otrzymywanych faktur, wyłącznie dla deklarowanej
przez nabywcę, określonej jednostki wewnętrznej podatnika.
Dzięki opisanemu rozwiązaniu, w przypadku, gdy w strukturze FA(3) w części Podmiot2
zostaną wskazane dane nabywcy (spółki z o. o.), a w Podmiot3 zostaną wskazane dane
oddziału, którego dotyczy dana faktura (w tym jego identyfikator wewnętrzny), to m. in.:
• pracownik oddziału 1 nie będzie miał dostępu do faktur oddziału 2 i oddziału 3,
• pracownik oddziału 2 nie będzie miał dostępu do faktur oddziału 1 i oddziału 3,
• pracownik oddziału 3 nie będzie miał dostępu do faktur oddziału 1 i oddziału 2,
W przypadku, gdy w strukturze FA(3) w części Podmiot2 zostaną wskazane dane nabywcy
(spółki z o. o.), ale część Podmiot3 (w tym pole IDWew) pozostanie pusta, osoby uprawnione do
dostępu do faktur w poszczególnych oddziałach (pracownicy oddziałów 1-3) nie będą miały
dostępu do tych faktur zakupowych w ramach opisanego wyżej modelu uprawnień.
WAŻNE
Nie ma przeszkód, aby wyodrębnioną jednostką wewnętrzną podatnika była określona osoba
fizyczna (np. prezes zarządu lub pracownik).
81

---

Przykład 31. Identyfikator wewnętrzny dla osób fizycznych.
Stan faktyczny:
Prezes zarządu spółki z o.o. w związku z pełnioną przez siebie funkcją odbywa częste wyjazdy
służbowe. W związku z powyższym na rzecz spółki wystawiane są faktury np. za wydatki
reprezentacyjne czy zakup paliwa do auta służbowego (ponoszone przez prezesa).
Jednocześnie, aby możliwe było rozliczenie tych wydatków przez prezesa zarządu, na
fakturach podawany jest wygenerowany dla prezesa identyfikator wewnętrzny (w Podmiot3).
Etap 1. Wygenerowanie identyfikatorów wewnętrznych dla oddziałów spółki
1 IDENTYFIKATOR WEWNĘTRZNY
PODATNIK SP. Z O. O.
(PREZES ZARZĄDU)
Opis procesu:
Podatnik (spółka z o. o.) uwierzytelnia się w KSeF kwalifikowaną pieczęcią elektroniczną, a
następnie:
1 - generuje identyfikator wewnętrzny dotyczący prezesa zarządu spółki z o. o.
Etap 2. Wyznaczenie administratorów jednostek wewnętrznych oraz osób uprawnionych w
ramach jednostek wewnętrznych
ADMINISTRATOR JEDNOSTKI
WEWNĘTRZNEJ
PODATNIK SP. Z O.O.
(PREZES ZARZĄDU)
OSOBA FIZYCZNA
(GŁÓWNA KSIĘGOWA SPÓŁKI)
Opis procesu:
Podatnik (spółka z o.o.) uwierzytelnia się w KSeF kwalifikowaną pieczęcią elektroniczną, a
następnie:
82

---

1 - wyznacza osobę fizyczną (prezesa zarządu spółki) jako administratora jednostki
wewnętrznej,
2 - administrator jednostki wewnętrznej (prezes zarządu) uwierzytelnia się w KSeF podpisem
kwalifikowanym w kontekście jednostki wewnętrznej i nadaje uprawnienie do dostępu do
faktur w ramach tej jednostki, w celu rozliczania poniesionych wydatków, osobie fizycznej –
głównej księgowej.
Dzięki opisanemu modelowi, księgowa spółki ma bezpośredni dostęp do faktur zakupowych
spółki, dotyczących wydatków ponoszonych przez prezesa zarządu.
Uprawnienia pośrednie a model uprawnień wykorzystujący identyfikator wewnętrzny
Uprawnienie do wystawiania lub dostępu do faktur w KSeF posiada również:
• podmiot wskazany przez jednostkę wewnętrzną podatnika,
• osoba fizyczna wskazana przez podmiot, który został wskazany przez jednostkę
wewnętrzną podatnika.
Administrator jednostki wewnętrznej podczas nadawania uprawnień bezpośrednich może
uprawnić podmiot z NIP do wystawiania faktur w jej imieniu oraz/lub do dostępu do jej faktur
oraz wskazać przy tym, że podmiot ten ma prawo nadawania uprawnień pośrednich.
Podmiot z NIP wskazany przez administratora jednostki wewnętrznej, może posiadać w KSeF
uprawnienia do:
• wystawiania faktur, w których w danych sprzedawcy (Podmiot1) znajdą się dane
podatnika, a w danych podmiotu trzeciego (Podmiot3) dane jednostki wewnętrznej (w
tym jej identyfikator wewnętrzny w polu IDWew),
• dostępu do faktur dotyczących podatnika, w których dodatkowo w danych podmiotu
trzeciego (Podmiot3) znajdą się dane jednostki wewnętrznej (w tym jej identyfikator
wewnętrzny w polu IDWew).
Z uwagi na fakt, że jeden podmiot (np. jedno biuro rachunkowe) obsługuje zwykle wielu
partnerów, a poszczególni pracownicy biura zajmują się konkretnymi partnerami (a nie
wszystkimi), podmiot uprawniony przez administratora jednostki wewnętrznej może:
• nadać uprawnienie osobie fizycznej (np. swojemu pracownikowi) do wystawiania faktur
oraz/lub dostępu do faktur w ramach konkretnej jednostki wewnętrznej (partnera),
• nadać uprawnienie osobie fizycznej (np. swojemu pracownikowi) do wystawiania faktur
oraz/lub dostępu do faktur wszystkich partnerów.
83

---

Korzystanie z tego rozwiązania jest dobrowolne. Pozwala na wyeliminowanie konieczności
każdorazowej aktualizacji osób fizycznych uprawnionych do fakturowania, jeśli jednostka
wewnętrzna korzysta z usług np. biura rachunkowego wystawiającego faktury w jej imieniu.
Wystarczy wówczas aktualizacja przez samo biuro, a nie wszystkie jednostki wewnętrzne,
które wskazały to biuro jako uprawnione do wystawiania faktur w swoim imieniu.
Osoba fizyczna, uprawniona pośrednio przez podmiot, może posiadać w KSeF wyłącznie
uprawnienia do:
• wystawiania faktur, w których w danych sprzedawcy (Podmiot1) znajdą się dane
podatnika, a w danych podmiotu trzeciego (Podmiot3) dane jednostki wewnętrznej (w
tym jej identyfikator wewnętrzny w polu IDWew),
• posiadać dostęp do faktur dotyczących podatnika, w których dodatkowo w danych
podmiotu trzeciego (Podmiot3) znajdą się dane jednostki wewnętrznej (w tym jej
identyfikator wewnętrzny w polu IDWew).
WAŻNE
Podmiot nie wskazuje tej osoby w imieniu danej jednostki wewnętrznej podatnika, lecz w
swoim imieniu (kontekście). Nadając uprawnienie osobie fizycznej, podmiot wskazuje, czy
osoba ta będzie posiadała uprawnienie do pracy (wystawiania oraz/lub dostępu do faktur) w
ramach wszystkich partnerów podmiotu czy też konkretnego partnera.
Jeśli kilku partnerów (np. kilka jednostek wewnętrznych) nada danemu podmiotowi
uprawnienie do wystawiania oraz/lub dostępu do faktur, a podmiot ten (np. biuro rachunkowe)
nada uprawnienie osobie fizycznej do dostępu oraz/lub wystawiania faktur tylko jednego
spośród ww. partnerów, to ww. osoba fizyczna będzie posiadała dostęp pośredni do faktur tego
jednego partnera i będzie mogła wystawiać faktury wyłącznie jednego partnera (jednostki
wewnętrznej).
Jeśli kilku partnerów (np. kilka jednostek wewnętrznych) nada danemu podmiotowi
uprawnienie do wystawiania oraz/lub dostępu do faktur, a podmiot ten (np. biuro rachunkowe)
nada uprawnienie osobie fizycznej do dostępu oraz/lub wystawiania faktur wszystkich
partnerów, to ww. osoba fizyczna będzie posiadała dostęp pośredni do faktur wszystkich
partnerów i będzie mogła wystawiać faktury wszystkich partnerów.
84

---

Przykład 32. Przykładowy przebieg procesu nadawania uprawnień z wykorzystaniem IDWew.
Etap 1. Wygenerowanie identyfikatorów wewnętrznych
PODATNIK (S. A.)
OSOBA FIZYCZNA WSKAZANA W ZAW-FA
(PREZES ZARZĄDU)
2 3 4
IDENTYFIKATOR IDENTYFIKATOR IDENTYFIKATOR
WEWNĘTRZNY WEWNĘTRZNY WEWNĘTRZNY
(ODDZIAŁ 1) (ODDZIAŁ 2) (ODDZIAŁ 3)
Opis procesu:
1 - podatnik (spółka akcyjna) nie posiada kwalifikowanej pieczęci elektronicznej, w związku z
tym składa zawiadomienie ZAW-FA wskazując osobę fizyczną (prezesa zarządu), która będzie
w jej imieniu korzystać z KSeF,
2 - osoba fizyczna (wskazana w ZAW-FA), uwierzytelniona w KSeF Podpisem Zaufanym
generuje identyfikator wewnętrzny dotyczący oddziału 1,
3 - osoba fizyczna (wskazana w ZAW-FA), uwierzytelniona w KSeF Podpisem Zaufanym
generuje identyfikator wewnętrzny dotyczący oddziału 2,
4 - osoba fizyczna (wskazana w ZAW-FA), uwierzytelniona w KSeF Podpisem Zaufanym
generuje identyfikator wewnętrzny dotyczący oddziału 3.
85

---

Etap 2. Nadanie uprawnień osobom fizycznym – administratorom jednostek wewnętrznych
oraz nadanie uprawnień podmiotom wyznaczonym przez administratorów
OSOBA FIZYCZNA WSKAZANA W ZAW-FA
(PREZES ZARZĄDU)
1 2 3
ADMINISTRATOR ADMINISTRATOR ADMINISTRATOR
ODDZIAŁU 1 ODDZIAŁU 2 ODDZIAŁU 3
(DYREKTOR ODDZIAŁU 1) (DYREKTOR ODDZIAŁU 2) (DYREKTOR ODDZIAŁU 3)
4 5 6
PODMIOT
(BIURO RACHUNKOWE X)
Opis procesu:
Osoba fizyczna uprawniona przez podatnika w zawiadomieniu ZAW-FA uwierzytelnia się w
KSeF kwalifikowanym podpisem elektronicznym. Następnie:
1 - wyznacza osobę fizyczną – dyrektora oddziału 1 jako administratora jednostki
wewnętrznej (oddziału 1),
2 - wyznacza osobę fizyczną – dyrektora oddziału 2 jako administratora jednostki
wewnętrznej (oddziału 2),
3 - wyznacza osobę fizyczną – dyrektora oddziału 3 jako administratora jednostki
wewnętrznej (oddziału 3),
4 - administrator jednostki wewnętrznej (dyrektor oddziału 1) nadaje uprawnienie do
wystawiania faktur oraz dostępu do faktur w ramach oddziału 1 na rzecz biura rachunkowego
X, wskazując przy tym, że biuro ma prawo nadawania uprawnień pośrednich,
86

---

5 - administrator jednostki wewnętrznej (dyrektor oddziału 2) nadaje uprawnienie do
wystawiania faktur oraz dostępu do faktur w ramach oddziału 2 na rzecz biura rachunkowego
X, wskazując przy tym, że biuro ma prawo nadawania uprawnień pośrednich,
6 - administrator jednostki wewnętrznej (dyrektor oddziału 3) nadaje uprawnienie do
wystawiania faktur oraz dostępu do faktur w ramach oddziału 3 na rzecz biura rachunkowego
X, wskazując przy tym, że biuro ma prawo nadawania uprawnień pośrednich.
Etap 3. Nadanie uprawnień przez podmiot - osobom fizycznym
PODMIOT
(BIURO RACHUNKOWE X)
7 8 9
OSOBA FIZYCZNA 1 OSOBA FIZYCZNA 2 OSOBA FIZYCZNA 3
OBSŁUGUJĄCA OBSŁUGUJĄCA OBSŁUGUJĄCA
ODDZIAŁ 1 ODDZIAŁ 2 ODDZIAŁ 3
(PRACOWNIK BIURA (PRACOWNIK BIURA (PRACOWNIK BIURA
RACHUNKOWEGO X) RACHUNKOWEGO X) RACHUNKOWEGO X)
Opis procesu:
Biuro rachunkowe X uwierzytelnia się w KSeF kwalifikowaną pieczęcią elektroniczną w swoim
kontekście. Następnie:
7 - nadaje uprawnienie osobie fizycznej 1 (swojemu pracownikowi) do wystawiania faktur w
imieniu partnera (oddziału 1) oraz do dostępu do jego faktur,
8 - nadaje uprawnienie osobie fizycznej 2 (swojemu pracownikowi) do wystawiania faktur w
imieniu partnera (oddziału 2) oraz do dostępu do jego faktur,
9 - nadaje uprawnienie osobie fizycznej 3 (swojemu pracownikowi) do wystawiania faktur w
imieniu partnera (oddziału 3) oraz do dostępu do jego faktur.
Dzięki opisanemu modelowi:
• osoba fizyczna 1 (pracownik biura rachunkowego), uwierzytelniona w KSeF w
kontekście oddziału 1 - może wystawiać faktury, w których oddział 1 występuje jako
Podmiot3 (w których w polu IDWew został wskazany identyfikator wewnętrzny
87

---

oddziału 1), a spółka akcyjna jako Podmiot1 (sprzedawca) oraz posiadać dostęp do
faktur spółki, w których oddział 1 występuje jako Podmiot3,
• osoba fizyczna 2 (pracownik biura rachunkowego), uwierzytelniona w KSeF w
kontekście oddziału 2 - może wystawiać faktury, w których oddział 2 występuje jako
Podmiot3 (w których w polu IDWew został wskazany identyfikator wewnętrzny
oddziału 2), a spółka akcyjna jako Podmiot1 (sprzedawca) oraz posiadać dostęp do
faktur spółki, w których oddział 2 występuje jako Podmiot3,
• osoba fizyczna 3 (pracownik biura rachunkowego), uwierzytelniona w KSeF w
kontekście oddziału 3 - może wystawiać faktury, w których oddział 3 występuje jako
Podmiot3 (w których w polu IDWew został wskazany identyfikator wewnętrzny
oddziału 3), a spółka akcyjna jako Podmiot1 (sprzedawca) oraz posiadać dostęp do
faktur spółki, w których oddział 3 występuje jako Podmiot3.
Dodatkowo, biuro rachunkowe X (obsługujące oddział 1, oddział 2 i oddział 3) może upoważnić
osoby fizyczne, np. swoich pracowników do wystawiania faktur biura (w modelu uprawnień
bezpośrednich). Dzięki temu:
• osoba fizyczna 1 - po uwierzytelnieniu się w KSeF w kontekście biura rachunkowego –
może wystawiać faktury, w których biuro rachunkowe występuje jako Podmiot1 oraz
posiadać dostęp do faktur biura rachunkowego,
• osoba fizyczna 2 - po uwierzytelnieniu się w KSeF w kontekście biura rachunkowego –
może wystawiać faktury, w których biuro rachunkowe występuje jako Podmiot1 oraz
posiadać dostęp do faktur biura rachunkowego,
• osoba fizyczna 3 - po uwierzytelnieniu się w KSeF w kontekście biura rachunkowego –
może wystawiać faktury, w których biuro rachunkowe występuje jako Podmiot1 oraz
posiadać dostęp do faktur biura rachunkowego.
Kolejność działań w nadawaniu uprawnień pośrednich oraz odebranie uprawnień
pośrednich
Jak wskazano wyżej, aby uprawnienia nadane pośrednio działały, konieczne jest istnienie
całego łańcucha uprawnień, czyli:
• partner (jednostka wewnętrzna) powinien udzielić uprawnienia do wystawiania
oraz/lub dostępu do faktur podmiotowi z NIP (z możliwością przekazywania tych
uprawnień na inne podmioty), a
• podmiot z NIP powinien nadać uprawnienie do wystawiania oraz/lub dostępu do faktur
osobie fizycznej (do pracy w kontekście danego partnera lub wszystkich partnerów).
88

---

Kwestia ta jest weryfikowana w chwili nawiązania sesji przez osobę uprawnioną.
Pozostaje bez znaczenia kolejność nadawania uprawnień w całym łańcuchu. Podmiot z NIP
może nadać najpierw uprawnienie osobie fizycznej do wystawiania oraz/lub dostępu do faktur
w imieniu danego partnera (danej jednostki wewnętrznej), a dopiero później sam otrzymać
uprawnienia do wystawiania oraz/lub dostępu do faktur (z opcją ich przekazywania) od tego
partnera. W tym przypadku uprawnienie takie będzie nadane osobie fizycznej, ale pozostaje
nieaktywne. Stanie się aktywne dopiero w chwili, w której podmiot z NIP otrzyma dane
uprawnienie od partnera (jednostki wewnętrznej).
Jeżeli w przyszłości partner (jednostka wewnętrzna) odbierze uprawnienia podmiotowi z NIP,
skutkować to będzie niemożnością obsługi tego partnera, przez wszystkie osoby uprawnione
pośrednio przez ten podmiot. Uprawnienia pośrednie pozostają nadane, lecz będą nieaktywne.
Przykład 33. Skutki odebrania uprawnień podmiotowi z NIP.
W stanie faktycznym opisanym w przykładzie 32, administrator oddziału 1 (dyrektor oddziału)
uwierzytelnia się w KSeF w kontekście identyfikatora wewnętrznego oddziału i odbiera
uprawnienie do wystawiania oraz do dostępu do faktur podmiotowi z NIP, którym jest biuro
rachunkowe X. Biuro rachunkowe X jako uprawnionego do wystawiania faktur i dostępu do
faktur, w imieniu oddziału 1 , wyznaczył wcześniej osobę fizyczną 1 (pracownika biura).
Administrator oddziału 1 odbierając uprawnienie do wystawiania oraz dostępu do faktur biuru
rachunkowemu X spowodował, że osoba fizyczna 1 (pracownik biura) nie będzie mogła już
wystawiać ani mieć dostępu do faktur tej jednostki wewnętrznej. Uprawnienia nadane przez
biuro rachunkowe X, osobie fizycznej 1 (pracownikowi biura) nie zostaną odebrane, ale w
związku z „przerwaniem” łańcucha pozostaną nieaktywne.
3.3.3. Uprawnienia dedykowane JST
Model uprawnień dedykowany JST został omówiony w cz. IV Podręcznika KSeF 2.0.
3.3.4. Uprawnienia dedykowane GV
Model uprawnień dedykowany GV został omówiony w cz. IV Podręcznika KSeF 2.0.
3.3.5. Modele uprawnień dedykowane komornikowi sądowemu oraz organowi
egzekucyjnemu
Modele uprawnień dedykowane komornikowi sądowemu oraz organowi egzekucyjnemu
zostały omówione w cz. IV Podręcznika KSeF 2.0.
89

---

3.3.6. Model uprawnień dedykowany przedstawicielowi podatkowemu
Model uprawnień umożliwiający wystawianie faktur przez przedstawiciela podatkowego
został omówiony w cz. IV Podręcznika KSeF 2.0.
3.3.7. Model uprawnień umożliwiający wystawianie faktur VAT RR oraz faktur VAT RR
KOREKTA
Model uprawnień umożliwiający wystawianie faktur VAT RR oraz faktur VAT RR KOREKTA
wraz z ze szczegółami dotyczącymi zasad wystawiania tych dokumentów w KSeF został
omówiony w cz. III Podręcznika KSeF 2.0.
90

---

Spis grafik
Grafika 1. Nagłówek oraz cz. A zawiadomienia ZAW-FA. ........................................................................62
Grafika 2. Cz. B zawiadomienia ZAW-FA. ......................................................................................................65
Grafika 3. Cz. C zawiadomienia ZAW-FA. ......................................................................................................66
Grafika 4. Cz. D zawiadomienia ZAW-FA. .....................................................................................................67
Grafika 5. Cz. E zawiadomienia ZAW-FA. ......................................................................................................68
91

---

Spis przykładów
Przykład 1. Metody oraz kontekst uwierzytelnienia w przypadku jednoosobowej działalności
gospodarczej.............................................................................................................................................................27
Przykład 2. Metody uwierzytelnienia oraz kontekst uwierzytelnienia w przypadku
jednoosobowej działalności gospodarczej. ....................................................................................................28
Przykład 3. Metody uwierzytelnienia oraz kontekst uwierzytelnienia w przypadku podmiotu
niebędącego osobą fizyczną. ...............................................................................................................................28
Przykład 4. Metody uwierzytelnienia oraz kontekst uwierzytelnienia w przypadku podmiotu
niebędącego osobą fizyczną. ...............................................................................................................................28
Przykład 5. Metody uwierzytelnienia oraz kontekst uwierzytelnienia w przypadku
samofakturowania. .................................................................................................................................................29
Przykład 6. Metody uwierzytelnienia oraz kontekst uwierzytelnienia w przypadku
samofakturowania z podmiotem UE. ...............................................................................................................29
Przykład 7. Metody uwierzytelnienia oraz kontekst uwierzytelnienia w przypadku jednostek
wewnętrznych. ........................................................................................................................................................29
Przykład 8. Zgłoszenie danych unikalnych powiązanych z certyfikatem kwalifikowanego
podpisu elektronicznego. .....................................................................................................................................32
Przykład 9. Zgłoszenie danych unikalnych powiązanych z certyfikatem kwalifikowanej pieczęci
elektronicznej. .........................................................................................................................................................33
Przykład 10. Sposób generowania tokenów i zarządzania tokenami w spółce. ...............................34
Przykład 11. Sposób generowania tokenów i zarządzania tokenami przez osoby fizyczne i
spółki. ..........................................................................................................................................................................35
Przykład 12. Generowanie tokenów przez osobę fizyczną. ....................................................................37
Przykład 13. Wpływ zmiany zakresu posiadanych uprawnień na token. ...........................................38
Przykład 14. Określenie daty ważności certyfikatu KSeF (we wniosku wskazano datę
początkową)..............................................................................................................................................................43
Przykład 15. Określenie daty ważności certyfikatu KSeF (we wniosku nie wskazano daty
początkowej). ...........................................................................................................................................................43
Przykład 16. Określenie daty ważności certyfikatu KSeF (we wniosku nie wskazano daty
początkowej). ...........................................................................................................................................................43
Przykład 17. Sposób generowania certyfikatów KSeF i zarządzania certyfikatami w spółce. ....45
Przykład 18. Sposób generowania certyfikatów KSeF i zarządzania certyfikatami w spółce. ....47
Przykład 19. Działanie systemu przy przekroczeniu maksymalnej liczby żądań wydania
certyfikatów KSeF. .................................................................................................................................................48
Przykład 20. Wpływ zmiany zakresu posiadanych uprawnień na ważność certyfikatu KSeF. ...48
92

---

Przykład 21. Potwierdzenie (w formie e-mail) wprowadzenia danych z zawiadomienia ZAW-FA
do systemu. ...............................................................................................................................................................60
Przykład 22. Elementy potwierdzenia e-mail. ..............................................................................................60
Przykład 23. Potwierdzenie (w formie e-mail) wprowadzenia danych z zawiadomienia ZAW-FA
do systemu. ...............................................................................................................................................................62
Przykład 24. Przykładowy przebieg procesu nadawania uprawnień w modelu standardowym.
.......................................................................................................................................................................................70
Przykład 25. Przykładowy przebieg procesu nadawania uprawnień w modelu standardowym.
.......................................................................................................................................................................................70
Przykład 26. Przykładowy przebieg procesu nadawania uprawnień w modelu standardowym.
.......................................................................................................................................................................................71
Przykład 27. Przykładowy przebieg procesu nadawania uprawnień w modelu standardowym.
.......................................................................................................................................................................................72
Przykład 28. Przykładowy przebieg procesu nadawania uprawnień w ramach uprawnień
pośrednich. ................................................................................................................................................................74
Przykład 29. Skutki odebrania uprawnień pośrednich. .............................................................................77
Przykład 30. Przykładowy przebieg procesu nadawania uprawnień z wykorzystaniem IDWew.
.......................................................................................................................................................................................79
Przykład 31. Identyfikator wewnętrzny dla osób fizycznych. ................................................................82
Przykład 32. Przykładowy przebieg procesu nadawania uprawnień z wykorzystaniem IDWew.
.......................................................................................................................................................................................85
Przykład 33. Skutki odebrania uprawnień podmiotowi z NIP. ...............................................................89
93

---

Spis schematów
Schemat 1. Rodzaje certyfikatu KSeF. .............................................................................................................41
Schemat 2. Nadawanie uprawnień poprzez zawiadomienie ZAW-FA. ................................................57
94

---

Spis tabel
Tabela 1. Harmonogram wdrożenia KSeF. ....................................................................................................13
Tabela 2. Metody uwierzytelnienia w KSeF w podziale na formę prawną podmiotu. ....................25
Tabela 3. Porównanie cech tokenów i certyfikatów KSeF. ......................................................................50
95