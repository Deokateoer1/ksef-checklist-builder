# FAQ z https://ksef.podatki.gov.pl/pytania-i-odpowiedzi-ksef-20/

## 1.Co to jest KSeF?

Krajowy System e-Faktur (KSeF) to system służący do wystawiania, przesyłania, odbierania i przechowywania faktur ustrukturyzowanych. Od 1 lutego 2026 r. KSeF obejmuje etapami wszystkich przedsiębiorców oraz wystawiających faktury w Polsce. Wdrożenie KSeF służy cyfryzacji procesów fakturowania oraz księgowania faktur. Pozwala także unikać błędów przy ich wystawianiu.

## 2.Jak korzystać z KSeF?

Możesz korzystać z KSeF przy użyciu: •    programów finansowo-księgowych, o ile są zintegrowane z KSeF (integracja przez API), •    bezpłatnych narzędzi Ministerstwa Finansów, dostępnych na stronie ksef.podatki.gov.pl tj. - dostępnej online Aplikacji Podatnika KSeF (umożliwiającej korzystanie z systemu, zarządzanie uprawnieniami, tokenami i docelowo również certyfikatami KSeF, podgląd faktur oraz pobranie UPO); - Aplikacji Mobilnej KSeF (zapewniającej wygodne i szybkie wystawianie i odbieranie faktur w systemie przy użyciu smartfona, podgląd faktur oraz utworzenie wersji roboczej faktury) Z KSeF można też korzystać przez e-mikrofirmę dostępną w e-Urzędzie Skarbowym. Dzięki powiązaniu istniejącego konta z KSeF podatnik może wystawiać i odbierać faktury w systemie oraz przenosić je bezpośrednio do ewidencji VAT, bez konieczności ręcznego przepisywania danych.

## 3.Co to jest e-Faktura?

To zgodny z wzorem plik XML, przesłany do systemu KSeF, któremu został nadany unikalny numer. W KSeF znajdzie ją odbiorca (podatnik posiadający NIP) i tu jest archiwizowana przez 10 lat. Nie wysyła się jej mailem, nie drukuje (poza ustawowymi wyjątkami), nigdy się już nie zniszczy ani nie zginie.

## 4.KSeF w praktyce – co zyskujesz?

Ujednolicenie procesu fakturowania – mniejsze ryzyko błędów. Usprawnienie obiegu dokumentów – faktury trafiają do odbiorcy niemal w czasie rzeczywistym. Łatwiejsze przygotowanie dokumentów – integracja z KSeF umożliwia import danych z faktur klientów i dostawców prosto do systemu księgowego firmy / księgowej. Stały dostęp do faktur przez 10 lat – bez konieczności ich przechowywania samodzielnie, faktury zawsze są po ręką. Szybszy zwrot VAT – w 40 dni zamiast 60. Zwiększenie wzajemnego zaufania przedsiębiorców – nabywca wie, że faktura została wystawiona przez podmiot uprawniony.

## 5.Od kiedy trzeba wystawiać faktury w KSeF?

Obowiązek wystawiania faktur w KSeF wejdzie etapami: od 1 lutego 2026 r. dla firm, które w 2024 r. miały sprzedaż powyżej 200 mln zł (z VAT), od 1 kwietnia 2026 r. dla pozostałych. Dodatkowo do 31 grudnia 2026 r. można jeszcze wystawiać faktury poza KSeF (papierowe lub elektroniczne), jeśli w danym miesiącu suma sprzedaży z VAT na takich fakturach nie przekroczy 10 000 zł. To ułatwienie ma pomóc w sprawnym przejściu na nowy system.

## 6.Jaki jest powód dwóch terminów startu obowiązkowego KSeF (1.02 i 1.04.2026)?

Podział na dwa etapy to wynik zaleceń audytu informatycznego.  To również wyjście naprzeciw oczekiwaniom mniejszych przedsiębiorców, którzy zyskają dodatkowy czas na dopięcie przygotowań.

## 7.Jak będą mogły wystawić fakturę osoby prowadzące działalność gospodarczą, a nieposiadające dostępu do internetu, oraz nie obsługujące komputera?

Internet jest niezbędny do wystawiania faktur w KSeF. W przypadku niekorzystania z internetu jedną z opcji jest nadanie uprawnień innej osobie do wystawiania faktur np. pracownikowi biura rachunkowego. Obowiązek korzystania z KSeF został odroczony do lutego 2026 r. m.in. w celu stworzenia zaplecza technicznego pozwalającego na korzystanie z KSeF.

## 8.Jakie są korzyści z wdrożenia KSeF dla Skarbu Państwa?

Cyfryzacja procesów i relacji między administracją a przedsiębiorcami Zwiększenie konkurencyjności przedsiębiorstw Większa efektywność kontroli Większa transparentność obrotu gospodarczego Przyspieszenie obiegu dokumentów i rozliczeń

## 9.Dlaczego obowiązek wystawiania faktur w KSeF wchodzi w życie od lutego, a nie z początkiem roku?

Początek roku to spiętrzenie rozliczeń i sprawozdań. Dlatego wybrano terminy w trakcie roku (1 lutego i 1 kwietnia 2026 r.). To również zgodne z rekomendacjami po audycie systemu.

## 1.Jaki wpływ będzie miał unijny pakiet VIDA na funkcjonowanie KSeF?

Unijne przepisy dotyczące pakietu VIDA zostały opublikowane. Rozwiązania krajowe będą przedmiotem odrębnej ustawy. Polska dokłada wszelkich starań, aby pakiet VIDA nie wpływał znacząco na funkcjonalności KSeF.

## 2.Do kiedy paragony fiskalne z NIP nabywcy będą uznawane za fakturę uproszczoną i będą wyłączone z obowiązkowego KSeF?

Do końca 31 grudnia 2026 r. - do tego czasu możliwe jest wystawianie faktur przez kasy rejestrujące (w tym paragonów z NIP do 450 zł) i brak obowiązku ich wystawiania w KSeF.

## 3.Czy KSeF będzie obejmował faktury wystawiane dotąd na kasach fiskalnych online?

Do końca 2026 r. faktury można wystawiać przy użyciu kas fiskalnych, bez konieczności stosowania KSeF. Od 2027 r., jeśli do transakcji zaewidencjonowanej przy użyciu kasy fiskalnej online będzie wystawiana faktura, to będzie musiała ona zostać wystawiona w KSeF, jeśli dotyczy sprzedaży na rzecz podatnika. Faktury dla osób fizycznych (konsumentów, którzy nie prowadzą działalności gospodarczej) nie muszą być wystawiane w KSeF – można je wystawiać w KSeF nieobowiązkowo.

## 4.Czy Jednostki Samorządu Terytorialnego (JST) będą zwolnione z obowiązku korzystania z KSeF?

Nie. KSeF obowiązkowy będzie również dla wszystkich JST.

## 5.Kwiaciarka wystawia trzy faktury w miesiącu o wartościach od 1 500 zł do 2 500 zł każda. Czy musi wystawiać faktury w KSeF?

Docelowo tak. Obowiązek stosowania KSeF obejmie kwiaciarkę od 1 stycznia 2027 r. Do końca 2026 roku mali przedsiębiorcy mogą wystawiać faktury poza KSeF o ile łączna wartość sprzedaży na fakturach nie przekracza w miesiącu 10 000 zł.

## 6.W jaki sposób opracowywano przepisy KSeF. Czy konsultowano je z przedsiębiorcami?

•    Przeprowadziliśmy jedne z najszerszych konsultacji społecznych w historii administracji, w których w sumie wzięło udział 10 tys. przedsiębiorców •    W toku weryfikacji założeń biznesowych i technicznych projektu, uwzględniliśmy kluczowe postulaty zgłaszane przez przedsiębiorców w zakresie wystawiania e-faktur w KSeF. •    Na tej podstawie stworzyliśmy projekt ustawy przekazany do uzgodnień zewnętrznych i konsultacji publicznych.

## 7.Osoba, która prowadzi gospodarstwo rolne (rozlicza VAT, w 2024 r. osiągnęła wartość sprzedaży 13 mln zł) wystawia faktury na sprzedaż swoich plonów. Czasami odbiorcą jest firma. Wartość pojedynczej faktury wynosi od 50 tys. zł w górę. Czy takie gospodarstwo będzie musiało wystawiać faktury w KSeF?

W opisanej sytuacji rolnik będący podatnikiem VAT czynnym, dokonując sprzedaży na rzecz innego podatnika będzie zobowiązany wystawiać faktury w KSeF począwszy od 1 kwietnia 2026 r.

## 8.Lekarz pracuje na kontrakcie cywilno-prawnym w szpitalu. Wystawia w miesiącu jedną fakturę na 20 000 zł. Od kiedy ma obowiązek wystawiania faktur w KSeF?

Lekarz, którego łączna wartość sprzedaży z wystawionych w miesiącu faktur przekroczyła 10 000 zł, ma obowiązek stosowania KSeF od 1 kwietnia 2026 r. Przepisy przejściowe umożliwiające do końca 2026 r. wystawianie faktur poza KSeF dotyczą przedsiębiorców, których wartość sprzedaży z faktur w danym miesiącu nie przekracza wartości 10 000 zł.

## 9.Czy faktury B2G (przedsiębiorca-administracja publiczna) są objęte obowiązkowym KSeF?

Tak, faktury B2G są objęte obowiązkowym KSeF.

## 10.Czy obowiązek korzystania z KSeF dotyczy tylko spółek? Co z jednoosobowymi działalnościami gospodarczymi?

Forma prawna nie ma znaczenia. Co do zasady każdy podatnik (czynny i zwolniony), który ma obowiązek wystawienia faktury, będzie wystawiał ją w KSeF — zgodnie z etapami: 1.02.2026 r. (duże podmioty) i 1.04.2026 r. (reszta). Obowiązek otrzymywania faktur w KSeF będzie istniał od 1.02.2026 r.

## 11.Czy faktury od zagranicznych dostawców trzeba raportować do KSeF?

Nie. KSeF nie służy do raportowania zakupów od zagranicznych dostawców. System jest przeznaczony do wystawiania faktur w rozumieniu polskich przepisów (w tym na rzecz zagranicznych kontrahentów).

## 12.Na czym polega dobrowolność (fakultatywność) wystawiania faktur VAT RR w KSeF od 1 kwietnia 2026 r.?

Nabywca (podatnik VAT) wystawi fakturę VAT RR w KSeF tylko wtedy, gdy rolnik ryczałtowy złoży w systemie oświadczenie, że jest rolnikiem ryczałtowym i wskaże tego nabywcę jako uprawnionego. Jeśli rolnik nie złoży oświadczenia w KSeF, faktura VAT RR będzie wystawiona poza systemem.

## 13.Kiedy podmiot zagraniczny (zarejestrowany jako podatnik VAT w Polsce) nie będzie objęty obowiązkiem fakturowania w KSeF?

Podmiot zagraniczny nie będzie objęty obowiązkiem fakturowania w KSeF, gdy: •    nie posiada siedziby działalności gospodarczej ani stałego miejsca prowadzenia działalności gospodarczej na terytorium kraju; •    nie posiada siedziby działalności gospodarczej na terytorium kraju, lecz posiada stałe miejsce prowadzenia działalności gospodarczej na terytorium kraju. Stałe miejsce prowadzenia działalności nie uczestniczy jednak w dostawie towarów lub świadczeniu usług, dla których wystawiono fakturę. Podmiot zagraniczny, który nie jest zobowiązany do wystawiania faktur w KSeF, może jednak dobrowolnie korzystać z systemu i wystawiać faktury za jego pośrednictwem.

## 14.Jak weryfikować miejsce prowadzenia działalności gospodarczej kontrahenta zaganicznego?

Ocena czy dany podmiot zagraniczny, zarejestrowany jako podatnik VAT czynny w Polsce, posiada na terytorium kraju stałe miejsce prowadzenia działalności gospodarczej wymaga indywidualnej oceny konkretnego stanu faktycznego. Ministerstwo Finansów planuje wydanie wyjaśnień odnoszących się do kwestii związanych z definicją stałego miejsca prowadzenia działalności gospodarczej.

## 15.Czy w związku z wdrożeniem obligatoryjnego KSeF, obowiązek przekazywania plików JPK_FA będzie wyłączony?

Obowiązek przekazywania plików JPK_FA nie będzie dotyczył faktur wystawionych w KSeF. Jeśli wystawisz fakturę poza KSeF (np. w ramach wyłączeń ustawowych), urząd nadal może zażądać JPK_FA dla tych faktur.

## 16.Sprzedaż ma miejsce 5 kwietnia 2026 r. Termin wystawienia faktury upływa 15 maja 2026 r. Fakturę na rzecz nabywcy (podatnika) wystawiono 7 maja 2026 r. Czy fakturę wlicza się do limitu 10 tys. zł za kwiecień czy za maj?

Fakturę wlicza się do limitu 10 tys. zł zawsze zgodnie datą wystawienia, czyli w maju 2026 r.

## 17.Czyli jeśli w jednym miesiącu nie przekroczę 10.000 zł obrotu, to w tym miesiącu nie muszę wystawić faktur w KSeF? A jak w następnym przekroczę to już muszę? W kolejnym, jeśli nie przekroczę to znowu nie muszę, itd.?

Jeśli w pierwszym miesiącu podatnik nie przekroczy 10 000 zł to nie wystawia faktur w KSeF. Jeśli w drugim miesiącu przekroczy limit, to wystawia już w KSeF tę fakturę, którą przekroczył limit oraz wszystkie kolejne faktury. Fakt nieprzekroczenia limitu w trzecim miesiącu pozostaje już bez znaczenia.

## 18.Czy do limitu 10 tys. zł należy wliczać wartość sprzedaży na rzecz osób fizycznych nieprowadzących działalności gospodarczej udokumentowaną wyłącznie przy użyciu kasy rejestrującej, w stosunku do której nie została wystawiona faktura?

Nie. Do limitu 10 tys. zł nie wlicza się wartości sprzedaży na rzecz osób fizycznych nieprowadzących działalności gospodarczej udokumentowanej wyłącznie przy użyciu kasy rejestrującej.

## 19.Czy do limitu 10 tys. zł należy wliczać wartość sprzedaży na rzecz osób fizycznych nieprowadzących działalności gospodarczej, udokumentowaną tzw. fakturą konsumencką?

Nie.  Faktury konsumenckie nie są objęte obowiązkowym KSeF.  Do limitu 10 000 zł wlicza się wyłącznie wartość tych faktur, w stosunku do których podatnik jest zobowiązany do ich wystawienia w KSeF.

## 20.Czy do limitu 10 tys. zł, należy wliczać wartość faktur wystawionych przy użyciu kas rejestrujących oraz paragonów fiskalnych do 450 zł uznanych za faktury uproszczone?

Nie, gdyż w tych przypadkach można wystawić faktury w postaci papierowej lub elektronicznej. Do limitu 10 tys. zł wlicza się jedynie faktury, które obowiązkowo należy wystawić w KSeF. Dlatego do wartości sprzedaży 10 tys. zł nie będzie wliczana ani wartość faktur wystawionych przy użyciu kas rejestrujących, ani wartość paragonów fiskalnych do 450 zł uznanych za faktury uproszczone.

## 21.Czy do limitu 10 tys. zł, są wliczane tylko faktury, które obowiązkowo należy wystawiać w KSeF (B2B), czy wlicza się wszystkie wystawione faktury?

Do limitu 10 tys. zł wlicza się jedynie faktury, które obowiązkowo należy wystawić w KSeF (tj. w stosunku do których nie istnieją żadne wyłączenia lub przepisy epizodyczne pozwalające na ich wystawienie poza KSeF).

## 1.Czy jeśli wystawię kilka faktur w KSeF „na próbę” przed 1 lutego 2026 r. to od tej pory muszę wystawiać wszystkie faktury w KSeF?

Nie, wystawienie kilku faktur w KSeF w okresie fakultatywnym nie zobowiązuje do dalszego korzystania z systemu przed 1 lutego 2026 r. Obowiązek zacznie się dopiero w terminach ustawowych.

## 2.Czy osoba fizyczna, która wynajmuje firmie lokal, od 01.04.2026 r. będzie musiała wystawiać faktury w KSeF (nie jest zarejestrowana do VAT)?

Co do zasady tak, gdyż osoba, która wynajmuje lokal jest podatnikiem prowadzącym działalność gospodarczą na gruncie ustawy o VAT. Nie będzie jednak musiała wystawiać faktur w KSeF do końca 2026 r., jeśli wartość sprzedaży (wraz z kwotą podatku) udokumentowana fakturami nie przekroczy 10 tys. zł w skali miesiąca.

## 3.Co to jest tryb offline24?

Tryb offline24 umożliwia wszystkim podatnikom wystawianie e-faktur poza KSeF (zgodnych z wzorem faktury ustrukturyzowanej) np. w przypadku problemów z siecią lub brakiem Internetu, z obowiązkiem przesłania ich do systemu najpóźniej następnego dnia roboczego. Faktury w tym trybie muszą być oznaczone dwoma kodami QR, przy czym do wygenerowania drugiego kodu konieczny będzie pobrany wcześniej certyfikat KSeF.

## 4.Czym różni się tryb online od trybu offline? Do czego potrzebny jest certyfikat KSeF?

W KSeF faktury można wystawiać w trybie online (w czasie rzeczywistym) albo w trybie offline (faktura wystawiona poza KSeF z późniejszym dosłaniem jej do KSeF). Tryby offline (offline24, offline-niedostępność KSeF, tryb awaryjny) wymagają przekazania faktury do KSeF w określonym terminie oraz jej oznaczenia dwoma kodami QR w przypadku jej przekazania nabywcy poza systemem, przy czym do wygenerowania drugiego kodu konieczny będzie wygenerowany wcześniej certyfikat KSeF (typu 2). Certyfikat KSeF (typu 1) jest również jedną z metod  uwierzytelnienia się w systemie.

## 5.Czy faktury dla konsumentów (B2C) trzeba wystawiać w KSeF?

Zarówno przed 1 lutego 2026 r. jak i po tej dacie wystawianie faktur B2C (na rzecz osób prywatnych – konsumentów) w KSeF jest dobrowolne.

## 6.Czy faktury "proforma" również będą musiały być wystawiane w KSeF?

Nie. W rozumieniu ustawy o VAT „proforma” nie jest fakturą. Wystawianie tego typu dokumentów nie będzie odbywać się KSeF.

## 7.Czy obowiązkowy KSeF będzie obejmował inne niż faktury dokumenty np. zamówienia?

Nie. KSeF dotyczy tylko faktur. Zamówienie może pojawić się jedynie jako element danych przy fakturze zaliczkowej (zgodnie z przepisami).

## 8.Czy faktury wystawiane osobom fizycznym prowadzącym działalność gospodarczą, które dotyczą prywatnych zakupów towarów lub usług, będą musiały być wystawiane przez KSeF?

Wystawianie  faktur na rzecz osób fizycznych prowadzących działalność gospodarczą, które dotyczą zakupu towarów lub usług na użytek prywatny (czyli stanowiące w istocie transakcję B2C), będzie w KSeF dobrowolne.

## 9.Jak wystawić fakturę dla klienta spoza UE?

Wystawiasz ją w KSeF, a następnie przekazujesz nabywcy w ustalony sposób (np. PDF). Taka faktura ma kod QR z numerem KSeF, dzięki któremu łatwo ją zweryfikować.

## 10.W jakim terminie należy przekazać fakturę do KSeF?

W pierwszej kolejności należy podkreślić, że KSeF nie jest systemem do raportowania wystawianych faktur, tylko system ten służy do ich wystawiania. Dokument przygotowywany w systemach księgowych podatnika musi być wystawiony przy użyciu KSeF. Dokument taki jest przesyłany do systemu, a walor faktury otrzymuje dopiero po otrzymaniu nr KSeF, poza wyjątkami typu offline 24, offline, czy tryb awaryjny. W przypadku faktury ustrukturyzowanej wystawianej w trybie online – fakturę uznaje się za wystawioną w dacie jej przesłania do KSeF (o ile data wskazana w polu P_1 jest zgodna z datą przesłania pliku xml faktury do KSeF). Tego typu faktura jest wystawiana w KSeF w czasie rzeczywistym. Natomiast w przypadku faktur wystawionych w trybie offline24, offline (niedostępność systemu) lub w trybie awaryjnym ustawa określa termin na dosłanie faktur do KSeF. W przypadku trybu offline24 fakturę dosyła się niezwłocznie, nie później niż w następnym dniu roboczym po dniu jej wystawienia. W przypadku trybu offline (niedostępność systemu) fakturę dosyła się do KSeF nie później niż w następnym dniu roboczym po dniu zakończenia okresu niedostępności. W przypadku trybu awaryjnego fakturę przesyła się do KSeF nie później niż w ciągu 7 dni roboczych od zakończenia awarii KSeF. Faktury w ww. trzech trybach uznaje się za wystawione w dacie wskazanej przez podatnika w polu P_1 struktury logicznej FA.

## 11.Czy odbiorca musi akceptować fakturę z KSeF, żeby była ważna?

Nie. W KSeF nie jest wymagana akceptacja faktur przez odbiorcę. Faktura jest uznana za otrzymaną w momencie, gdy system nada jej numer. Nie trzeba już dodatkowo czekać na potwierdzenie od kontrahenta. Tylko w niektórych szczególnych przypadkach (np. przy fakturach dla konsumentów albo dla zagranicznych odbiorców) sprzedawca i nabywca muszą ustalić sposób przekazania faktury (np. PDF-em).

## 12.Czy fakturę online trzeba wysłać tego samego dnia, w którym ją wystawiam?

Tak. Jeśli wystawiasz fakturę w trybie online, musi być wysłana do KSeF jeszcze tego samego dnia. Jeżeli zrobisz to dopiero następnego dnia, system potraktuje ją jako fakturę wystawioną w trybie offline24.

## 13.Co jeśli wyślę fakturę w trybie online 1 lutego, ale numer KSeF dostanę dopiero 2 lutego?

Datą wystawienia faktury w trybie online będzie 1 lutego, czyli dzień, w którym wysłałeś fakturę do systemu i w którym plik zarejestrował się na bramce. Nawet jeśli system nada numer KSeF dopiero następnego dnia, faktura  będzie wystawiona w dniu jej przesłania do systemu.

## 14.Zgodnie z przepisami dotyczącymi obowiązkowego KSeF, warunkiem uznania faktury ustrukturyzowanej za wystawioną, jest nadanie fakturze numeru KSeF. Czy oznacza to, że systemy księgowe muszą wstrzymać się z wprowadzaniem faktur sprzedażowych do momentu nadania numeru KSeF?

Jeśli podatnik zdecyduje się na wystawienie faktury w trybie online, datą wystawienia faktury ustrukturyzowanej jest data przesłania do KSeF. Faktura jest fakturą ustrukturyzowaną, jeśli jest wystawiona przy użyciu KSeF i został jej nadany numer identyfikujący tę fakturę w tym systemie. Nadanie numeru KSeF jest jedną z metod potwierdzenia skutecznego przyjęcia faktury do systemu. Zgodnie z art. 106nda ust. 16 ustawy za fakturę wystawioną w trybie offline24 uznaje się fakturę ustrukturyzowaną, jeżeli data jej przesłania do KSeF jest późniejsza niż data, o której mowa w art. 106e ust. 1 pkt 1 ustawy o VAT, wskazana na tej fakturze w polu P_1. Jeśli podatnik zdecyduje się na wystawienie faktury w trybie offline24 (zgodnie z art. 106nda ustawy o VAT) datą wystawienia faktury jest data, o której mowa w art. 106e ust. 1 pkt 1 ustawy o VAT – wskazana w polu P_1. Identyczna zasada będzie obowiązywała również w okresie niedostępności KSeF (art. 106nh ustawy) oraz jego awarii (art. 106nf ustawy). W systemach księgowych w przypadkach, w których data wystawienia faktury ma wpływ na datę ujęcia zdarzenia w ewidencji, powyższe reguły będzie należało uwzględnić.

## 15.Co system sprawdza zanim nada numer KSeF?

System weryfikuje dwie rzeczy: czy dokuemnt (plik XML) jest zgodny z obowiązującym wzorem e-Faktury, czy osoba, która wysyła plik, ma odpowiednie uprawnienia.

## 16.Co znaczy „przesłanie faktury” do KSeF?

„Przesłanie faktury” to zainicjowanie wysyłki pliku w ramach otwartej sesji i jego rejestracja na bramce. Jeśli plik jest poprawny, to otrzyma numer KSeF. Jeśli plik ma błędy, system odrzuci go i faktura nie zostanie wystawiona — wtedy trzeba go poprawić i wysłać ponownie.

## 17.Czy można wystawić fakturę w KSeF bez NIP sprzedawcy?

Nie. NIP sprzedawcy jest obowiązkowy. Bez niego faktura nie zostanie przyjęta w systemie.

## 18.Czy będzie możliwość edytowania wystawionej faktury w razie jakiegoś błędu?

Nie. Faktura po przyjęciu do KSeF staje się dokumentem prawnym i nie można jej zmieniać. Jeśli pojawi się błąd, trzeba wystawić fakturę korygującą.

## 19.Co jeśli w fakturze są błędy rachunkowe, np. źle policzona kwota należności ogółem?

Plik przesyłany do KSeF powinien zawierać prawidłowe wartości rachunkowe. System nie weryfikuje takich błędów i przyjmie taki plik XML. Faktura będzie jednak wystawiona z błędem. Aby poprawić dane, trzeba będzie wystawić fakturę korygującą.

## 20.Co zrobić z plikiem XML odrzuconym przez system? Wystawić korektę lub anulować?

Skoro plik XML został odrzucony, to faktura nie została wystawiona. Nie można więc wystawić faktury korygującej ani anulować faktury. Trzeba przygotować i wysłać nowy, poprawny plik XML.

## 21.Czy KSeF odrzuci fakturę wystawioną na złego kontrahenta?

Nie. System nie sprawdza poprawności danych kontrahenta. Jeśli podałeś zły NIP, faktura zostanie przyjęta. Wtedy prawidłowym rozwiązaniem jest wystawienie korekty do zera dla błędnego kontrahenta i nowej faktury dla właściwego.

## 22.Ile korekt można wystawić do jednej faktury?

Nie ma ograniczenia. Można wystawiać tyle korekt, ile jest konieczne do wystawienia finalnie  prawidłowej faktury.

## 23.Co należy zrobić, gdy wystawię fakturę na błędnego nabywcę?

Aby skorygować błąd związany z wystawieniem faktury na błędnego nabywcę w KSeF, należy wystawić fakturę korygującą do zera z błędnym NIP nabywcy oraz nową fakturę pierwotną z poprawnym numerem NIP nabywcy. Jest to konieczne ze względu na uwarunkowania systemowe. Po przetworzeniu, faktura z błędnym NIP będzie dostępna dla podmiotu o tym numerze NIP, jeśli taki istnieje.

## 24.Czy przy fakturach korygujących zbiorczych trzeba podawać dane wszystkich faktur pierwotnych?

Tak. Faktura korygująca musi wskazywać dane wszystkich faktur pierwotnych, których dotyczy korekta (tj. ich numery nadane przez podatnika, numery KSeF, daty wystawienia).

## 25.Czy w KSeF jest możliwe samofakturowanie?

Tak. Nabywca może wystawić fakturę w imieniu sprzedawcy, ale sprzedawca musi wcześniej nadać mu takie uprawnienie w KSeF.

## 26.Czy firmy zagraniczne mogą wystawiać faktury w imieniu polskich firm (samofakturowanie)?

Tak, nabywcy z innych krajów UE, którzy posiadają numer identyfikacji na cele transakcji wewnątrzwspólnotowych, będą mogli wystawić fakturę w imieniu polskiego sprzedawcy  w ramach samofakturowania (w przypadku dokonania przez niego WDT).

## 27.Czy KSeF sprawdza status kontrahenta w Wykazie Podatników VAT?

Aktualnie nie jest planowane wprowadzenie takiej funkcjonalności. Biorąc pod uwagę, że Wykaz Podatników VAT zawiera wyłącznie dane podatników zarejestrowanych do VAT jako podatnicy VAT czynni lub jako podatnicy VAT zwolnieni (brak podatników zwolnionych, którzy nie zarejestrowali się jako podatnicy VAT zwolnieni), takie podejście nie pozwoliłoby na realizację celu związanego z identyfikacją statusu wszystkich podmiotów objętych KSeF.

## 28.Jak ustalić status nabywcy, jeśli nie ma NIP i nie ma go w Wykazie Podatników VAT?

W zakresie kwestii związanych z identyfikacją podatników zwolnionych na potrzeby KSeF, zostały zaproponowane odpowiednie rozwiązania w przepisach (tzw. samoidentyfikacja nabywcy). W pozostałych przypadkach, gdy nabywcą jest podatnik nieposiadający NIP, kluczowa pozostaje komunikacja na linii sprzedawca-nabywca.

## 29.Czy KSeF przewiduje jakieś mechanizmy przeciwdziałania oszustwom i  wystawianiu fałszywych faktur?

Tak, system umożliwia zgłaszanie administracji skarbowej faktur, w stosunku do których zachodzi podejrzenie oszustwa. To dodatkowe zabezpieczenie przed nadużyciami.

## 30.Czy można wskazać kilku odbiorców faktury (np. faktor, płatnik)?

Tak. Można wskazać dodatkowych odbiorców i wtedy każdy z nich ma dostęp do faktury w KSeF.

## 31.Co, jeśli chcę umieścić długi opis na fakturze?

Dodatkowe informacje na fakturze będzie można zamieścić w polu DodatkowyOpis lub polu StopkaFaktury (zawiera ono maksymalnie 3500 znaków). Dodatkowo będzie możliwość przesyłania faktur z załącznikiem do KSeF, ale tylko w przypadku potrzeby zawarcia w załączniku złożonych danych w zakresie ceny, ilości i miary (szczególnie istotne dla dostawców mediów i firm świadczących usługi telekomunikacyjne).

## 32.Czy wizualizacja faktury może być po angielsku albo dwujęzyczna?

Tak. Wizualizacja może być w innym języku, ale musi być zgodna pod względem merytorycznym (po przetłumaczeniu) z danymi w pliku XML przesłanym do KSeF.

## 33.Czy wizualizacja faktury musi wyglądać tak jak wzór Ministerstwa?

Nie. Programy mogą generować własny wygląd faktury. Wizualizacja musi odzwierciedlać pod względem merytorycznym dane w KSeF aby nie wprowadzać w błąd co do warunków transakcji, osoby, która taką wizualizację otrzymuje.

## 34.Czy wizualizacja musi mieć kod QR?

Tak, jeśli faktura będzie przekazywana poza KSeF (np. w PDF-ie). Kod QR umożliwia sprawdzenie w systemie, a po wpisaniu danych dodatkowych jej pobranie z systemu.

## 35.Czy trzeba mieć płatny program, żeby wystawiać faktury w KSeF?

Nie. Ministerstwo Finansów zapewnia bezpłatne narzędzia – Aplikację Podatnika KSeF, dostępną w wersji online (wersja testowa dostępna będzie od 3 listopada 2025 r.) i Aplikację Mobilną KSeF (od 01 lutego 2026 r.).

## 36.Jak zagraniczny kontrahent otrzyma fakturę wystawioną w KSeF?

Faktura zostaje wystawiona w KSeF, ale zagraniczny odbiorca, który z założenia nie posiada polskiego NIP, nie będzie mógł zalogować się do systemu i jej pobrać. Dlatego sprzedawca musi przekazać mu dokument w uzgodniony sposób — np. w formie PDF, mailowo, albo nawet papierowo, jeśli tak się umówią. Faktura powinna być opatrzona kodem QR, który pozwoli zweryfikować kontrahentowi, że dokument faktycznie istnieje w KSeF.

## 37.Gdzie można sprawdzić datę nadania numeru KSeF?

Informacja ta jest podana w UPO (Urzędowym Poświadczeniu Odbioru) w polu "Data przyjęcia dokumentu do systemu teleinformatycznego MF”. oraz w danych widocznych dla odbiorcy w systemie. To właśnie ta data decyduje o momencie otrzymania faktury przez nabywcę.

## 38.Czy system automatycznie poinformuje mnie, że ktoś wystawił fakturę dla mojej firmy?

Nie, KSeF nie wysyła powiadomień. Twoje oprogramowanie (program księgowy, aplikacja) musi regularnie sprawdzać, czy pojawiły się nowe faktury. MF udostępnia Aplikację Podatnika KSeF (w wersji online) oraz  Aplikację Mobilną KSeF (do pobrania na smartfon) do której możesz się zalogować i sprawdzić wszystkie faktury wystawione dla Ciebie.

## 39.Czy można sprawdzić, czy nabywca pobrał fakturę z KSeF?

Nie, system nie daje takiej informacji.

## 40.Czy możliwe jest automatyczne pobieranie faktur z KSeF?

Tak. System pozwala na integrację, dzięki której faktury będą automatycznie pobierane. O szczegóły zapytaj swojego dostawcę oprogramowania.

## 41.Czy trzeba wysyłać kontrahentowi numer KSeF faktury?

Nie ma takiego obowiązku, ponieważ faktura pojawia się w systemie odbiorcy automatycznie.

## 42.Co z fakturami wystawionymi na spółkę przed wejściem do grupy VAT? Czy będą nadal dostępne?

Tak. Wszystkie faktury wystawione przed wejściem do grupy VAT pozostają w systemie i podatnik nadal ma do nich dostęp. Wejście do grupy VAT nie powoduje utraty dostępu do faktur wystawionych lub otrzymanych przez spółkę przed wejściem do grupy VAT.

## 43.Od kiedy będę musiał zamieszczać numer KSeF w przelewie (w tytule płatności)?

Tak, przepis dodawanego art. 108g ustawy o VAT będzie stosowany do płatności dokonanych od dnia 1 stycznia 2027 r. W tym samym terminie zacznie obowiązywać znowelizowany art. 108a ust. 3 pkt 3 ustawy o VAT, wprowadzający obowiązkowe zamieszczenie numeru KSeF w przelewie w zakresie faktur, których płatność regulowana jest w mechanizmie podzielonej płatności (kwoty VAT wpłacane na odrębny rachunek techniczny podatnika).

## 44.Dlaczego od 1 stycznia 2027 r. będę musiał podawać numer KSeF przy płatnościach za faktury (w tytule płatności)?

Głównym celem jest przeciwdziałanie zatorom płatniczym. Rozwiązanie to przyczyni się także do zwiększenia poprawności dokonywania płatności pomiędzy podmiotami.

## 1.Od kiedy będzie możliwe wystawienie w KSeF faktury z załącznikiem?

Od 1 lutego 2026 r.

## 2.Czy załącznik jest obowiązkowy?

Dobrowolny i zależeć będzie od podatnika oraz specyfiki jego działalności.

## 3.Dlaczego załączniki będą przyjmowane tylko jako pliki XML, a nie np. PDF?

Załącznik jest traktowany jako integralna część faktury. Faktura w KSeF musi mieć format pliku XML. Dlatego nie można dołączyć PDF czy Worda. Dzięki temu całość pozostaje spójna i możliwa do automatycznego odczytania przez systemy księgowe.

## 4.Czy można dodać załącznik w formie nieustrukturyzowanej, np. zdjęcie?

Nie. Do KSeF można przesyłać wyłącznie pliki ustrukturyzowane (XML). Pliki typu JPG, PNG czy inne zdjęcia albo dokumenty PDF można oczywiście przekazywać kontrahentom, ale tylko poza systemem KSeF.

## 5.Co z dokumentami dodatkowymi, np. listem przewozowym, które do tej pory wysyłano razem z fakturą w jednym mailu?

Takie dokumenty jak list przewozowy nie są częścią faktury i nie będą przekazywane w KSeF. Nadal trzeba je wysyłać poza systemem, np. mailowo lub w inny uzgodniony sposób.

## 6.Czy można dołączać do e-Faktury protokoły odbioru?

Nie. Protokoły odbioru nadal będą przekazywane poza KSeF. Jeśli chcesz, możesz dopisać dodatkowe informacje na fakturze w polach DodatkowyOpis albo StopkaFaktury. Ale sam protokół nie będzie mógł być zawarty w załączniku do faktury.

## 7.Czy tylko niektóre branże będą mogły wystawiać faktury z załącznikami?

Nie, możliwość dodawania załączników nie jest ograniczona do określonych branż – może z niej korzystać każdy podatnik. Niemniej opcja ta została wprowadzona głównie z myślą o potrzebach branż, gdzie faktury mają bardzo złożone dane, np. media, telekomunikacja, paliwa.

## 8.Jakie działania musi podjąć podatnik, żeby wystawiać faktury z załącznikiem?

Przedsiębiorca będzie musiał złożyć zgłoszenie w e-Urzędzie Skarbowym (e-US), informując Szefa KAS o zamiarze wystawiania i przesyłania do KSeF faktur z załącznikiem. Dopiero po otrzymaniu przez podatnika potwierdzenia mailowego o możliwości wystawiania i przesyłania do KSeF faktur z załącznikiem, będzie można korzystać z tej funkcji.

## 9.Od kiedy można składać zgłoszenia dotyczące załącznika w e-Urzędzie Skarbowym?

Zgłoszenia będzie można składać od 1 stycznia 2026 r., czyli na miesiąc przed startem obowiązkowego KSeF dla największych firm.

## 10.Jak długo trwa realizacja zgłoszenia? Czy może być odrzucone?

Zgłoszenie zostanie zrealizowane maksymalnie w ciągu 3 dni roboczych. Nie przewiduje się możliwości odrzucenia takich zgłoszeń – wystarczy poprawnie je złożyć, aby zostało przyjęte.

## 11.Czy żeby odbierać faktury z załącznikiem, też trzeba składać zgłoszenie?

Nie. Zgłoszenie muszą składać tylko ci podatnicy, którzy chcą wystawiać faktury z załącznikami. Odbieranie takich faktur nie wymaga żadnych dodatkowych formalności.

## 12.Czy zgłoszenie można złożyć w wersji papierowej?

Nie. Zgłoszenia składa się wyłącznie elektronicznie w e-Urzędzie Skarbowym.

## 13.Czy zgłoszenie dotyczące załącznika można złożyć w Aplikacji Podatnika KSeF albo w innym programie księgowym zintegrowanym z KSeF?

Nie. Zgłoszenie można złożyć tylko w e-Urzędzie Skarbowym. Nie ma możliwości zrobienia tego w Aplikacji Podatnika KSeF czy w programie księgowym.

## 14.Czy UPO (Urzędowe Poświadczenie Odbioru) oznacza, że zgłoszenie dotyczące załącznika zostało zrealizowane?

Nie. UPO potwierdza jedynie, że zgłoszenie zostało skutecznie złożone w e-Urzędzie Skarbowym. Dopiero po jego realizacji podatnik dostanie osobny e-mail z potwierdzeniem, że może wystawiać i przesyłać do KSeF faktury z załącznikiem.

## 15.Kto składa zgłoszenie o wystawianie faktur z załącznikiem w przypadku jednoosobowej działalności gospodarczej, a kto w przypadku spółki?

Zgłoszenie w e-Urzędzie Skarbowym w przypadku jednoosobowej działalności zgłoszenie składa sam podatnik (osoba fizyczna). W spółce zgłoszenie składa użytkownik konta organizacji (UKO).

## 16.Dostawcy mediów (np. woda, energia, gaz) często wpisują w fakturach dodatkowe informacje, takie jak numer licznika czy odczyty. Jak to będzie wyglądało w KSeF?

Takie dane można wpisać w fakturze w polu „DodatkowyOpis” albo – w okresie obowiązkowego KSeF w załączniku do faktury . Co ważne, faktury wystawiane na rzecz konsumentów (osób fizycznych) w KSeF będą dobrowolne, więc w wielu przypadkach te dane będą mogły być dalej przekazywane jak dotychczas.

## 17.Jaki będzie maksymalny rozmiar faktury z załącznikiem?

Maksymalny rozmiar takiej faktury wyniesie 3 MB. To limit, który pozwala zmieścić sporo danych, ale jednocześnie gwarantuje sprawne działanie systemu.

## 18.Czy faktury z załącznikiem będzie można wystawiać w bezpłatnych aplikacjach MF (Aplikacji Podatnika KSeF, Aplikacji Mobilnej KSeF)?

Nie. Wystawienie faktury z załącznikiem będzie możliwe tylko w komercyjnych programach księgowych zintegrowanych z API KSeF 2.0. Bezpłatne aplikacje MF będą obsługiwały e-faktury, ale bez tej dodatkowej funkcji.

## 19.Zajmuję się sprzedażą usług telekomunikacyjnych i wystawiam faktury o złożonym zakresie danych w zakresie ceny, jednostki miary i ilości. Złożyłem w e-US zgłoszenie w sprawie wystawiania faktur z załącznikiem, które zostało zrealizowane. Czy od teraz wystawiam faktury z załącznikiem również w moim drugim profilu działalności (handel obuwiem), w którym nie wystawiam faktur o złożonym zakresie danych?

Nie, ponieważ faktury w drugim profilu działalności nie dotyczą czynności o złożonych danych w zakresie ceny jednostkowej, miary i ilości.

## 20.Co jeśli zmienię profil działalności i już nie będę wystawiać faktur z załącznikami, ale nadal muszę czasem wystawić korekty do starych faktur?

Nie należy zgłaszać zaprzestania korzystania z załączników. Jeśli to zrobisz, stracisz możliwość wystawiania również korekt do wcześniejszych faktur z załącznikiem. Dlatego nawet jeśli w nowym profilu działalności nie używasz już tej funkcji, nie zgłaszaj zaprzestania wystawiania i przesyłania do KSeF faktur z załącznikiem.

## 1.Czy podatnik, który wystawia faktury o łącznej wartości brutto nieprzekraczającej 10 tys. zł miesięcznie, może wystawiać je w formie papierowej, bez obowiązku korzystania z KSeF?

Tak, do końca 2026 r. podatnik może wystawiać faktury poza KSeF (np. papierowo lub elektronicznie), jeśli w danym miesiącu łączna wartość sprzedaży z podatkiem z tych faktur nie przekracza 10 000 zł. Jeśli jednak wartość ta zostanie przekroczona, podatnik musi wystawiać faktury w KSeF – począwszy od faktury, która przekroczył limit. Zachęcamy jednak, aby już wcześniej przygotować swoją firmę do KSeF. Odsunięcie w czasie obowiązku wystawiania faktur w KSeF nie wpłynie na konieczność ich odbierania w systemie. Otrzymywanie faktur od 1 lutego 2026 r. będzie odbywało się za pośrednictwem KSeF.

## 2.Czy jest planowana integracja KSeF i Portalu Elektronicznego fakturowania (PEF).

Tak. Obecnie trwają prace nad integracją KSeF i PEF, które od 1 lutego 2026 r. zapewnią przesyłanie faktur PEF do środowiska produkcyjnego KSeF 2.0.

## 3.Czy struktura logiczna FA(3) będzie obowiązywała od 1 lutego 2026 r.?

Tak. Struktura logiczna FA(3) będzie obowiązywała od 1 lutego 2026 r.

## 4.Jakie najważniejsze zmiany nastąpiły w strukturze logicznej FA(3) w porównaniu do struktury logicznej FA(2)?

W strukturze logicznej FA(3) nastąpiły zmiany korzystne dla podatników, związane w szczególności z prezentacją terminu płatności, wprowadzeniem nowej roli w Podmiot3 – pracownik (rozwiązanie istotne dla identyfikacji wydatków pracowniczych), zwiększeniem ilości znaków w polu P_7 (nazwa towaru lub usługi), rozwiązaniami dedykowanymi JST i GV czy możliwością dodania załącznika do faktury.

## 5.Jakie zmiany zostały wprowadzone w strukturze FA(3) pod kątem JST i GV?

W strukturze logicznej wprowadzono rozwiązanie, które ułatwi jednostkom podległym JST oraz członkom GV odbiór faktur zakupowych w KSeF. Zmiana polega na wprowadzeniu w Podmiot2 dodatkowych oznaczeń, które będą wskazywały, że faktura dotyczy (oznaczenie „1” w polu JST i GV) lub nie dotyczy (oznaczenie „2” w polu JST i GV) jednostki podrzędnej JST lub członka grupy VAT. W przypadku wskazania „1” należy uzupełnić sekcję Podmiot3, w tym identyfikator NIP lub IDWew podmiotu trzeciego (choć formalnie w dalszym ciągu będzie to pole opcjonalne).

## 6.Czy system będzie przyjmował faktury bez elementów nieobowiązkowych (innych niż wynikające z ustawy o VAT), ale wynikających ze struktury logicznej?

Przesyłana faktura musi być zgodna z obowiązującą strukturą logiczną. W przypadku, gdy faktura będzie zawierała błędy np. nie wszystkie wymagane przez strukturę pola zostaną wypełnione, faktura zostanie odrzucona. Należy podkreślić, że w strukturze istnieją pola, które stają się obowiązkowe w momencie wypełniania węzłów lub sekwencji o charakterze fakultatywnym, w których pola te są zawarte, mimo że dotyczą elementów, których nie wymaga ustawa o VAT. W tego typu sytuacjach fakultatywność osiągana jest na poziomie węzła lub sekwencji. Zatem w przypadku wypełniania fakultatywnych węzłów zawartych w fakturze, pola obowiązkowe w tym węźle muszą zostać wypełnione dla skuteczności wysyłki pliku faktury.

## 7.Posiadam w systemie finansowo-księgowym więcej informacji niż chciałbym prezentować na fakturze, czy pola oznaczone w schemie xsd jako nieobligatoryjne mogą pozostać niewypełnione?

Obligatoryjny charakter danego pola wynika w szczególności z treści obowiązujących przepisów. Struktura logiczna e-Faktury oprócz elementów, których występowanie regulowane jest art. 106a - 106q ustawy o VAT, zawiera także elementy, których stosowanie jest całkowicie dobrowolne i dowolne. Uwzględnienie ich w strukturze wynika z praktyki biznesowej obserwowanej na rynku. To tzw. dodatkowe elementy faktury, które nie wynikają z przepisów VAT, a których stosowanie w fakturze nie jest zabronione. Pola te mogą pozostać niewypełnione, nawet w przypadku posiadania takich danych.

## 8.Struktura logiczna e-Faktury zawiera szereg nowych pól, których nie było do tej pory w strukturach JPK_FA. Czy to oznacza, że rozszerzono zakres danych wymaganych w fakturach?

Struktura logiczna e-Faktury oprócz elementów, których występowanie regulowane jest art. 106a - 106q ustawy o VAT, zawiera także elementy, których stosowanie jest całkowicie dobrowolne i dowolne. Uwzględnienie ich w strukturze wynika z praktyki biznesowej obserwowanej na rynku, w tym na skutek uwag zgłaszanych w trakcie konsultacji społecznych struktury. To tzw. dodatkowe elementy faktury, które nie wynikają z przepisów VAT, a których stosowanie w fakturze nie jest zabronione.

## 9.Czy jest dostępna lista pól obowiązkowych i nieobowiązkowych w strukturze logicznej e-Faktury?

Nieobowiązkowymi węzłami są węzły Rozliczenie, Platnosc, WarunkiTransakcji, Stopka oraz Zalacznik. Przy czym wypełniając węzły dobrowolne, może zachodzić konieczność wypełnienia pól obowiązkowych zawartych w tych węzłach. Węzeł Zamowienie dotyczy wyłącznie faktur zaliczkowych i ich korekt. W przypadku takich faktur nie wypełnia się węzła FaWiersze. Pozostałe pola wypełniane są w zależności od wymogów przewidzianych w ustawie dla danego dokumentowanego fakturą przypadku.

## 10.Struktura logiczna e-Faktury zawiera pole dobrowolne StatusInfoPodatnika. Czy informacja np. o tym, że sprzedawca znajduje się stanie likwidacji powinna być przechowywana i odkładana w systemie finansowo-księgowym nabywcy, który otrzymał taką fakturę, czy można ją pominąć?

Faktura ustrukturyzowana, którą pobierze nabywca ze swojego systemu finansowo-księgowego (za pośrednictwem API) zawiera identyczną treść w porównaniu do faktury przesłanej do KSeF przez sprzedawcę w formacie xml. Przepisy wprowadzające KSeF nie przewidują nowych, dodatkowych obowiązków ewidencyjnych po stronie nabywcy.

## 11.Czy nie powinniśmy najpierw rozważyć w Polsce obowiązkowego posiadania NIP dla osób prywatnych niebędących przedsiębiorcami? Pomogłoby to w transakcjach B2C. Ja mam NIP, mimo że nie prowadzę żadnej działalności.

Przepisy dotyczące obowiązku posiadania identyfikatora podatkowego NIP przez osoby prywatne zostały zniesione w 2012 r. i nie jest planowany powrót do tamtych regulacji. W KSeF możliwe jest wystawienie faktury bez wskazywania identyfikatora nabywcy w Podmiot2 (wówczas wypełniane jest pole BrakID – wartość „1”).

## 12.Jak się ma data i czas wytworzenia dokumentu e-faktury do pola data wystawienia (P_1) z elementu <Fa> ?

Data podana w polu P_1 to wskazana przez wystawcę faktury data jej wystawienia, o której mowa w art. 106e ust. 1 pkt 1 ustawy o VAT. Natomiast pole DataWytworzeniaFa ma jedynie charakter techniczny, to generowana przez system podatnika data i czas wytworzenia faktury (pliku xml).

## 13.Czy w fakturze przesyłanej do KSeF w trybie online należy wypełnić pole P_1 (data wystawienia), skoro fakturę ustrukturyzowaną uznaje się za wystawioną w dniu jej przesłania? Czy będzie mogło dojść do sytuacji, w której faktura ustrukturyzowana przesłana o 23:59 danego dnia (z perspektywy wysyłającego) zostanie uznana przez KSeF za przesłaną o 0:01 następnego dnia? Czy w sytuacji, gdy KSeF uzna fakturę ustrukturyzowaną za wystawioną (przesłaną) w innym dniu, niż data wskazana w polu P_1, faktura taka zostanie przez KSeF odrzucona?

Pole P_1 dotyczące daty wystawienia jest polem obowiązkowym, które musi zostać wypełnione, aby faktura mogła być przyjęta przez KSeF. Faktura wystawiona w trybie online będzie uznana za wystawioną w dniu jej przesłania do KSeF zgodnie z art. 106na ust. 1 ustawy o VAT, czyli w momencie, w którym trafi do systemu (zostanie zarejestrowana na bramce) niezależnie od późniejszego momentu jej przetworzenia. Kluczowe (w okresie obowiązkowego KSeF) dla uznania faktury za fakturę online jest, aby data wskazana przez podatnika w polu P_1 była zgodna z datą przesłania pliku xml faktury do KSeF (a nie datą nadania numeru KSeF).

## 14.Struktura FA(2) w części podsumowania stawek VAT Faktura/Fa (np. P_13_1, P_14_1) nie pozwala nabywcy na jednoznaczną interpretację zastosowanej przez wystawiającego stawki VAT (22% i/lub 23%), Czy zostało to poprawione w wersji struktury FA(3)?

Obowiązującą aktualnie stawką jest 23%. Przypadki dotyczące zastosowania stawki 22% są marginalne. Stawkę można zidentyfikować na poziomie wiersza faktury. Znajduje się tam pole P_12 będące polem słownikowym, w którym podatnik wskazuje konkretną stawkę podatku.

## 15.W schemie FA(2) oznaczenie „np I” i „np II” odnosi się wyłącznie do transakcji dostaw towarów i świadczenia usług poza terytorium kraju. W praktyce na fakturach oznaczenie „np” stosuje się często dla sprzedaży bonów (innych niż bony jednego przeznaczenia) lub kart podarunkowych (lub innych transakcji, które nie podlegają ustawie o VAT). W jaki sposób wykazywać na fakturze KSeF takie operacje lub korygować tego typu operacje udokumentowane wcześniej fakturami wystawionymi poza KSeF?

W przypadku dokumentowania wyłącznie czynności niepodlegającej ustawie VAT tj. sprzedaży bonu różnego przeznaczenia – nie wystawia się faktury. Tego typu czynności i ich korekty niepodlegające ustawie VAT nie powinny być prezentowane na fakturze jako pozycje (wiersze) z oznaczeniem „np I” ani „np II”. Mogą one zostać zaprezentowane w ramach informacji dodatkowych na fakturze, przy wykorzystaniu węzła fakultatywnego „Rozliczenie” (przy założeniu, że faktura zawiera także pozycje podlegające ustawie, a czynności niepodlegające stanowią dodatkowy element transakcji).

## 16.Co to jest uniwersalny unikalny numer wiersza faktury (UU_ID)? Jak bardzo ma być on unikalny? Czy na fakturze korygującej ten numer ma być taki sam jak na korygowanej?

Wykorzystanie pola UU_ID lub UU_IDZ jest dobrowolne i umożliwia nadawanie wierszom faktury unikalnych numerów, które może ułatwiać ich identyfikację w wykorzystywanych systemach księgowych oraz pozwala na jednoznaczne wiązanie numerów wierszy faktury pierwotnej z numerami wierszy w fakturach korygujących. Pola przyjmują do 50 znaków.

## 17.Czy została dodana w strukturze FA(3) w wierszu faktury, informacja o rabacie procentowym?

Nie, taka zmiana nie została wprowadzona. Udzielenie rabatu procentowego do faktury jako całości nie wymaga powielania zapisów do wszystkich wierszy faktury. Rabat może zostać dodany jako osobna pozycja faktury.

## 18.Jakich sytuacji dotyczą pola KursUmowny, WalutaUmowna?

Pola KursUmowny i WalutaUmowna dotyczą przypadków, gdy faktura wystawiona jest w złotówkach, co oznacza, że określone w art. 106e ust. 1 – 10 ustawy o VAT kwoty w fakturze wyrażone są w złotych, względnie faktura jest tzw. fakturą dwuwalutową, gdzie wszystkie te kwoty są wyrażone jednocześnie w złotówkach i walucie obcej, a strony transakcji chcą w fakturze zawrzeć informację o kursie waluty w oparciu, o który dokonano takiego umownego przeliczenia. Jest to sytuacja odmienna od przypadku, gdy kwoty w fakturze określone są wyłącznie w walucie obcej i jedynie kwota podatku przeliczona jest na złotówki zgodnie z art. 106e ust. 11 ustawy o VAT. Wówczas wypełniane są pola KodWaluty i KursWaluty.

## 19.Jak będą wyglądały faktury wystawiane w walucie obcej dla kontrahentów polskich?

W takiej fakturze kwoty określone są wyłącznie w walucie obcej i jedynie kwota podatku w polu P_14_xW przeliczona jest na złotówki zgodnie z art. 106e ust. 11 ustawy o VAT. Wówczas oprócz pola KodWaluty wypełniane jest pole KursWaluty, względnie pole KursWalutyZ.

## 20.Czy MF może rekomendować wystawcom faktur na sprzedaż leków właściwe pola, w których należy podawać serię i daty ważności produktów? Aktualnie obsługujemy około 450 dostawców, gdzie w dobie KSeF każdy może wskazać te dane nieobowiązkowo i w polach wybranych przez siebie.

Tego typu dane można umieszczać np. w polu DodatkowyOpis.

## 21.W jaki sposób oprócz numerów zamówienia nadawanych przez system dostawcy będą podawać także numery zamówień generowane przez system nabywcy?

Struktura e-Faktury KSeF umożliwia podawanie dodatkowych danych niewymaganych przepisami ustawy o VAT. Do ich prezentacji służy element DodatkowyOpis. Dane te mogą być podawane w odniesieniu do konkretnego wiersza faktury lub w odniesieniu do faktury jako całości.

## 22.Czy struktura logiczna e-Faktury przewiduje pole do swobodnego wykorzystania w korespondencji do nabywcy?

Nie. Natomiast, jest możliwość zamieszczania w fakturze dodatkowych informacji w polach: - DodatkowyOpis – pole rezerwowe przeznaczone dla wykazywania dodatkowych informacji na fakturze, w tym wymaganych przepisami prawa, dla których nie przewidziano innych pól/elementów, - StopkaFaktury- pozostałe informacje na fakturze (maks. 3500 znaków).

## 23.Czy w wersji wzoru FA(3) nastąpiły zmiany dotyczące struktury pola IDWew?

Nie. W zakresie pola IDWew, dotyczącego modelu uprawnień wykorzystującego unikalny identyfikator wewnętrzny zakładu (oddziału) osoby prawnej bądź innej wyodrębnionej jednostki wewnętrznej podatnika, nie nastąpiły żadne zmiany.

## 24.Czy planowane przejście na strukturę FA(3) od 1 lutego 2026 r. będzie oznaczało konieczność jej stosowania (od tej daty) także przez "niedużych" podatników, którzy wchodzą w obowiązkowe wystawianie faktur od 1 kwietnia 2026 r., ale będą je wystawiać w systemie dobrowolnie już w lutym i marcu?

Tak, struktura logiczna FA(3) będzie obowiązywała powszechnie. Podatnik, który jest objęty obowiązkiem wystawiania faktur w KSeF od 1 kwietnia 2026 r., ale będzie je już wystawiał w lutym i marcu dobrowolnie, także będzie stosował strukturę FA(3).

## 25.Jeżeli mój system jest obecnie zintegrowany z KSeF 1.0 czy potrzebuję integracji z nowym systemem w wersji 2.0?

Tak, integracja jest niezbędna ponieważ wersja API KSeF 2.0 wprowadza nowe funkcjonalności wcześniej niedostępne w API KSeF 1.0, takie jak np. struktura logiczna faktury w formacie FA(3) z węzłem załącznik, tryby offline24 czy certyfikaty KSeF.

## 26.Kiedy zostanie uruchomiona usługa zgłaszania faktur scamowych oraz ukrywania faktur?

Usługa zgłaszania faktur scamowych oraz ukrywania faktur zostaną udostępnione w kolejnych wersjach systemu już po uruchomieniu nowej wersji produkcyjnej systemu.

## 1.Jakie tryby wystawiania faktur będą dostępne w KSeF 2.0?

System przewiduje dwa tryby:  online i tryb offline. Tryb online to podstawowy tryb i polega na wystawianiu faktur w KSeF w czasie rzeczywistym. Tryb offline będzie obejmował w istocie trzy możliwe procedury szczególne: •    tryb offline24  - możesz wystawić fakturę bez połączenia z KSeF, ale musisz ją dosłać do systemu najpóźniej następnego dnia roboczego. To rozwiązanie można stosować np. w razie chwilowych problemów z internetem (ale również gdy takie ograniczenia nie będą występować) •    tryb offline -  kiedy Ministerstwo Finansów prowadzi prace serwisowe i system nie działa, faktury można wystawiać offline. Trzeba je dosłać do KSeF najpóźniej dzień po zakończeniu przerwy. •    tryb awaryjny - gdy nastąpi awaria KSeF ogłoszona w BIP MF i oprogramowaniu interfejsowym faktury wystawiasz offline i masz aż 7 dni roboczych od zakończenia awarii, aby je przesłać do systemu Każdy tryb ma inne zasady, ale w każdym z nich najważniejsze jest, żeby ostatecznie faktura trafiła do systemu.

## 2.Jaki jest powód wprowadzenia różnych trybów offline?

Celem jest zapewnienie przedsiębiorcom funkcjonowania i wystawiania faktur nawet w przypadku różnych sytuacji awaryjnych. Jeśli nie ma internetu, system przechodzi przerwę techniczną albo wystąpi awaria KSeF, można nadal wystawiać faktury. Wystąpi jednak obowiązek późniejszego dosłania ich do KSeF w odpowiednim terminie. Dzięki temu zapewniona jest ciągłość wystawiania fakturowania pomimo różnych okoliczności.

## 3.Czy w trybach offline można wystawiać faktury dla konsumentów (B2C)?

Tak, przepisy nie ograniczają tego — faktury dla konsumentów można wystawiać offline.

## 4.Czy trzeba mieć dowód, że faktycznie nie było internetu, żeby wystawić fakturę offline24?

Nie. Przepisy nie wymagają od podatnika żadnego dodatkowego dowodu. Wystarczy, że wystawisz fakturę w tym trybie i doślesz ją w terminie.

## 5.Co oznacza „niedostępność KSeF” (art. 106nh ustawy)?

Niedostępność KSeF to w szczególności planowane prace serwisowe systemu ogłaszane przez MF. Prace te najczęściej będą odbywać się nocą albo w godzinach najmniej uciążliwych. W tym czasie podatnicy mogą wystawiać faktury offline i później je dosyłać.

## 6.Co to jest kod QR i do czego służy?

Kod QR to specjalny znak graficzny umieszczany na wizualizacji faktury. Pozwala w prosty sposób sprawdzić czy dokument znajduje się w systemie, a po wpisaniu dodatkowych danych pobrać go z KSeF. Faktury wystawione online i faktury wystawione w trybie offline (już dosłane do KSeF) mają kod QR z napisem w postaci numeru KSeF. Faktury wystawione offline, ale jeszcze nie dosłane do KSeF, mają dwa kody QR. Pierwszy z napisem „OFFLINE” zapewnia dostęp do tej faktury i weryfikację danych z faktury, a drugi kod QR z napisem „CERTYFIKAT”, umożliwia weryfikację tożsamości wystawcy.

## 7.Czy na fakturze wystawionej w trybie online i przekazywanej nabywcy poza KSeF musi być jeden czy dwa kody QR?

Na fakturze online, którą przekazujesz nabywcy poza systemem KSeF (np. jako PDF), powinien być jeden kod QR. Ten kod umożliwia weryfikację danych i daje dostęp do faktury w systemie. Pod kodem musi się znajdować numer KSeF faktury, dzięki czemu nabywca może łatwo sprawdzić jej autentyczność. Drugi kod QR w tym przypadku nie jest potrzebny.

## 8.Ile kodów QR powinno się znaleźć na fakturze wystawionej w trybie offline24 przekazywanej nabywcy poza KSeF, zanim zostanie dosłana do KSeF?

Na takiej fakturze muszą być dwa kody QR: pierwszy kod QR pozwala zweryfikować dane faktury i zapewnia dostęp do niej (pod nim widnieje napis „OFFLINE”), drugi kod QR służy do potwierdzenia tożsamości wystawcy faktury (pod nim widnieje napis „CERTYFIKAT”).            Dwa kody są konieczne, bo w tym momencie faktura jeszcze nie ma nadanego numeru KSeF, więc trzeba potwierdzić zarówno jej dane, jak i osobę lub podmiot, która ją wystawiła.

## 9.Ile kodów QR powinno się znaleźć na fakturze wystawionej w trybie offline24 używanej poza KSeF, po tym, jak zostanie już dosłana do systemu i dostanie numer?

W takiej sytuacji na wizualizacji faktury wystarczy zawrzeć jeden kod QR – taki sam jak w fakturze online. Ten kod pozwala sprawdzić dane i uzyskać dostęp do faktury w systemie, a pod nim znajduje się numer KSeF. Drugi kod (z napisem „CERTYFIKAT”) nie jest już potrzebny, bo faktura została przyjęta przez system i został jej już nadany numer KSeF.

## 10.Kiedy funkcjonalność kodów QR będzie dostępna dla faktur wystawianych w KSeF w środowisku produkcyjnym?

Kody QR są rozwiązaniem przygotowanym na okres obowiązkowego KSeF. Dlatego na środowisku produkcyjnym pojawią się od 1 lutego 2026 r. W okresie dobrowolnym (przed tą datą) faktury w KSeF nie muszą zawierać kodów QR.

## 1.Kiedy będzie opublikowana nowa wersja struktury JPK_VAT z deklaracją?

Nowa struktura JPK_VAT zostanie udostępniona jeszcze przed wejściem w życie KSeF obligatoryjnego, aby zapewnić stabilny proces jej implementacji w narzędziach do wysyłki plików JPK. Będzie obowiązywać od 1 lutego 2026 r.

## 2.Jak osoba fizyczna prowadząca działalność gospodarczą uzyska dostęp do KSeF?

W przypadku osób fizycznych prowadzących działalność gospodarczą, które są podatnikami VAT, system KSeF automatycznie przypisuje im tzw. uprawnienia właścicielskie. To oznacza, że taka osoba nie musi nic zgłaszać ani o nic wnioskować, aby korzystać z KSeF jako właściciel. Osoba fizyczna (podatnik) posiadający NIP ma dostęp do KSeF automatycznie.

## 3.Co to jest uprawnienie właścicielskie?

Uprawnienie właścicielskie to uprawnienie, które jest przypisane domyślnie, systemowo dla identyfikatora NIP podatnika.

## 4.W jaki sposób osoba fizyczna (która posiada uprawnienia właścicielskie) może zalogować się do KSeF?

Taka osoba może zalogować się do KSeF korzystając z Podpisu Zaufanego  lub kwalifikowanego podpisu elektronicznego W przypadku gdy podpis nie zawiera NIP ani PESEL, trzeba zgłosić dane tego podpisu. Należy to zrobić korzystając z formularza ZAW-FA. System na tej podstawie powiąże dany podpis z konkretnym podatnikiem.

## 5.W jaki sposób jest nadawane pierwotne uprawnienie w KSeF w przypadku podatnika niebędącego osobą fizyczną?

Jeśli firma (np. spółka) posiada kwalifikowaną pieczęć z NIP, może korzystać z KSeF na podstawie domyślnych uprawnień właścicielskich — bez zgłoszeń w US. Gdy pieczęci nie posiada, firma składa ZAW-FA, wskazując osobę fizyczną uprawnioną do korzystania z KSeF. Ta osoba może potem nadawać kolejne uprawnienia już elektronicznie w KSeF.

## 6.Jak technicznie nadać uprawnienie innej osobie do wystawiania faktur w imieniu podatnika/firmy?

Trzeba nadać tej osobie dedykowane uprawnienie do wystawiania faktur. Zrobisz to w: • Aplikacji Podatnika KSeF - narzędziu dostepnym w wersji online, udostępnionym przez MF albo • w programie komercyjnym zintegrowanym z KSeF (przez API). Po nadaniu uprawnienia wskazana osoba będzie mogła wystawiać faktury w Twoim imieniu.

## 7.Czy w KSeF przewidziana jest procedura samofakturowania?

Tak. Sprzedawca nadaje w KSeF nabywcy uprawnienie do samofakturowania. Wtedy nabywca (albo osoby, którym sam nada uprawnienia) może wystawiać faktury w imieniu sprzedawcy bezpośrednio w KSeF.

## 8.Czy osoba uprawniona przez API musi zakładać „konto” w KSeF? Jak ma to zrobić?

Nie ma obowiązku „zakładania konta”. Wystarczy, że osoba uprawniona uwierzytelni się jedną z dopuszczalnych metod (np. Profil Zaufany, podpis kwalifikowany). Jeśli posiada odpowiednie uprawnienia może od razu działać.

## 9.Czy konta w KSeF są tylko dla osób fizycznych? Czy mogą być też „na firmę”?

Z KSeF korzystają osoby fizyczne i podmioty (firmy). Podmiot niebędący osobą fizyczną może się uwierzytelnić pieczęcią kwalifikowaną. Jeśli jej nie ma, składa ZAW-FA, w którym wskazuje osobę fizyczną do obsługi KSeF (uprawnioną do wystawiania faktur, dostępu do faktur,  odbierania i nadawania uprawnień).

## 10.Biuro rachunkowe wystawia moje faktury. Czy muszę każdemu pracownikowi biura nadawać uprawnienia osobno?

Nie musisz. Możesz nadać uprawnienie całemu podmiotowi (biuru). W okresie obowiązkowego KSeF możesz zaznaczyć opcję, że ten podmiot może delegować uprawnienia swoim pracownikom. Wtedy to biuro wskaże osoby, które w praktyce będą wystawiać Twoje faktury.

## 11.Czy podatnik niebędący osobą fizyczną może zgłosić w ZAW-FA więcej niż jedną osobę „z pełnią uprawnień”?

Nie. W ZAW-FA zgłaszasz tylko pierwszą osobę o najszerszych uprawnieniach. Kolejne osoby z pełnymi uprawnieniami można dodać elektronicznie w KSeF — zrobi to ta pierwsza, uprawniona osoba.

## 12.Co w sytuacji, gdy firma nagle zakończy współpracę z osobą zgłoszoną w ZAW-FA i nie ma innej osoby z pełnymi uprawnieniami?

Składasz nowe ZAW-FA, wskazując kolejną osobę w miejsce dotychczasowej. To przywróci możliwość zarządzania uprawnieniami.

## 13.Kiedy trzeba ponownie zgłaszać uprawnienia powiązane z tzw. odciskiem palca podpisu?

Gdy przedłużysz ważność podpisu albo uzyskasz nowy podpis (dla tej samej osoby), trzeba ponownie zgłosić uprawnienia powiązane z jego „odciskiem palca”.

## 14.Czy trzeba aktualizować uprawnienia w KSeF, jeśli osoba przedłuża ważność podpisu kwalifikowanego lub uzyskuje nowy, ale nadal zawiera on NIP lub PESEL?

Nie trzeba aktualizować uprawnień. Nadane uprawnienia pozostają ważne.

## 15.Czy jest jakaś forma późniejszej aktualizacji danych podanych w ZAW-FA?

Nie. W ZAW-FA podajesz stan na dzień złożenia. Jeśli NIP podmiotu składającego i NIP/PESEL osoby uprawnionej się nie zmieniają, nie ma potrzeby aktualizowania innych danych.

## 16.Od kiedy nadane uprawnienia zaczynają działać? A co jeśli ZAW-FA wysyłam pocztą?

Uprawnienia działają po wprowadzeniu do systemu: • przy zgłoszeniu elektronicznym — zwykle od razu po przetworzeniu, • przy zgłoszeniu przez ZAW-FA — urząd skarbowy najpierw zweryfikuje dokument i wprowadzi uprawnienia, a Ty dostaniesz e-mail z potwierdzeniem. Wysyłka pocztą oznacza naturalne opóźnienie o czas doręczenia.

## 17.Co powinien zrobić komornik oraz organ egzekucyjny, aby korzystać z KSeF?

Komornik (osoba fizyczna) może korzystać z KSeF bez zgłoszeń — system rozpozna status na podstawie rejestrów. Komornik może nadawać dalsze uprawnienia elektronicznie. Organ egzekucyjny musi złożyć ZAW-FA do właściwego naczelnika US (nadanie/odebranie uprawnień).

## 18.Czy pełnomocnik podmiotu zagranicznego, działającego w Polsce bez podpisu elektronicznego, może korzystać z KSeF i nadawać dalsze uprawnienia?

Podmiot zagraniczny posiadający polski identyfikator NIP może działać za pośrednictwem pełnomocnika. W takim przypadku konieczne jest złożenie przez ten podmiot, zawiadomienia ZAW-FA, w którym podmiot wyznaczy określoną osobę fizyczną do korzystania z KSeF (w tym do nadawania uprawnień, odbierania uprawnień, wystawiania faktur w imieniu podmiotu oraz dostępu do faktur).

## 19.Czy w ZAW-FA mogę upoważnić dwóch członków zarządu, czy tylko jednego?

W ZAW-FA upoważniasz jedną osobę (nie musi to być członek zarządu). Następnie ta osoba może dodać kolejne uprawnione osoby elektronicznie - w KSeF.

## 20.Czy wspólnik spółki jawnej może się uwierzytelnić przez Profil Zaufany czy ZAW-FA?

Spółka jawna może się uwierzytelnić pieczęcią kwalifikowaną. Jeśli jej nie ma, składa ZAW-FA. Wspólnik wskazany w ZAW-FA będzie mógł działać w imieniu spółki, uwierzytelniając się np. Profilem Zaufanym.

## 21.Jak wygląda nadawanie uprawnień w sp. z o.o.? Czy prezes musi nadawać wszystkim uprawnienia przez ZAW-FA?

Spółka z o.o. może się uwierzytelnić pieczęcią kwalifikowaną. Jeśli jej nie ma, składa ZAW-FA podpisane przez osobę reprezentującą spółkę i wskazuje np. dyrektora finansowego. Ten, jako osoba wskazana w ZAW-FA, nadaje następnie kolejne uprawnienia (np. księgowym) elektronicznie - w KSeF, bez składania kolejnych ZAW-FA.

## 22.Generujemy token i wgrywamy go do programu komercyjnego. Czy możemy wysyłać/pobierać faktury bez dodatkowych podpisów (np. Profil Zaufany)?

Tak — do końca 2026 r. będzie to możliwe, o ile token został wygenerowany przez osobę mającą stosowne uprawnienia (np. do wystawiania i dostępu do faktur). W ramach tych uprawnień program może działać bez konieczności użycia innych form uwierzytelnienia.

## 23.Czy IDWew jest tylko dla JST, czy też dla jednostek wewnętrznych (oddziałów)?

JST posiadają dedykowany, odrębny model uprawnień. Niemniej z IDWew mo korzystać zarówno jednostki wewnętrzne/oddziały oraz JST. To wygodny sposób porządkowania uprawnień i dostępu w dużych strukturach — używasz go, gdy to dla Ciebie praktyczne.

## 24.Czy planowane są zmiany dla podmiotów wielooddziałowych (wystawianie i dostęp do faktur)?

Nie. Już działa model z IDWew właśnie dla takich podmiotów. Nie planuje się zmian w obsłudze wielooddziałowości i uprawnień w tym zakresie.

## 25.Czy zmieni się zasada, że uprawnienia nadaje się osobom/podmiotom, a nie „systemom”?

Nie. KSeF opiera się na poświadczeniu tożsamości osób i podmiotów. Uprawnienia nadaje się konkretnym osobom lub podmiotom, a nie „systemom” jako takim. Ta zasada pozostaje bez zmian.

## 26.Czy można użyć Podpisu Zaufanego we własnej aplikacji komercyjnej, żeby przedsiębiorca nie musiał samodzielnie generować tokenu w aplikacji MF?

Podpis Zaufany można wykorzystać do logowania i autoryzacji w KSeF, ale tylko w aplikacjach przygotowanych przez organy publiczne, np. w Aplikacji Podatnika KSeF. Jeśli korzystasz z programu komercyjnego, i tak trzeba się uwierzytelnić w systemie np. podpisem kwalifikowanym czy tokenem.

## 27.Czy do wysyłania faktur lub paczek faktur potrzebny jest podpis?

Wysyłki pliku lub paczki faktur może dokonać osoba lub podmiot uwierzytelniony w systemie. Wysyłkę możesz zrobić: w trybie interaktywnym (pojedyncze dokumenty), lub w trybie wsadowym (paczki dokumentów). Za wysyłkę odpowiada podatnik lub osoba przez niego uprawniona, a autoryzacja odbywa się np. podpisem kwalifikowanym, pieczęcią, tokenem albo certyfikatem KSeF.

## 28.Czy ktoś może się podszyć pod mój PESEL i zalogować do KSeF w moim imieniu?

Nie. Sam PESEL nie wystarczy. Żeby się zalogować, potrzebny jest Podpis Zaufany, podpis kwalifikowany, pieczęć kwalifikowana, token albo certyfikat KSeF. Bez tego nikt nie będzie w stanie uwierzytelnić się w systemie w Twoim imieniu.

## 29.Czym jest zgłaszanie „odcisku palca” podpisu kwalifikowanego?

Dotyczy to sytuacji, gdy podpis kwalifikowany nie zawiera NIP ani PESEL. Wtedy trzeba go zgłosić w KSeF jako tzw. odcisk palca. Przypadki: a) Podatnik–osoba fizyczna zgłasza swój podpis przez ZAW-FA. b) Podatnik zgłasza podpis osoby uprawnionej (która ma NIP/PESEL, ale podpis tego nie zawiera) — przez ZAW-FA przy pierwszej osobie, a kolejne już elektronicznie. c) Podatnik zgłasza podpis osoby uprawnionej bez NIP i PESEL — analogicznie: pierwsza przez ZAW-FA, kolejne elektronicznie. Jeśli podpis kwalifikowany ma NIP lub PESEL, nie trzeba nic zgłaszać. Od 2026 r. możliwe będzie też zgłaszanie „odcisku palca” pieczęci kwalifikowanej bez NIP.

## 30.Czy przez aplikację MF można będzie robić operacje administracyjne (np. nadawać uprawnienia, generować tokeny)? Czy system ERP może używać tylko tokenu?

Tak, takie operacje będzie można wykonywać w aplikacji MF. Tokeny będą działały tylko do końca 2026 r. Warto skonsultować z dostawcą ERP, jak najlepiej się logować. Możliwe sposoby uwierzytelnienia w systemach zewnętrznych to: podpis kwalifikowany, pieczęć kwalifikowana, token (do 2026) albo certyfikat KSeF (od lutego 2026).

## 31.Czy trzeba aktualizować uprawnienia, jeśli ktoś przedłuży ważność podpisu lub zmieni podpis kwalifikowany, ale nadal zawiera on NIP albo PESEL?

Nie. Jeśli podpis kwalifikowany nadal ma NIP lub PESEL tej samej osoby, nie trzeba nic zgłaszać.

## 32.Kiedy trzeba ponownie zgłaszać uprawnienia nadane w powiązaniu z „odciskiem palca podpisu”?

Wtedy, gdy podpis zostaje odnowiony (przedłużenie ważności) lub wydany jest nowy podpis — nawet jeśli korzysta z niego ta sama osoba.

## 33.Czy autoryzacja w KSeF jest przypisana do osoby czy do firmy?

Korzystać mogą zarówno osoby fizyczne, jak i firmy. Firma (np. spółka) może logować się pieczęcią kwalifikowaną, a jeśli jej nie ma — musi złożyć ZAW-FA, wyznaczając osobę do obsługi KSeF. Osoby fizyczne logują się np. podpisem kwalifikowanym, Podpisem Zaufanym, tokenem (do 2026) albo certyfikatem KSeF (od lutego 2026).

## 34.Jeśli spółka ma własny program księgowy zintegrowany z KSeF, to czy trzeba się dodatkowo logować?

Autoryzacja odbywa się w ramach wykorzystywanego programu, zintegrowanego z KSeF. Nieważne, z jakiego oprogramowania korzystasz, zawsze musi być spełniony wymóg autoryzacji. Jeśli spółka nie ma pieczęci kwalifikowanej, to do pierwszej autoryzacji musi złożyć ZAW-FA w urzędzie skarbowym.

## 35.Czy do logowania w KSeF będzie można użyć aplikacji mObywatel?

Tak. Od 1 kwietnia 2026 r. planowane jest umożliwienie logowania do KSeF przez węzeł krajowy, czyli także przez aplikację mObywatel.

## 36.Czy w KSeF 2.0 będę mógł korzystać z tokenów uwierzytelniających, który zostały wygenerowane w KSeF 1.0?

Nie, tokeny wygenerowane w KSeF 1.0 nie będą kompatybilne z KSeF 2.0. Możliwość generowania tokenów zostanie udostępniona 1 lutego 2026 r. wraz z uruchomieniem systemu KSeF 2.0.

## 37.Czy uprawnienia nadane pracownikom firmy w KSeF 1.0 będą ważne w systemie KSeF 2.0?

Nie, skorzystanie z uprawnień nadanych w systemie KSeF 1.0 nie będzie możliwe w KSeF 2.0, za wyjątkiem uprawnień nadanych na podstawie ZAW-FA i tzw. uprawnień „właścicielskich” (przypisanych do NIP domyślnie, systemowo). Od 1 listopada 2025 r. udostępniony zostanie Moduł Certyfikatów i Uprawnień (MCU), który umożliwi nadawanie uprawnień pracownikom firm zgodnych z nowym modelem uprawnień, z których będzie można skorzystać od 1 lutego 2026 r wraz z uruchomieniem systemu KSeF 2.0.

## 1.Do czego będzie służył certyfikat KSeF?

Certyfikat KSeF posiada dwie kluczowe funkcjonalności. Certyfikat KSeF służy do uwierzytelniania się w systemie (certyfikat typu 1). Certyfikat KSeF (typu 2) będzie natomiast wymagany przy wystawianiu faktur w trybie szczególnym offline (offline24, offline - niedostępność KSeF w związku z trwającymi pracami serwisowymi i w trybie awaryjnym, gdy system nie działa). Certyfikat KSeF typu 2 umożliwi opatrzenie faktury wystawionej offline, przekazywanej nabywcy poza KSeF (w ustawowo określonych sytuacjach), kodem QR umożliwiającym weryfikację tożsamości wystawcy faktury.

## 2.Czy certyfikaty KSeF będą po określonym czasie wygasać?

Tak. Certyfikat KSeF jest ważny nie dłużej niż 2 lata od daty jego wydania lub od daty początkowej jego obowiązywania wskazanej przez podatnika.

## 3.Czy certyfikaty i tokeny będą działały równolegle?

Tak, przez pewien czas. Tokeny będą działać do końca 2026 r. Równolegle wprowadzane będą certyfikaty KSeF – można je pobierać od 1 listopada 2025 r., a używać od 1 lutego 2026 r. W okresie przejściowym podatnik może korzystać jednocześnie i z tokenów, i z certyfikatów.

## 4.Kto będzie mógł pobrać certyfikat KSeF – tylko osoba fizyczna czy także spółka?

Certyfikat może być wydany: osobie fizycznej – identyfikowanej po NIP (np. JDG) lub po PESEL (jeśli ma jakiekolwiek uprawnienia w KSeF), spółce lub innej firmie z NIP niebędacej osobą fizyczną – po uwierzytelnieniu się pieczęcią kwalifikowaną. W przypadku osoby/podmiotu uwierzytelniającego się za pomocą kwalifikowanego podpisu/kwalifikowanej pieczęci elektronicznej bez identyfikatora NIP i PESEL  certyfikat może być wydany na tzw. dane unikalne powiązane z certyfikatem (tzw. odcisk palca podpisu) użytym do uwierzytelnienia.

## 5.Od kiedy będzie można pobrać certyfikat KSeF?

Od listopada 2025 r.

## 6.Od kiedy będzie można używać certyfikatu KSeF do uwierzytelniania w systemie?

Od 1 lutego 2026 r.

## 7.Jak uzyskać certyfikat KSeF?

Od 1 listopada 2025 r. w Module Certyfikatów i Uprawnień (MCU) będzie można złożyć wniosek. O certyfikat bez dodatkowych warunków mogą wystąpić: osoby fizyczne wskazane w ZAW-FA, osoby fizyczne z uprawnieniami właścicielskimi, firmy (niebędące osobami fizycznymi) z uprawnieniami właścicielskimi i pieczęcią kwalifikowaną. Konieczność ponownego nadania uprawnień w module MCU wystąpi w przypadku: •    osoby fizycznej, która nie została uprawniona na podstawie ZAW-FA w KSeF 1.0 do 31 października 2025 r. •    podmiotu, który otrzymał uprawnienia do KSeF do 31 października 2025 r. Po ponownym nadaniu uprawnień w module MCU osoba fizyczna lub podmiot będą mogli wystąpić o certyfikat KSeF. Wniosek o certyfikat wymaga uwierzytelnienia w KSeF np. Podpisem Zaufanym, podpisem kwalifikowanym lub pieczęcią. Osoba/podmiot z ważnym certyfikatem KSeF może też wnioskować o kolejny certyfikat.

## 8.Prowadzę jednoosobową działalność gospodarczą. Pobrałam certyfikat KSeF. Czy mogę go udostępnić swojej księgowej, aby miała wgląd w moje faktury?

Nie. Certyfikat KSeF jest osobistym elektronicznym poświadczeniem tożsamości – zawiera dane osoby lub podmiotu, który o niego wnioskował. Jeśli pobrałaś certyfikat na siebie (JDG), możesz korzystać z niego tylko Ty. Księgowej trzeba nadać uprawnienia w inny sposób.

## 9.Spółka z o.o. pobrała kilka certyfikatów. Czy może udostępnić je pracownikom?

Tak. Certyfikat wydany na spółkę nie jest powiązany z konkretną osobą. Spółka może go przekazać wybranym pracownikom, ale to ona odpowiada za rejestrację, kontrolę, udostępnianie i unieważnianie certyfikatów.

## 10.Jestem księgową, mam certyfikat KSeF i uprawnienia nadane przez kilka firm. Co jeśli jedna firma odbierze mi uprawnienia – czy certyfikat straci ważność?

Nie. Certyfikat nadal będzie ważny. Może być używany w różnych kontekstach (dla różnych podmiotów), a zmiany w uprawnieniach nie mają wpływu na ważność samego certyfikatu.

## 11.Czy o certyfikat może wystąpić ktoś, kto nie jest uwierzytelniony w KSeF?

Nie. Wniosek o certyfikat mogą złożyć tylko podatnicy i osoby już uwierzytelnione w KSeF, np. Podpisem Zaufanym, podpisem kwalifikowanym czy pieczęcią. Podmiot/osoba uwierzytelniona certyfikatem KSeF również może wnioskować o kolejny certyfikat.

## 12.Czy API KSeF 1.0 obsłuży certyfikaty, czy trzeba przejść na API 2.0?

Obsługa certyfikatów będzie dostępna tylko w API KSeF 2.0. API 1.0 nie przewiduje tej funkcjonalności.

## 1.Czy będzie możliwość masowego pobierania faktur w postaci plików xml oraz PDF poprzez API?

Tak, jest przewidziana możliwość masowego pobierania faktur, ale wyłącznie w postaci xml.

## 2.Jaki jest termin ważności tokenu?

Wygenerowany token pozostaje ważny do czasu jego unieważnienia przez użytkownika. Nalezy jednak pamiętać, że możliwość generowania i wykorzystywania tokenów wygasa z końcem 2026 r.

## 3.Czy KSeF 2.0 zapewni bezpieczeństwo przechowywanych w nim danych ?

Tak, KSeF 2.0 zapewni odpowiedni poziom bezpieczeństwa danych.

## 4.Czy KSeF posiada zabezpieczenia na wypadek awarii? Jaka będzie dostępność aplikacji?

Tak, system posiada zabezpieczenia (tzw. redundancję) na wypadek awarii. KSeF będzie działał 24 godziny na dobę, 7 dni w tygodniu i 365 dni w roku.

## 5.Czy Ministerstwo Finansów wskaże platformy brokerów w KSeF?

Nie. Firmy mogą tworzyć własne rozwiązania do obsługi KSeF bez podpisywania umów z Ministerstwem Finansów – inaczej niż w systemie PEF.

## 6.Czy w wersji testowej KSeF 2.0 i w wersji przedprodukcyjnej (demo) KSeF 2.0 wysyła się faktury? Jeśli tak, to czy są one wiążącym dokumentem?

Faktury wysyłane w wersji testowej i przedprodukcyjnej  trafiają do środowisk, które z założenia nie są środowiskami wywołującymi skutki prawne. Należy jednak pamiętać, że w przypadku podawania w takich fakturach numerów NIP nawet losowo generowanych, podmioty o tych NIP mają potencjalny dostęp do danych zawartych w takich fakturach. Jednocześnie przypominamy, że w środowisku testowym API oraz testowej wersji Aplikacji Podatnika nie należy używać rzeczywistych danych firmy. Wersja testowa API KSeF 2.0 zostanie udostępniona 30 września 2025 r. W wersji produkcyjnej faktury trafiają do obiegu prawnego – są wystawione w KSeF, są to faktury ustrukturyzowane w rozumieniu ustawy VAT.

## 7.Czym różni się wersja testowa KSeF 2.0 i wersja przedprodukcyjna (Demo) KSeF 2.0 od wersji produkcyjnej?

W wersji produkcyjnej faktury trafiają do obiegu prawnego. W wersji testowej i przedprodukcyjnej (Demo) faktury nie wywołują skutków prawnych. W wersji testowej możliwa jest symulacja poświadczeń co oznacza możliwość autoryzacji w kontekście dowolnego NIP. W wersji Demo poświadczenia działają tak samo jak na środowisku produkcyjnym, czyli oparte są o rzeczywiste narzędzia autoryzacyjne.

## 8.Czy w API KSeF będzie możliwość pobierania faktur przyrostowo bez stronicowania?

Nie.

## 9.Czy w związku z wdrożeniem KSef, Ministerstwo Finansów planuje modyfikować narzędzia, z których już korzystają przedsiębiorcy tj. Aplikacja Podatnika KSeF, e-mikrofrima ?

Trwają prace nad dostosowaniem tych narzędzi do funkcjonalności nowej architektury systemu KSeF 2.0. W listopadzie 2025 r. Ministerstwo Finansów udostepni testową wersję Aplikacji Podatnika KSeF 2.0 dostosowaną do nowej wersji KSeF 2.0.

## 10.Czy wdrożenie systemu w nowej architekturze (KSeF 2.0.) oznacza konieczność dostosowania programów księgowych dostępnych już na rynku komercyjnych?

KSeF 2.0 oferuje wiele dodatkowych funkcjonalności, których nie było w KSeF 1.0 (tryb offline24, możliwość wystawiania faktur z załącznikiem, certyfikaty KSeF). W związku z postulatami rynku na okres obligatoryjnego KSeF wprowadzona zostaje także nowa wersja struktury logicznej e-Faktury - FA(3), która została już udostępniona na ePUAP.  Konieczne będzie więc dostosowanie programów do tej wersji struktury. Na podstawie wyników audytu informatycznego Ministerstwo Finansów zdecydowało również o budowie nowej architektury KSeF 2.0. Dokładamy starań aby z perspektywy integratorów nie były to jednak diametralne zmiany.

## 11.Czy nowy KSeF 2.0 będzie miał lepszą przepustowość niż pierwsza wersja systemu?

System KSeF jest budowany od początku. Wykonawca powołał zespół specjalistów od architektury IT. Aktualnie prowadzone są intensywne prace informatyczne. Ministerstwo Finansów stale monitoruje ich postęp. Założeniem jest, że nowa wersja systemu (KSeF 2.0) będzie miała znacząco lepszą przepustowość i wydajność niż KSeF 1.0.

## 12.Kiedy nastąpi udostępnienie środowiska produkcyjnego KSeF 2.0?

Udostępnienie środowiska produkcyjnego KSeF 2.0 nastąpi 1 lutego 2026 r.

## 13.Czy Ministerstwo Finansów planuje stworzenie usługi, która będzie informować użytkowników o trwających awariach systemu.

Tak, Ministerstwo Finansów planuje wdrożenie takiej usługi.

## 14.Czy w KSeF 2.0 będę mógł korzystać z tokenów uwierzytelniających, który zostały wygenerowane w KSeF 1.0?

Nie, tokeny wygenerowane w KSeF 1.0 nie będą kompatybilne z KSeF 2.0. Możliwość generowania tokenów zostanie udostępniona 1 lutego 2026 r. wraz z uruchomieniem systemu KSeF 2.0.

## 15.Czy uprawnienia nadane pracownikom firmy w KSeF 1.0 będą ważne w systemie KSeF 2.0?

Nie, skorzystanie z uprawnień nadanych w systemie KSeF 1.0 nie będzie możliwe w KSeF 2.0, za wyjątkiem uprawnień nadanych na podstawie ZAW-FA i tzw. uprawnień „właścicielskich” (przypisanych do NIP domyślnie, systemowo). Od 1 listopada 2025 r. udostępniony zostanie Moduł Certyfikatów i Uprawnień (MCU), który umożliwi nadawanie uprawnień pracownikom firm zgodnych z nowym modelem uprawnień, z których będzie można skorzystać od 1 lutego 2026 r wraz z uruchomieniem systemu KSeF 2.0.

