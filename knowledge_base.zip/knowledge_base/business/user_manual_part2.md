Podręcznik
KSeF 2.0
Cz. II
Wystawianie i otrzymywanie faktur w KSeF
Stan prawny na dzień: 1 lutego 2026 r.
Warszawa, listopad 2025 r.
1

---

1. Faktura ustrukturyzowana ................................................................................................................................................... 5
1.1. Definicje faktury .............................................................................................................................................................. 5
1.2. Data wystawienia faktury ustrukturyzowanej (tryb ONLINE) ....................................................................... 6
1.3. Kroki prowadzące do wystawienia faktury w KSeF ............................................................................................ 7
1.4. Praktyczne kwestie związane z wystawianiem faktur ....................................................................................... 9
1.4.1. Weryfikacja pliku XML oraz przesłanki odrzucenia pliku ...................................................................... 10
1.4.2. Brak możliwości edytowania wystawionej faktury .................................................................................. 11
1.4.3. Brak możliwości anulowania lub usunięcia wystawionej faktury ....................................................... 11
1.4.4. Wystawienie faktury na błędnego nabywcę ............................................................................................... 12
1.4.5. Wizualizacja faktury ............................................................................................................................................ 12
1.4.6. Możliwość wydania nabywcy „potwierdzenia transakcji” ..................................................................... 15
1.4.7. Kolejny numer faktury a odrzucenie pliku XML przez KSeF ................................................................. 20
2. Zalecenia dotyczące prawidłowego wypełniania struktury logicznej FA(3) .................................................... 21
2.1. Prawidłowy zapis identyfikatorów podatkowych ............................................................................................. 23
2.1.1. Brak znaków rozdzielających w numerze NIP ............................................................................................ 23
2.1.2. Wydzielenie dwuliterowego prefiksu sprzedawcy „PL” w osobnym polu........................................ 24
2.1.3. Wydzielenie dwuliterowego prefiksu nabywcy w osobnym polu ....................................................... 24
2.1.4. Identyfikator podatkowy nabywcy ujęty w polu NIP .............................................................................. 25
2.1.5. Identyfikator kontrahenta z kraju trzeciego ujęty w polach KodKraju i NrID ............................... 25
2.1.6. Sposób prezentacji w strukturze FA(3) przypadku, gdy nabywca jest konsumentem ................ 25
2.2. Faktura zawierająca dane podmiotów trzecich .................................................................................................. 26
2.2.1. Faktura obejmująca dane faktora ................................................................................................................... 27
2.2.2. Faktura zawierająca dane kilku nabywców ................................................................................................. 28
2.2.3. Faktura uwzględniająca dane jednostki podrzędnej JST ........................................................................ 29
2.2.4. Faktura uwzględniająca dane członka GV ................................................................................................... 29
2.2.5. Faktura zawierająca dane zakładu lub wyodrębnionej jednostki wewnętrznej podatnika ....... 29
2.3. Dodatkowe informacje o przedmiocie sprzedaży.............................................................................................. 30
2.4. Faktura dokumentująca sprzedaż zwolnioną od podatku .............................................................................. 31
2.5. Faktura walutowa .......................................................................................................................................................... 32
2.6. Faktura zaliczkowa ........................................................................................................................................................ 33
2.7. Faktura rozliczająca ...................................................................................................................................................... 35
2.8. Faktura końcowa „zerowa” ........................................................................................................................................ 36
2.9. Faktura VAT marża ....................................................................................................................................................... 37
2.10. Faktura uproszczona do 450 zł .............................................................................................................................. 39
2.11. Faktura dokumentująca WDT i eksport towarów .......................................................................................... 40
2.12. Faktura wystawiona w procedurze samofakturowania ............................................................................... 41
2.13. Faktury korygujące ..................................................................................................................................................... 41
2

---

2.13.1. Cechy charakterystyczne faktury korygującej ........................................................................................ 41
2.13.2. Prezentowanie „różnic” w fakturach korygujących ............................................................................... 42
2.13.3. Wystawienie kilku faktur korygujących do jednej faktury pierwotnej .......................................... 43
2.13.4. Zasady korygowania wierszy (pozycji) faktury ....................................................................................... 44
2.13.5 Faktura korygująca fakturę zaliczkową i fakturę rozliczającą ............................................................ 45
2.13.6. Faktury korygowane wystawione w KSeF i poza KSeF ........................................................................ 45
2.13.7. Faktura korygująca zbiorcza .......................................................................................................................... 47
2.13.8. Podmiot1K i Podmiot2K w fakturze korygującej ................................................................................... 48
2.14. Kwota należności ogółem na fakturze ................................................................................................................ 49
2.15. Struktura FA(3) a wydatki pracownicze ............................................................................................................. 50
3. Aspekty techniczne związane z wysyłką faktur do KSeF ......................................................................................... 53
3.1. Jak wystawić e-Fakturę? ............................................................................................................................................. 53
3.2. Rodzaje udostępnionych środowisk KSeF ............................................................................................................ 53
3.2.1. Środowisko testowe ............................................................................................................................................ 54
3.2.2. Środowisko przedprodukcyjne (demo) ......................................................................................................... 54
3.2.3. Środowisko produkcyjne .................................................................................................................................... 54
3.3. Sesja interaktywna i wsadowa .................................................................................................................................. 55
3.3.1.Sesja interaktywna ................................................................................................................................................ 55
3.3.2. Sesja wsadowa ....................................................................................................................................................... 56
3.4. Weryfikacja duplikatów faktur ................................................................................................................................. 58
4. Potwierdzenie skutecznego wystawienia faktury w KSeF...................................................................................... 58
4.1. Numer KSeF faktury ..................................................................................................................................................... 58
4.1.1. Numer KSeF faktury zaliczkowej w fakturze rozliczającej .................................................................... 60
4.1.2. Numer KSeF w fakturze zaliczkowej ............................................................................................................. 60
4.1.3. Numer KSeF faktury pierwotnej podawany w fakturze korygującej ................................................. 61
4.1.4. Numer KSeF wskazywany w komunikacie przelewu MPP .................................................................... 62
4.1.5. Numer KSeF w płatnościach pomiędzy podatnikami VAT czynnymi ................................................ 63
4.1.6. Numer KSeF w plikach JPK ............................................................................................................................... 64
4.2. Urzędowe Poświadczenie Odbioru ......................................................................................................................... 64
5. Otrzymywanie faktur w KSeF oraz dostęp do faktur. Kody QR. ........................................................................... 68
5.1. Data otrzymania faktury ustrukturyzowanej (tryb ONLINE) ....................................................................... 68
5.2. Otrzymanie faktury w KSeF. Dostęp do faktury. ............................................................................................... 69
5.3. Przekazanie faktury w postaci uzgodnionej ........................................................................................................ 71
5.3.1. Udostępnienie faktury w sposób uzgodniony ............................................................................................ 71
5.3.2. Zapewnienie dostępu do faktury nabywcom bez NIP i konsumentom ............................................. 71
5.4. Kody weryfikujące ......................................................................................................................................................... 72
5.4.1. Kod QR do weryfikacji faktury ONLINE lub OFFLINE ............................................................................ 72
3

---

5.4.2. Kod QR do weryfikacji tożsamości wystawcy faktury OFFLINE ......................................................... 74
5.4.3. Co to jest wyróżnik faktury? ............................................................................................................................. 75
5.4.4. Brak możliwości zamieszczenia kodu na wizualizacji faktury .............................................................. 75
5.5. Dostęp dwuetapowy do faktury z wykorzystaniem kodu QR ....................................................................... 76
5.6. Weryfikacja tożsamości wystawcy faktury w trybie OFFLINE z użyciem kodu QR ............................. 79
5.7. Anonimowy dostęp do faktury w KSeF (bez kodu QR) .................................................................................... 79
6. Praktyczne kwestie związane z otrzymywaniem faktur w KSeF .......................................................................... 83
6.1. Brak zgody nabywcy na otrzymywanie faktur w KSeF .................................................................................... 83
6.2. Otrzymywanie faktur przez nabywcę, który odbiera faktury w KSeF od 1 lutego 2026 r., ale będzie
wystawiał faktury w KSeF dopiero od 1 kwietnia 2026 r. lub od 1 stycznia 2027 r. ..................................... 84
6.3. Brak możliwości odrzucenia faktury przez podmiot wskazany jako nabywca ........................................ 85
6.4. Brak powiadomień systemowych o otrzymaniu faktury w KSeF ................................................................. 86
6.5. Brak możliwości sprawdzenia, że nabywca pobrał fakturę z KSeF ............................................................. 86
7. Przechowywanie faktur w KSeF ....................................................................................................................................... 87
Spis grafik ....................................................................................................................................................................................... 89
Spis przykładów ........................................................................................................................................................................... 90
Spis schematów ........................................................................................................................................................................... 91
Spis tabel ........................................................................................................................................................................................ 92
Rejestr zmian ................................................................................................................................................................................ 93
4

---

1. Faktura ustrukturyzowana
1.1. Definicje faktury
Fakturą, zgodnie z art. 2 pkt 31 ustawy jest dokument w postaci papierowej lub w postaci
elektronicznej zawierający dane wymagane ustawą i przepisami wydanymi na jej podstawie.
Zakres obowiązkowych elementów faktury określa w szczególności art. 106e ustawy oraz
rozporządzenie w sprawie wystawiania faktur1.
Wyróżnia się następujące rodzaje faktur:
FAKTURA FAKTURA
FAKTURA PAPIEROWA
ELEKTRONICZNA USTRUKTURYZOWANA
Faktura elektroniczna, w myśl art. 2 pkt 32 ustawy jest to faktura w postaci elektronicznej
wystawiona i otrzymana w dowolnym formacie elektronicznym (np. jako plik pdf).
WAŻNE
Faktura ustrukturyzowana (zwana e-Fakturą) jest to faktura wystawiona przy użyciu KSeF
wraz z przydzielonym numerem identyfikującym tę fakturę w tym systemie.
Faktura ustrukturyzowana:
• od 1 lutego 2026 r. będzie wystawiana przy użyciu struktury logicznej FA(3),
• jest wystawiana i otrzymywana przy użyciu KSeF,
• przyjmuje format pliku XML,
• posiada przydzielony numer KSeF.
Pojęcia faktury elektronicznej i faktury ustrukturyzowanej nie stanowią synonimów. Faktura
elektroniczna, w przeciwieństwie do faktury ustrukturyzowanej:
• nie musi być wystawiana przy użyciu struktury FA,
• nie jest przesyłana do KSeF ani otrzymywana przy użyciu KSeF,
• może być dowolnym plikiem np. pdf przesyłanym w wiadomości e-mail do kontrahenta.
W KSeF wystawiane są wyłącznie faktury ustrukturyzowane (przyjmujące postać plików XML).
1 Rozporządzenie Ministra Finansów z dnia 29 października 2021 r. w sprawie wystawiania faktur (Dz. U.
z 2021 r. poz. 1979 ze zm.).
5

---

WAŻNE
Do KSeF nie będą przesyłane rachunki w rozumieniu art. 87 ustawy OP, faktury pro forma,
noty obciążeniowe, noty uznaniowe, faktury wewnętrzne, dowody wewnętrzne i załączniki
w formie nieustrukturyzowanej.
1.2. Data wystawienia faktury ustrukturyzowanej (tryb ONLINE)
Podstawową i kluczową funkcjonalnością KSeF jest wystawianie faktur ustrukturyzowanych.
KSeF udostępnia podmiotom korzystającym z systemu informacje m.in. o dacie i czasie
wystawienia faktury ustrukturyzowanej. Określenie daty wystawienia faktury jest kluczowe
m.in. dla weryfikacji czy faktura została wystawiona terminowo. Data wystawienia faktury jest
widoczna m.in. w Urzędowym Poświadczeniu Odbioru (tzw. UPO).
Zgodnie z art. 106na ust. 1 ustawy datą wystawienia faktury ustrukturyzowanej jest data
przesłania faktury do KSeF – przy założeniu, że data wystawienia faktury, wskazana przez
podatnika w polu P_1 jest tożsama z datą przesłania faktury do KSeF.
Jeśli jednak data przesłania faktury do KSeF będzie późniejsza niż data wskazana na fakturze
przez podatnika w polu P_1, to w myśl art. 106nda ust. 16 ustawy faktura zostanie uznana za
fakturę wystawioną w trybie offline24, a datą jej wystawienia będzie data wskazana przez
podatnika na fakturze w polu P_1 (a nie data przesłania jej do KSeF).
Przykład 1. Data wystawienia faktury w trybie ONLINE (data w polu P_1 tożsama z datą przesłania pliku XML do KSeF).
Podatnik wystawia fakturę w trybie ONLINE. W pliku faktury wskazał 1 lutego 2026 r. jako
datę wystawienia faktury. W tym samym dniu podatnik (o godz. 23:50) przesłał fakturę do
KSeF i została ona zarejestrowana przed północą na bramce. Numer KSeF został nadany
fakturze 2 lutego 2026 r. (o godz. 00:01). Datą wystawienia faktury jest w tym przypadku data
przesłania faktury do KSeF, czyli 1 lutego 2026 r. Wynika to z faktu, że data wskazana w pliku
faktury jest zgodna z datą przesłania faktury do KSeF.
Przykład 2. Data wystawienia faktury w trybie ONLINE (data przesłania pliku XML do KSeF późniejsza niż data wskazana w
polu P_1).
Podatnik wystawia fakturę w trybie ONLINE. W pliku faktury wskazał 2 lutego 2026 r. jako
datę wystawienia faktury. W kolejnym dniu, 3 lutego 2026 r. podatnik przesłał fakturę do KSeF
i została ona zarejestrowana w tym samym dniu na bramce. Numer KSeF został nadany
fakturze 3 lutego 2026 r. Datą wystawienia faktury jest w tym przypadku data wskazana na
fakturze przez podatnika w polu P_1, czyli 2 lutego 2026 r. Wynika to z faktu, że data przesłania
pliku XML faktury do KSeF jest późniejsza niż data wskazana w polu P_1 na tej fakturze.
Fakturę uznaje się za wystawioną w trybie offline24.
6

---

WAŻNE
Jeżeli data wskazana w polu P_1 będzie późniejsza niż data przesłania faktury do KSeF,
wówczas nastąpi odrzucenie pliku XML na bramce. Data w polu P_1 nie może być więc datą z
przyszłości.
Przykład 3. Odrzucenie pliku XML faktury.
Podatnik wystawia fakturę w trybie ONLINE. Podatnik przesłał plik XML do KSeF w dniu 2
lutego 2026 r. W polu P_1 jako datę wystawienia podatnik wskazał natomiast 3 lutego 2026 r.,
czyli datę z przyszłości. W przedstawionej sytuacji nastąpi odrzucenie pliku XML.
1.3. Kroki prowadzące do wystawienia faktury w KSeF
Chcąc wystawić fakturę w KSeF podatnik powinien wykonać kilka kroków, które są niezależne
od rodzaju programu, z którego będzie on korzystał. Różnice pomiędzy różnymi aplikacjami
mogą oczywiście wystąpić, jednak pewien schemat postępowania będzie powtarzalny.
KROK 1 Weryfikacja zakresu posiadanych uprawnień do
wystawiania faktur w KSeF
Jeśli podatnik prowadzi jednoosobową działalność gospodarczą, komplet uprawnień w KSeF
jest przypisany do niego automatycznie. Może zalogować się w systemie i wystawić fakturę
samodzielnie lub w razie potrzeby nadać uprawnienie do wystawiania faktur, elektronicznie,
innej osobie lub podmiotowi.
Jeśli podatnikiem jest podmiot niebędący osobą fizyczną np. spółka, wówczas może
uwierzytelnić się on w KSeF elektroniczną pieczęcią kwalifikowaną. Jeśli nie posiada pieczęci,
składa zawiadomienie ZAW-FA i wyznacza osobę fizyczną, która w jego imieniu będzie
korzystała z KSeF. Ta osoba będzie mogła uwierzytelnić się w systemie w kontekście spółki, w
tym wystawiać jej faktury sprzedażowe jak również, nadawać uprawnienie do wystawiania
faktur w KSeF innym osobom lub podmiotom.
Szczegóły dotyczące zasad nadawania i odbierania uprawnień w KSeF zostały przedstawione w
cz. I Podręcznika KSeF 2.0.
7

---

KROK 2 Uwierzytelnienie w programie do wystawiania
faktur
Aby wystawić fakturę podatnik lub osoba/podmiot uprawniony w imieniu podatnika powinien
uwierzytelnić się do swojego programu do obsługi KSeF. Do metod uwierzytelnienia w
systemie należy Podpis Zaufany, podpis kwalifikowany (dla osób fizycznych), pieczęć
kwalifikowana (dla podmiotów niebędących osobą fizyczna) jak również certyfikat KSeF lub
token (zarówno dla osób fizycznych jak i podmiotów niebędących osobą fizyczną).
Szczegóły dotyczące zasad uwierzytelnienia się w KSeF zostały przedstawione w cz. I
Podręcznika KSeF 2.0.
Wypełnienie danych faktury oraz sprawdzenie
KROK 3
ich poprawności
Podatnik lub osoba/podmiot wystawiający fakturę w imieniu podatnika powinien wypełnić
dane faktury w formatce/interfejsie znajdującym się w programie fakturującym
zintegrowanym z API KSeF 2.0, z którego korzysta.
Wystawca powinien:
• pamiętać, aby zawrzeć w fakturze wszystkie obowiązkowe elementy, m.in. takie jak
dane stron transakcji czy dane kwotowe, pozycje faktury i stawkę podatku itp.
• zwrócić uwagę na elementy, które występują tylko w określonych sytuacjach np. dane
faktury pierwotnej, gdy wystawiana jest faktura korygująca lub dane dotyczące
zamówienia, gdy wystawiana jest faktura zaliczkowa.
Możliwe (ale nie wymagane) jest zawarcie na fakturze także danych dodatkowych o
charakterze biznesowym np. terminu i formy płatności czy danych kontaktowych stron
transakcji.
Po wprowadzeniu wszystkich danych faktury podatnik powinien upewnić się, że nie popełnił
błędu w treści wystawianej faktury. W razie wątpliwości związanych z obsługą danego
programu finansowo-księgowego wystawca faktury powinien zapoznać się z instrukcją obsługi
lub skontaktować się bezpośrednio z dostawcą tej aplikacji.
8

---

KROK 4
Wysłanie faktury do KSeF
Po przygotowaniu faktury lub paczki faktur należy przesłać ją do KSeF.
Nastąpi wówczas weryfikacja i przetwarzanie dokumentu. W tym czasie system sprawdzi czy
osoba lub podmiot, który wysłał fakturę do KSeF był uprawniony do tej czynności oraz czy
wszystkie pozycje wymagane wzorem e-Faktury zostały wypełnione. Jeśli warunki te zostały
dochowane – faktura zostanie przyjęta do systemu.
Uzyskanie nr KSeF i UPO
KROK 5
Po weryfikacji i przetworzeniu dokumentu w systemie fakturze zostanie nadany
automatycznie unikalny numer identyfikujący tę fakturę w KSeF. Możliwe będzie także
pobranie Urzędowego Poświadczenia Odbioru (UPO). Oznacza to, że proces wysyłki faktury do
KSeF zakończył się sukcesem, a faktura została wystawiona.
Schemat 1. Proces wystawienia faktury w KSeF – działania w systemie.
1.4. Praktyczne kwestie związane z wystawianiem faktur
KSeF zapewnia możliwość wystawiania e-Faktur. Fakturę wystawić może zarówno sam
podatnik, osoba fizyczna przez niego uprawniona lub podmiot uprawniony przez podatnika do
9

---

wystawiania faktur. W systemie obsługiwane są także szczególne przypadki wystawiania
faktur tj. samofakturowanie (tj. wystawianie faktur przez nabywcę), faktury VAT RR
(dokumentujące zakup produktów rolnych lub usług od rolnika ryczałtowego), faktury
wystawiane w ramach egzekucji czy faktury dotyczące zamówień publicznych. Szczegóły
dotyczące obsługi tych szczególnych przypadków zostały omówione w cz. III i IV Podręcznika
KSeF 2.0.
1.4.1. Weryfikacja pliku XML oraz przesłanki odrzucenia pliku
Niezależnie od rodzaju wystawianej faktury system:
• będzie weryfikował zawsze zgodność przesyłanego pliku XML z dedykowaną dla danego
typu faktury strukturą xsd, która jest deklarowana podczas nawiązywania sesji w KSeF
(FA(3), FA_RR(1) czy struktura PEF),
• będzie sprawdzał czy osoba lub podmiot, która przesłała fakturę do KSeF miała do tego
odpowiednie uprawnienie.
Odrzucenie faktury przez system może wystąpić z powodu niezgodności struktury pliku ze
wzorem struktury logicznej lub z powodu wprowadzania jej do systemu przez osobę
nieuprawnioną. KSeF będzie prezentował podmiotom korzystającym z systemu informacje o
dacie i czasie odrzucenia faktury w przypadku jej niezgodności ze wzorem faktury
ustrukturyzowanej, a w przypadku braku uprawnień do korzystania z KSeF będzie informował
o braku uprawnień.
Przesyłany plik XML musi być zgodny ze strukturą logiczną faktury ustrukturyzowanej - od 1
lutego 2026 r. jest to struktura FA(3). W przypadku, gdy plik XML będzie zawierał błędy np. nie
wszystkie wymagane przez strukturę pola zostaną wypełnione, plik zostanie odrzucony. W
przypadku negatywnej weryfikacji system nie przydzieli numeru KSeF faktury. Oznacza to, że
faktura nie została wystawiona. Należy więc zweryfikować poprawność wprowadzonych
danych i ponowić wysyłkę.
MF zachęca do implementacji w systemach służących do fakturowania, mechanizmów
sprawdzających zgodność pliku XML ze wzorem struktury logicznej przed wysyłką pliku, co w
praktyce pozwoli wyeliminować opisaną wyżej sytuację.
Dodatkowo, jeśli do KSeF zostanie przesłana faktura z załącznikiem, sprawdzone zostanie, czy
podmiot występujący na fakturze jako sprzedawca złożył wcześniej zgłoszenie w e-Urzędzie
Skarbowym. Jeżeli takie zgłoszenie nie zostało złożone i podatnik nie ma udostępnionej w API
KSeF 2.0 tej funkcjonalności (lub taka funkcjonalność została mu odebrana), to przesłana do
KSeF faktura z załącznikiem nie zostanie przyjęta przez system.
10

---

Przesłanką odrzucenia pliku XML na bramce będzie także wspomniana już wcześniej, wskazana
w polu P_1 data z przyszłości (tj. późniejsza niż data przesłania pliku XML do KSeF).
Przesłanką odrzucenia pliku XML przez system nie będzie jednak wskazanie w polu P_1 daty
wcześniejszej niż data przesłania pliku XML do KSeF. Jeżeli dana faktura zostanie przesłana do
systemu dopiero kolejnego dnia, a nie w dniu wskazanym w polu P_1, to plik nie zostanie z tego
powodu odrzucony. Faktura zostanie uznana za fakturę wystawioną w trybie offline24, a datą
jej wystawienia będzie data z pola P_1 .
1.4.2. Brak możliwości edytowania wystawionej faktury
Po przesłaniu pliku faktury do KSeF nie jest możliwe jej edytowanie w systemie. Wraz z
wejściem w życie obowiązkowego KSeF jedyną formą poprawienia błędu w wystawionej
fakturze ustrukturyzowanej będzie wystawienie faktury korygującej w KSeF. Od 1 lutego
2026r. zostaną również uchylone przepisy dotyczące wystawiana not korygujących. Zatem w
przypadku zidentyfikowania pomyłki w wystawionej fakturze podatnik zawsze będzie
wystawiał fakturę korygującą.
WAŻNE
KSeF weryfikuje m.in. zgodność pliku XML faktury z obowiązującą strukturą logiczną faktury
ustrukturyzowanej. KSeF nie dokonuje obliczeń matematycznych. Nie odrzuci faktury w
przypadku wystąpienia na niej błędów rachunkowych (np. gdy dana faktura będzie zawierała
nieprawidłowo wyliczoną kwotę podatku VAT w stosunku do wskazanej na tej fakturze kwoty
netto). Tego typu weryfikacje mogą jednak odbywać się na poziomie danej aplikacji do
wystawiania e-Faktur.
1.4.3. Brak możliwości anulowania lub usunięcia wystawionej faktury
Jeśli plik XML został wysłany do KSeF, przyjęty w systemie i końcowo fakturze został nadany
numer identyfikujący ją w KSeF, oznacza to, że faktura weszła do obrotu prawnego. W związku
z powyższym, jeśli w wystawionym dokumencie zidentyfikowano błędy, sprzedawca powinien
wystawić fakturę korygującą w celu poprawienia tych błędów. W KSeF nie jest możliwe
anulowanie wystawionej faktury.
Anulowanie faktury nie jest możliwe również w przypadku, gdy faktura została wystawiona na
błędnego nabywcę (błędny identyfikator podatkowy NIP w polu
Podmiot2/DaneIdentyfikacyjne/NIP). W tej sytuacji należy wystawić fakturę korygującą „do
zera” i nową fakturę pierwotną zawierającą poprawne dane (w tym poprawny identyfikator
podatkowy NIP) nabywcy.
11

---

Faktury wystawione w KSeF są przechowywane w systemie przez okres 10 lat od końca roku,
w którym faktura została wystawiona. Po tym czasem zostaną automatycznie usunięte.
Podatnicy nie mają możliwości samodzielnego usunięcia wystawionej faktury z systemu,
niezależnie czy faktura była ona wystawiona prawidłowo czy nieprawidłowo.
1.4.4. Wystawienie faktury na błędnego nabywcę
Jak wskazano wyżej, mogą zdarzyć się sytuacje, w których sprzedawca dokona dostawy towaru
na rzecz podatnika „A”, ale omyłkowo wystawi fakturę ustrukturyzowaną na rzecz podmiotu
„B” – czyli w części Podmiot2/DaneIdentyfikacyjne/NIP struktury FA(3) sprzedawca wskaże
identyfikator podatkowy NIP podmiotu „B” zamiast identyfikatora podatkowego NIP podmiotu
„A”. W takim przypadku fakturę w KSeF otrzyma podmiot „B”, którego identyfikator
podatkowy znalazł się na fakturze, ale który nie był faktycznym nabywcą towaru.
Jeżeli sprzedawca przesłał do KSeF fakturę z błędnym NIP nabywcy, zobowiązany jest do
wystawienia faktury korygującej "do zera" z tym błędnym NIP nabywcy. Następnie jest
obowiązany przesłać do KSeF poprawną fakturę (pierwotną) z prawidłowymi danymi nabywcy
„A” (w tym w szczególności z jego prawidłowym numerem NIP).
W opisanej sytuacji nie należy wystawiać faktury korygującej błędny numer NIP na inny
prawidłowy, gdyż w KSeF nie wystąpi sytuacja, że fakturę odebrał podmiot będący rzeczywistą
stroną transakcji, a jedynie jego numer NIP, podany w tej fakturze był błędny. Wynika to z
uwarunkowań systemowych. Faktura z błędnym NIP nabywcy zostanie po przetworzeniu
udostępniona podmiotowi o takim numerze NIP (mimo, iż to nie on jest faktycznym nabywcą
towaru).
1.4.5. Wizualizacja faktury
Założeniem KSeF jest, że faktura będzie otrzymywana przez nabywcę krajowego
posiadającego identyfikator podatkowy NIP przy użyciu systemu. Niemniej, w kilku ustawowo
określonych sytuacjach wystąpi obowiązek przekazania nabywcy faktury w sposób uzgodniony
(np. jako wydruk lub plik pdf). Przypadki te określa w szczególności art. 106gb ust. 4 ustawy.
Jest to np. sytuacja gdy nabywcą będzie podmiot zagraniczny, konsument czy inny podmiot
nieposiadający NIP.
W momencie wprowadzenia obowiązkowego KSeF, nie zostanie wprowadzony jeden,
obowiązujący wzór wizualizacji e-Faktury, w przypadku przekazywania faktury nabywcy w
sposób uzgodniony lub w sytuacji posługiwania się fakturą ustrukturyzowaną poza systemem.
Dostawcy aplikacji do wystawiania faktur mogą tworzyć własne wizualizacje, dostosowane do
potrzeb swoich klientów.
12

---

E-Fakturę można zwizualizować (np. w postaci pliku pdf) także w bezpłatnych narzędziach
oferowanych przez MF – tj. w Aplikacji Podatnika KSeF, Aplikacji Mobilnej KSeF czy e-
mikrofirmie. Wraz z udostepnieniem struktury logicznej faktury ustrukturyzowanej na ePUAP
udostępniono także transformatę, która może być pomocna w procesie tworzenia wizualizacji:
FA(3) USTRUKTURYZOWANA FAKTURA VAT, nr ID wzoru 13775 (CRDWE).
Zawartość wizualizacji faktury
O sposobie prezentacji poszczególnych danych na wizualizacji decyduje wystawca
faktury/integrator systemu. Biorąc jednak pod uwagę, że faktura w formie zwizualizowanej jest
pochodną przesłanego do KSeF pliku XML, należy zadbać o:
• jej spójność w porównaniu do zawartości pliku XML faktury przesłanego do KSeF,
• czytelność dokumentu, poprzez odpowiedni, logiczny układ danych w wizualizacji,
• brak sprzeczności pomiędzy zawartością pliku XML przesłanego do KSeF, przyjętego
przez system a treścią wizualizacji.
WAŻNE
Nie jest zalecane postępowanie polegające na przesyłaniu do KSeF pliku xml zawierającego
tylko podstawowe dane wymagane przepisami, przy jednoczesnym wskazywaniu wszystkich
danych dodatkowych tylko na wizualizacji (np. terminów czy formy płatności, numeru rachunku
bankowego czy dodatkowych informacji o przedmiocie transakcji). Taki sposób postępowania
uniemożliwiałby nabywcy zapisanie wszystkich danych faktury w systemie z uwagi na ich brak
w treści pliku XML. Utrudniłoby to również automatyzację procesów związanych z
zaksięgowaniem faktury zakupowej i nie pozwalałoby w pełni realizować celów wynikających z
wdrożenia KSeF, związanych z brakiem konieczności ręcznego wprowadzania danych do
systemów. Z tego też względu MF zachęca do pełnego wykorzystywania możliwości, które
daje wzór e-Faktury. Należy zwrócić uwagę, że struktura logiczna FA(3) umożliwia prezentację
dodatkowych danych w formie ustrukturyzowanej (np. w polu DodatkowyOpis czy elementach
tj. Platnosc, Rozliczenie, WarunkiTransakcji).
Wizualizacja, poza danymi znajdującymi się w pliku XML może zawierać jednak dodatkowe
dane typu logo firmy czy np. kontakt do biura obsługi klienta, które z punku widzenia
systemowego nie mają znaczenia.
Posługiwanie się fakturą ustrukturyzowaną poza KSeF wymaga również opatrzenia jej kodem
QR (z odpowiednim napisem zawierającym numer KSeF faktury), a w przypadku faktur
wystawianych w trybie OFFLINE i nieprzesłanych jeszcze do KSeF, dwoma kodami QR (z
napisami „OFFLINE” i „CERTYFIKAT”).
13

---

Wizualizacja faktury a znaczniki dotyczące braku wystąpienia adnotacji
Jak wskazano wyżej, wizualizacja faktury co do zasady powinna być odzwierciedleniem pliku
XML faktury. Jednocześnie w strukturze e-Faktury występuje element Adnotacje zawierający
informacje dotyczące dodatkowych adnotacji na fakturze np. „metoda kasowa”,
„samofakturowanie”, „odwrotne obciążenie”. Struktura logiczna jest skonstruowana w ten
sposób, że podatnik musi zadeklarować czy dana adnotacja występuje na fakturze czy nie
(podając w zależności od sytuacji wartość „1” lub „2”). W związku z tym w pliku XML faktury
taka informacja zawsze zostanie odłożona. Należy jednak podkreślić, że jeżeli podatnik wskaże,
że faktura nie zawiera danej adnotacji, to w wizualizacji faktury taka informacja nie musi zostać
dodatkowo zadeklarowana. Podatnik będzie mieć obowiązek zawarcia adnotacji na
wizualizacji, tylko gdy taka adnotacja wystąpi.
Przykładowo pole P_16 dotyczy dostawy towarów lub świadczenia usług, w odniesieniu do
których obowiązek podatkowy powstaje zgodnie z art. 19a ust. 5 pkt 1 lub art. 21 ust. 1 ustawy,
w przypadku których faktura zawiera adnotację „metoda kasowa”. W ww. polu należy podać
wartość „1” jeżeli faktura zawiera ww. adnotację. W przeciwnym przypadku podaje się wartość
„2”. W wizualizacji faktury:
• w przypadku wskazania „1” w polu P_16 – należy zamieścić adnotację „metoda kasowa”,
• w przypadku wskazania „2” w polu P_16 – nie trzeba zamieszczać żadnej informacji w
zakresie tego pola tzn. nie trzeba wskazywać, że pole P_16 jest równe „2” lub że „faktura
nie zawiera adnotacji metoda kasowa”.
Podsumowując, jeżeli zgodnie z przepisami ustawy, dana adnotacja występuje, to w pliku XML
należy zastosować odpowiedni znacznik, a dana adnotacja powinna znaleźć się także w
wizualizacji. Jeżeli natomiast nie ma podstaw do zamieszczania danej adnotacji na fakturze, to
w pliku XML należy zastosować odpowiedni znacznik (dotyczący braku adnotacji), a na
wizualizacji nie ma konieczności zamieszczania informacji, że dana faktura danej adnotacji nie
zawiera.
Wizualizacja w języku obcym
Wizualizacja e-Faktury może zawierać informacje w języku obcym. Możliwe jest wystawienie
faktury w języku polskim (tj. plik XML w języku polskim), a następnie jej zwizualizowanie w
języku obcym lub np. zastosowanie wizualizacji w dwóch językach równocześnie. Kluczowe jest
jednak, aby dane umieszczone na wizualizacji (w języku obcym) pod względem merytorycznym
odpowiadały zawartości pliku XML faktury w języku polskim.
14

---

Ponadto, nie ma również przeszkód, aby plik XML faktury przesyłany do KSeF zawierał dane
przygotowane w języku obcym.
1.4.6. Możliwość wydania nabywcy „potwierdzenia transakcji”
Jaki dokument wydać nabywcy w przypadku faktury wystawionej w trybie ONLINE?
W przypadku faktury wystawionej w trybie ONLINE:
• Jeśli fakturze został już nadany numer KSeF i jednocześnie:
o nabywcą jest podatnik krajowy z NIP (który otrzymał fakturę w KSeF) -
sprzedawca może dodatkowo wydać nabywcy fakturę w postaci
zwizualizowanej np. wydruk tej faktury lub plik pdf, pamiętając o opatrzeniu
tego dokumentu kodem QR (z oznaczeniem w postaci numeru KSeF), lub
o nabywcą jest podmiot wymieniony w art. 106gb ust. 4 ustawy - sprzedawca
wydaje nabywcy fakturę w postaci uzgodnionej; w przypadku przekazania poza
KSeF faktura powinna być opatrzona kodem QR (z oznaczeniem numeru KSeF);
• Jeśli fakturze nie został jeszcze nadany numer KSeF - sprzedawca może wydać
nabywcy (bez względu na jego status) potwierdzenie transakcji (tj. potwierdzenie, że w
KSeF będzie wystawiona faktura o danej treści handlowej).
W przypadku, gdy faktura dotyczy transakcji na rzecz nabywcy, o którym mowa w art.
106gb ust. 4 ustawy, konieczne będzie wydanie tej faktury nabywcy w sposób
uzgodniony bez względu na to, czy wystawca przekazał temu nabywcy potwierdzenie
transakcji.
Art. 106gb ust. 4 ustawy dotyczy:
• przypadku gdy miejscem świadczenia jest terytorium państwa członkowskiego inne niż
terytorium kraju lub terytorium państwa trzeciego,
• podmiotu bez siedziby i stałego miejsca prowadzenia działalności gospodarczej w kraju,
• podmiotu nieposiadającego siedziby, ale posiadającego stałe miejsce prowadzenia
działalności gospodarczej w kraju, które nie uczestniczy w danej transakcji,
• podatnika korzystającego ze zwolnienia z art. 113a ust. 1 ustawy (tzw. procedura SME),
• podmiotu innego niż wyżej wymieniony, nieposiadającego NIP,
• osoby fizycznej nieprowadzącej działalności gospodarczej (konsumenta).
15

---

Schemat 2. Dokument wydawany nabywcy poza KSeF w przypadku faktury wystawianej w trybie ONLINE.
DOKUMENT WYDAWANY NABYWCY POZA
KSeF
CZY NUMER KSeF JEST NADANY?
TAK NIE
PRZEKAZANIE FAKTURY PRZEKAZANIE NABYWCY
OPATRZONEJ KODEM QR Z POTWIERDZENIA TRANSKACJI
OZNACZENIEM NR KSeF Z DWOMA KODAMI QR
Jaki dokument wydać nabywcy w przypadku faktury wystawionej w trybie OFFLINE
(offline24 – art. 106nda ustawy oraz niedostępność KSeF – art. 106nh ustawy)?
W przypadku faktury wystawionej w trybie offline24 oraz offline-niedostępność KSeF:
• Jeśli fakturze został już nadany numer KSeF – sprzedawca może wydać nabywcy
fakturę w postaci zwizualizowanej np. wydruk tej faktury lub plik pdf drogą
elektroniczną, pamiętając o opatrzeniu tego dokumentu kodem QR (z oznaczeniem w
postaci numeru KSeF),
• Jeśli fakturze nie został jeszcze nadany numer KSeF i jednocześnie:
o nabywcą jest podmiot wymieniony w art. 106gb ust. 4 ustawy- sprzedawca
wydaje nabywcy fakturę w postaci uzgodnionej; w przypadku gdy faktura jest
wydawana poza KSeF, powinna zostać opatrzona dwoma kodami QR (z
oznaczeniem „OFFLINE” oraz „CERTYFIKAT”), lub
o nabywcą jest podatnik krajowy z NIP (który otrzyma fakturę w KSeF) –
sprzedawca nie wydaje nabywcy faktury w sposób inny niż poprzez KSeF,
natomiast może wydać nabywcy potwierdzenie transakcji (tj. potwierdzenie
wystawienia faktury, która zostanie przekazana nabywcy w KSeF).
16

---

Schemat 3. Dokument wydawany nabywcy poza KSeF w przypadku faktury wystawianej w trybie offline24 i offline-
niedostępność KSeF.
DOKUMENT WYDAWANY NABYWCY POZA KSeF
CZY NUMER KSeF JEST NADANY?
TAK NIE
PRZEKAZANIE FAKTURY CZY NABYWCA JEST PODATNIKIEM
OPATRZONEJ KODEM QR KRAJOWYM Z NIP?
Z OZNACZENIEM NR KSeF
NIE TAK
PRZEKAZANIE PRZEKAZANIE NABYWCY
NABYWCY FAKTURY Z POTWIERDZENIA
DWOMA KODAMI QR TRANSKACJI Z DWOMA
KODAMI QR
Jaki dokument wydać nabywcy w przypadku faktury wystawionej w trybie OFFLINE
(tryb awaryjny – art. 106nf ustawy)?
W przypadku faktury wystawionej w trybie awaryjnym, faktura jest wydawana nabywcy w
sposób uzgodniony (niezależnie od statusu nabywcy):
• Jeżeli nabywca uzgodnił otrzymanie faktury poza KSeF – sprzedawca wydaje
nabywcy np. wydruk tej faktury lub przesyła mu plik pdf drogą elektroniczną,
pamiętając o opatrzeniu tej faktury dwoma kodami QR (pierwszy z napisem
„OFFLINE”, drugi z napisem „CERTYFIKAT”),
17

---

• Jeżeli nabywca uzgodnił otrzymanie faktury w KSeF – sprzedawca może dodatkowo
wydać temu nabywcy potwierdzenie transakcji (dzięki temu nabywca po zeskanowaniu
kodu QR będzie mógł m.in. zweryfikować czy faktura została już dosłana do systemu).
Schemat 4. Dokument wydawany nabywcy poza KSeF w przypadku faktury wystawianej w trybie awaryjnym.
DOKUMENT WYDAWANY NABYWCY
POZA KSeF
CZY NABYWCA UZGODNIŁ OTRZYMANIE
FAKTURY W KSeF?
TAK NIE
PRZEKAZANIE NABYWCY PRZEKAZANIE NABYWCY
POTWIERDZENIA FAKTURY Z DWOMA
TRANSKACJI Z DWOMA KODAMI QR
KODAMI QR
Założenia dotyczące wydawania potwierdzenie transakcji
Wydanie potwierdzenia transakcji nie będzie regulowane przepisami ustawy ani
rozporządzenia z uwagi na fakt, że nie wiąże się z żadnymi nowymi obowiązkami dla
podatników. Wprowadzenie tego rozwiązania jest odpowiedzią na potrzeby rynku, a
korzystanie z niego jest w pełni dobrowolne.
Potwierdzenie transakcji będzie mogło być wydane w obu funkcjonujących w KSeF trybach
wystawiania faktur: ONLINE i OFFLINE. Szczególnie przydatne będzie to np. w przypadku
dokonywania sprzedaży w sklepach stacjonarnych, na stacjach benzynowych gdzie klient
oczekuje przy kasie na dokument potwierdzający transakcję (fakturę). Wydanie potwierdzenia
transakcji zabezpieczy więc interes nabywcy w sytuacjach, gdy wystawiona w trybie ONLINE
lub OFFLINE faktura, nie posiada jeszcze numeru KSeF. Dzięki zamieszczonym na
18

---

potwierdzeniu transakcji kodom QR możliwy będzie m.in. dostęp do faktury i weryfikacja jej
danych.
Elementy potwierdzenia transakcji
Przykład 4. Przykładowe potwierdzenie transakcji.
Należy zaznaczyć, że potwierdzenie transakcji z uwagi na swój zakres elementów nie będzie
fakturą w rozumieniu art. 2 pkt 32 ustawy ani fakturą uproszczoną w rozumieniu przepisów
rozporządzenia w sprawie wystawiania faktur. Dokument ten powinien posiadać nazwę
„potwierdzenie transakcji”.
19

---

Potwierdzenie transakcji musi zawierać tylko poniższe elementy:
• podstawowe dane stron transakcji tj.:
o dane sprzedawcy (Podmiot1) - nazwę, identyfikator podatkowy NIP, adres,
o dane nabywcy (Podmiot2) - nazwę, identyfikator podatkowy NIP/inny
identyfikator lub informację o braku identyfikatora, adres,
• numer faktury nadany przez podatnika (wartość z pola P_2),
• kwotę należności ogółem (wartość z pola P_15),
• dwa kody QR/linki, z czego pierwszy zapewnia dostęp do faktury i weryfikację danych z
faktury, a drugi pozwala na weryfikację wystawcy faktury; nad pierwszym kodem QR
zamieszcza się napis „sprawdź fakturę w KSeF”, a nad drugim kodem QR „zweryfikuj
wystawcę faktury”;
Pod kodami QR/ linkami nie zamieszcza się natomiast żadnych napisów (np. „OFFLINE” czy
„CERTYFIKAT”), niezależnie od trybu, w którym jest wystawiana faktura, której to
potwierdzenie transakcji dotyczy.
W ramach ww. elementów potwierdzenia transakcji znajdują się więc m.in. dane określone
rozporządzeniem w sprawie korzystania z KSeF2, które umożliwią nabywcy za pomocą kodu
QR/ linku, dostęp do faktury w KSeF, bez konieczności uwierzytelnienia w systemie.
1.4.7. Kolejny numer faktury a odrzucenie pliku XML przez KSeF
Zgodnie z art. 106e ust. 1 pkt 2 ustawy faktura powinna zawierać między innymi kolejny numer
faktury nadany w ramach jednej lub więcej serii, który w sposób jednoznaczny identyfikuje
fakturę.
Może zaistnieć sytuacja, w której podatnik przygotował pliki XML w swoim programie
księgowym, nadał tym dokumentom numery faktur zgodnie z art. 106e ust. 1 pkt 2 ustawy, ale
do KSeF przesłał je w kolejności niezgodnej z chronologią wynikającą z numerów ww. faktur.
Przyczyną może być np. odrzucenie pliku XML przez KSeF w związku np. z niezgodnością
dokumentu ze strukturą FA(3) lub brakiem uprawnienia do korzystania z KSeF.
Jeśli zasada numeracji narastającej (w momencie przygotowywania plików XML w programie
księgowym) była zachowana, ale z przyczyn technicznych doszło do wystawienia faktur
ustrukturyzowanych w KSeF w kolejności niezgodnej z ich numeracją, nie będzie to przesłanką
2 Proces legislacyjny w toku: https://legislacja.rcl.gov.pl/projekt/12379252.
20

---

odrzucenia faktury przez system. Nie jest to również przesłanką zobowiązująca podatnika do
wystawienia faktury korygującej, w celu poprawienia nadanego pierwotnie numeru faktury,
wskazanego w polu P_2 (w przypadku, gdy faktura o numerze wcześniejszym została przesłana
do KSeF później niż faktura o numerze późniejszym).
Przykład 5. Kolejny numer faktury a odrzucenie pliku XML przez system.
Podatnik przygotował pliki XML faktur nr 7/02/2026, nr 8/02/2026 oraz nr 9/02/2026 w
swoim programie księgowym. Wystawiał faktury w trybie ONLINE. Plik XML faktury nr
7/02/2026 został odrzucony przez KSeF z powodu braku zgodności dokumentu ze strukturą. Z
kolei faktura nr 8/02/2026 oraz nr 9/02/2026 zostały przyjęte i nadany został im numer KSeF.
Podatnik doprowadził przygotowany plik XML faktury nr 7/02/2026 do zgodności ze strukturą
FA(3) i ponowił jej wysyłkę w tym samym dniu. Wysyłka zakończyła się sukcesem i fakturze nr
7/02/2026 został nadany numer KSeF.
Doszło więc do sytuacji, w której faktura o numerze wcześniejszym (nr 7/02/2026) została
przesłana skutecznie do KSeF później, niż faktury o numerach późniejszych (nr 8/02/2026 oraz
nr 9/02/2026).
2. Zalecenia dotyczące prawidłowego wypełniania struktury logicznej
FA(3)
Faktura ustrukturyzowana jest wystawiana i otrzymywana przy użyciu KSeF za pomocą
oprogramowania interfejsowego, w postaci elektronicznej i zgodnie z wzorem dokumentu
elektronicznego w rozumieniu ustawy z dnia 17 lutego 2005 r. o informatyzacji działalności
podmiotów realizujących zadania publiczne3.
Od 1 lutego 2026 r. faktury ustrukturyzowane wystawia się przy użyciu struktury logicznej
FA(3). Struktura logiczna FA(3) to wzór e-Faktury obowiązujący od 1 lutego 2026 r.,
opublikowany przez MF na ePUAP i dostępny pod adresem:
https://epuap.gov.pl/wps/portal/strefa-urzednika/inne-systemy/crwde (nr wzoru 13775).
Programy fakturujące na podstawie wprowadzonych przez wystawcę, w danej aplikacji, danych
faktury (m.in. dane sprzedawcy, nabywcy, nazwa towaru lub usługi, cena jednostkowa, stawka,
podsumowania kwot itp.) będą tworzyć na tej podstawie plik XML:
• plik XML musi być zgodny ze wzorem opublikowanym przez MF (większość programów
będzie sprawdzała to automatycznie),
3 Dz.U. 2024 poz. 1557 ze zm.
21

---

• przygotowany plik XML będzie wysyłany do KSeF,
• jeśli plik XML nie będzie zgodny ze wzorem – to nie zostanie przyjęty do KSeF.
WAŻNE
Struktura logiczna e-Faktury nie jest wzorem rozumianym jako graficzna (zwizualizowana)
postać faktury.
Struktura logiczna:
• określa co powinien (i co może) zawierać plik XML faktury oraz
• jakie dane faktury należy umieścić w danym polu i w jaki formacie należy je ująć (np.
format daty – w przypadku daty sprzedaży, format kwoty – w przypadku kwoty
należności ogółem lub format procentów w przypadku stawki podatku),
• każde wypełnione w formatce faktury pole ma swój odpowiednik we wzorze, np. nazwa
towaru lub usługi to pole P_7, a stawka podatku to pole P_12.
Wzór faktury ustrukturyzowanej nie wykracza poza dane, które powinny być zamieszczane na
fakturach. Zakres danych wymaganych na fakturach określa nadal art. 106e ustawy o VAT.
Wzór e-Faktury zawiera szereg informacji dodatkowych (niewymaganych ustawą), które nie są
obowiązkowe, a które przedsiębiorcy zwykle zamieszczają na fakturach, np. dane kontaktowe
stron transakcji. Wskazywanie takich elementów na fakturze nie jest obowiązkowe.
Schemat 5. Schemat główny struktury logicznej FA(3).
22

---

Struktura logiczna FA(3) składa się z ośmiu głównych elementów:
• Naglowek - element zawierający dane techniczne (kod i wariant formularza, nazwę
programu do wystawiania faktur, z którego korzysta podatnik, datę wytworzenia pliku
XML),
• Podmiot1 - element zawierający dane sprzedawcy (w tym m.in. jego identyfikator
podatkowy, nazwę, adres, dane kontaktowe),
• Podmiot2 - element zawierający dane nabywcy (w tym m.in. jego identyfikator
podatkowy, nazwę, adres, dane kontaktowe),
• Podmiot3 - element zawierający dane podmiotu trzeciego np. faktora albo płatnika (w
tym m.in. jego identyfikator podatkowy, nazwę, adres, dane kontaktowe, rolę podmiotu
trzeciego),
• PodmiotUpowazniony - element zawierający dane podmiotu upoważnionego np.
komornika sądowego (w tym m.in. jego identyfikator podatkowy, nazwę, adres, dane
kontaktowe, rolę podmiotu upoważnionego),
• Fa - element zawierający szczegółowe dane dotyczące transakcji dokumentowanej
fakturą, m.in.: numer faktury nadany przez podatnika, datę wystawienia oraz datę
sprzedaży, dane kwotowe (m.in. kwotę netto, VAT, kwotę należności ogółem), pozycje
faktury, stawkę, adnotacje wymagane ustawą czy dodatkowe informacje o płatności,
rozliczeniu czy warunkach transakcji,
• Stopka - element zawierający stopkę faktury np. numer KRS, wartość kapitału
zakładowego,
• Zalacznik – element zawierający ustrukturyzowany załącznik do faktury (funkcjonalność
dostępna tylko po złożeniu zgłoszenia w e-US).
Przydatna podczas analizy wzoru e-Faktury będzie Broszura informacyjna dotycząca struktury
logicznej FA(3), dostępna na stronie: https://ksef.podatki.gov.pl. Przedstawione są w niej
zasady wypełnienia poszczególnych pól struktury logicznej, wraz z praktycznymi przykładami
ich wykorzystania.
W kolejnych podrozdziałach niniejszego podręcznika w szczególności skupiono się natomiast
na przekrojowym zaprezentowaniu wykorzystania struktury, w kontekście różnych rodzajów
wystawianych faktur i transakcji, które one dokumentują.
2.1. Prawidłowy zapis identyfikatorów podatkowych
2.1.1. Brak znaków rozdzielających w numerze NIP
Identyfikatory NIP (występujące m.in. w elementach: Podmiot1/DaneIdentyfikacyjne,
Podmiot2/DaneIdentyfikacyjne, Podmiot3/DaneIdentyfikacyjne,
23

---

PodmiotUpowazniony/DaneIdentyfikacyjne) należy zapisywać jako ciąg kolejno po sobie
następujących cyfr, bez spacji i innych znaków rozdzielających.
Tabela 1. Sposób prezentacji w strukturze FA(3) identyfikatora podatkowego NIP.
Nazwa pola Przykład prawidłowego zapisu Przykład nieprawidłowego zapisu
NIP 9999999999 999-999-99-99
2.1.2. Wydzielenie dwuliterowego prefiksu sprzedawcy „PL” w osobnym polu
W przypadku transakcji, dla których sprzedawca (Podmiot1) jest zobowiązany do podania na
fakturze dwuliterowego kodu (prefiksu) kraju „PL” (np. wewnątrzwspólnotowa dostawa
towarów, świadczenie usług na rzecz podatnika podatku od wartości dodanej, do których ma
zastosowanie art. 28b ustawy) – kod należy wyodrębnić w osobnym polu
Podmiot1/PrefiksPodatnika.
Tabela 2. Sposób prezentacji w strukturze FA(3) dwuliterowego prefiksu sprzedawcy.
Nazwa pola Przykład prawidłowego zapisu Przykład nieprawidłowego zapisu
PrefiksPodatnika PL * Pole pozostało niewypełnione
NIP 9999999999 PL9999999999
2.1.3. Wydzielenie dwuliterowego prefiksu nabywcy w osobnym polu
W przypadku transakcji, dla których sprzedawca jest zobowiązany wskazać na fakturze
dwuliterowy kod (prefiks) nabywcy VAT UE (np. wewnątrzwspólnotowa dostawa towarów,
świadczenie usług na rzecz podatnika podatku od wartości dodanej, do których ma
zastosowanie art. 28b ustawy) – kod kraju kontrahenta należy wskazać w polu KodUE (element
Podmiot2/DaneIdentyfikacyjne), a numer identyfikacyjny kontrahenta nadany na cele podatku
od wartości dodanej - w polu NrVatUE.
Tabela 3. Sposób prezentacji w strukturze FA(3) dwuliterowego prefiksu oraz numeru identyfikacyjnego nabywcy.
Nazwa pola Przykład prawidłowego zapisu Przykład nieprawidłowego zapisu
KodUE DE * Pole pozostało niewypełnione
NrVatUE 9999999999 * Pole pozostało niewypełnione
KodKraju * Pole pozostało niewypełnione DE
NrID * Pole pozostało niewypełnione 9999999999
24

---

2.1.4. Identyfikator podatkowy nabywcy ujęty w polu NIP
W przypadku wystawienia faktury na rzecz nabywcy posługującego się polskim
identyfikatorem podatkowym NIP, kluczowe jest, aby identyfikator ten został wpisany w polu
NIP (element Podmiot2/DaneIdentyfikacyjne), ponieważ na tej podstawie faktura przesyłana
do KSeF będzie mogła być udostępniona nabywcy w tym systemie. Nie należy podawać
polskiego identyfikatora podatkowego NIP w innych polach np. w polu NrID.
Tabela 4. Sposób prezentacji w strukturze FA(3) identyfikatora podatkowego NIP.
Nazwa pola Przykład prawidłowego zapisu Przykład nieprawidłowego zapisu
NIP 9999999999 * Pole pozostało niewypełnione
NrID * Pole pozostało niewypełnione 9999999999
2.1.5. Identyfikator kontrahenta z kraju trzeciego ujęty w polach KodKraju i NrID
W przypadku transakcji, w których nabywcą (Podmiot2) jest podmiot z siedzibą w kraju
trzecim, nie jest obowiązkowe wskazywanie na fakturze jego identyfikatora podatkowego
nadanego na cele podatku o podobnym charakterze. W tym przypadku wystarczające jest
wpisanie w polu BrakID wartości „1”, co oznacza, że nabywca nie posiada identyfikatora
podatkowego lub identyfikator ten nie występuje na fakturze.
Jeżeli natomiast nabywca z kraju trzeciego posiada identyfikator, a sprzedawca zdecydował się
zawrzeć go na fakturze, wtedy wypełnia pole NrID oraz fakultatywnie KodKraju. Nie zaleca się
łączenia w polu NrID identyfikatora podatkowego z kodem kraju.
Tabela 5. Sposób prezentacji w strukturze FA(3) identyfikatora podatkowego kontrahenta z kraju trzeciego.
Nazwa pola Przykład prawidłowego zapisu Przykład nieprawidłowego zapisu
KodKraju CH * Pole pozostało niewypełnione
NrID 9999999999 CH9999999999
2.1.6. Sposób prezentacji w strukturze FA(3) przypadku, gdy nabywca jest
konsumentem
W przypadku transakcji, w których nabywcą (Podmiot2) jest osoba fizyczna nieprowadząca
działalności gospodarczej (konsument) nie podaje się jego identyfikatora podatkowego NIP. W
tym przypadku wystarczające jest wpisanie w polu BrakID wartości „1”, co oznacza, że nabywca
nie posiada identyfikatora podatkowego lub identyfikator ten nie występuje na fakturze.
25

---

Tabela 6. Sposób prezentacji w strukturze FA(3) przypadku, gdy nabywca jest konsumentem.
Nazwa pola Przykład prawidłowego zapisu
BrakID 1
2.2. Faktura zawierająca dane podmiotów trzecich
Struktura logiczna e-Faktury zawiera w swojej konstrukcji część Podmiot3, w której podatnik
może wskazać dane podmiotów związanych z fakturą, innych niż sprzedawca (wskazany w
części Podmiot1) oraz innych niż nabywca (wskazany w części Podmiot2).
W części Podmiot3 można wskazać m.in.:
• dane identyfikacyjne podmiotu trzeciego (NIP, imię i nazwisko lub nazwę),
• adres oraz adres korespondencyjny podmiotu trzeciego,
• dane kontaktowe podmiotu trzeciego (numer telefonu, adres e-mail),
• rolę podmiotu trzeciego.
Rolę podmiotu trzeciego można wskazać w polu Rola – podając:
„1” - Faktor - w przypadku, gdy na fakturze występują dane faktora,
„2” - Odbiorca - w przypadku, gdy na fakturze występują dane jednostek wewnętrznych,
oddziałów, wyodrębnionych w ramach nabywcy, które same nie stanowią nabywcy w
rozumieniu ustawy,
„3” - Podmiot pierwotny - w przypadku, gdy na fakturze występują dane podmiotu będącego w
stosunku do podatnika podmiotem przejętym lub przekształconym, który dokonywał dostawy
lub świadczył usługę (z wyłączeniem przypadków, o których mowa w art. 106j ust. 2 pkt 3
ustawy, gdy dane te wykazywane są w części Podmiot1K),
„4” - Dodatkowy nabywca - w przypadku, gdy na fakturze występują dane kolejnych (innych niż
wymieniony w części Podmiot2) nabywców,
„5” - Wystawca faktury - w przypadku, gdy na fakturze występują dane podmiotu
wystawiającego fakturę w imieniu podatnika (nie dotyczy przypadku, gdy wystawcą faktury
jest nabywca),
„6” - Dokonujący płatności - w przypadku, gdy na fakturze występują dane podmiotu
regulującego zobowiązanie w miejsce nabywcy,
26

---

„7” - Jednostka samorządu terytorialnego - wystawca,
„8” - Jednostka samorządu terytorialnego - odbiorca,
„9” - Członek grupy VAT - wystawca,
„10” - Członek grupy VAT - odbiorca,
„11” - Pracownik.
Jeżeli podatnik chce zawrzeć w fakturze dane podmiotu trzeciego o roli innej niż jedna z wyżej
wymienionych, wówczas może wskazać „1” w polu RolaInna, a w polu OpisRoli opisać tę rolę.
Możliwe jest więc wystawienie w KSeF faktury, która poza danymi sprzedawcy i nabywcy,
będzie zawierała np. dane faktora, płatnika czy oddziału podatnika. Faktura ustrukturyzowana
może zawierać dane wielu podmiotów trzecich (maksymalnie stu).
Jeżeli jeden podmiot trzeci będzie występował na fakturze w dwóch różnych rolach, wówczas
podatnik może wypełnić element Podmiot3 dwa razy (dla każdej roli osobno) lub jeden raz
korzystając z opcji wskazania roli innej podmiotu trzeciego, która będzie w tym przypadku
zawierać opis dwóch ról.
2.2.1. Faktura obejmująca dane faktora
W elemencie Podmiot3 podatnik może fakultatywnie wskazać dane faktora, w tym m.in.:
• dane identyfikacyjne faktora (w szczególności jego NIP, imię i nazwisko lub nazwę),
• adres faktora,
• adres korespondencyjny faktora,
• dane kontaktowe faktora (jego e-mail, numer telefonu),
• rolę podmiotu trzeciego – w tym przypadku „1” (faktor).
Dodatkowo warto zwrócić uwagę, że struktura e-Faktury zawiera także w części Fa/Platnosc
element RachunekBankowyFaktora, w którym można podać:
• pełny numer rachunku faktora,
• kod SWiFT,
• znacznik, że dany rachunek jest rachunkiem własnym banku,
• nazwę banku, w którym prowadzony jest rachunek faktora (maksymalnie 256 znaków),
27

---

• opis rachunku faktora (dowolne, dodatkowe informacje dotyczące rachunku,
maksymalnie 256 znaków).
Dane dotyczące terminu i formy płatności można zamieścić w elemencie Fa/Platnosc (pola
TerminPlatnosci, FormaPlatnosci (lub PlatnoscInna, OpisPlatnosci).
Schemat 6. Element RachunekBankowyFaktora w strukturze FA(3).
Przykładowy plik e-Faktury zawierającej dane faktora można znaleźć pod adresem:
https://www.gov.pl/web/kas/krajowy-system-e-faktur (dokument: „Przykładowe pliki dla
struktury logicznej e-Faktury FA(3)”, przykład nr 4).
2.2.2. Faktura zawierająca dane kilku nabywców
W KSeF możliwe jest wystawienie faktury na więcej niż jednego nabywcę. W tym celu:
• dane pierwszego nabywcy należy uwzględnić w elemencie Podmiot2 struktury
logicznej FA(3),
• dane drugiego (i każdego kolejnego) nabywcy należy ująć w elemencie Podmiot3
struktury FA(3), wskazując w polu Rola – „4” (dodatkowy nabywca).
Z myślą o fakturach wystawianych na kilku nabywców stworzone zostało również pole Udzial.
Jest to pole, w którym można zawrzeć procentowy udział dodatkowego nabywcy
(wymienionego w części Podmiot3).
Różnica pomiędzy wartością 100% a sumą udziałów dodatkowych nabywców jest udziałem
nabywcy wymienionego w części Podmiot2. W przypadku niewypełnienia pola przyjmuje się, że
udziały występujących na fakturze nabywców są równe. KSeF nie waliduje ww. pola, tzn. nie
bada czy łączna wartość udziałów daje 100%.
28

---

Przykładowy plik e-Faktury zawierającej dane kilku nabywców (wraz z wypełnionym polem
Udzial) można znaleźć pod adresem: https://www.gov.pl/web/kas/krajowy-system-e-faktur
(dokument: „Przykładowe pliki dla struktury logicznej e-Faktury FA(3)”, przykład nr 10).
2.2.3. Faktura uwzględniająca dane jednostki podrzędnej JST
Wyjaśnienia dotyczące zasad wypełnienia struktury logicznej FA(3) w przypadku, gdy faktura
zawiera dane jednostki podrzędnej JST zostały zawarte w cz. IV Podręcznika KSeF 2.0.
2.2.4. Faktura uwzględniająca dane członka GV
Wyjaśnienia dotyczące zasad wypełnienia struktury logicznej FA(3) w przypadku, gdy faktura
zawiera dane członka GV zostały zawarte w cz. IV Podręcznika KSeF 2.0.
2.2.5. Faktura zawierająca dane zakładu lub wyodrębnionej jednostki wewnętrznej
podatnika
WAŻNE
Warunkiem poprawnego działania modelu uprawnień dedykowanego zakładowi (oddziałowi)
lub innej jednostce wewnętrznej podatnika jest każdorazowe wskazanie unikalnego
identyfikatora zakładu (oddziału)/wyodrębnionej jednostki wewnętrznej podatnika w
strukturze FA(3) w części Podmiot3/DaneIdentyfikacyjne w polu IDWew.
W strukturze logicznej e-Faktury FA(3), w elemencie Podmiot3/DaneIdentyfikacyjne
funkcjonuje pole IDWew. Jest to pole, w którym wskazuje się unikalny identyfikator zakładu
(oddziału) osoby prawnej lub innej wyodrębnionej jednostki wewnętrznej podatnika.
Wskazany w polu IDWew identyfikator umożliwia identyfikację tej jednostki w KSeF na cele
funkcjonowania opisanego modelu uprawnień. Aby osoba uprawniona do dostępu do faktur (w
ramach danego zakładu (oddziału)/ jednostki wewnętrznej podatnika) mogła uzyskać dostęp w
KSeF do faktur zakupu (w których nabywcą jest podatnik, ale dotyczą one danego
zakładu/jednostki wewnętrznej tego podatnika) w strukturze FA(3) wskazuje się m.in.:
• dane nabywcy (podatnika), w tym jego identyfikator podatkowy NIP w części Podmiot2,
• dane zakładu (oddziału) osoby prawnej lub innej wyodrębnionej jednostki wewnętrznej
podatnika, w tym w szczególności jej unikalny identyfikator wewnętrzny (w polu
IDWew) w części Podmiot3.
Z kolei, aby osoba uprawniona do wystawiania faktur (w ramach danego zakładu (oddziału)/
jednostki wewnętrznej) mogła wystawić w KSeF fakturę (w której sprzedawcą jest podatnik,
29

---

ale dotyczy ona sprzedaży danego zakładu (oddziału)/jednostki wewnętrznej) na fakturach
sprzedaży należy ująć m.in.:
• identyfikator podatkowy NIP podatnika (sprzedawcy) w polu Podmiot1,
• dane zakładu (oddziału) osoby prawnej lub innej wyodrębnionej jednostki wewnętrznej
podatnika, w tym w szczególności jej unikalny identyfikator wewnętrzny (w polu
IDWew) w części Podmiot3. Powyższe rozwiązanie umożliwi także dostęp do faktury
sprzedażowej, osobie uprawnionej do dostępu do faktur w ramach danego zakładu
(oddziału)/ jednostki wewnętrznej podatnika).
2.3. Dodatkowe informacje o przedmiocie sprzedaży
Zgodnie z art. 106e ust. 1 pkt 7 ustawy faktura powinna zawierać między innymi nazwę (rodzaj)
towaru lub usługi. Informacje w tym zakresie uwzględnia się w strukturze FA(3) w polu P_7,
znajdującym się w części FaWiersz. Maksymalna ilość znaków w polu P_7 wynosi 512.
Biorąc pod uwagę różnorodność transakcji mogących wystąpić w obrocie gospodarczym, w
strukturze e-Faktury przewidziano kilka dodatkowych pól, w których można zawrzeć
dodatkowe dane dotyczące dostarczanego towaru lub świadczonej usługi.
Są to pola fakultatywne znajdujące się na poziomie wiersza faktury tj.:
▪ Indeks - pole przeznaczone jest do wpisania wewnętrznego kodu towaru lub usługi
nadanego przez podatnika albo dodatkowego opisu towaru lub usługi, składające się
maksymalnie z 50 znaków,
▪ GTIN - Globalny numer jednostki handlowej, pole składające się maksymalnie z 20
znaków,
▪ PKWiU - symbol Polskiej Klasyfikacji Wyrobów i Usług, pole składające się
maksymalnie z 50 znaków,
▪ CN - symbol Nomenklatury Scalonej, pole składające się maksymalnie z 50 znaków,
▪ PKOB – symbol Polskiej Klasyfikacji Obiektów Budowlanych, pole składające się
maksymalnie z 50 znaków.
Struktura logiczna e-Faktury przewiduje również pole DodatkowyOpis (w części Fa),
przeznaczone dla wykazywania dodatkowych danych na fakturze, w tym wymaganych
przepisami prawa, dla których nie przewidziano innych pól/elementów.
Warto zwrócić uwagę, że element DodatkowyOpis to:
▪ typ złożony z:
30

---

o pola NrWiersza, w którym podatnik może wskazać numer wiersza faktury,
którego dotyczy dana informacja (w przypadku braku wypełnienia pola
NrWiersza uznaje się, że podawana informacja dotyczy całej faktury, a nie danej
pozycji faktury),
o pola Klucz, w którym podatnik wskazuje nazwę pola,
o pola Wartosc, w którym podatnik wskazuje zawartość pola.
▪ element, który może wystąpić w fakturze maksymalnie 10000 razy.
Schemat 7. Element DodatkowyOpis w strukturze FA(3).
Powyższa konstrukcja umożliwia podatnikom zawarcie na fakturze wszelkich dodatkowych
danych, w tym specyficznych dla danej branży. W szczególności pole może być
wykorzystywane przy wystawianiu faktur za dostawę mediów czy usługi telekomunikacyjne, w
celu przedstawienia informacji o zużyciu, numerze licznika, adresie punktu poboru itp. (gdy
podatnik nie wykazuje tych danych w elemencie Zalacznik).
2.4. Faktura dokumentująca sprzedaż zwolnioną od podatku
Zgodnie z art. 106e ust. 4 pkt 3 ustawy, faktura w przypadku, o którym mowa w art. 106b ust. 3
pkt 2 ustawy nie zawiera danych określonych w art. 106e ust. 1 pkt 12-14 ustawy. Jeżeli więc
faktura dokumentuje sprzedaż zwolnioną od podatku na podstawie art. 43 ust. 1, art. 113 ust. 1
i 9 ustawy lub przepisów wydanych na podstawie art. 82 ust. 3 ustawy, to nie zawiera:
• stawki podatku,
• sumy wartości sprzedaży netto, z podziałem na sprzedaż objętą poszczególnymi
stawkami podatku i sprzedaż zwolnioną od podatku,
• kwoty podatku od sumy wartości sprzedaży netto, z podziałem na kwoty dotyczące
poszczególnych stawek podatku.
31

---

W strukturze e-Faktury przewidziano jednak pole P_13_7 (element Fa), w którym można
uwzględnić sumę wartości sprzedaży zwolnionej od podatku. Z kolei w elemencie FaWiersz w
polu P_12 (stawka podatku) możliwe jest wskazanie oznaczenia „zw”. Wypełnienie powyższych
danych w fakturze nie jest obowiązkowe, ale jest zalecane.
Warto również zwrócić uwagę, że struktura logiczna e-Faktury zawiera w swojej konstrukcji
część Fa/Adnotacje, która umożliwia podanie podstawy prawnej zastosowanego zwolnienia od
podatku:
• w polu P_19A – wskazuje się przepis ustawy albo aktu wydanego na podstawie ustawy,
na podstawie którego podatnik stosuje zwolnienie od podatku (np. „art. 43 ust. 1 pkt 10
ustawy o podatku od towarów i usług”),
• w polu P_19B - wskazuje się przepis dyrektywy 2006/112/WE, który zwalnia od podatku
taką dostawę towarów lub takie świadczenie usług,
• w polu P_19C - podaje się inną podstawę prawną wskazującą na to, że dostawa towarów
lub świadczenie usług korzysta ze zwolnienia od podatku.
WAŻNE
Struktura logiczna umożliwia wypełnienie tylko jednego z ww. pól. W przypadku więc, gdyby
faktura dokumentowała sprzedaż objętą dwoma różnymi podstawami zwolnienia (np.
jednocześnie na podstawie ustawy oraz dyrektywy), wówczas w takiej sytuacji można opisać te
podstawy prawne łącznie, w jednym z ww. pól. Każde z pól P_19A, P_19B, P_19C zawiera maks.
256 znaków, więc ich długość umożliwia ten sposób prezentacji danych.
2.5. Faktura walutowa
Struktura logiczna FA(3) umożliwia podatnikom wystawianie faktur w walucie obcej.
Zgodnie z art. 106e ust. 11 ustawy kwoty podatku wykazuje się w złotych. Kwoty podatku
wyrażone w walucie obcej wykazuje się w złotych przy zastosowaniu zasad przeliczania na
złote, przyjętych dla przeliczania kwot stosowanych do określenia podstawy opodatkowania.
Wystawiając fakturę w walucie obcej, podatnik powinien:
• w polu KodWaluty – wpisać kod waluty (ISO 4217) np. „EUR”,
• w przypadku sprzedaży w stawce 23% - wpisać w polach P_13_1 (suma wartości
sprzedaży netto w przypadku stawki 23%) i P_14_1 (kwota podatku od sumy wartości
sprzedaży netto w stawce 23%) kwoty określone w walucie obcej, a w polu P_14_1W
kwotę podatku od sumy wartości netto, przeliczoną na polskie złote,
32

---

• w przypadku sprzedaży w stawce 8% - wpisać w polach P_13_2 (suma wartości
sprzedaży netto w przypadku stawki 8%) i P_14_2 (kwota podatku od sumy wartości
sprzedaży netto w stawce 8%) kwoty określone w walucie obcej, a w polu P_14_2W
kwotę podatku od sumy wartości netto, przeliczoną na polskie złote,
• w przypadku sprzedaży w stawce 5% - wpisać w polach P_13_3 (suma wartości
sprzedaży netto w przypadku stawki 5%) i P_14_3 (kwota podatku od sumy wartości
sprzedaży netto w stawce 5%) kwoty określone w walucie obcej, a w polu P_14_3W
kwotę podatku od sumy wartości netto, przeliczoną na polskie złote,
• w przypadku sprzedaży objętej ryczałtem dla taksówek osobowych - wpisać w polach
P_13_4 (suma wartości sprzedaży netto objętej ryczałtem dla taksówek osobowych) i
P_14_4 (kwota podatku od sumy wartości sprzedaży netto objętej ryczałtem dla
taksówek osobowych) kwoty określone w walucie obcej, a w polu P_14_4W kwotę
podatku od sumy wartości netto, przeliczoną na polskie złote.
Zatem w takiej fakturze kwoty określone są wyłącznie w walucie obcej i jedynie kwota podatku
w polu P_14_xW przeliczona jest na polskie złote, zgodnie z art. 106e ust. 11 ustawy.
Dodatkowo, na fakturze możliwe jest wskazanie kursu waluty właściwego dla danej pozycji
faktury. Służy do tego pole FaWiersz/KursWaluty, a w przypadku faktur zaliczkowych pole
Fa/KursWalutyZ lub Fa/ZaliczkaCzesciowa/KursWalutyZW (w przypadku faktury
dokumentującej np. kilka otrzymanych zaliczek). Każde z ww. pól może zawierać maksymalnie
6 miejsc po kropce.
Przykładowy plik e-Faktury dotyczący faktury walutowej można znaleźć pod adresem:
https://www.gov.pl/web/kas/krajowy-system-e-faktur (dokument: „Przykładowe pliki dla
struktury logicznej e-Faktury FA(3)”, przykład nr 20 i 21.)
2.6. Faktura zaliczkowa
Zgodnie z obowiązującymi przepisami faktura, o której mowa w art. 106b ust. 1 pkt 4 ustawy,
dokumentująca otrzymanie przez podatnika całości lub części zapłaty przed dokonaniem
czynności powinna zawierać:
1) dane, o których mowa w art. 106e ust. 1 pkt 1-6 ustawy,
2) otrzymaną kwotę zapłaty,
3) kwotę podatku wyliczoną według wzoru:
33

---

ZB x SP
KP = ────────
100 + SP
gdzie:
KP - oznacza kwotę podatku,
ZB - oznacza kwotę otrzymanej całości lub części zapłaty,
SP - oznacza stawkę podatku,
4) dane dotyczące zamówienia lub umowy, a w szczególności: nazwę (rodzaj) towaru lub usługi,
ilość zamówionych towarów, wartość zamówionych towarów lub usług bez kwoty podatku,
stawki podatku, kwoty podatku oraz wartość zamówienia lub umowy z uwzględnieniem kwoty
podatku.
Struktura logiczna e-Faktury umożliwia wystawienie m.in. faktury zaliczkowej.
Charakterystyczne elementy tego typu dokumentu (poza podstawowymi jej danymi) to w
szczególności:
• data otrzymania całości lub części zapłaty przed wykonaniem usługi lub dokonaniem
dostawy towarów (o ile taka data jest określona i różni się od daty wystawienia faktury)
– ujęta w polu P_6 lub
• daty otrzymania całości lub części zapłaty przed wykonaniem usługi lub dokonaniem
dostawy towarów – ujęte w elemencie ZaliczkaCzesciowa (który może wystąpić w
strukturze maksymalnie 31 razy) i dotyczy wyłącznie sytuacji, gdy:
o jedna faktura dokumentuje otrzymanie więcej niż jednej zaliczki – wtedy w
przypadku dokumentowania np. dwóch zaliczek jedną fakturą zaliczkową,
element zostanie wypełniony dwa razy (data otrzymania danej zapłaty zostanie
wskazana w polu P_6Z, a kwota zapłaty kwoty w polu P_15Z; fakultatywnie
można wypełnić także pole KursWalutyZW (kurs waluty stosowany do
wyliczenia kwoty podatku, w przypadku, gdy otrzymano zaliczkę w walucie
obcej),
o faktury, o której mowa w art. 106e ust. 1a ustawy (tj., gdy zaliczka oraz
usługa/dostawa miały miejsce w tym samym miesiącu i podatnik zdecydował, iż
34

---

nie wystawia odrębnej faktury zaliczkowej, a w fakturze dokumentującej
usługę/dostawę będą podawane dane dot. otrzymanej zapłaty),
• w polu RodzajFaktury wskazane oznaczenie „ZAL” (faktura dokumentująca otrzymanie
zapłaty lub jej części przed dokonaniem czynności oraz faktura wystawiona w związku z
art. 106f ust. 4 ustawy - tj. faktura zaliczkowa),
• wypełnione pola dotyczące podsumowania podstawy opodatkowania oraz kwot
podatku w zależności od właściwej stawki podatku, w odniesieniu do kwoty otrzymanej
zaliczki (P_13_1, P_14_1, P_14_1W, P_13_2, P_14_2, P_14_2W itp.),
• kwota należności ogółem (kwota otrzymanej zapłaty , czyli wartość zaliczki)
dokumentowana fakturą, wskazana w polu P_15 (jeżeli faktura dokumentuje kilka
zaliczek to pole P_15 obejmuje sumę pól P_15Z),
• wypełniony element FakturaZaliczkowa (w przypadku, gdy wystawiono więcej niż
jedną fakturę dokumentującą otrzymanie części zapłaty, a faktury te obejmują łącznie
całą zapłatę, ostatnia z tych faktur powinna zawierać dane wcześniej wystawionych
faktur zaliczkowych),
• wypełniony element Zamowienie,
• pominięty element FaWiersz.
Przykładowy plik e-Faktury dokumentującej otrzymanie części zapłaty przed wykonaniem
czynności można znaleźć pod adresem: https://www.gov.pl/web/kas/krajowy-system-e-faktur
(dokument: „Przykładowe pliki dla struktury logicznej e-Faktury FA(3)”, przykład nr 10).
2.7. Faktura rozliczająca
Struktura logiczna e-Faktury umożliwia wystawienie m.in. faktury rozliczającej.
Charakterystyczne elementy tego typu dokumentu (poza podstawowymi danymi faktury) to w
szczególności:
• w polu RodzajFaktury wskazane oznaczenie „ROZ” (faktura wystawiona w związku z
art. 106f ust. 3 ustawy- tj. faktura rozliczająca),
• wypełnione pola dotyczące podsumowania podstawy opodatkowania oraz kwot
podatku w zależności od właściwej stawki podatku (P_13_1, P_14_1, P_14_1W, P_13_2,
P_14_2, P_14_2W itp.), odnoszące się wyłącznie do kwoty pozostałej do zapłaty (czyli
kwoty zapłaty końcowej), ponieważ w fakturze wystawianej po wydaniu towaru lub
wykonaniu usługi sumę wartości towarów lub usług pomniejsza się o wartość
35

---

otrzymanych części zapłaty, a kwotę podatku pomniejsza się o sumę kwot podatku
wykazanego w fakturach dokumentujących otrzymanie części zapłaty,
• kwota należności ogółem (kwota pozostała do zapłaty) ujęta w polu P_15,
• wypełniona sekcja ZaliczkaCzesciowa, w której wskazuje się dane dotyczące
otrzymanej zaliczki, w przypadku faktury, o której mowa w art. 106e ust. 1a ustawy (tj.
faktury rozliczającej, wystawianej po wydaniu towaru lub wykonaniu usługi, w
przypadku, gdy zgodnie z art. 106b ust. 1a ustawy, gdy podatnik nie wystawił faktury
zaliczkowej),
• wypełniony element FakturaZaliczkowa (jeżeli wystawiona wcześniej faktura
zaliczkowa nie obejmuje całej zapłaty, faktura rozliczająca, powinna również zawierać
numery identyfikujące w KSeF faktury wystawione przed wydaniem towaru lub
wykonaniem usługi, a w przypadku faktur innych niż faktury ustrukturyzowane -
numery tych faktur),
• pominięty element Zamowienie,
• wypełniony element FaWiersz (zawierający pełne wartości dotyczące przedmiotu
transakcji).
Przykładowy plik faktury rozliczającej można znaleźć pod adresem:
https://www.gov.pl/web/kas/krajowy-system-e-faktur (dokument: „Przykładowe pliki dla
struktury logicznej e-Faktury FA(3)”, przykład nr 14 i nr 17).
2.8. Faktura końcowa „zerowa”
W przypadku, gdy podatnik otrzymał 100% zapłaty na poczet dostawy towarów lub
świadczenia usługi oraz wystawił w związku z tym fakturę zaliczkową, podatnik ten nie ma
obowiązku wystawienia po wydaniu towaru lub wykonaniu usługi faktury rozliczającej
(końcowej). Obowiązujące przepisy prawa podatkowego nie zabraniają jednak wystawiania
faktur końcowych, które są dodatkowym dowodem potwierdzającym dokonanie sprzedaży, i z
których wynikać będzie, że należność w całości została uregulowana. Jeżeli podatnik wystawi
fakturę końcową w momencie wydania towaru lub wykonania usługi, gdy wcześniej do danej
transakcji wystawił fakturę zaliczkową (100%), w takiej fakturze rozliczającej powinien zostać
"wyzerowany podatek". Dodatkowo, taka faktura powinna zawierać numer faktury
wystawionej przed dokonaniem dostawy lub wykonaniem usługi (numer faktury zaliczkowej).
Przekładając powyższe założenia na rozwiązania przewidziane w strukturze FA(3),
wystawiając fakturę rozliczającą „zerową” podatnik:
36

---

• w części Fa:
o w polu RodzajFaktury zastosuje oznaczenie „ROZ”,
o w polu P_15 (kwota należności ogółem wynikająca z faktury) wskaże „0”,
o w części FakturaZaliczkowa ujmie numer faktury zaliczkowej oraz znacznik
faktury zaliczkowej wystawionej poza KSeF lub numer KSeF faktury zaliczkowej
(jeśli była wystawiona w KSeF),
• w części FaWiersz wskaże pełne wartości dotyczące przedmiotu transakcji (w
szczególności cenę jednostkową netto/brutto i wartość sprzedaży netto/brutto)
• pominie element Zamowienie.
2.9. Faktura VAT marża
Konstrukcja struktury FA(3) umożliwia również wystawianie przez podatnika faktur
dokumentujących sprzedaż dokonywaną w ramach procedury VAT marża, dotyczących:
• świadczenia usług turystyki,
• dostawy towarów używanych,
• dostawy dzieł sztuki,
• dostawy przedmiotów kolekcjonerskich i antyków.
W myśl art. 106e ust. 2 ustawy, w przypadku świadczenia usług turystyki, dla których podstawę
opodatkowania stanowi kwota marży, faktura:
• w zakresie danych określonych w art. 106e ust. 1 pkt 1-17 ustawy - powinna zawierać
wyłącznie dane określone w ust. 1 pkt 1-8 i 15-17 ustawy oraz
• wyrazy „procedura marży dla biur podróży”.
Zgodnie z art. 106e ust. 3 ustawy, w przypadku dostawy towarów używanych, dzieł sztuki,
przedmiotów kolekcjonerskich i antyków, dla których podstawę opodatkowania stanowi
marża, faktura:
• w zakresie danych określonych w art. 106e ust. ust. 1 pkt 1-17 ustawy - powinna
zawierać wyłącznie dane określone w ust. 1 pkt 1-8 i 15-17 ustawy, a także
• wyrazy „procedura marży - towary używane”, „procedura marży - dzieła sztuki” lub
„procedura marży - przedmioty kolekcjonerskie i antyki”.
37

---

Faktura dokumentująca sprzedaż w procedurze VAT marża nie zawiera zatem m.in. ceny
jednostkowej towaru lub usługi bez kwoty podatku (ceny jednostkowej netto), wartości
dostarczonych towarów lub wykonanych usług objętych transakcją, bez kwoty podatku
(wartości sprzedaży netto), stawki podatku, sumy wartości sprzedaży netto w podziale na
sprzedaż objętą poszczególnymi stawkami podatku i sprzedaż zwolnioną od podatku i kwoty
podatku od sumy wartości sprzedaży netto, z podziałem na kwoty dotyczące poszczególnych
stawek podatku.
Biorąc pod uwagę budowę struktury FA(3), podatnik wystawiając fakturę w procedurze VAT
marża w części Fa:
• w polu P_13_11 – może wskazać sumę wartości sprzedaży w procedurze marży, o
której mowa w art. 119 i art. 120 ustawy (postępowanie zalecane),
• w polu P_15 – uwzględnia kwotę należności ogółem na fakturze,
• w elemencie Adnotacje deklaruje, że sprzedaż nastąpiła w procedurze VAT marża
(znacznik „1” w polu P_PMarzy) oraz wskazuje „1” w polu :
o P_PMarzy_2 - w przypadku świadczenia usług turystyki, dla których podstawę
opodatkowania stanowi marża, aby faktura dokumentująca świadczenie
zawierała wyrazy "procedura marży dla biur podróży",
o P_PMarzy_3_1 – w przypadku dostawy towarów używanych, dla których
podstawę opodatkowania stanowi marża, aby faktura dokumentująca dostawę
zawierała wyrazy "procedura marży - towary używane",
o P_PMarzy_3_2 – w przypadku dostawy dzieł sztuki, dla których podstawę
opodatkowania stanowi marża, aby faktura dokumentująca dostawę zawierała
wyrazy "procedura marży - dzieła sztuki"
o P_PMarzy_3_3 – w przypadku dostawy przedmiotów kolekcjonerskich i
antyków, dla których podstawę opodatkowania stanowi marża, aby faktura
dokumentująca dostawę zawiera wyrazy "procedura marży - przedmioty
kolekcjonerskie i antyki",
• w elemencie FaWiersz może wskazać cenę jednostkową towaru lub usługi oraz wartość
sprzedaży.
38

---

Przykładowy plik e-Faktury dotyczący sprzedaży w procedurze VAT marża można znaleźć pod
adresem: https://www.gov.pl/web/kas/krajowy-system-e-faktur (dokument: „Przykładowe
pliki dla struktury logicznej e-Faktury FA(3)”, przykład nr 8).
2.10. Faktura uproszczona do 450 zł
Struktura faktury ustrukturyzowanej FA(3) jest dostosowana także do wystawiania faktur, o
których mowa w art. 106e ust. 5 pkt 3 ustawy.
W przypadku faktury, w której kwota należności ogółem nie przekracza kwoty 450 zł albo
kwoty 100 euro, jeżeli kwota ta określona jest w euro, faktura może nie zawierać:
• danych określonych w art. 106e ust. 1 pkt 3 dotyczących nabywcy oraz
• danych określonych w art. 106e ust. 1 pkt 8, 9 i 11-14 ustawy, pod warunkiem, że
zawiera dane pozwalające określić dla poszczególnych stawek podatku kwotę
podatku.
Wystawiając tego typu fakturę podatnik:
• w części Podmiot2 (dotyczącej danych nabywcy) może wskazać tylko NIP nabywcy (nie
ma obowiązku wskazywania jego imienia, nazwiska lub nazwy oraz adresu),
• w polu RodzajFaktury wskazuje „UPR”,
• SPOSÓB I
o w części Fa wypełnia pola (w zależności od stawki P_13_1, P_14_1, P_14_1W;
P_13_2, P_14_2, P_14_2W itd.) i wskazuje kwotę należności ogółem w polu P_15,
o w części FaWiersz w polu P_7 wskazuje nazwę towaru lub usługi, ale nie
wypełnia pozostałych pól dotyczących wiersza faktury, w tym pola P_12
(ponieważ dzięki wcześniejszemu wypełnieniu pól - w zależności od stawki
P_13_1, P_14_1, P_14_1W; P_13_2, P_14_2, P_14_2W itd.- możliwe jest
wyliczenie kwoty podatku danej stawki);
• SPOSÓB II
o w części Fa nie wypełnia pól P_13_1, P_14_1, P_14_1W; P_13_2, P_14_2,
P_14_2W (itd.), ale wskazuje kwotę należności ogółem w polu P_15,
o w części FaWiersz w polu P_7 wskazuje nazwę towaru lub usługi, a w polu P_12
określa właściwą stawkę podatku (dzięki temu możliwe jest wyliczenie kwoty
podatku dla tej stawki).
39

---

• w przypadku, gdyby faktura zawierała wiersze według różnych stawek podatku i miała
przy tym nie zawierać danych w polach P_13_1, P_14_1, P_14_1W; P_13_2, P_14_2,
P_14_2W (itd.), dla spełnienia wymogu ustawowego musiałaby dodatkowo zawierać
kwoty w polach P_11 lub P_11A.
Należy zwrócić uwagę, że w Aplikacji Podatnika KSeF nie jest przewidziana funkcjonalność
polegająca na wystawieniu faktury uproszczonej do 450 zł, o której mowa w art. 106e ust. 5 pkt
3 ustawy.
Przykładowe pliki e-Faktur dotyczących faktur uproszczonych do 450 zł można znaleźć pod
adresem: https://www.gov.pl/web/kas/krajowy-system-e-faktur (dokument: „Przykładowe
pliki dla struktury logicznej e-Faktury FA(3)”, przykład nr 15 i nr 16).
2.11. Faktura dokumentująca WDT i eksport towarów
W KSeF można wystawić m.in. faktury dokumentujące transakcje tj. WDT i eksport towarów.
Warto zwrócić więc uwagę, na cechy charakterystyczne faktur dokumentujących tego typu
czynności.
Faktura dokumentująca eksport towarów:
• zawiera w danych sprzedawcy (Podmiot1) m.in. numer, za pomocą którego podatnik
jest zidentyfikowany na potrzeby podatku (pole NIP),
• może zawierać w danych nabywcy (Podmiot2) m.in. identyfikator podatkowy nabywcy
i kod kraju nadania tego identyfikatora (pola KodKraju i NrID),
• zawiera w polu P_13_6_3 sumę wartości sprzedaży objętej stawką 0% (eksport),
• zawiera w polu P_12 (na poziomie wiersza faktury) – oznaczenie stawki podatku 0% dla
eksportu towarów: „0 EX”.
Faktura dokumentująca wewnątrzwspólnotową dostawę towarów:
• zawiera w danych sprzedawcy (Podmiot1) m.in. numer, za pomocą którego podatnik
jest zidentyfikowany na potrzeby podatku (pole NIP), poprzedzony kodem PL (pole
PrefiksPodatnika),
• zawiera w danych nabywcy (Podmiot2) m.in. numer, za pomocą którego nabywca
towaru jest zidentyfikowany na potrzeby podatku od wartości dodanej w danym
państwie członkowskim oraz dwuliterowy kod stosowany na potrzeby podatku od
wartości dodanej właściwy dla tego państwa członkowskiego (pola KodUE oraz
NrVatUE),
40

---

• zawiera w polu P_13_6_2 sumę wartości sprzedaży objętej stawką 0% (WDT),
• zawiera w polu P_12 (na poziomie wiersza faktury) – oznaczenie stawki podatku 0% dla
wewnątrzwspólnotowej dostawy towarów: „0 WDT”.
Przykładowe pliki faktur korygujących można znaleźć pod adresem:
https://www.gov.pl/web/kas/krajowy-system-e-faktur/ (dokument: „Przykładowe pliki dla
struktury logicznej e-Faktury FA(3)”, przykład nr 22, nr 23).
2.12. Faktura wystawiona w procedurze samofakturowania
Informacje na temat wypełnienia struktury logicznej FA(3) w przypadku samofakturowania
zostały zawarte w cz. III Podręcznika KSeF 2.0.
2.13. Faktury korygujące
2.13.1. Cechy charakterystyczne faktury korygującej
Wystawiając fakturę korygującą, warto zwrócić uwagę na pola struktury FA(3),
charakterystyczne dla tego typu dokumentów. Należą do nich w szczególności pola:
• RodzajFaktury:
o „KOR” - oznaczenie wskazywane, jeżeli wystawiana jest faktura korygująca do
faktury podstawowej lub uproszczonej,
o „KOR_ZAL” - oznaczenie wskazywane, jeśli wystawiana jest faktura korygująca
do faktury zaliczkowej,
o „KOR_ROZ” - oznaczenie wskazywane w przypadku faktury korygującej do
faktury rozliczającej.
• PrzyczynaKorekty, które pozwala na opisanie przyczyny wystawienia faktury
korygującej (obecnie podawanie przyczyny korekty nie jest obowiązkowe),
• TypKorekty, w którym można podać typ skutku korekty w ewidencji VAT, jest to pole
nieobowiązkowe, które może przyjmować jedną z trzech wartości:
o „1” - korekta skutkująca w dacie ujęcia faktury pierwotnej,
o „2” - korekta skutkująca w dacie wystawienia faktury korygującej,
o „3” - korekta skutkująca w dacie innej, w tym, gdy dla różnych pozycji faktury
korygującej daty te są różne.
41

---

• NrFaKorygowany, w którym podaje poprawny numer faktury korygowanej w
przypadku, gdy przyczyną korekty jest błędny numer faktury korygowanej; pole
wypełniane jest w szczególnym przypadku, gdy przyczyną korekty jest nadanie przez
podatnika fakturze pierwotnej błędnego numeru (w takim przypadku błędny numer
faktury podaje się w fakturze korygującej w polu NrFaKorygowanej).
• DaneFaKorygowanej – zawiera dane dotyczące faktury korygowanej/faktur
korygowanych (m.in. tj. numer faktury, numer KSeF faktury, data wystawienia); element
ten może wystąpić wielokrotnie (do 50 000 razy), ponieważ jedną fakturą korygującą
można korygować wiele faktur pierwotnych (tzw. korekty zbiorcze).
• P_15ZK - które można wypełnić w przypadku:
o korekt faktur zaliczkowych (pole zawiera kwotę zapłaty przed korektą),
o korekt faktur rozliczających (pole zawiera kwotę pozostałą do zapłaty przed
korektą).
• KursWalutyZK to kurs waluty stosowany do wyliczenia kwoty podatku w przypadkach,
o których mowa w Dziale VI ustawy przed korektą. Pole dedykowane jest dla faktur
korygujących faktury zaliczkowe, wystawianych w walucie obcej (w przypadku korekt
faktur podstawowych i rozliczających kursy walut przed korektą mogą być podawane
na wierszach dotyczących stanu przed korektą).
2.13.2. Prezentowanie „różnic” w fakturach korygujących
Zgodnie z art. 106j ust. 2 pkt 5 ustawy, jeżeli faktura korygująca wpływa na zmianę podstawy
opodatkowania lub kwoty podatku należnego – powinna zawierać odpowiednio kwotę korekty
podstawy opodatkowania lub kwotę korekty podatku należnego z podziałem na kwoty
dotyczące poszczególnych stawek podatku i sprzedaży zwolnionej.
W fakturach korygujących, kwoty zawarte w polach, w zależności od stawki P_13_1, P_14_1,
P_14_1W; P_13_2, P_14_2, P_14_2W (itd.), P_15, czyli tzw. podsumowanie faktury obejmujące
kwoty podstaw opodatkowania i podatku w podziale na stawki oraz kwotę należności ogółem
wypełniane są przez różnicę w stosunku do kwoty zawartej w fakturze pierwotnej.
Przykładowo:
• podatnik wystawił fakturę na 2000 zł netto (pole P_13_1=2000), 460 zł VAT (pole
P_14_1=460), brutto 2460 zł (pole P_15=2460),
42

---

• następnie podatnik zorientował się, że popełnił błąd, w związku z czym wystawił
fakturę korygującą na -200 zł netto, ponieważ transakcja miała mieć wartość 1800 zł
netto; zapis na fakturze korygującej powinien odnosić się do różnicy w kwocie
podstawy opodatkowania, kwocie podatku oraz kwocie należności ogółem tj. pole
P_13_1 = -200, pole P_14_1= -46, pole P_15= -246).
Jest to ogólna zasada obowiązująca we wszystkich typach faktur korygujących, czyli może też
dotyczyć np. korekty błędnie zafakturowanej wysokości otrzymanej zaliczki.
2.13.3. Wystawienie kilku faktur korygujących do jednej faktury pierwotnej
Może zdarzyć się sytuacja, gdy podatnik wystawi fakturę pierwotną, następnie wystawi do niej
fakturę korygującą podstawę opodatkowania i kwotę podatku, a po pewnym czasie wystawi
kolejną fakturę korygującą podstawę opodatkowania i kwotę podatku. W przypadku
wystawiania kolejnych faktur korygujących do faktury pierwotnej, skutkujących zmianą
wartości podstawy opodatkowania i podatku, w sytuacji, gdy wcześniejsza korekta już na te
wartości wpływała należy odnosić się zawsze do wartości uwzględniających wcześniej
wystawioną fakturę korygującą. W sekcji DaneFaKorygowanej należy podawać natomiast dane
(m.in. numer, numer KSeF, jeśli faktura pierwotna była wystawiona w KSeF, datę wystawienia)
faktury pierwotnej. W fakturze korygującej nie jest konieczne podawanie danych (numerów,
dat wystawienia) wcześniej wystawionych faktur korygujących.
Przykładowo:
• podatnik wystawił fakturę na 1000 zł netto (pole P_13_1=1000), 230 zł VAT (pole
P_14_1=230), brutto 1230 zł (pole P_15=1230),
• następnie wystawił fakturę korygującą na -100 zł netto, ponieważ transakcja miała
mieć wartość 900 zł netto (pole P_13_1 = -100, pole P_14_1= -23, pole P_15= -123),
• następnie wystawił kolejną fakturę korygującą na -200 zł netto, ponieważ zorientował
się, że faktura nadal zawiera błąd, gdyż transakcja ostatecznie miała mieć wartość 700
zł netto (zapis w fakturze korygującej: pole P_13_1 = -200, pole P_14_1= -46, pole
P_15= -246).
W drugiej fakturze korygującej podatnik powinien odnieść się więc do kwot, uwzględniających
wcześniej wystawioną fakturę korygującą. Po pierwszej korekcie faktura opiewała na kwotę
900 zł netto, 207 zł VAT, 1107 zł brutto. W stosunku do docelowych, poprawnych wartości
(700 zł netto, 161 zł VAT, 861 zł brutto) w drugiej fakturze korygującej właściwe było
wskazanie więc zapisu: -200 zł netto, -46 zł VAT, - 246 zł brutto.
43

---

2.13.4. Zasady korygowania wierszy (pozycji) faktury
W przypadku korygowania danych kwotowych zawartych w poszczególnych pozycjach
(wierszach) faktury, względnie pozycji (wierszy) zamówienia faktury zaliczkowej stosowane
mogą być trzy metody.
• Korygowanie przez różnicę
W takim przypadku jednemu wierszowi faktury korygowanej odpowiada jeden wiersz na
fakturze korygującej. Kwota wynikająca z takiego wiersza jest kwotą różnicy w stosunku do
wartości zawartej w fakturze pierwotnej. Przykładem takiego sposobu korygowania jest
całkowity zwrot towaru, gdzie ujemna wartość wiersza zeruje wartość wykazaną w fakturze
pierwotnej.
• Korygowanie z wykorzystaniem znacznika StanPrzed
Powyższa metoda umożliwia czytelną prezentację danych dla każdego przypadku korekty.
Zalecana jest szczególnie w przypadku całkowitej zmiany stawki VAT lub zmiany kursów walut.
W takim przypadku jednemu wierszowi faktury korygowanej odpowiadają dwa wiersze faktury
korygującej. Pierwszy z wierszy zawiera dane w stanie przed korektą i opatrywany jest
znacznikiem StanPrzed. Jest to osobne pole w wierszu przyjmujące w takim przypadku wartość
„1”. Drugi z wierszy zawiera prawidłowe dane po korekcie.
Na potrzeby obliczania kwot podsumowania wartość wiersza oznaczonego znacznikiem
StanPrzed przyjmuje znak przeciwny (tzn., że dodatnie wartości „stanu przed” są traktowane
jako ujemne). Wiersze dla „stanu przed” i „stanu po” posiadają odrębną numerację.
• Korygowanie poprzez storna
Jest to metoda podobna do metody wykorzystującej znacznik StanPrzed, ale zamiast jego
stosowania wiersz odnoszący się do stanu przed korektą prezentowany jest ze znakiem
przeciwnym. Wiersz faktury pierwotnej (o wartości dodatniej) prezentowany jest w fakturze
korygującej z wartością ujemną. W celu jej uzyskania prezentuje się ujemną ilość lub ujemną
cenę jednostkową.
Ponadto, wystawiając fakturę korygującą podatnik może wykorzystać pole „UU_ID” -
uniwersalny unikalny numer wiersza faktury. Funkcjonalność tego pola umożliwia
jednoznaczne powiązanie wiersza faktury korygującej z wierszem faktury korygowanej, pod
warunkiem, że numer ten nadawany jest wierszowi już w fakturze pierwotnej. Wykorzystanie
tego pola umożliwia łatwe korygowanie np. błędu w nazwie towaru, zawartej w fakturze
korygowanej, poprzez podanie w wierszu faktury korygującej m.in. tego numeru. Niezbędne
44

---

jest zapewnienie unikalności numeru wiersza w ramach wszystkich faktur danego podatnika
lub wszystkich faktur danego podatnika w danym systemie do fakturowania. Wykorzystanie tej
funkcjonalności jest dobrowolne.
Przykładowe pliki faktur korygujących można znaleźć pod adresem:
https://www.gov.pl/web/kas/krajowy-system-e-faktur (dokument: „Przykładowe pliki dla
struktury logicznej e-Faktury FA(3)”, przykład nr 2, nr 3).
2.13.5 Faktura korygująca fakturę zaliczkową i fakturę rozliczającą
W przypadku faktur korygujących faktury zaliczkowe i faktur korygujących faktury
rozliczające, nawet jeśli korekta nie dotyczy wartości zamówienia i jednocześnie zmienia
wysokość podstawy opodatkowania lub podatku, zaleca się wprowadzenie zapisu wg stanu
przed korektą i zapisu w stanie po korekcie - w części Zamowienie (w przypadku faktury
korygującej fakturę zaliczkową) lub w części FaWiersz (w przypadku faktury korygującej
fakturę rozliczającą) - w celu potwierdzenia braku zmiany wartości danej pozycji faktury.
Dotyczy to np. przypadku, gdy przyczyną korekty jest błędnie zafakturowana wartość zaliczki
mimo braku zmiany poszczególnych pozycji zamówienia. W polu P_15 należy wówczas wskazać
kwotę różnicy wartości zaliczki w stosunku do faktury pierwotnej.
W fakturach zaliczkowych występuje pole WartoscZamowienia (wartość zamówienia lub
umowy z uwzględnieniem kwoty podatku). Powinna ona odpowiadać sumie wartości brutto
poszczególnych wierszy zamówienia. W przypadku, gdy faktura korygująca dotyczy korekty
wartości zamówienia, pole to powinno zawierać prawidłową wartość zamówienia w stanie po
korekcie, zatem powinno odpowiadać sumie wartości brutto poszczególnych wierszy
zamówienia w stanie po korekcie.
Przykładowe pliki e-Faktur dotyczących faktury korygującej do faktury zaliczkowej i
rozliczającej można znaleźć pod adresem: https://www.gov.pl/web/kas/krajowy-system-e-
faktur (dokument: „Przykładowe pliki dla struktury logicznej e-Faktury FA(3)”, przykład nr 12 i
nr 18).
2.13.6. Faktury korygowane wystawione w KSeF i poza KSeF
Struktura FA(3) zawiera m.in. element DaneFaKorygowanej, który może wystąpić w fakturze
do 50 000 razy.
Dzięki budowie tego elementu możliwe jest wystawienie w KSeF zbiorczej faktury korygującej
(np. w przypadku udzielenia rabatu do wszystkich dostaw w danym okresie), odnoszącej się
jednocześnie do faktur pierwotnych wystawionych poza KSeF oraz faktur pierwotnych
45

---

wystawionych przy użyciu KSeF. Wówczas element DaneFaKorygowanej zostanie wypełniony
tyle razy, ile faktur pierwotnych jest korygowanych.
Schemat 8. Element DaneFaKorygowanej w strukturze logicznej FA(3).
Element DaneFaKorygowanej składa się z:
• pola DataWystFaKorygowanej - data wystawienia faktury korygowanej,
• pola NrFaKorygowanej - numer faktury korygowanej,
• sekwencji typu „choice” (wybór), w skład której wchodzi:
o sekwencja złożona z pól:
▪ NrKSeF - znacznik faktury korygowanej wystawionej w KSeF,
▪ NrKSeFFaKorygowanej - numer identyfikujący fakturę korygowaną w
KSeF,
o pole NrKSeFN - znacznik faktury korygowanej wystawionej poza KSeF.
W związku z tym, w przypadku wystawienia faktury korygującej zbiorczej:
• wskazując dane faktury pierwotnej wystawionej poza KSeF - podatnik wypełnia pola
DataWystFaKorygowanej, NrFaKorygowanej oraz wskazuje „1” w polu NrKSeFN
(potwierdzając, że faktura pierwotna jest fakturą wystawioną poza KSeF),
• wskazując dane faktury pierwotnej wystawionej przy użyciu KSeF - podatnik wypełnia
pola DataWystFaKorygowanej oraz NrFaKorygowanej. Dodatkowo w polu NrKSeF
wskazuje „1” (potwierdzając, że faktura pierwotna jest fakturą wystawioną przy użyciu
KSeF) oraz wypełnia pole NrKSeFFaKorygowanej.
Zakres pól wypełnianych w elemencie DaneFaKorygowanej zależy więc od tego, czy
wskazywane są dane faktury pierwotnej wystawionej w KSeF czy poza KSeF. Możliwa jest
46

---

sytuacja, w której jedna faktura korygująca zbiorcza będzie odnosiła się zarówno do faktur
pierwotnych wystawionych w KSeF jak i poza KSeF.
2.13.7. Faktura korygująca zbiorcza
W myśl art. 106j ust. 3 ustawy w przypadku, gdy podatnik udziela opustu lub obniżki ceny,
może wystawić fakturę korygującą dotyczącą dostaw towarów lub świadczenia usług na rzecz
jednego odbiorcy w danym okresie, która:
• zawiera dodatkowo wskazanie okresu, do którego odnoszą się udzielany opust lub
udzielana obniżka;
• może nie zawierać nazwy (rodzaju) towaru lub usługi objętych korektą - w przypadku,
gdy korekta dotyczy wszystkich dostaw towarów i świadczonych usług.
W KSeF możliwe jest wystawienie tego typu faktury korygującej.
Przykładowo, gdy korekta dotyczy wszystkich dostaw towarów i usług, podatnik:
• ujmie kwotę korekty podstawy opodatkowania (ze znakiem „-”) i kwotę korekty
podatku należnego z podziałem na kwoty dotyczące poszczególnych stawek podatku i
sprzedaży zwolnionej w polach P_13_1, P_14_1, P_14_1W; P_13_2, P_14_2, P_14_2W
(itp.),
• korektę kwot należności ogółem wynikających z faktur korygowanych wskaże w polu
P_15,
• zastosuje w polu RodzajFaktury oznaczenie „KOR”,
• fakultatywnie może uwzględnić przyczynę wystawienia faktury korygującej w polu
PrzyczynaKorekty, np. „rabat 5% w związku z osiągnięciem progu dokonanych
zakupów w II kwartale 2026 r.”,
• fakultatywnie może wskazać typ skutku korekty w ewidencji na cele podatku od
towarów i usług w polu TypKorekty,
• wskaże dane poszczególnych faktur korygowanych w elemencie DaneFaKorygowanej
(element ten może wystąpić w strukturze do 50 000 razy),
• uwzględni okres faktury korygowanej, do którego odnosi się udzielany opust lub
udzielana obniżka w polu OkresFaKorygowanej (pole tekstowe które może
przyjmować zarówno zakres dat jak i opis tekstowy, dotyczy wyłącznie faktur
korygujących, o których mowa w art. 106j ust. 3 ustawy),
• nie zawiera żadnych danych w części FaWiersz.
47

---

Jeżeli zbiorcza faktura korygująca dotyczy części dostaw towarów i świadczonych usług
na rzecz jednego odbiorcy w danym okresie, powinna zawierać dodatkowo nazwę (rodzaj)
towaru lub usługi objętych korektą w polu P_7 w części FaWiersz.
Przykładowe pliki e-Faktur korygujących zbiorczych (w sytuacji, gdy rabat dotyczy wszystkich
dostaw danego okresu oraz gdy rabat dotyczy części dostaw danego okresu) można znaleźć
pod adresem: https://www.gov.pl/web/kas/krajowy-system-e-faktur (dokument:
„Przykładowe pliki dla struktury logicznej e-Faktury FA(3)”, przykład nr 6 i nr 7).
WAŻNE
Fakturę korygującą zbiorczą można wystawić zarówno dla faktur korygujących „in minus” jak i
faktur korygujących „in plus”. Uproszczenia w zakresie obowiązkowych elementów faktury, o
których mowa w art. 106j ust. 3 ustawy wystąpią jednak wyłącznie w przypadku wystawienia
faktur korygujących „in minus”.
2.13.8. Podmiot1K i Podmiot2K w fakturze korygującej
Ważnymi elementami, w przypadku wystawiania faktur korygujących są sekcje Podmiot1K
oraz Podmiot2K.
W sekcji Podmiot1K podaje się dane identyfikacyjne i adresowe sprzedawcy, jeśli uległy one
zmianie, choćby częściowo w stosunku do danych zawartych w fakturze pierwotnej.
W takim przypadku w Podmiot1K należy podać pełne dane sprzedawcy występujące na
fakturze korygowanej (pierwotnej). Poprawne dane (po korekcie) należy umieścić natomiast w
części Podmiot1 faktury korygującej.
Podmiot1K nie dotyczy przypadku korekty błędnego NIP występującego na fakturze
pierwotnej - wówczas wymagana jest korekta faktury do wartości zerowych. Do wystawienia
faktury z błędnym NIP może dojść wyłącznie w przypadku, gdy wystawca faktury posiadał
uprawnienia do wystawiania faktur w imieniu różnych podatników (tzn. posiadał uprawnienia
do kilku kontekstów) i wystawił ją w kontekście podatnika, do którego posiadał uprawnienia,
ale który faktycznie nie dokonał danej sprzedaży (sprzedaży dokonał inny podatnik, do którego
posiada uprawnienia).
W sekcji Podmiot2K podaje się dane identyfikacyjne i adresowe nabywcy, w przypadku
korekty danych nabywcy występującego jako Podmiot2 lub dodatkowego nabywcy
występującego jako Podmiot3. Należy podać pełne dane tego podmiotu występujące na
fakturze korygowanej (pierwotnej). Korekcie nie podlegają błędne numery identyfikujące
nabywcę oraz dodatkowego nabywcę. W przypadku korygowania pozostałych danych
48

---

nabywcy lub dodatkowego nabywcy, wskazany numer identyfikacyjny powinien być tożsamy z
numerem w części Podmiot2 (względnie Podmiot3) faktury korygującej.
W KSeF przewidziano możliwość podawania w fakturze danych więcej niż jednego nabywcy.
Sekcja Podmiot2K może wystąpić wielokrotnie, m.in. w celu podania danych wielu nabywców
występujących w fakturze pierwotnej.
Z punktu widzenia technicznego, istotna jest możliwość powiązania, danych nabywcy po
korekcie występujących w części Podmiot2 (względnie Podmiot3) z danymi w stanie przed
korektą w sekcjach Podmiot2K. W tym celu wprowadzono pole „IDNabywcy”. Jest to unikalny
klucz powiązania danych nabywcy, stosowany na potrzeby wystawienia danej faktury
korygującej. Pole występuje wyłącznie w fakturach korygujących, w których ulegają zmianie
dane nabywcy (wypełniona sekcja Podmiot2K). Jest to dowolny unikalny ciąg znaków (maks. 32
znaki).
Przykładowy plik e-Faktury, w której wykorzystano pola Podmiot2K oraz IDNabywcy można
znaleźć pod adresem: https://www.gov.pl/web/kas/krajowy-system-e-faktur (dokument:
„Przykładowe pliki dla struktury logicznej e-Faktury FA(3)”, przykład nr 5).
2.14. Kwota należności ogółem na fakturze
Istotną kwestią, na którą należy zwrócić uwagę, jest prawidłowy sposób wypełniania pola P_15
(kwota należności ogółem).
W przypadku:
• faktury podstawowej jest to kwota należności ogółem z niej wynikająca,
• faktury zaliczkowej jest to kwota otrzymanej lub planowanej do otrzymania zapłaty
(wartość zaliczki) dokumentowana fakturą,
• faktury rozliczającej, o której mowa w art. 106f ust. 3 ustawy, jest to kwota pozostała
do zapłaty,
• faktury korygującej, jest to korekta (różnica) kwoty wynikającej z faktury korygowanej,
• faktury korygującej, o której mowa w art. 106j ust. 3 ustawy jest to korekta (różnica)
kwot wynikających z faktur korygowanych.
W wartości z pola P_15 nie należy uwzględniać kwot, które w rozumieniu ustawy nie stanowią
wynagrodzenia za dostawę towarów lub wykonaną usługę, dokumentowaną tą fakturą (np.
dodatkowe obciążenie usługobiorcy przez sprzedawcę wydatkami poniesionymi w imieniu i na
rzecz usługobiorcy, należności o charakterze odszkodowawczym itp.).
49

---

Z myślą o umożliwieniu podatnikom wykazywania danych dotyczących dodatkowych obciążeń
lub pomniejszeń, stworzony został w strukturze FA(3) element fakultatywny Rozliczenie. Jego
wypełnienie ma charakter dobrowolny. Konstrukcja pozwala zaprezentować w sposób
przejrzysty i czytelny:
• do 100 kwot i powodów obciążeń,
• sumę obciążeń,
• do 100 kwot i powodów odliczeń,
• sumę odliczeń,
• kwotę do zapłaty lub do rozliczenia (w zależności od wyniku pomniejszenia lub/i
powiększenia kwoty z pola P_15).
Schemat 9. Element Rozliczenie w strukturze FA(3).
Przykład zastosowania elementu Rozliczenie znajduje się Broszurze informacyjnej dotyczącej
struktury logicznej FA(3) zamieszczonej na stronie https://ksef.podatki.gov.pl.
2.15. Struktura FA(3) a wydatki pracownicze
Istotnym zagadnieniem związanym z KSeF, jest identyfikacja faktur dokumentujących wydatki
pracownicze (np. zakup paliwa do pojazdu służbowego).
Nabywcą towaru lub usługi jest tu co prawda podatnik, niemniej w jego imieniu, w samej
transakcji, bezpośrednio uczestniczy pracownik. Dotychczasowa praktyka opierała się na tym,
że pracownik działając w imieniu pracodawcy zwracał się do sprzedawcy o wystawienie faktury
dokumentującej dany zakup informując go, że nabywcą jest podatnik. Następnie w celu
rozliczenia pracownik przekazywał daną fakturę pracodawcy, zwykle w postaci papierowej.
50

---

W okresie obligatoryjnego KSeF w przypadku wystawienia tego typu faktury wprowadzone
zostają odpowiednie rozwiązania w strukturze logicznej e-Faktury FA(3).
Z uwagi na fakt, że nabywcą jest tu podatnik, istotne jest, aby NIP nabywcy - pracodawcy
znalazł się w elemencie Podmiot2. Dzięki temu faktura zostanie mu odpowiednio udostępniona
w KSeF.
Istnieje kilka sposobów mających na celu ułatwienie przyporządkowania danego wydatku
pracowniczego do konkretnego pracownika:
• Wykorzystanie pola IDWew w części Podmiot3 struktury FA(3)
Tabela 7. Sposób wypełnienia struktury FA(3) w celu identyfikacji wydatków pracowniczych.
Nazwa pola Sposób wypełniania
Podmiot3/ IDWew 9999999999-11118
DaneIdentyfikacyjne Nazwa Jan Kowalski
KodKraju PL
Podmiot3/Adres
AdresL1 ul. Zielona 13, 33-333 Opole
Podmiot3 Rola 11
Pole IDWew w Podmiot3 to unikalny identyfikator zakładu (oddziału) osoby prawnej lub innej
wyodrębnionej jednostki wewnętrznej podatnika. Jest to identyfikator zawierający numer
identyfikacji podatkowej (NIP) podatnika i ciąg znaków numerycznych.
Podatnik (pracodawca) po uwierzytelnieniu się w KSeF, może wygenerować identyfikatory
wewnętrzne np. dla swoich pracowników (osoba fizyczna również może być wyodrębnioną
jednostką wewnętrzną). Pracownicy mogą zwrócić się do sprzedawcy, aby wystawiając fakturę,
poza danymi nabywcy (w części Podmiot2), w tym jego identyfikatorem NIP, zawarł w niej
również dane pracownika (w części Podmiot3), w tym jego identyfikator wewnętrzny - IDWew.
Warto również zaznaczyć, że pracodawca może nadać uprawnienia osobie fizycznej (np.
pracownikowi działu księgowości czy pracownikowi działu kadr) do dostępu do faktur
dotyczących danego pracownika. Może też nadać takie uprawnienia samemu pracownikowi.
W związku z tym, że na fakturze znajdują się także dane nabywcy (Podmiot2) – pracodawcy, po
uwierzytelnieniu się w systemie, również on będzie posiadał dostęp do danej faktury.
51

---

Dzięki temu, że każdy pracownik będzie posiadał swój identyfikator, możliwe będzie
zidentyfikowanie, którego pracownika dotyczy dany wydatek.
• Wykorzystanie części Podmiot3 struktury FA(3)
Wykorzystanie pola IDWew oczywiście nie jest obowiązkowe. Część Podmiot3 można
wykorzystać np. wyłącznie do wskazania w nim danych pracownika oraz wskazania jego roli
(bez wskazywania identyfikatora wewnętrznego). Zamieszczenie danych adresowych
pracownika w Podmiot3 jest możliwe, ale nie jest obowiązkowe.
Tabela 8. Sposób wypełnienia struktury FA(3) w celu identyfikacji wydatków pracowniczych.
Nazwa pola Sposób wypełniania
Podmiot3/ BrakID 1
DaneIdentyfikacyjne Nazwa Jan Kowalski
KodKraju PL
Podmiot3/Adres
AdresL1 ul. Zielona 13, 33-333 Opole
Podmiot3 Rola 11
• wykorzystanie elementu DodatkowyOpis
W strukturze FA(3) występuje pole DodatkowyOpis (złożone z pól NrWiersza, Klucz i
Wartosc), w którym podatnik może zawrzeć dowolną, dodatkową informację. W tym miejscu
również, w razie potrzeby, można wskazać np. dane pracownika wraz z informacją, że jest to
wydatek pracowniczy. Wypełnienie pola NrWiersza nie jest konieczne, jeśli informacja będzie
odnosiła się do całej faktury.
Tabela 9. Sposób wypełnienia struktury FA(3) w celu identyfikacji wydatków pracowniczych.
Nazwa pola Sposób wypełniania
Klucz Rodzaj wydatku
DodatkowyOpis Wydatek pracowniczy -
Nazwa
Jan Kowalski
52

---

WAŻNE
Wskazane rozwiązania stanowią wyłącznie przykład postępowania. Organizacja procesu
dostępu do faktur oraz sposób identyfikacji faktur dokumentujących wydatki pracownicze
mogą być kształtowane dowolnie przez podatnika, w zależności od jego potrzeb i możliwości.
3. Aspekty techniczne związane z wysyłką faktur do KSeF
3.1. Jak wystawić e-Fakturę?
Fakturę ustrukturyzowaną można wystawić bezpośrednio przy użyciu komercyjnych
programów finansowo-księgowych podatnika. Od 1 lutego 2026 r. faktury te będą przesyłane
do środowiska produkcyjnego za pomocą API KSeF 2.0.
korzystać z KSeF. Narzędzia te zostaną odpowiednio dostosowane do założeń nowego KSeF
2.0 na okres obligatoryjny . Należy do nich:
• Aplikacja Podatnika KSeF, umożliwiająca korzystanie z KSeF podatnikom i podmiotom
uprawnionym przez tych podatników, zarządzanie uprawnieniami oraz tokenami,
generowanie certyfikatów KSeF, wystawianie i odbieranie e-Faktur w KSeF, podgląd e-
Faktury, weryfikację statusu wysyłki i możliwość pobrania UPO KSeF; aplikacja
dostępna w wersji testowej (od 3 listopada 2025 r.), przedprodukcyjnej (od 15 listopada
2025 r.) oraz produkcyjnej (od 1 lutego 2026 r.);
• Aplikacja Mobilna KSeF, pozwalająca na wygodne i szybkie wystawianie faktur
ustrukturyzowanych, odbieranie ich w czasie rzeczywistym oraz zarządzanie nimi z
dowolnego miejsca;
• Aplikacja e-mikrofirma umożliwiająca powiązanie istniejącego konta z KSeF,
wystawianie faktur w KSeF, odbieranie faktur ustrukturyzowanych z KSeF oraz
przenoszenie ich bezpośrednio do ewidencji VAT, bez konieczności ręcznego
przepisywania danych. Aplikacja dostępna jest w e-Urzędzie Skarbowym.
3.2. Rodzaje udostępnionych środowisk KSeF
Aby umożliwić dostosowanie systemów informatycznych do wymogów KSeF 2.0, we wrześniu
2025 r. udostępnione zostało środowisko testowe, a w październiku 2025 r. środowisko
przedprodukcyjne. Od 1 lutego 2026 r. zostanie udostępnione środowisko produkcyjne KSeF
2.0.
53

---

3.2.1. Środowisko testowe
Środowisko testowe API KSeF 2.0 dostępne jest od 30 września 2025 r.
Celem udostępnienia tego środowiska jest testowanie nowych funkcjonalności oferowanych
przez API KSeF 2.0. Wystawione w środowisku testowym dokumenty nie będą
fakturami/dokumentami księgowymi i nie będą wywoływać żadnych skutków prawnych.
Z uwagi na ogólnodostępność środowiska testowego należy używać w nim zanonimizowanych
danych. Nie powinno używać się rzeczywistych danych firmy (środowisko jest publicznie
dostępne). W celu zapewnienia anonimizacji danych nie należy używać rzeczywistych numerów
NIP i PESEL w połączeniu z rzeczywistymi pozostałymi danymi jak nazwy, imiona, nazwiska itp.
Na środowisku testowym dopuszcza się użycie samodzielnie wygenerowanego certyfikatu
będącego odpowiednikiem certyfikatów kwalifikowanych. Dzięki temu możliwe będzie
wygodne testowanie podpisu bez potrzeby posiadania certyfikatu kwalifikowanego. Szczegóły
przedstawiono w dokumentacji technicznej zamieszczonej na stronie
https://ksef.podatki.gov.pl/.
3.2.2. Środowisko przedprodukcyjne (demo)
Środowisko przedprodukcyjne KSeF 2.0 opiera się o faktyczne dane uwierzytelniające, zgodne
z rejestrem informacji o właścicielach firm. W celu zalogowania się do usługi konieczne jest
posiadanie faktycznych uprawnień, analogicznych jak dla środowiska produkcyjnego.
Testowanie KSeF na tym środowisku nie jest dostępne publicznie (tj. opiera się o faktyczne
dane uwierzytelniające (np. NIP) zgodne z rejestrem informacji o właścicielach firm), a proces
logowania do usługi pozwala wykorzystywać faktyczny zestaw uprawnień właścicielskich,
analogiczny jak dla środowiska produkcyjnego.
Działanie środowiska demo jest analogiczne do działania docelowego systemu produkcyjnego z
tą różnicą, że wystawione w środowisku przedprodukcyjnym dokumenty nie są
fakturami/dokumentami księgowymi i nie wywołują skutków prawnych.
3.2.3. Środowisko produkcyjne
Środowisko produkcyjne KSeF 2.0 będzie opierać się o faktyczne dane uwierzytelniające
zgodne z rejestrem informacji o właścicielach firm. W celu zalogowania się do usługi konieczne
będzie posiadanie faktycznych uprawnień. Dokumenty wystawione w tym środowisku będą
pełnoprawnymi fakturami.
54

---

WAŻNE
Wysyłka testowa niewywierająca skutków prawnych może odbywać się wyłącznie w ramach
środowiska testowego i przedprodukcyjnego (demo). Niedopuszczalne jest przesyłanie faktur
testowych do środowiska produkcyjnego, gdyż w przypadku wysyłki zakończonej sukcesem i
nadaniem numeru KSeF jest to równoznaczne z wystawieniem pełnoprawnej faktury, która w
istocie nie dokumentuje żadnej transakcji. Skutkować to może obowiązkiem zapłaty podatku,
wynikającym z treści art. 108 ustawy.
W przypadku popełnienia tego typu błędu – tj. wystawienia faktury, która nie dokumentuje
faktycznie wykonanej czynności opodatkowanej, należy niezwłocznie wystawić fakturę
korygującą „do zera”.
3.3. Sesja interaktywna i wsadowa
3.3.1.Sesja interaktywna
Przesłanie faktury do KSeF może odbyć się w ramach sesji interaktywnej lub sesji wsadowej.
Sesja interaktywna polega na przesyłaniu do API KSeF pojedynczych faktur
ustrukturyzowanych. Wymogiem koniecznym jest, aby przesyłany plik posiadał format XML i
był zgodny z opublikowanym aktualnie na ePUAP schematem e-Faktury.
Wysyłkę interaktywną obsługują bezpłatne narzędzia do wystawiania faktur
ustrukturyzowanych, udostępniane przez MF, np. Aplikacja Podatnika KSeF.
55

---

Przykład 6. Przebieg wysyłki interaktywnej.
Przygotowanie pliku PLIK XML Wysyłka
PODATNIK XML w programie NR 1 pojedynczego KSeF
finansowo-księgowym pliku XML
……..
Przygotowanie pliku Wysyłka
PLIK XML
XML w programie pojedynczego
PODATNIK
NR 2 KSeF
finansowo-księgowym pliku XML
……..
Przygotowanie pliku Wysyłka
PLIK XML
XML w programie pojedynczego
PODATNIK
finansowo-księgowym NR 3 pliku XML
KSeF
……..
Opis procesu:
Podatnik przygotowuje trzy pliki XML. Korzystając z wysyłki interaktywnej przesyła
pojedyncze pliki XML do KSeF. We wskazanym wyżej przypadku najpierw prześle do KSeF plik
XML pierwszej faktury, później drugiej a na końcu trzeci. Zakładając, że weryfikacja faktur
będzie pozytywna, finalnie dla każdej z faktur zostanie przydzielony numer KSeF. Podatnik
będzie mógł też pobrać UPO.
W ramach wysyłki interaktywnej obowiązuje maksymalny rozmiar pliku – 1 MB. W sesji
interaktywnej nie będzie możliwe wystawianie faktur z załącznikiem (za wyjątkiem tzw.
korekty technicznej takiej faktury). Maksymalna liczba faktur w jednej sesji wynosi 10 000.
Szczegółowe informacje w tym zakresie można znaleźć w dokumentacji technicznej API KSeF
2.0 zamieszczonej na stronie: Wsparcie dla integratorów.
3.3.2. Sesja wsadowa
Dla wysyłki zbiorczej dedykowana jest natomiast wysyłka wsadowa. Wysyłka wsadowa jest
zestawem operacji oraz procesem pozwalającym na wystawienie wielu faktur jednocześnie.
56

---

Umożliwia jednorazowe przesłanie do KSeF wielu faktur w pojedynczym pliku ZIP, zamiast
wysyłania do systemu każdej z faktur oddzielnie.
Przykład 7. Przebieg wysyłki wsadowej.
Przygotowanie pliku PLIK XML
XML w programie
PODATNIK
finansowo-księgowym NR 1
……..
Wysyłka paczki
złożonej np. z trzech
Utworzenie
faktur do KSeF
paczki
Przygotowanie pliku faktur
XML w programie PLIK XML
PACZKA
PODATNIK finansowo-księgowym
NR 2 KSeF
ZIP
……..
Przygotowanie pliku
XML w programie PLIK XML
PODATNIK finansowo-księgowym
NR 3
……..
Opis procesu:
Podatnik przygotowuje w swoim programie finansowo-księgowym trzy pliki XML. Następnie
tworzy z nich paczkę plików ZIP. Korzystając z wysyłki wsadowej przesyła paczkę plików XML
do KSeF. Zakładając, że weryfikacja faktur będzie pozytywna, finalnie dla każdej z faktur
zostanie przydzielony numer KSeF. Podatnik będzie mógł pobrać UPO.
W ramach wysyłki wsadowej obowiązuje maksymalny rozmiar pliku – 1 MB dla faktury bez
załącznika oraz 3 MB dla faktury z załącznikiem. Wystawianie faktur z załącznikiem jest
możliwe wyłącznie w sesji wsadowej (za wyjątkiem tzw. korekty technicznej takiej faktury).
Maksymalna liczba faktur w jednej sesji wynosi 10 000. W ramach wysyłki wsadowej można
wysłać maksymalnie 50 paczek ZIP, każda o maksymalnym rozmiarze 100 MB.
Szczegółowe informacje w tym zakresie można znaleźć w dokumentacji technicznej API KSeF
2.0 zamieszczonej na stronie: Wsparcie dla integratorów.
57

---

Odrzucenie paczki przez KSeF
Założeniem wysyłki wsadowej nie jest atomowość procesu. Oznacza to, że paczka nie zostanie
w całości odrzucona, jeśli któryś z plików XML, który się w nim znajduje nie będzie prawidłowy.
Podczas przesyłania paczki dokumentów każdy plik XML przetwarzany będzie niezależnie, a
ewentualne błędy wpłyną wyłącznie na konkretne pliki, a nie na całość przesyłki.
KSeF w takiej sytuacji odrzuci tylko błędne semantycznie pliki XML i poinformuje o powodzie
odrzucenia poszczególnych plików przesłanych w ramach paczki faktur, po odpytaniu o
odrzucone dokumenty XML w danej sesji. Lista błędnych plików XML będzie zwracana po
sprawdzeniu wszystkich dokumentów przesłanych do KSeF. Dla pozostałych prawidłowych
plików XML znajdujących się w paczce, po ich weryfikacji, system wygeneruje numery KSeF.
3.4. Weryfikacja duplikatów faktur
Warto podkreślić, że w API KSeF 2.0 zostanie wdrożony mechanizm blokowania duplikatów
faktur. Funkcjonalność ma dla podatnika bardzo duże znaczenie, jeśli chodzi o zabezpieczenie
ich przed przesłaniem do systemu dwóch takich samych pod względem zawartości,
dokumentów, gdzie każda z wysyłek zakończyła się sukcesem oraz nadane zostały dwa różne
numery KSeF. W takim bowiem przypadku w obrocie gospodarczym funkcjonowałyby dwie
faktury ze wszystkimi ich skutkami prawnymi.
Weryfikacja duplikatów faktur będzie odbywała się na podstawie następujących danych:
• identyfikator podatkowy NIP sprzedawcy (pole NIP w Podmiot1/DaneIdentyfikacyjne),
• kolejny numer nadany przez podatnika w ramach jednej lub więcej serii, który w sposób
jednoznaczny identyfikuje fakturę (pole P_2),
• rodzaj faktury (pole RodzajFaktury).
W przypadku, gdy plik XML przesyłany do systemu, będzie zawierał identyczne wartości we
wszystkich trzech wskazanych wyżej parametrach, które posiada już znajdująca się w KSeF
faktura, to plik ten zostanie odrzucony. KSeF w odpowiedzi wyświetli także odpowiedni
komunikat, wskazujący na powód odrzucenia pliku. W tym przypadku będzie to kod błędu 440
„Duplikat faktury”. Unikalność faktury będzie weryfikowana w okresie 10 lat wstecz, czyli
zgodnie z okresem przechowywania faktur w KSeF.
4. Potwierdzenie skutecznego wystawienia faktury w KSeF
4.1. Numer KSeF faktury
Numer KSeF to unikalny numer, który identyfikuje fakturę w systemie. Numer ten generowany
jest automatycznie przez KSeF i jest zwracany w Urzędowym Poświadczeniu Odbioru (UPO).
58

---

Składa się z następujących elementów:
Schemat 10. Elementy numeru KSeF faktury.
WAŻNE
Numer KSeF przydzielony e-Fakturze nie jest częścią pliku XML tej faktury.
Struktura logiczna FA(3) nie zawiera pola dedykowanego dla numeru KSeF danej faktury
ustrukturyzowanej. Zawiera natomiast kolejny numer faktury nadany przez podatnika w
ramach jednej lub więcej serii, który w sposób jednoznaczny identyfikuje fakturę, o którym
mowa w art. 106e ust. 1 pkt 2 ustawy. Jest on wskazywany w polu P_2.
Schemat 11. Wykorzystanie numeru KSeF faktury.
FAKTURA ZALICZKOWA FAKTURA ROZLICZAJĄCA
(ostatnia)
zawiera numery KSeF faktur
zawiera numery KSeF zaliczkowych
poprzednich faktur zaliczkowych
FAKTURA PŁATNOŚĆ W RAMACH
KORYGUJĄCA WYKORZYSTANIE MPP
zawiera numery KSeF NR KSeF FAKTURY wskazanie numeru KSeF
faktur pierwotnych w komunikacie przelewu
PLIKI JPK PŁATNOŚĆ ZA FAKTURĘ
wskazanie numerów KSeF e-Faktur wskazanie numeru KSeF podczas
m.in. w plikach JPK_V7M/V7K, dokonywania płatności za fakturę
JPK_KR_PD
59

---

Warto zwrócić uwagę, że numer KSeF faktury z uwagi na swoje walory analityczne będzie
potrzebny podatnikowi w kilku sytuacjach. Nastąpi to m.in. podczas wystawiania faktur
korygujących oraz faktur rozliczających. Numer KSeF będzie także wykorzystywany od 1
stycznia 2027 r. podczas dokonywania płatności za fakturę pomiędzy podatnikami czynnymi
oraz podczas dokonywania płatności w ramach mechanizmu podzielonej płatności.
4.1.1. Numer KSeF faktury zaliczkowej w fakturze rozliczającej
W myśl art. 106f ust. 3 ustawy w przypadku, gdy faktura dokumentująca otrzymanie zapłaty
lub jej części przed dokonaniem czynności (tj. faktura zaliczkowa), nie obejmuje całej zapłaty,
na fakturze wystawianej po wydaniu towaru lub wykonaniu usługi (tj. na fakturze rozliczającej),
należy zawrzeć:
• numery KSeF faktur wystawionych przed wydaniem towaru lub wykonaniem usługi (tj.
numer KSeF faktur zaliczkowych), natomiast
• w przypadku faktur zaliczkowych innych niż e-Faktury, powinna ona zawierać numery
tych faktur nadane przez podatnika.
4.1.2. Numer KSeF w fakturze zaliczkowej
Zgodnie z art. 106f ust. 4 ustawy w przypadku, gdy wystawiono więcej niż jedną fakturę
dokumentującą otrzymanie części zapłaty (tj. więcej niż jedną fakturę zaliczkową), a faktury te
obejmują łącznie całą zapłatę, ostatnia z tych faktur zaliczkowych powinna zawierać również:
• numery KSeF poprzednich faktur zaliczkowych lub
• numery poprzednich faktur, nadane przez podatnika – w przypadku faktur innych niż e-
Faktury.
Numery KSeF faktur zaliczkowych (zarówno w przypadku wystawienia faktury rozliczającej jak
i ostatniej z faktur zaliczkowych, podaje się w części FakturaZaliczkowa struktury FA(3).
Element FakturaZaliczkowa może wystąpić w fakturze do 100 razy. Jest to element typu
„choice” (wybór) co oznacza, że:
• podatnik wypełni pole NrKSeFZN (podając „1” w przypadku, gdy faktura zaliczkowa
została wystawiona poza KSeF) oraz NrFaZaliczkowej (podając numer faktury nadany
przez podatnika) lub
• podatnik wypełni pole NrKSeFFaZaliczkowej w przypadku, gdy faktura zaliczkowa była
wystawiona w KSeF (podając numer KSeF faktury zaliczkowej.
60

---

Schemat 12. Element FakturaZaliczkowa w strukturze FA(3).
4.1.3. Numer KSeF faktury pierwotnej podawany w fakturze korygującej
Faktura korygująca powinna zawierać:
• numer kolejny oraz datę jej wystawienia,
• numer KSeF faktury, której dotyczy faktura korygująca (tj. numer KSeF faktury
pierwotnej), z wyjątkiem faktur korygujących wystawianych do faktur, dla których nie
został nadany numer KSeF,
• dane zawarte w fakturze, której dotyczy faktura korygująca (tj. w fakturze pierwotnej):
o określone w art. 106e ust. 1 pkt 1-5 ustawy (datę wystawienia kolejny numer
faktury nadany przez podatnika, dane stron transakcji),
o nazwę (rodzaj) towaru lub usługi objętych korektą,
• jeżeli korekta wpływa na zmianę podstawy opodatkowania lub kwoty podatku należnego
- odpowiednio kwotę korekty podstawy opodatkowania lub kwotę korekty podatku
należnego z podziałem na kwoty dotyczące poszczególnych stawek podatku i sprzedaży
zwolnionej,
• w przypadkach innych niż wskazane w pkt wyżej - prawidłową treść korygowanych
pozycji.
Faktura korygująca powinna zawierać więc między innymi numer KSeF faktury, której dotyczy
faktura korygująca. Wymóg ten nie dotyczy jednak przypadków, gdy fakturze korygowanej nie
został nadany ten numer.
Numer KSeF powinna zawierać także faktura korygująca wystawiona do faktury, wystawionej
zgodnie z art. 106nf ust. 1 (tj. w trybie awaryjnym), art. 106nh ust. 1 ustawy (w trybie offline –
niedostępność systemu) oraz zgodnie z art. 106nda ust. 1 ustawy (w trybie offline24) . Wymóg
taki podyktowany jest dbałością o zachowanie ciągłości systemu wystawiania faktur, w tym
zachowaniem waloru dla czynności kontrolnych przeprowadzanych przez organy podatkowe, a
także dla wiarygodnej i prawidłowej wartości analitycznej.
Numery KSeF faktur pierwotnych podaje się w części DaneFaKorygowanej struktury FA(3).
61

---

4.1.4. Numer KSeF wskazywany w komunikacie przelewu MPP
W art. 108a ustawy wprowadzone zostają zmiany mające na celu dostosowanie płatności
realizowanych w mechanizmie podzielonej płatności do wdrażanego obowiązku e-
fakturowania. Do komunikatu przelewu dedykowanego dla płatności w ramach mechanizmu
podzielonej płatności wprowadzona zostanie dodatkowa informacja - numer KSeF e-Faktury.
Obowiązek zamieszczania tej informacji będzie dotyczył wyłącznie sytuacji, w której dostawca
lub usługodawca jest obowiązany do wystawiania e-Faktur w KSeF.
WAŻNE
Obowiązek podawania numeru KSeF faktury będzie dotyczył płatności realizowanych od 1
stycznia 2027 r.
W związku z powyższym dokonując płatności za daną fakturę ustrukturyzowaną, w
mechanizmie podzielonej płatności, podatnik wskaże:
• kwotę odpowiadającą całości albo części kwoty podatku wynikającej z faktury, która ma
zostać zapłacona w mechanizmie podzielonej płatności,
• kwotę odpowiadająca całości albo części wartości sprzedaży brutto,
• numer faktury, w związku z którą dokonywana jest płatność, a w przypadku faktury
ustrukturyzowanej – numer KSeF tej faktury,
• identyfikator podatkowy NIP dostawcy towaru lub usługodawcy.
Przykład 8. Przykładowy przebieg procesu płatności w ramach MPP z wykorzystaniem numeru KSeF faktury
SPRZEDAWCA 1 2 NABYWCA
KSeF
XML NR KSeF
RACHUNEK RACHUNEK
BANKOWY BANKOWY
SPRZEDAWCY NABYWCY
3 KOMUNIKAT PRZELEWU MPP
(z numerem KSeF faktury)
Opis procesu:
1 - podatnik (sprzedawca) uwierzytelniony w KSeF przesyła plik XML e-Faktury do KSeF,
2 - fakturze zostaje nadany numer KSeF, jest to jednocześnie moment otrzymania faktury
ustrukturyzowanej przez nabywcę,
62

---

3 - nabywca dokonuje płatności w ramach MPP ze swojego rachunku bankowego na rachunek
bankowy sprzedawcy, uwzględnia przy tym numer KSeF faktury w komunikacie przelewu.
Informacje na temat posługiwania się zbiorczym identyfikatorem (wygenerowanym dla więcej
niż jednej e-Faktury) w przypadku płatności w ramach MPP zostały zawarte w cz. III
Podręcznika KSeF 2.0.
4.1.5. Numer KSeF w płatnościach pomiędzy podatnikami VAT czynnymi
Z dniem 1 lutego 2026 r. dodany zostaje art. 108g ustawy.
Nabywca towaru lub usługi (zarejestrowany jako podatnik VAT czynny), dokonujący płatności
za:
• faktury ustrukturyzowane oraz
• za faktury, o których mowa w art. 106nda ust. 1 i art. 106nh ust. 1 ustawy (wystawione
w trybie offline24 oraz w trybie offline-niedostępność KSeF),
na rzecz innego podatnika (zarejestrowanego jako podatnik VAT czynny), za pośrednictwem
usługi polecenia przelewu4 lub innego instrumentu płatniczego w rozumieniu ustawy o usługach
płatniczych5, umożliwiającego podanie tytułu transferu środków pieniężnych, jest obowiązany
do podania numeru KSeF faktury lub identyfikatora zbiorczego nadanego przez KSeF.
WAŻNE
Obowiązek podawania numeru KSeF faktury w płatnościach pomiędzy podatnikami VAT
czynnymi będzie dotyczył płatności realizowanych od 1 stycznia 2027 r.
Obowiązek ten dotyczy również wystawcy faktury, gdy płatność jest dokonywana przy użyciu
polecenia zapłaty6. Status podatnika, na rzecz którego dokonywana jest płatność, tzn. czy jest
on podatnikiem VAT czynnym jest ustalany na podstawie Wykazu podatników, na dzień
dokonywania płatności za faktury.
Przepisów dotyczących obowiązku podawania numeru KSeF/zbiorczego identyfikatora
płatności nie stosuje się w przypadku, gdy nabywca towaru lub usługi dokonuje płatności za
faktury, o których mowa w art. 106nda ust. 1 i art. 106nh ust. 1 ustawy (tj. wystawione w trybie
4 Usługa polecenia przelewu, o której mowa w art. 3 ust. 4 ustawy z dnia 19 sierpnia 2011 r. o usługach
płatniczych (Dz.U. 2025 poz. 611).
5 Ustawa z dnia 19 sierpnia 2011 r. o usługach płatniczych (Dz.U. 2025 poz. 611).
6 Polecenie zapłaty, o którym mowa w art. 3 ust. 2 ustawy z dnia 19 sierpnia 2011 r. o usługach
płatniczych (Dz.U. 2025 poz. 611).
63

---

offline24 i w trybie offline-niedostępność KSeF), niewprowadzone do KSeF w związku z
zamieszczonymi komunikatami o awarii KSeF7.
WAŻNE
Obowiązek podawania numeru KSeF/zbiorczego identyfikatora w płatnościach pomiędzy
podatnikami VAT czynnymi nie będzie dotyczył m.in. faktur wystawianych podczas awarii KSeF
(w trybie określonym w art. 106nf ustawy).
Informacje na temat zasad generowania zbiorczego identyfikatora zostały zawarte w cz. III
Podręcznika KSeF 2.0.
4.1.6. Numer KSeF w plikach JPK
W związku ze wprowadzeniem obowiązkowego KSeF zostanie znowelizowane rozporządzenie
Ministra Finansów, Inwestycji i Rozwoju z dnia 15 października 2019 r. w sprawie JPK_VAT z
deklaracją8. W oparciu o zapisy rozporządzenia zostanie wdrożona nowa wersja struktur
logicznych JPK_V7M oraz JPK_V7K. Od lutego 2026 r. w części ewidencyjnej pliku
JPK_V7M/V7K podatnik będzie miał obowiązek podawać numery KSeF wystawionych faktur
sprzedażowych i otrzymywanych faktur zakupowych, a w przypadku braku nr KSeF będzie miał
obowiązek stosowania odpowiednich oznaczeń.
Numer KSeF wykorzystywany będzie również w innych strukturach JPK, np. w strukturze
logicznej JPK_KR_PD.
4.2. Urzędowe Poświadczenie Odbioru
W przypadku przesłania do KSeF pliku XML, zgodnego ze strukturą logiczną e-Faktury przez
osobę lub podmiot tego uprawniony, po przetworzeniu dokumentu status wysyłki zmieni się na
„200” i fakturze zostanie nadany numer KSeF. W systemie dostępne będzie również w związku
z tym Urzędowe Poświadczenie Odbioru (UPO). UPO stanowi formalne potwierdzenie odbioru
dokumentu elektronicznego przez KSeF. Jest to odrębny od e-Faktury dokument w formacie
XML, możliwy do pobrania przez API.
System będzie umożliwiał pobranie UPO bez konieczności uwierzytelnienia się w systemie dla:
• pojedynczych faktur wystawionych w określonej sesji - możliwe również podczas
otwartej sesji, pod warunkiem pozytywnego przetworzenia pliku XML faktury oraz
nadania mu numeru KSeF, lub
7 Zgodnie z art. 106ne ust. 1 i 3 ustawy.
8 Dz. U. z 2019 r. poz. 1988 ze zm.
64

---

• wszystkich faktur wystawionych w określonej sesji (pod warunkiem, że wszystkie
dokumenty w danej sesji zostały przetworzone i co najmniej jeden dokument otrzymał
numer KSeF oraz został trwale zapisany, sesja musi być zamknięta).
65

---

Przykład 9. Wizualizacja Urzędowego Poświadczenia Odbioru.
66

---

Opis elementów UPO
1. Numer referencyjny wysłanego zbioru dokumentów. W przypadku wysyłki interaktywnej
jest to numer referencyjny sesji.
W przypadku wysyłki wsadowej jest to numer referencyjny paczki.
Uwaga! Numer referencyjny sesji nie jest numerem KSeF przesłanej faktury.
2. Typ identyfikatora, który został wskazany na etapie uwierzytelnienia w systemie.
Kontekstem może być np. NIP lub identyfikator wewnętrzny.
3. Wartość identyfikatora kontekstu uwierzytelnienia np. 1111111111 (dla typu kontekstu
NIP).
4. Numer nadawany automatycznie po weryfikacji i przyjęciu pliku e-Faktury w KSeF.
5. Kolejny numer faktury, o którym mowa w art. 106e ust. 1 pkt 2 ustawy o VAT. Wartość
znajdująca się w polu P_2 pliku e-Faktury przesłanej do KSeF.
6. Identyfikator podatkowy NIP sprzedawcy wskazany w polu
Podmiot1/DaneIdentyfikacyjne/NIP.
7. Data wystawienia faktury, o której mowa w art. 106e ust. 1 pkt 1 ustawy o VAT. Wartość
znajdująca się w polu P_1 pliku e-Faktury przesłanej do KSeF.*
* Jest to data wystawienia faktury w trybie offline24, trybie offline-niedostępność KSeF oraz
trybie awaryjnym.
8. Data przesłania pliku e-Faktury do KSeF.*
* Jest to data wystawienia faktury w trybie online (zgodna z datą w polu P_1).
9. Data nadania numeru KSeF = data otrzymania e-Faktury przez nabywcę*
* Przepisy wskazują także szczególne zasady określania daty otrzymania e-Faktury, w
szczególności w przypadku wystawienia jej na rzecz nabywcy, o którym mowa w art. 106gb ust.
4 ustawy o VAT.
10. Unikalny ciąg znaków obliczony na podstawie skrótu kryptograficznego faktury o długości
256 bitów wytworzonego przy użyciu algorytmu kryptograficznego z rodziny SHA2.
Przykładowa wizualizacja UPO wraz z opisem najważniejszych pól dostępna jest także na
stronie https://ksef.podatki.gov.pl/.
67

---

5. Otrzymywanie faktur w KSeF oraz dostęp do faktur. Kody QR.
Faktura wystawiona w KSeF, która została przyjęta do systemu i został jej nadany numer KSeF
jest automatycznie dostępna po stronie nabywcy, o ile w dokumencie został uwzględniony jego
identyfikator podatkowy NIP (w części Podmiot2/DaneIdentyfikacyjne/NIP).
WAŻNE
Z dniem 1 lutego 2026 r. zostaje uchylony art. 106na ust. 2 ustawy, co oznacza, że
otrzymywanie e-Faktur nie będzie już wymagało akceptacji odbiorcy tej faktury.
5.1. Data otrzymania faktury ustrukturyzowanej (tryb ONLINE)
Zgodnie z art. 106na ust. 3 ustawy faktura ustrukturyzowana jest uznana za otrzymaną przy
użyciu KSeF w dniu przydzielenia jej w tym systemie numeru KSeF.
W myśl natomiast art. 106na ust. 4 ustawy przypadku udostępnienia faktury
ustrukturyzowanej nabywcy, o którym mowa w art. 106gb ust. 4 ustawy, czyli np. nabywcy
zagranicznemu, podatnikowi z innego kraju UE, korzystającemu ze zwolnienia w ramach
procedury SME, podmiotowi, który nie posługuje się numerem NIP, czy konsumentowi - w
sposób inny niż przy użyciu KSeF, za datę otrzymania tej faktury uznaje się datę jej faktycznego
otrzymania przez tego nabywcę.
Przykład 10. Data otrzymania faktury w przypadku nabywcy krajowego (podatnika posiadającego NIP).
Podatnik wystawia fakturę w trybie ONLINE. W pliku faktury wskazał 1 lutego 2026 r. jako
datę wystawienia faktury i w tym samym dniu (o godz. 23:56) przesłał fakturę do KSeF. Faktura
została przyjęta na bramce w tym samym dniu. Numer KSeF faktury został nadany 2 lutego
2026 r. (o godz. 00:01). Nabywcą nie był podmiot wymieniony w art. 106gb ust. 4 ustawy.
Datą otrzymania faktury jest w tym przypadku data przydzielenia fakturze numeru KSeF, czyli
2 lutego 2026 r.
Przykład 11. Data otrzymania faktury w przypadku nabywcy zagranicznego.
Podatnik wystawia fakturę w trybie ONLINE. W pliku faktury wskazał 1 lutego 2026 r. jako
datę wystawienia faktury i w tym samym dniu (o godz. 23:56) przesłał fakturę do KSeF. Faktura
została przyjęta na bramce w tym samym dniu. Numer KSeF faktury także został nadany 1
lutego 2026 r. Faktura została wystawiona na rzecz nabywcy nieposiadającego siedziby
działalności gospodarczej w Polsce, czyli na rzecz podmiotu wymienionego w art. 106gb ust. 4
ustawy. Nabywca otrzymał fakturę w sposób uzgodniony, poza KSeF –jako załącznik pdf do
wysłanej do niego przez sprzedawcę wiadomości e-mail. Nastąpiło to 3 lutego 2026 r.
68

---

Datą otrzymania faktury jest w tym przypadku data faktycznego otrzymania faktury poza
KSeF, czyli 3 lutego 2026 r.
W przypadku trybów OFFLINE istnieją szczególne zasady określania daty otrzymania faktury.
Zostały one przedstawione w cz. III Podręcznika KSeF 2.0.
5.2. Otrzymanie faktury w KSeF. Dostęp do faktury.
Sprzedawca
Sprzedawca (Podmiot1), którego NIP został uwzględniony w wystawianej fakturze posiada do
niej dostęp jako jedna ze stron transakcji. W przypadkach szczególnych, gdy np. wystawienie
faktury odbywa się w ramach samofakturowania przez nabywcę towaru lub usługi bądź
wystawcą faktury w imieniu podatnika będzie np. organ egzekucyjny, sprzedawca także
otrzyma taką fakturę w KSeF. Wynika to z faktu, że na tej fakturze, w elemencie Podmiot1
znajdzie się jego identyfikator podatkowy NIP.
Dostęp do wystawianych przez sprzedawcę faktur (samodzielnie lub przez osoby i podmioty
przez niego uprawnione) będzie posiadał zarówno sam sprzedawca jak również osoby fizyczne i
podmioty, którym ten sprzedawca nadał uprawnienie do dostępu do faktur. Uprawnienie do
dostępu do faktur obejmuje dostęp do wszystkich faktur, w których dany podatnik występuje
jako strona transakcji (sprzedawca, nabywca, podmiot trzeci, podmiot upoważniony).
Nabywca
KSeF jest systemem teleinformatycznym służącym m.in. do otrzymywania faktur
ustrukturyzowanych. Oznacza to, że po przesłaniu przez sprzedawcę pliku XML do KSeF,
nadaniu numeru KSeF faktury, nabywca (Podmiot2), którego identyfikator podatkowy NIP
podano w tej fakturze (w polu NIP) otrzyma ją również w tym systemie. Nabywca (lub osoba
fizyczna bądź podmiot uprawniony przez nabywcę do dostępu do faktur), po uwierzytelnieniu
się w KSeF uzyska dostęp do wszystkich swoich faktur, w tym faktur zakupowych.
WAŻNE
Aby nabywca otrzymał fakturę w KSeF należy wskazać jego identyfikator podatkowy NIP w
polu NIP w elemencie Podmiot2. Wskazanie identyfikatora podatkowego NIP w innym polu np.
NrVatUE lub NrID uniemożliwi nabywcy odbiór faktury w KSeF, pomimo uwierzytelnienia się
w systemie.
Podmiot trzeci
W przypadku, gdy na fakturze, poza danymi sprzedawcy (Podmiot1) oraz nabywcy (Podmiot2)
wskazane zostaną dane podmiotu trzeciego (Podmiot3), związanego z fakturą np. płatnika czy
69

---

faktora, wraz z jego identyfikatorem podatkowym NIP lub IDWew, podmiot ten także otrzyma
tę fakturę w systemie. Nabywca (lub osoba fizyczna bądź podmiot uprawniony przez nabywcę
do dostępu do faktur), po uwierzytelnieniu się w KSeF uzyska dostęp do faktur, w których
występuje jako podmiot trzeci (poza fakturami w których występowałby np. w roli sprzedawcy
czy nabywcy).
Podmiot upoważniony
W określonych ustawowo przypadkach, faktury mogą być wystawione przez podmioty tj.
komornik sądowy, organ egzekucyjny i przedstawiciel podatkowy. Wypełniany jest wówczas
element PodmiotUpowazniony w strukturze FA(3). Podmioty te z racji, że wystawiają faktury w
imieniu sprzedawcy (Podmiot1) i jednocześnie sami są stroną transakcji
(PodmiotUpowazniony), posiadają w KSeF dostęp do tego typu faktur (poza fakturami, w
których sami występują jako sprzedawca, nabywca czy podmiot trzeci). Po uwierzytelnieniu w
systemie dostęp do faktur podmiotu upoważnionego będą również posiadać m.in. osoby przez
nich uprawnione.
Schemat 13. Proces pobrania faktury z KSeF (z uwierzytelnieniem).
Dostęp do faktury w KSeF możliwy jest również bez konieczności uwierzytelnienia się w
systemie (za pomocą omówionego w dalszej części podręcznika tzw. dostępu dwuetapowego z
wykorzystaniem kodu QR lub tzw. dostępu anonimowego).
70

---

5.3. Przekazanie faktury w postaci uzgodnionej
5.3.1. Udostępnienie faktury w sposób uzgodniony
Fakturą ustrukturyzowaną z założenia jest plik XML. W określonych ustawowo sytuacjach,
poza obowiązkiem wystawienia faktury w KSeF, wystąpi dodatkowo konieczność przekazania
nabywcy faktury w sposób uzgodniony. Okoliczności te określa art. 106gb ust. 4 ustawy. Poza
przekazaniem faktury w postaci uzgodnionej należy pamiętać również o opatrzeniu
przekazywanej poza KSeF faktury odpowiednim kodem weryfikującym.
Obowiązek przekazania nabywcy faktury w sposób uzgodniony wystąpi, gdy:
• miejscem świadczenia jest terytorium państwa członkowskiego inne niż terytorium
kraju lub terytorium państwa trzeciego lub
• nabywcą jest podmiot nieposiadający siedziby działalności gospodarczej ani stałego
miejsca prowadzenia działalności gospodarczej na terytorium kraju, lub
• nabywcą jest podmiot nieposiadający siedziby działalności gospodarczej na terytorium
kraju, który posiada stałe miejsce prowadzenia działalności gospodarczej na terytorium
kraju, przy czym to stałe miejsce prowadzenia działalności nie uczestniczy w nabyciu
towaru lub usługi, dla którego wystawiono fakturę,
• nabywcą jest podatnik z innego kraju UE, korzystający ze zwolnienia w ramach
procedury SME,
• nabywcą jest podmiot, który nie posługuje się numerem NIP,
• nabywcą jest osoba fizyczna nieprowadząca działalności gospodarczej (konsument).
W przypadku udostępnienia faktury nabywcy, o którym mowa w poprzednim akapicie, poza
KSeF lub w przypadku użycia faktury poza KSeF, wystąpi obowiązek oznaczenia faktury
ustrukturyzowanej kodem weryfikującym (a w niektórych przypadkach kodami
weryfikującymi). Oznaczenie faktury kodem QR umożliwi dostęp do tej faktury w KSeF oraz
weryfikację danych zawartych na tej fakturze (tzw. dostęp dwuetapowy).
5.3.2. Zapewnienie dostępu do faktury nabywcom bez NIP i konsumentom
W przypadku gdy faktura ustrukturyzowana jest wystawiana na rzecz nabywcy, który nie
posługuje się NIP lub który jest konsumentem i jest otrzymywana przez tego nabywcę przy
użyciu KSeF, podatnik jest obowiązany zapewnić temu nabywcy dostęp do tej faktury poprzez
podanie kodu weryfikującego do faktury oraz danych umożliwiających zidentyfikowanie tej
faktury w systemie. Jeżeli zatem nabywca np. konsument (osoba fizyczna nieprowadząca
71

---

działalności gospodarczej) będzie chciała odebrać fakturę korzystając z KSeF, to sprzedawca
będzie mógł jej wydać wyłącznie kod QR wraz z danymi dostępowymi do faktury, bez
konieczności przekazywania jej np. wydruku faktury. Wówczas osoba fizyczna po
zeskanowaniu kodu QR i wpisaniu ww. danych dostępowych będzie mogła pobrać fakturę bez
konieczności uwierzytelnienia się w systemie (które w przypadku konsumentów generalnie nie
jest możliwe).
5.4. Kody weryfikujące
Kod QR (Quick Response) to graficzna postać linku prowadzącego do faktury w KSeF
umożliwiająca weryfikację, czy dana faktura znajduje się w KSeF, pobranie jej z systemu bez
konieczności logowania oraz w przypadku faktur wystawianych w trybie OFFLINE,
pozwalająca potwierdzić tożsamość wystawcy faktury. Wprowadzenie takiego rozwiązania
pozwoli na szybkie odczytanie informacji bez konieczności korzystania z komputera. Kod QR
będzie można zeskanować używając np. smartfona. Kody QR w kontekście KSeF są wdrażane w
szczególności z myślą o sytuacjach, w których faktura jest przekazywana nabywcy innym
kanałem niż bezpośrednie pobranie z API KSeF (np. gdy nabywcą jest podatnik zagraniczny).
Generowanie kodów będzie odbywało się lokalnie na poziomie danego narzędzia do
wystawiania faktur, w oparciu o dane zawarte w wystawionej fakturze.
WAŻNE
Przez oznaczenie faktury kodem weryfikującym rozumie się utworzenie linku do faktury lub
znaku graficznego (QR kodu) i naniesienie go bezpośrednio na fakturę przed przekazaniem jej
odbiorcy (wraz z odpowiednim numerem lub napisem). Sposób utworzenia kodu określony jest
w dokumentacji technicznej.
Znak graficzny (QR kod) przedstawia unikalny ciągu znaków w postaci dwuwymiarowego,
kwadratowego kodu graficznego QR zgodnego z normą ISO/IEC 18004:2024.
Oznaczenie faktury kodem weryfikującym powinno następować każdorazowo podczas
wizualizowania jej w programach komercyjnych. Bezpłatne programy udostępniane przez MF
także będą posiadać taką funkcjonalność.
5.4.1. Kod QR do weryfikacji faktury ONLINE lub OFFLINE
W zależności od trybu wystawienia faktury (ONLINE lub OFFLINE) na wizualizacji faktury:
• wystawionej ONLINE - zamieszczony będzie jeden kod QR (KOD I), a pod tym kodem
powinno znaleźć się oznaczenie w postaci numeru KSeF faktury, lub
• wystawionej OFFLINE zamieszczone będą dwa kody QR:
72

---

o pierwszy (KOD I ) – z napisem „OFFLINE” pod tym kodem,
o drugi (KOD II) – z napisem „CERTYFIKAT” pod tym kodem.
Przykład 12. Przykładowy kod graficzny QR dla faktury ONLINE i OFFLINE (KOD I)
KOD I (dla faktury ONLINE LUB OFFLINE)
• zapewni dostęp do tej faktury w KSeF,
• umożliwi weryfikację danych zawartych na tej fakturze, w przypadku posługiwania się
fakturą poza KSeF,
• jest zamieszczany na wizualizacji faktury wystawionej w trybie ONLINE,
• służy do oznaczenia faktury wystawionej w trybie offline24, offline-niedostępność
KSeF lub w trybie awaryjnym przekazywanej nabywcy lub używanej poza KSeF,
• jeśli dotyczy faktury znajdującej się już w KSeF posiada oznaczenie w postaci numeru
KSeF faktury, a jeśli dotyczy faktury wystawionej w trybie offline-24, offline-
niedostępność KSeF lub w trybie awaryjnym (jeszcze nieprzesłanej do KSeF) to zawiera
napis „OFFLINE”.
Kod weryfikujący zawiera (niezależnie od trybu fakturowania):
• adres zasobu oprogramowania interfejsowego, wskazany w specyfikacji tego
oprogramowania,
• datę wystawienia faktury wskazaną przez podatnika - w przypadku struktury logicznej
FA(3) jest to data z pola P_1,
• identyfikator podatkowy NIP sprzedawcy (również w przypadku faktur wystawianych
przez nabywcę w procedurze samofakturowania),
• wyróżnik faktury.
73

---

WAŻNE
Kod weryfikujący (KOD I) zapewnia dostęp do faktury oraz umożliwia weryfikację danych
zawartych w fakturze. Niezależnie czy dotyczy faktury wystawionej w trybie ONLINE czy
OFFLINE, składa się z tych samych elementów.
Szczegółowe informacje na temat elementów kodu weryfikującego dla szczególnego
przypadku tj. faktury VAT RR został opisany w cz. III Podręcznika KSeF 2.0.
5.4.2. Kod QR do weryfikacji tożsamości wystawcy faktury OFFLINE
KOD II (wyłącznie dla faktur OFFLINE)
• umożliwi zapewnienie autentyczności pochodzenia i integralności treści tej faktury,
• pozwoli na sprawdzenie czy certyfikat jest aktywny oraz czy właściciel certyfikatu
posiada uprawnienia do wystawienia faktury w imieniu podatnika,
• będzie służył do oznaczania faktur wystawionych w trybie offline24, offline-
niedostępność KSeF i w trybie awaryjnym, udostępnianych nabywcy w sposób inny niż
przy użyciu KSeF (przed przesłaniem faktury do KSeF),
• powinien zawierać napis „CERTYFIKAT”.
WAŻNE
Do wygenerowania tego kodu niezbędne jest posiadanie certyfikatu KSeF (typu 2).
Kod umożliwiający weryfikację tożsamości wystawcy składa się z:
• adresu zasobu oprogramowania interfejsowego, wskazanego w specyfikacji tego
oprogramowania,
• typu identyfikatora kontekstu i jego wartości,
• identyfikatora podatkowego NIP sprzedawcy,
• identyfikatora certyfikatu KSeF,
• wyróżnika faktury,
• składników, o których mowa wyżej opatrzonych certyfikatem KSeF (typu 2).
Typ identyfikatora kontekstu to np. NIP, identyfikator wewnętrzny, identyfikator złożony NIP-
VAT UE. Kontekst to z kolei identyfikator podatnika uprawnionego do wystawiania faktur w
KSeF, służący do weryfikacji uprawnień posiadanych przez wystawcę faktury przy przesyłaniu
tych faktur do KSeF.
74

---

Przykład 13. Przykładowy kod graficzny QR dla faktury OFFLINE (KOD II).
5.4.3. Co to jest wyróżnik faktury?
Wyróżnik potocznie nazywany „skrótem faktury” to unikalny ciąg znaków obliczony zgodnie ze
specyfikacją oprogramowania interfejsowego, na podstawie skrótu kryptograficznego faktury
(pliku XML) o długości 256 bitów wytworzonego przy użyciu algorytmu kryptograficznego z
rodziny SHA2. Jest umieszczany na wystawianych przy użyciu KSeF lub przesyłanych do tego
systemu fakturach jako składnik kodu weryfikującego.
5.4.4. Brak możliwości zamieszczenia kodu na wizualizacji faktury
W przypadku gdy faktura jest przesyłana odbiorcy w formacie ustrukturyzowanych danych
uniemożliwiających naniesienie tego kodu (linku lub kodu QR) bezpośrednio na fakturę,
podatnik będzie mógł wraz z tą fakturą:
• przesłać odrębny link/odrębne linki, razem z odpowiednimi oznaczeniami (w zależności
od sytuacji numer KSeF, napis „OFFLINE”, napis „CERTYFIKAT”),
• przesłać odrębny znak graficzny/odrębne znaki graficzne razem z odpowiednimi
oznaczeniami (w zależności od sytuacji numer KSeF, napis „OFFLINE”, napis
„CERTYFIKAT”).
Rozwiązanie to stanowi efekt wsłuchania się w głos rynku. Przedsiębiorcy podczas
przeprowadzanych konsultacji zgłaszali bowiem trudności w realizacji obowiązku
bezpośredniego opatrywania faktur kodami graficznymi QR lub linkami. Wynikało to w
szczególności ze stosowania przez nich tzw. EDI, czyli Elektronicznej Wymiany Danych
(Electronic Data Interchange). Jest to ustandaryzowana metoda automatycznej wymiany
dokumentów biznesowych (w tym faktur) pomiędzy systemami informatycznymi różnych firm.
Wymiana danych często odbywa się w ustalonym formacie (np. jako pliki XML), niekoniecznie
mającym postać zwizualizowaną. Biorąc jednak pod uwagę, że faktura jest wówczas nadal
przekazywana nabywcy/ używana poza KSeF, razem z tak przekazanym poza systemem plikiem
75

---

zajdzie obowiązek dołączenia do niej odpowiedniego kodu QR lub linku (wraz ze stosownym
napisem), a nie koniecznie bezpośrednie opatrzenie tym kodem lub linkiem samej faktury.
5.5. Dostęp dwuetapowy do faktury z wykorzystaniem kodu QR
Po zeskanowaniu kodu QR przy użyciu smartfona lub kliknięciu w link, każda osoba będzie
miała możliwość szybkiej i uproszczonej weryfikacji zgodności faktury z jej oryginalnymi
danymi zawartymi w KSeF. Nie będzie w tym przypadku wymagane uwierzytelnienie w
systemie. Po zeskanowaniu kodu QR/kliknięciu w link nastąpi odczyt informacji zawartych w
kodzie i zostaną wyświetlone podstawowe dane identyfikujące tę fakturę wraz z informacją czy
dokument znajduje się w KSeF. W przypadku pozytywnej weryfikacji użytkownik zostanie
poproszony o wskazanie danych dostępowych faktury, których zakres wynika z treści
rozporządzenia w sprawie korzystania z KSeF9. Po wprowadzeniu tych danych możliwe będzie
pobranie całej faktury.
Dostęp w KSeF do faktury wystawionej w trybie ONLINE lub faktury wystawionej trybie
OFFLINE (tj. offline24, offline-niedostępność KSeF lub trybie awaryjnym) przesłanej do KSeF,
wymaga podania:
• numeru faktury, o którym mowa w art. 106e ust. 1 pkt 2 ustawy (wartość z pola P_2),
• identyfikatora podatkowego NIP lub innego identyfikatora nabywcy towarów lub usług
albo informacji o braku identyfikatora,
• kwoty należności ogółem, o której mowa w art. 106e ust. 1 pkt 15 ustawy (wartość z pola
P_15).
Dostęp w KSeF do faktury korygującej wystawionej w trybie ONLINE lub faktury korygującej
wystawionej trybie OFFLINE (tj. offline24, offline-niedostępność KSeF lub trybie awaryjnym)
przesłanej do KSeF, wymaga podania:
• numeru faktury korygującej, o którym mowa w art. 106j ust. 2 pkt 2 ustawy (wartość z
pola P_2),
• identyfikatora podatkowego NIP lub innego identyfikatora nabywcy towarów lub usług
albo informacji o braku identyfikatora,
• kwoty należności ogółem zawartej w fakturze korygującej, o której mowa w art. 106e
ust. 1 pkt 15 ustawy (wartość z pola P_15).
9 Proces legislacyjny w toku: https://legislacja.rcl.gov.pl/projekt/12379252.
76

---

Przykład 14. Przebieg procesu uzyskania dostępu do faktury z wykorzystaniem kodu QR.
Podatnik „X” wystawił fakturę ustrukturyzowaną (w trybie ONLINE) na rzecz nabywcy
nieposiadającego siedziby ani stałego miejsca prowadzenia działalności gospodarczej na
terytorium kraju oraz przekazał mu ją w sposób uzgodniony – papierowo. Faktura w postaci
zwizualizowanej została opatrzona kodem weryfikującym QR.
Nabywca może zeskanować kod QR i sprawdzić czy sprzedawca faktycznie przesłał fakturę do
KSeF. Po wprowadzeniu danych dostępowych będzie mógł natomiast pobrać fakturę i
zweryfikować czy dane znajdujące się w KSeF są zbieżne z danymi w otrzymanym wydruku.
Przykład 15. Przebieg dwuetapowego dostępu do faktury.
KROK 1 Zeskanowanie kodu QR
2a 2b
Wyświetlenie podstawowych danych Brak wyświetlenia podstawowych
faktury: danych faktury
• Nr KSeF faktury, • Informacja o braku danej faktury w
• NIP sprzedawcy, KSeF
• Data wystawienia faktury,
• Skrót dokumentu,
KONIEC PROCESU
• Typ schemy,
• Data otrzymania faktury.
4
KROK 2
Wskazanie przez podatnika danych dostępowych do
faktury:
• Nr faktury nadany przez podatnika,
Pobranie 5 • Identyfikator podatkowy nabywcy lub informacja o jego
braku,
faktury z KSeF
• Kwota należności ogółem na fakturze.
77

---

Opis procesu:
1 - nabywca skanuje kod QR znajdujący się na wydruku faktury,
2a - w przypadku, gdy faktura identyfikowana danym kodem QR znajduje się w KSeF
wyświetlone zostają jej podstawowe dane tj.:
• Nr KSeF faktury,
• NIP sprzedawcy,
• Data wystawienia faktury,
• Skrót dokumentu,
• Typ schemy,
• Data otrzymania faktury,
• Informacja czy faktura była modyfikowana przed wysyłką (dotyczy wyłącznie faktur
wystawionych w trybie OFFLINE).
2b - w przypadku, gdy faktura identyfikowana danym kodem QR nie zostanie znaleziona w
systemie, wówczas pojawi się komunikat o braku danej faktury w KSeF i na tym etapie proces
zostanie zakończony,
3 - w przypadku wskazanym w pkt 2a podatnik będzie mógł przejść do kolejnego kroku w celu
pobrania faktury,
4 - w przypadku wskazanym w pkt 2a podatnik poda następnie dane dostępowe do faktury:
• Nr faktury nadany przez podatnika,
• Identyfikator podatkowy nabywcy lub informacja o jego braku,
• Kwota należności ogółem na fakturze.
5 - po wpisaniu prawidłowych danych dostępowych podatnik może pobrać fakturę z KSeF bez
konieczności uwierzytelnienia w systemie.
W przypadku wskazania kilka razy z rzędu błędnych danych dostępowych, nastąpi czasowa
blokada możliwości pobrania danej faktury. Blokada następuje na poziomie skrótu faktury
(SHA256).
78

---

5.6. Weryfikacja tożsamości wystawcy faktury w trybie OFFLINE z użyciem kodu QR
Jak wskazano we wcześniejszych rozdziałach, link/kod QR z napisem „CERTYFIKAT” (KOD II)
jest generowany wyłącznie w przypadku faktur wystawianych w trybie OFFLINE (offline24,
offline-niedostępność KSeF, tryb awaryjny) i umożliwia potwierdzenie tożsamości wystawcy
tej faktury. Aby ten kod QR wygenerować, bezwzględnie wymaganym warunkiem jest
posiadanie aktywnego certyfikatu KSeF. Wynika to z konieczności opatrzenia składników kodu
certyfikatem KSeF. Jest to zabezpieczenie przed sfałszowaniem linku/kodu QR przez podmioty
nieposiadające dostępu do certyfikatu.
API KSeF 2.0 będzie pozwalał na weryfikację certyfikatu należącego do wystawcy faktury po
przekazaniu odpowiednich danych do systemu (czyli po zeskanowaniu kodu QR lub kliknięciu w
link). System zwróci wynik weryfikacji danego certyfikatu KSeF, którym posłużono się przy
tworzeniu kodu QR i będzie obejmował m.in informację czy certyfikat KSeF istnieje w systemie,
czy certyfikat jest aktywny a jego właściciel ma uprawnienia do wystawiania faktur w
imieniu sprzedawcy.
Nie będą jednak zwracane dane osobowe powiązane z danym certyfikatem KSeF, który został
użyty do wystawienia faktury w trybie OFFLINE.
5.7. Anonimowy dostęp do faktury w KSeF (bez kodu QR)
W okresie fakultatywnego KSeF funkcjonowała usługa tzw. anonimowego dostępu do faktury
(https://ksef.mf.gov.pl/web/anonymous-access). Funkcjonalność ta nie wymaga
uwierzytelnienia się w systemie. Usługa anonimowego dostępu do faktury na okres
obligatoryjnego KSeF zostanie utrzymana. Nowe rozporządzenie w sprawie korzystania z
KSeF10 zawiera w tym zakresie odpowiednie regulacje, wskazujące na zakres danych, których
podanie jest konieczne, aby uzyskać dostęp do faktury11.
Zgodnie z § 8 rozporządzenia dostęp do faktury ustrukturyzowanej jest możliwy poprzez
podanie:
• numeru KSeF faktury,
• numeru faktury, o którym mowa w art. 106e ust. 1 pkt 2 ustawy (wartość z pola P_2),
• numeru identyfikacji podatkowej (NIP) lub innego identyfikatora nabywcy towarów lub
usług, albo informacji o braku identyfikatora,
• imienia i nazwiska lub nazwy nabywcy towarów lub usług albo informacji o braku tych
danych,
10 Proces legislacyjny w toku: https://legislacja.rcl.gov.pl/projekt/12379252.
11 Proces legislacyjny w toku: https://legislacja.rcl.gov.pl/projekt/12379252.
79

---

• kwoty należności ogółem, o której mowa w art. 106e ust. 1 pkt 15 ustawy (wartość z pola
P_15).
Dostęp do faktury korygującej w postaci faktury ustrukturyzowanej jest możliwy poprzez
podanie:
• numeru KSeF faktury korygującej,
• numeru faktury korygującej, o którym mowa w art. 106j ust. 2 pkt 2 ustawy (wartość z
pola P_2),
• numeru identyfikacji podatkowej (NIP) lub innego identyfikatora nabywcy towarów lub
usług, albo informacji o braku identyfikatora,
• imienia i nazwiska lub nazwy nabywcy towarów lub usług albo informacji o braku tych
danych,
• kwoty należności ogółem, o której mowa w art. 106e ust. 1 pkt 15 ustawy (wartość z pola
P_15) zawartej w fakturze korygującej.
Grafika 1.Anonimowe pobranie faktury – krok 1.
W ramach pierwszego kroku uzyskania anonimowego dostępu do faktury, należy wskazać jej
numer KSeF i wybrać „Dalej”.
80

---

Grafika 2. Anonimowe pobranie faktury – krok 2.
W ramach drugiego kroku należy wskazać numer faktury nadany przez sprzedawcę,
identyfikator podatkowy nabywcy lub informację o jego braku, podać imię i nazwisko lub
nazwę nabywcy (o ile faktura zawiera takie dane) oraz kwotę należności ogółem. Następnie, po
wprowadzeniu wszystkich danych należy wybrać „Wyszukaj fakturę”.
81

---

Grafika 3. Anonimowe pobranie faktury – krok 3.
System zweryfikuje, czy faktura o wskazanych parametrach znajduje się w systemie. Podatnik
będzie mógł wybrać format pliku oraz pobrać go na dysk swojego komputera.
Grafika 4. Anonimowe pobranie faktury – krok 4.
Po pobraniu faktury pojawi się komunikat potwierdzający pobranie pliku.
82

---

Grafika 5. Anonimowe pobranie faktury – wskazanie błędnych danych dostępowych.
W przypadku, gdy podatnik wskaże choć jedną informację błędnie, pojawi się komunikat o
braku znalezienia faktury spełniającej zadeklarowane parametry. W tym przypadku należy
przejść przez proces od początku, weryfikując źródło błędu i wskazując poprawne dane
faktury.
W okresie obligatoryjnego KSeF funkcjonować więc będą dwie metody uzyskania dostępu do
faktury, które nie wymagają uwierzytelnienia w systemie. Tzw. dostęp dwuetapowy (z
linkiem/kodem QR) w porównaniu do dostępu anonimowego jest jednak narzędziem
udoskonalonym, ponieważ pozwala zidentyfikować dany dokument w systemie bez
konieczności wprowadzania ręcznie numeru KSeF, jak również nie wymaga podawania imienia,
nazwiska lub nazwy nabywcy.
6. Praktyczne kwestie związane z otrzymywaniem faktur w KSeF
6.1. Brak zgody nabywcy na otrzymywanie faktur w KSeF
W okresie fakultatywnym, zgodnie z art. 106na ust. 2 ustawy, otrzymywanie faktur
ustrukturyzowanych przy użyciu KSeF wymagało akceptacji odbiorcy faktury. Jeżeli odbiorca
faktury nie wyraził akceptacji, sprzedawca mógł wystawić fakturę ustrukturyzowaną w
systemie, ale miał obowiązek przesłać ją temu podmiotowi w postaci z nim uzgodnionej.
Na okres obligatoryjnego KSeF przepis ten zostaje uchylony, co oznacza przyjęcie generalnej i
powszechnej zasady, że otrzymywanie faktur w KSeF staje się obowiązkowe (art. 106gb ust. 1
ustawy wchodzący w życie z dniem 1 lutego 2026 r.). Szczególnie traktowane będą jedynie
podmioty wymienione w art. 106gb ust. 4 ustawy (np. podmioty zagraniczne, konsumenci czy
podmioty nieposiadające identyfikatora podatkowego NIP – którym fakturę będzie należało
wydać w sposób z nimi uzgodniony, czyli np. papierowo lub elektronicznie).
83

---

WAŻNE
W okresie obligatoryjnym nabywca nie będzie mógł wyrazić braku akceptacji na otrzymanie
faktury w KSeF.
6.2. Otrzymywanie faktur przez nabywcę, który odbiera faktury w KSeF od 1 lutego
2026 r., ale będzie wystawiał faktury w KSeF dopiero od 1 kwietnia 2026 r. lub od 1
stycznia 2027 r.
Jak wskazano na wstępie Podręcznika KSeF 2.0 obowiązek wystawiania faktur w KSeF nastąpi
od:
• 1 lutego 2026 r. dla podatników, u których wartość sprzedaży (wraz z kwotą podatku)
przekroczyła w 2024 r. 200 mln zł,
• 1 kwietnia 2026 r. dla pozostałych podatników.
WAŻNE
Odroczenie terminów KSeF w stosunku do niektórych podatników (do 1 kwietnia 2026 r. lub 1
stycznia 2027 r. dla najmniejszych przedsiębiorców) dotyczy wyłącznie obowiązku
wystawiania faktur ustrukturyzowanych, a nie ich otrzymywania. Otrzymywanie faktur przy
użyciu KSeF będzie obowiązkowe już od 1 lutego 2026 r. (poza przypadkami wyłączonymi
ustawowo, gdzie faktura jest przekazana w sposób uzgodniony).
Podstawową metodą uzyskania dostępu do otrzymanych faktur jest uwierzytelnienie się
podatnika lub osoby bądź podmiotu przez niego uprawnionego w KSeF (w kontekście tego
podatnika), w dowolnym narzędziu zintegrowanym z API KSeF 2.0.
Obowiązek otrzymywania faktur przy użyciu KSeF nie oznacza jednak, że na dzień 1 lutego
2026 r. wszyscy podatnicy (nawet Ci, którzy będą wystawiać faktury w systemie od 1 kwietnia
2026 r. lub od 1 stycznia 2027 r.) muszą posiadać już zintegrowany z KSeF 2.0 program do
wystawiania lub odbierania faktur oraz będą zobowiązani uwierzytelniać się w systemie.
W okresie przejściowym, dla podatnika który jeszcze nie będzie posiada zintegrowanego
narzędzia do wystawiania i otrzymywania faktur w KSeF, alternatywą będzie korzystanie z
bezpłatnych narzędzi udostępnianych przez MF tj. Aplikacja Podatnika KSeF, Aplikacja
Mobilna KSeF czy e-mikrofirma. Narzędzia te po uwierzytelnieniu się w systemie zapewnią
dostęp do otrzymanych faktur zakupowych. Aplikacje te mogą także stanowić docelowe
narzędzie, przy użyciu których podatnik objęty obowiązkiem wystawiania faktur w KSeF od 1
kwietnia 2026 r. lub od 1 stycznia 2027 r. będzie mógł także wywiązać się z tego obowiązku. Z
84

---

KSeF można bowiem korzystać za pomocą narzędzi oferowanych przez MF lub przy użyciu
komercyjnych programów, które zostaną zintegrowane z API KSeF 2.0.
Należy zwrócić uwagę, że sprzedawcy (objęci obowiązkiem wystawiania faktur w KSeF od 1
lutego 2026 r.), którzy będą dokonywali sprzedaży i wystawiali faktury na rzecz podatników
objętych obowiązkowym KSeF od 1 kwietnia 2026 r. lub od 1 stycznia 2027 r., poza
przesłaniem faktury do KSeF, nie będą wydawać faktury poza systemem nabywcom krajowym
posiadającym identyfikator podatkowy NIP.
Warto jednak zwrócić w tym miejscu uwagę, na zasady wydawania dokumentów poza KSeF, w
tym tzw. potwierdzeń transakcji, opisane szczegółowo w podrozdziale: 1.4.6. Możliwość
wydania nabywcy „potwierdzenia transakcji”. Dzięki ww. rozwiązaniu nabywcy Ci dostęp do
otrzymanej e-Faktury będą mogli uzyskać bez konieczności uwierzytelnienia się w systemie,
przy użyciu usługi tzw. dwuetapowego dostępu do faktury (tj. po zeskanowaniu kodu QR lub
kliknięciu w link oraz po wprowadzeniu danych dostępowych do faktury). Nabywca, na rzecz
którego wystawiono fakturę, będzie mógł pobrać bezpośrednio z KSeF fakturę i skorzystać z
przysługującego mu prawa do odliczenia VAT (zakładając spełnienie wszystkich ustawowych
przesłanek).
Powyższe rozwiązanie (związane m.in. z wydawaniem potwierdzenia transakcji) można
oczywiście stosować nie tylko w ww. okresie przejściowym, niemniej w tej szczególnej sytuacji
będzie ono bardzo przydatne. Istotne będzie głównie dla podatników, którzy otrzymują
niewielką liczbę faktur zakupowych. W przypadku bowiem otrzymywania setek lub tysięcy
faktur zakupowych w miesiącu efektywniejsze będzie pobieranie faktur wprost z systemu
(masowo), po uprzednim zalogowaniu się do KSeF podatnika lub osoby bądź podmiotu przez
niego uprawnionego. Decyzja o wyborze optymalnej metody pobierania faktury z KSeF należy
więc do podatnika i będzie podyktowania specyfiką i skalą jego działalności oraz ilością
otrzymywanych faktur zakupowych.
6.3. Brak możliwości odrzucenia faktury przez podmiot wskazany jako nabywca
W życiu gospodarczym zdarzają się sytuację, w których nabywca nie akceptuje treści
otrzymanej faktury lub w ogóle faktu jej otrzymania. Warto jednak zaznaczyć, że podstawowe
funkcjonalności systemu to wystawianie, otrzymywanie i dostęp do faktur. KSeF nie posiada
opcji zatwierdzania lub odrzucania faktur po otrzymaniu ich przez nabywcę. Wyjaśnienie
ewentualnych wątpliwości co do zasadności wystawienia danej faktury, zidentyfikowanych w
niej błędów czy rozstrzygnięcie potencjalnych sporów pomiędzy sprzedawcą a nabywcą
odbywa się całkowicie poza systemem.
85

---

W systemie będzie widoczny jedynie efekt tych wyjaśnień i rozstrzygnięć, gdyż:
• Jeśli sprzedawca dokonał sprzedaży na rzecz podmiotu A (z identyfikatorem
podatkowym podmiotu A), ale przez pomyłkę wystawił fakturę na podmiot B (z
identyfikatorem podatkowym NIP podmiotu B) - zobowiązany będzie do wystawienia
faktury korygującej "do zera" i wystawienia poprawnej, nowej faktury z prawidłowymi
danymi nabywcy „A” (w tym w szczególności z jego prawidłowym identyfikatorem
podatkowym NIP).
Jak wskazano wyżej, KSeF nie przewiduje funkcjonalności odrzucenia przez podmiot
„B” nieprawidłowo wystawionej na jego rzecz faktury. Nabywca będzie mógł skorzystać
ewentualnie z opcji ukrycia faktury lub w uzasadnionych sytuacjach – opcji zgłoszenia
faktury scamowej. Funkcjonalności te została opisane w cz. III Podręcznika KSeF 2.0.
Zostaną ona wdrożone produkcyjnie kilka miesięcy po uruchomieniu KSeF 2.0 w wersji
produkcyjnej.
• Jeżeli sprzedawca wystawił fakturę zawierającą np. błędy w podstawie opodatkowania
lub kwocie podatku bądź jakiejkolwiek innej pozycji faktury – to jest zobowiązany na
podstawie art. 106j ust. 1 ustawy do wystawienia faktury korygującej.
6.4. Brak powiadomień systemowych o otrzymaniu faktury w KSeF
KSeF nie wysyła automatycznie powiadomień systemowych o otrzymaniu nowej faktury w
systemie. Taka możliwość nie jest zakładana, z uwagi na to, że dla podatników otrzymujących
bardzo duże ilości faktur mogłoby to być utrudnieniem, a nie ułatwieniem. W celu uzyskania
informacji o dostępnych fakturach program wykorzystywany przez podatnika będzie musiał
„odpytywać” KSeF. Nie jest natomiast wykluczone wprowadzanie takiej funkcjonalności
lokalnie, na poziomie poszczególnych programów finansowo-księgowych.
6.5. Brak możliwości sprawdzenia, że nabywca pobrał fakturę z KSeF
Faktury są udostępniane nabywcy w KSeF w czasie rzeczywistym. Następuje to w momencie
przydzielenia fakturze numeru KSeF. Nabywca lub osoba bądź podmiot przez nią uprawniony
mogą pobierać jedną fakturę wielokrotnie. Sprzedawca nie uzyska jednak informacji
systemowej czy dana faktura została już pobrana przez nabywcę ani ile razy to nastąpiło.
86

---

7. Przechowywanie faktur w KSeF
W KSeF są przechowywane:
• faktury ustrukturyzowane,
• faktury wystawione w trybach OFFLINE (tj. w trybie offline24 - zgodnie z art. 106nda ust.
1 ustawy, w trybie awarii - zgodnie art. 106nf ust. 1 ustawy oraz w trybie offline –
niedostępność KSeF – zgodnie z art. 106nh ust. 1 ustawy), po przesłaniu ich do KSeF
przez okres 10 lat, licząc od końca roku, w którym zostały wystawione. Przepisów art. 112 i art.
112a ustawy w tym przypadku nie stosuje się. Oznacza to, że podatnicy w tym okresie nie są
zobowiązani do przechowywania ww. faktur we własnym zakresie, przy zachowaniu warunków
szczegółowych wskazanych w tych regulacjach.
W KSeF przechowywane są również faktury VAT RR oraz faktury VAT RR KOREKTA
wystawione przy użyciu KSeF (w trybie ONLINE) oraz wystawione w trybie offline24 (po
dosłaniu do systemu) – zgodnie z art. 116 ust. 11 ustawy.
Przyjęcie 10-letniego okresu przechowywania faktur w KSeF, zapewnia, że większość
zobowiązań podatkowych w tym czasie się już przedawni. Okres 10 -letni jest również
związany z okresem dokonywania korekt podatku naliczonego w podatku VAT (w przypadku
nieruchomości).
Ponadto dzięki przechowywaniu faktur w KSeF niezasadne staje się żądanie udostępniania
tych dokumentów przez podatnika. W uzasadnionych przypadkach pracownicy administracji
skarbowej będą mogli bowiem uzyskać dostęp do faktur podatnika. Funkcjonalność ta ułatwi
więc kontrolę dokumentacji podatkowej, a jednocześnie odciąży podatników od obecnie
wymaganego obowiązku dostarczania faktur do urzędu skarbowego, np. w czasie prowadzenia
postępowań wyjaśniających.
Jeżeli 10-letni okres przechowywania faktur, upłynie przed upływem terminu przedawnienia
zobowiązania podatkowego, podatnik będzie przechowywał faktury, o których mowa wyżej,
poza KSeF do czasu upływu terminu przedawnienia zobowiązania podatkowego z
uwzględnieniem warunków określonych w art. 112 i 112a ustawy (m.in. w podziale na okresy
rozliczeniowe, w sposób zapewniający łatwe ich odszukanie). W tym przypadku podatnik
powinien pobrać faktury z KSeF z odpowiednim wyprzedzeniem, aby ustrzec się sytuacji, gdy,
okres przedawnienia jeszcze nie minął a pobranie faktur nie będzie już możliwe, z uwagi na ich
usunięcie z systemu.
87

---

Przykład 16. Przechowywanie faktur w KSeF.
PODATNIK KSeF
2 3
ZEWNĘTRZNY NOŚNIK DANYCH
1 - wysyłka pliku XML do KSeF w dniu 5 lutego 2026 r.,
2 - nadanie numeru KSeF e-Faktury,
3 - przechowywanie e-Faktury w KSeF do 31 grudnia 2036 r. (10 lat od końca roku 2026),
4 - pobranie e-Faktury z KSeF najpóźniej do dnia 31 grudnia 2036 r. przez podatnika,
5 - przechowywanie e-Faktury poza KSeF przez podatnika do czasu upływu przedawnienia
zobowiązania podatkowego.
88

---

Spis grafik
Grafika 1.Anonimowe pobranie faktury – krok 1. .......................................................................................80
Grafika 2. Anonimowe pobranie faktury – krok 2. ......................................................................................81
Grafika 3. Anonimowe pobranie faktury – krok 3. ......................................................................................82
Grafika 4. Anonimowe pobranie faktury – krok 4. ......................................................................................82
Grafika 5. Anonimowe pobranie faktury – wskazanie błędnych danych dostępowych. ...............83
89

---

Spis przykładów
Przykład 1. Data wystawienia faktury w trybie ONLINE (data w polu P_1 tożsama z datą
przesłania pliku XML do KSeF). ........................................................................................................................... 6
Przykład 2. Data wystawienia faktury w trybie ONLINE (data przesłania pliku XML do KSeF
późniejsza niż data wskazana w polu P_1). ....................................................................................................... 6
Przykład 3. Odrzucenie pliku XML faktury. ..................................................................................................... 7
Przykład 4. Przykładowe potwierdzenie transakcji. ..................................................................................19
Przykład 5. Kolejny numer faktury a odrzucenie pliku XML przez system. .......................................21
Przykład 6. Przebieg wysyłki interaktywnej. ................................................................................................56
Przykład 7. Przebieg wysyłki wsadowej. ........................................................................................................57
Przykład 8. Przykładowy przebieg procesu płatności w ramach MPP z wykorzystaniem numeru
KSeF faktury .............................................................................................................................................................62
Przykład 9. Wizualizacja Urzędowego Poświadczenia Odbioru. ...........................................................66
Przykład 10. Data otrzymania faktury w przypadku nabywcy krajowego (podatnika
posiadającego NIP). ................................................................................................................................................68
Przykład 11. Data otrzymania faktury w przypadku nabywcy zagranicznego. ................................68
Przykład 12. Przykładowy kod graficzny QR dla faktury ONLINE i OFFLINE (KOD I) .................73
Przykład 13. Przykładowy kod graficzny QR dla faktury OFFLINE (KOD II). ...................................75
Przykład 14. Przebieg procesu uzyskania dostępu do faktury z wykorzystaniem kodu QR. .......77
Przykład 15. Przebieg dwuetapowego dostępu do faktury. ....................................................................77
Przykład 16. Przechowywanie faktur w KSeF. .............................................................................................88
90

---

Spis schematów
Schemat 1. Proces wystawienia faktury w KSeF – działania w systemie. ............................................. 9
Schemat 2. Dokument wydawany nabywcy poza KSeF w przypadku faktury wystawianej w
trybie ONLINE. ........................................................................................................................................................16
Schemat 3. Dokument wydawany nabywcy poza KSeF w przypadku faktury wystawianej w
trybie offline24 i offline-niedostępność KSeF. .............................................................................................17
Schemat 4. Dokument wydawany nabywcy poza KSeF w przypadku faktury wystawianej w
trybie awaryjnym. ...................................................................................................................................................18
Schemat 5. Schemat główny struktury logicznej FA(3). ............................................................................22
Schemat 6. Element RachunekBankowyFaktora w strukturze FA(3). .................................................28
Schemat 7. Element DodatkowyOpis w strukturze FA(3). .......................................................................31
Schemat 8. Element DaneFaKorygowanej w strukturze logicznej FA(3)............................................46
Schemat 9. Element Rozliczenie w strukturze FA(3). .................................................................................50
Schemat 10. Elementy numeru KSeF faktury. ..............................................................................................59
Schemat 11. Wykorzystanie numeru KSeF faktury. ...................................................................................59
Schemat 12. Element FakturaZaliczkowa w strukturze FA(3). ..............................................................61
Schemat 13. Proces pobrania faktury z KSeF (z uwierzytelnieniem). ..................................................70
91

---

Spis tabel
Tabela 1. Sposób prezentacji w strukturze FA(3) identyfikatora podatkowego NIP. ....................24
Tabela 2. Sposób prezentacji w strukturze FA(3) dwuliterowego prefiksu sprzedawcy. ..............24
Tabela 3. Sposób prezentacji w strukturze FA(3) dwuliterowego prefiksu oraz numeru
identyfikacyjnego nabywcy. ...............................................................................................................................24
Tabela 4. Sposób prezentacji w strukturze FA(3) identyfikatora podatkowego NIP. ....................25
Tabela 5. Sposób prezentacji w strukturze FA(3) identyfikatora podatkowego kontrahenta z
kraju trzeciego. ........................................................................................................................................................25
Tabela 6. Sposób prezentacji w strukturze FA(3) przypadku, gdy nabywca jest konsumentem.26
Tabela 7. Sposób wypełnienia struktury FA(3) w celu identyfikacji wydatków pracowniczych. 51
Tabela 8. Sposób wypełnienia struktury FA(3) w celu identyfikacji wydatków pracowniczych. 52
Tabela 9. Sposób wypełnienia struktury FA(3) w celu identyfikacji wydatków pracowniczych. 52
92

---

Rejestr zmian
Rozdział/strona Opis zmiany
3.1 (str. 53) Aktualizacja informacji dot. Aplikacji Podatnika KSeF (terminy
uruchomienia poszczególnych wersji aplikacji).
3.2.2. (str. 54) Uszczegółowienie zasad funkcjonowania środowiska
przedprodukcyjnego (DEMO).
3.3.1. oraz 3.3.2 Aktualizacja informacji dot. wysyłki interaktywnej i wsadowej (w
(str. 56-57) tym limitu faktur w sesji).
4.1. (str. 58-59) Aktualizacja założeń dot. elementów numeru KSeF.
4.2 (str. 66-67) Aktualizacja wizualizacji UPO.
5.4 (str. 72) Zmiana normy ISO/IEC 18004:2015 na ISO/IEC 18004:2024.
93