# FAQ z https://ksef.podatki.gov.pl/pytania-i-odpowiedzi-ksef/

## 1.Jaki jest planowany termin wdrożenia obowiązkowego KSeF? Kiedy zostaną opublikowane rozporządzenia wykonawcze dotyczące KSeF?

Obowiązkowy KSeF wejdzie w życie etapowo, tj.: od 1 lutego 2026 r. dla przedsiębiorców, których wartość sprzedaży (wraz z kwotą podatku) przekroczyła w 2025 r. 200 mln zł, od 1 kwietnia 2026 r. dla pozostałych przedsiębiorców. Proces legislacyjny składa się z dwóch etapów. W ramach I etapu legislacji opublikowana została ustawa z dnia 9 maja 2024 r. zmieniająca ustawę o zmianie ustawy o podatku od towarów i usług oraz niektórych innych ustaw (Dz. U. z 2024 r. poz. 852) , która m.in. odroczyła termin obowiązkowego KSeF z 1 lipca 2024 r. na 1 lutego 2026 r. Odroczone zostały także terminy stosowania sankcji  i obowiązku dokonywania płatności z wykorzystaniem nr KSeF/zbiorczego identyfikatora płatności pomiędzy podatnikami czynnymi. Aktualnie trwają prace legislacyjne w zakresie II etapu legislacji. Planowane jest także wznowienie prac nad aktami wykonawczymi dotyczącymi KSeF.

## 2.Jak zmiana wpłynie na koszty biznesu związane z przygotowaniem się do korzystania z KSeF? Czy konieczny będzie zakup licencji do zaktualizowanych programów księgowych zintegrowanych z KSeF? Czy konieczne będzie ponowne przeszkolenie pracowników? Czy przedsiębiorcy będą musieli ponosić koszty pozostawania w gotowości do wdrożenia obowiązkowego KSeF?

Odroczenie terminu nie powinno wiązać się z dużymi kosztami po stronie przedsiębiorców. Przesuniecie terminu obowiązkowego KSeF zapewni im dodatkowy czas na wdrożenie systemu. Nadal możliwe jest prowadzenie prac związanych z integracją systemów komercyjnych z KSeF. W związku licznymi postulatami rynku zgłaszanymi podczas przeprowadzonych w lutym i marcu 2024 r. konsultacji publicznych – została podjęta decyzja o modyfikacji struktury FA(2). Konieczne będzie więc dostosowanie programów do nowej wersji struktury. Ministerstwo Finansów dostrzega konieczność przeprowadzenia szerokich szkoleń przez administrację dla przedsiębiorców i ich pracowników. W związku z tym w drugiej połowie 2024 r. w każdym z 400 urzędów skarbowych będzie można odbyć praktyczne szkolenie z przepisów wprowadzających obowiązkowy KSeF oraz z korzystania z darmowego oprogramowania do wystawiania e-faktur.

## 3.Czy modyfikowane będą narzędzia udostępnione przez Ministerstwo Finansów, z których już korzystają przedsiębiorcy tj. Aplikacja Podatnika KSeF, e-mikrofirma?

Bezpłatne narzędzia do e-fakturowania, udostępnione przez Ministerstwo Finansów są dostępne i zachęcamy do ich testowania. Podatnicy korzystający już z KSeF mogą nadal wystawiać e-faktury w tym systemie. Trwają prace nad dostosowaniem narzędzi do funkcjonalności KSeF związanych z obligatoryjnym e-fakturowaniem. Część z tych funkcjonalności jest już dostępna w wersji testowej Aplikacji Podatnika KSeF. Udostępniona została także Aplikacja Mobilna KSeF.

## 4.Czy unijne prace dotyczące pakietu VIDA wpłyną na sposób przygotowań do polskiego KSeF?

Prace związane z wdrożeniem unijnego pakietu VIDA znajdują się dopiero we wstępnej fazie. Polska zabiega w KE, aby pakiet VIDA nie wpływał na funkcjonalności KSeF.

## 5.Czy zmiany będą powodowały konieczność dostosowania przez producentów dostępnych już na rynku komercyjnych programów księgowych do „nowej wersji” KSeF?

W związku licznymi postulatami rynku zgłaszanymi podczas przeprowadzonych w lutym i marcu b.r. konsultacji publicznych – została podjęta decyzja o modyfikacji struktury FA(2). Konieczne będzie więc dostosowanie programów do nowej wersji struktury. Ponadto na podstawie wyników audytu informatycznego Ministerstwo Finansów zdecydowało o budowie nowej architektury KSeF, jednak z perspektywy integratorów nie powinny nastąpić diametralne zmiany

## 6.Czy Ministerstwo Finansów dopuszcza scenariusz, w którym w ogóle KSeF nie będzie wdrażany?

Nie jest planowana rezygnacja z wdrożenia KSeF w wersji obligatoryjnej.

## 7.Czy Ministerstwo Finansów planuje zmiany opublikowanych już rozporządzeń wykonawczych?

Tak, w związku z wprowadzeniem obowiązkowego KSeF uchylone zostanie rozporządzenie Ministra Finansów z dnia 27.12.2021 r. w sprawie korzystania z Krajowego Systemu e-Faktur (Dz. U. z 2021 r. poz. 2481 ze zm.). Zaznaczyć jednak należy, że w to miejsce opublikowane zostanie nowe rozporządzenie wykonawcze, którego zapisy częściowo będą pokrywać się z dotychczasowym brzmieniem, a w części będą to nowe regulacje dedykowane wersji obligatoryjnej systemu (kody QR, dostęp dwuetapowy do faktur, certyfikaty wewnętrzne). Ponadto 27 czerwca 2024 r. została opublikowana nowelizacja rozporządzenia JPK. Nowelizacja obejmuje m.in. nowy przedział czasowy, w którym podatnicy nie będą musieli wykazywać numeru KSeF faktury w ewidencji sprzedaży (1 lutego 2026 r. - 31 lipca 2026 r.). Ministerstwo Finansów podejmuje działania w celu niezwłocznego zakończeniu całego procesu legislacyjnego związanego z odroczeniem KSeF (nowelizacja ustawy, prace nad aktami wykonawczymi), kładąc przy tym także nacisk na przeprowadzenie dialogu z rynkiem i konsultacji publicznych.

## 8.Jak obecnie pod kątem obowiązkowego KSeF wygląda kwestia fakturowania przez podmiot zagraniczny lub gdy występuje on w roli nabywcy? Dlaczego podmioty zagraniczne są wyłączone z obowiązkowego KSeF?

Wyłączenie z obowiązku wystawiania w KSeF faktur przez: podatnika nieposiadającego siedziby działalności gospodarczej ani stałego miejsca prowadzenia działalności gospodarczej na terytorium kraju; podatnika nieposiadającego siedziby działalności gospodarczej na terytorium kraju, który posiada stałe miejsce prowadzenia działalności gospodarczej na terytorium kraju, przy czym to stałe miejsce prowadzenia działalności nie uczestniczy w dostawie towarów lub świadczeniu usług, dla których wystawiono fakturę wynika z Decyzji wykonawczej Rady (UE) 2022/1003 z dnia 17 czerwca 2022 r. upoważniającej Rzeczpospolitą Polską do stosowania szczególnego środka stanowiącego odstępstwo od art. 218 i 232 dyrektywy 2006/112/WE w sprawie wspólnego systemu podatku od wartości dodanej. Jeżeli natomiast chodzi o sytuację, gdy w roli nabywcy wystąpi: podmiot nieposiadający siedziby działalności gospodarczej ani stałego miejsca prowadzenia działalności gospodarczej na terytorium kraju, lub podmiot nieposiadający siedziby działalności gospodarczej na terytorium kraju, który posiada stałe miejsce prowadzenia działalności gospodarczej na terytorium kraju, przy czym to stałe miejsce prowadzenia działalności nie uczestniczy w nabyciu towaru lub usługi, dla którego wystawiono fakturę - faktura ustrukturyzowana będzie udostępniana nabywcy w sposób z nim uzgodniony. Przepisy nie wskazują konkretnego sposobu udostępnienia faktury nabywcy. Może to być np. przekazanie faktury w postaci papierowej lub np. wysyłka faktury w postaci pliku pdf (w wiadomości e-mail). Sposób udostępnienia podatnik powinien uzgodnić z nabywcą.

## 9.Do kiedy paragony fiskalne z NIP nabywcy będą uznawane za fakturę uproszczoną i będą wyłączone z obowiązkowego KSeF?

Planowane jest odroczenie likwidacji wystawiania faktur z kasy rejestrującej do końca lipca 2026 r

## 10.Czy zagraniczny podmiot zarejestrowany jako podatnik VAT w Polsce, ale nieposiadający siedziby w Polsce, spełnia kryteria posiadania stałego miejsca prowadzenia działalności na terytorium Polski i tym samym jest objęty obowiązkiem e-fakturowania? 
Jak podatnicy mają zabezpieczyć weryfikację kontrahenta pod kątem siedziby lub stałego miejsca prowadzenia działalności gospodarczej, czy samo oświadczenie kontrahenta zagranicznego wystarczy?

Zgodnie z aktualnym brzmieniem przepisów wprowadzających KSeF w wersji obligatoryjnej, obowiązkiem tym nie będą objęte m.in. faktury wystawiane przez: podatnika nieposiadającego siedziby działalności gospodarczej ani stałego miejsca prowadzenia działalności gospodarczej na terytorium kraju; podatnika nieposiadającego siedziby działalności gospodarczej na terytorium kraju, który posiada stałe miejsce prowadzenia działalności gospodarczej na terytorium kraju, przy czym to stałe miejsce prowadzenia działalności nie uczestniczy w dostawie towarów lub świadczeniu usług, dla których wystawiono fakturę Powyższe wynika z Decyzji wykonawczej Rady (UE) 2022/1003 z dnia 17 czerwca 2022 r. upoważniającej Rzeczpospolitą Polską do stosowania szczególnego środka stanowiącego odstępstwo od art. 218 i 232 dyrektywy 2006/112/WE w sprawie wspólnego systemu podatku od wartości dodanej. Ocena czy dany podmiot zagraniczny, zarejestrowany jako podatnik VAT czynny w Polsce posiada na terytorium kraju stałe miejsce prowadzenia działalności gospodarczej wymaga indywidualnej oceny konkretnego stanu faktycznego. Planowane jest wydanie wyjaśnień odnoszących się do kwestii związanych z definicją stałego miejsca prowadzenia działalności gospodarczej, co jest kluczowe dla określenia czy dany przedsiębiorca będzie objęty obowiązkowym e-fakturowaniem.

## 11.Kiedy zostaną przeprowadzone prace mające na celu poprawę przepustowości systemu?

Na podstawie wyników audytu została podjęta decyzja o budowie architektury systemowej od początku. Wykonawca powołał zespół specjalistów od architektury IT. Aktualnie prowadzone są intensywne prace informatyczne. Ministerstwo Finansów stale monitoruje ich postęp.

## 12.Czy faktury wystawiane na rzecz osób fizycznych prowadzących działalność gospodarczą, które dotyczą zakupu towarów lub usług na użytek prywatny będą wyłączone z obowiązkowego KSeF? W jaki sposób należy odróżnić/weryfikować podatnika od konsumenta na gruncie KSeF, zwłaszcza, że część podatników nie ma numeru NIP? 
W jaki sposób podatnik ma dokonywać weryfikacji statusu kontrahenta, czy samo kryterium posiadania NIP będzie uznane za prawidłowe, żeby zakwalifikować kontrahenta do KSeF?

Temat faktur konsumenckich (dotyczący także sytuacji, gdy zakupu dokonuje podmiot prowadzący działalność, ale zakup następuje na cele prywatne) był przedmiotem dyskusji podczas przeprowadzonych prekonsultacji w dniu 18 lipca 2024 r. W wyniku zgłoszonych opinii, w udostępnionym do konsultacji projekcie zaproponowano, aby faktury B2C były przesyłane do KSeF fakultatywnie. W powyższym projekcie zostały zawarte również rozwiązania związane z identyfikacją podatników zwolnionych na potrzeby KSeF (tzw. samoidentyfikacja nabywcy).

## 13.Czy nałożenie obowiązku fakturowania w KSeF przez podatników zagranicznych, którzy mają w Polsce stałe miejsce prowadzenia działalności gospodarczej, jest zgodne z prawem UE?

Wyłączenie z obowiązku wystawiania w KSeF faktur przez: podatnika nieposiadającego siedziby działalności gospodarczej ani stałego miejsca prowadzenia działalności gospodarczej na terytorium kraju; podatnika nieposiadającego siedziby działalności gospodarczej na terytorium kraju, który posiada stałe miejsce prowadzenia działalności gospodarczej na terytorium kraju, przy czym to stałe miejsce prowadzenia działalności nie uczestniczy w dostawie towarów lub świadczeniu usług, dla których wystawiono fakturę wynika z Decyzji wykonawczej Rady (UE) 2022/1003 z dnia 17 czerwca 2022 r. upoważniającej Rzeczpospolitą Polską do stosowania szczególnego środka stanowiącego odstępstwo od art. 218 i 232 dyrektywy 2006/112/WE w sprawie wspólnego systemu podatku od wartości dodanej. Zakłada się więc, że podatnicy nieposiadający siedziby działalności gospodarczej na terytorium Polski, ale posiadający na terytorium kraju stałe miejsce prowadzenia działalności gospodarczej uczestniczące w dostawie towarów lub świadczeniu usług, dla których wystawiana jest fakturę będą objęci obligatoryjnym e-fakturowaniem. Regulacja zawarta w dodawanym do ustawy art. 106ga ust. 2 ustawy o podatku od towarów i usług jest zatem zgodna z regulacjami UE.

## 14.Jakie błędy systemu KSeF zostały dotychczas wykryte?

Podsumowanie wyników przeprowadzonego audytu informatycznego KSeF zostało przedstawione podczas konferencji MF w dniu 26 kwietnia 2024 r.  i ujęte w poniższym komunikacie: Podsumowanie audytu KSeF .

## 15.Czy planowane jest zniesienie obowiązku podawania danych wszystkich faktur pierwotnych (numerów KSeF, dat wystawienia) w przypadku wystawiania faktur korygujących zbiorczych?

Struktura FA jest dostosowana do wystawiania faktur korygujących zbiorczych. W jednej fakturze korygującej można podać dane wielu faktur korygowanych. Wymóg podawania danych faktury korygowanej jest zgodny z treścią obowiązujących przepisów (art. 106j ust. 2 i ust. 3 ustawy o podatku od towarów i usług).

## 16.Czy nastąpi zniesienie planowanego obowiązku podawania numeru KSeF w tytule płatności, biorąc pod uwagę mnogość modeli rozliczeń między kontrahentami?

Nie jest planowane zniesienie obowiązku podawania numeru KSeF podczas dokonywania płatności za fakturę ustrukturyzowaną. Obowiązek ten będzie jednak stosowany dopiero do płatności dokonanych od dnia 1 sierpnia 2026 r.

## 17.W obecnym brzmieniu przepisów, obowiązek wystawienia faktury w KSeF dotyczył będzie między innymi faktur wystawianych na rzecz podatników zwolnionych z VAT. Jednocześnie jedyną możliwością weryfikacji statusu kontrahenta jest Wykaz Podatników VAT. Widoczni są na niej tylko podatnicy zarejestrowani jako podatnicy VAT czynni oraz zarejestrowani podatnicy VAT zwolnieni. Sprzedawcy nie mają więc możliwości identyfikacji podatników korzystających ze zwolnienia, którzy nie zarejestrowali się jako podatnicy VAT zwolnieni. Do takiej grupy kontrahentów należą np. osoby prowadzące najem prywatny, nieposiadające identyfikatora podatkowego NIP, ani wpisu do CEiDG. Jak Ministerstwo Finansów planuje wspomóc podatników we właściwej weryfikacji statusu kontrahentów?

W zakresie kwestii związanych z identyfikacją podatników zwolnionych na potrzeby KSeF, zostały zaproponowane odpowiednie rozwiązania w ramach II etapu legislacji (tzw. samoidentyfikacja nabywcy). Projekt wraz z uzasadnieniem jest dostępny na stronie Rządowego Centrum Legislacji .

## 18.Jaki jest szczegółowy harmonogram działań Ministerstwa Finansów dotyczący KSeF? Czy planowane jest odroczenie obowiązkowego KSeF do czasu wejścia w życie przepisów unijnych w zakresie  tzw. pakietu VIDA?

Nie jest planowane odroczenie KSeF do czasu wejścia w życie przepisów unijnych związanych z tzw. pakietem VIDA. Obowiązkowy KSeF wejdzie w życie etapowo, tj.: od 1 lutego 2026 r. dla przedsiębiorców, których wartość sprzedaży (wraz z kwotą podatku) przekroczyła w 2025 r. 200 mln zł, od 1 kwietnia 2026 r. dla pozostałych przedsiębiorców. Prace legislacyjne przebiegają w dwóch etapach, z czego jeden został ukończony a drugi etap trwa. Równolegle trwają prace techniczne związane ze stworzeniem nowej architektury systemu oraz dostosowaniem narzędzi (m.in. Aplikacji Podatnika KSeF) do wymagań obowiązkowego KSeF. Część funkcjonalności już została udostępniona na środowisku testowym. Planowane są także działania polegające na: tzw. wyrównaniu środowisk (testowego z przedprodukcyjnym i produkcyjnym) aby umożliwić stabilny proces integracji z KSeF, wdrożeniu załączników do faktur, aktualizacji struktury FA. Harmonogram działań związanych z KSeF został udostępniony na stronie Ministerstwa Finansów .

## 19.Które z dotychczas określonych wymagań funkcjonalnych dotyczących KSeF zostaną utrzymane w ostatecznym rozwiązaniu, a które zostaną zmienione i w jaki sposób? Przykładowo:
•	czy datą wystawienia faktury będzie nadal data przesłania faktury do KSeF?
•	czy transakcje B2C będą wyłączone z obowiązkowego KSeF?
•	czy zachowana zostanie numeracja faktur numerami identyfikującymi fakturę i konieczność pobrania tego numeru, daty wystawienia z KSeF do systemów wewnętrznych przedsiębiorców (np. dla potrzeb wystawiania faktur korygujących lub wskazania numeru identyfikującego fakturę w KSeF w przelewach)?
•	czy planowane są zmiany w strukturze dotyczące pola IDWew?

Nie są planowane zmiany dotyczące art. 106na ust. 1 ustawy o podatku od towarów i usług, w myśl którego fakturę ustrukturyzowaną uznaje się za wystawioną w dniu jej przesłania do Krajowego Systemu e-Faktur. Ministerstwo Finansów nie zdiagnozowało także potrzeby dokonania zmian związanych z nadawaniem i wykorzystywaniem numerów KSeF. Nie jest planowana likwidacja obowiązku wskazywania numeru KSeF faktury w przelewie. Obowiązek podawania numeru KSeF podczas dokonywania płatności za fakturę będzie dotyczył płatności realizowanych od 1 sierpnia 2026 r. Kwestia funkcjonowania w KSeF faktur B2C została omówiona z przedsiębiorcami podczas konsultacji publicznych w dniu 18 lipca 2024 r. W wyniku zgłoszonych opinii w udostępnionym do konsultacji projekcie zaproponowano, aby faktury B2C były przesyłane do KSeF fakultatywnie. Nie przewiduje się modyfikacji struktury FA w zakresie pola IDWew dotyczącego modelu uprawnień wykorzystującego unikalny identyfikator wewnętrzny zakładu (oddziału) osoby prawnej bądź innej wyodrębnionej jednostki wewnętrznej podatnika.

## 20.Jakie instrumenty wsparcia przewiduje Ministerstwo Finansów dla przedsiębiorców w związku z wydatkami już poniesionymi na wdrożenie KSeF i do zakończenia wdrożenia, a także wydatków już poniesionych, w przypadku ewentualnej zmiany wymagań dot. funkcjonalności?

Bezpośrednie korzyści biznesowe związane z KSeF przedsiębiorcy odczują po wdrożeniu systemu. Obligatoryjne e-fakturowanie będzie miało wpływ na usprawnienie obrotu gospodarczego przez wprowadzenie jednego standardu e-faktury, zamianę dokumentów papierowych i elektronicznych (PDF) na dane cyfrowe, a także cyfryzację i automatyzację obiegu faktur pomiędzy podatnikami oraz ich księgowania. Rozwiązanie to przyczyni się nie tylko do szybszego i sprawniejszego dokumentowania transakcji, ale również do przyspieszenia realizacji płatności. Nabywca będzie miał pewność, że faktura została wystawiona przez podmiot uprawniony. Dodatkowo wystawca faktury jest pewien, że odbiorca otrzymał fakturę. Ustrukturyzowany jednolity wzór faktury pozwoli na automatyzację procesów księgowych, co w konsekwencji przełoży na oszczędność czasu pracowników, który można wykorzystać w innych obszarach prowadzenia działalności. Warto podkreślić, że faktury ustrukturyzowane będą przechowywane w KSeF przez okres 10 lat, co daje realną możliwość oszczędności, związanych z brakiem obowiązku przechowywania tych dokumentów przez przedsiębiorców. Do instrumentów wsparcia podatników zaliczają się także udostępnione przez Ministerstwo Finansów bezpłatne narzędzia tj. Aplikacja Podatnika KSeF czy zaktualizowana e-mikrofirma. Udostępniona została także Aplikacja Mobilna KSeF. Ponadto, zgodnie z obowiązującymi przepisami podatnicy mogą uwzględnić koszty wdrożenia KSeF w podatku dochodowym, a podatnicy VAT czynni mogą dokonać odliczenia podatku naliczonego w przypadku zakupów towarów i usług związanych z wdrożeniem KSeF.

## 21.Czy w ramach przeprowadzanego audytu, będzie badana możliwość zmiany koncepcji KSeF czy raczej będzie dotyczył on kwestii technicznych?

Audyt dotyczył w szczególności kwestii technicznych, w tym wydajności systemu. Podsumowanie wyników audytu jest dostępne w komunikacie MF: Podsumowanie audytu KSeF

## 22.Czy planowane wejście w życie obligatoryjnego KSeF odbędzie się w tym samym terminie dla wszystkich podatników, czy raczej kolejne rozwiązania będą wprowadzane stopniowo w zależności od wielkości firmy? Czy w początkowym okresie wejścia w życie obligatoryjnego KSeF rozważana jest koncepcja bardziej liberalnego podejścia do niektórych z obowiązków nałożonych na podatników tj. pewna wyrozumiałość co do ewentualnych błędów, niedotrzymywania terminów, czy też mniejsza penalizacja?

Obowiązkowy KSeF wejdzie w życie etapowo, tj.: od 1 lutego 2026 r. dla przedsiębiorców, których wartość sprzedaży (wraz z kwotą podatku) przekroczyła w 2025 r. 200 mln zł, od 1 kwietnia 2026 r. dla pozostałych przedsiębiorców. W początkowym okresie obowiązywania systemu w wersji obligatoryjnej m.in. nie będą stosowane sankcje za niedopełnienie obowiązku KSeF. Sankcje te będą stosowane dopiero od 1 sierpnia 2026 r.

## 23.Czy Ministerstwo Finansów planuje zmiany w strukturze logicznej FA(2)?

Tak, biorąc pod uwagę wystarczająco długi czas pozostający do wdrożenia obowiązkowego KSeF oraz liczne postulaty zgłaszane w tym zakresie podczas przeprowadzonych w lutym i marcu 2024 r. konsultacji publicznych – została podjęta decyzja o aktualizacji struktury FA. Będą to zmiany korzystne dla podatników, związane z prezentacją terminu płatności, wprowadzeniem nowej roli w Podmiot3 – pracownik (rozwiązanie istotne dla identyfikacji wydatków pracowniczych), zwiększeniem ilości znaków w polu P_7 (nazwa towaru lub usług), czy rozwiązaniami dedykowanymi JST i GV. Struktura logiczna udostępniona w listopadzie 2024 r. do konsultacji podatkowych jest zamieszczona na stronie Ministerstwa Finansów w zakładce Konsultacje podatkowe - Konsultacje podatkowe struktur logicznych FA(3) i FA_RR(1) oraz koncepcja funkcjonowania załącznika do faktury w KSeF .

## 24.Czy Ministerstwo Finansów zakłada przygotowanie kompleksowego podręcznika dotyczącego funkcjonalności KSeF?

Kompendium wiedzy na temat Krajowego Systemu e-Faktur jest w trakcie przygotowania. Planowane jest opublikowanie podręcznika KSeF, w którym zostaną przedstawione kluczowe zagadnienia związane z obowiązkowym e-fakturowaniem. Podręcznik będzie zawierał wytyczne dotyczące między innymi nadawania uprawnień do korzystania z KSeF i uwierzytelnienia w systemie. Przedsiębiorcy będą mogli zaznajomić się z zasadami wystawiania e-faktur, ich otrzymywania oraz uzyskaniem dostępu do faktur. Opisane zostaną także nowe funkcjonalności systemu np. kody QR czy generowanie identyfikatorów zbiorczych. Planowane jest także wydanie wyjaśnień odnoszących się do kwestii związanych z definicją stałego miejsca prowadzenia działalności gospodarczej, co jest kluczowe dla określenia czy dany przedsiębiorca będzie objęty obowiązkowym e-fakturowaniem. Udostepnienie materiałów dotyczących Krajowego Systemu e-Faktur z pewnością pomoże podatnikom przygotować się do realizacji nowych obowiązków podatkowych. Warto podkreślić że aktualnie udostępniona jest już broszura informacyjna dotycząca struktury logicznej FA(2). Na stronie podatki.gov.pl zamieszczone są i na bieżąco aktualizowane najczęściej zadawane pytania i odpowiedzi Pytania i odpowiedzi - KSeF (podatki.gov.pl) .

## 25.Czy planowane są nowe funkcjonalności techniczne w działaniu KSeF?

Tak, z myślą o niektórych branżach wystawiających faktury o złożonym zakresie danych zostanie umożliwione przesyłanie załączników do KSeF. Planowane je także wyrównanie środowiska produkcyjnego KSeF w okresie fakultetu, które zapewni wdrożenie funkcjonalności „biznesowych”, ale bez zmiany obowiązków podatników oraz umożliwi wcześniejszą instalację certyfikatów do kodów QR offline przed wdrożeniem obowiązkowego KSeF. Harmonogram działań KSeF jest dostępny na stronie Ministerstwa Finansów w zakładce Aktualności - Finalne konsultacje KSeF .

## 26.Czy będą kontynuowane spotkania informacyjne dla biznesu w ramach cyklu „Środy z KSeF”? Czy Ministerstwo Finansów planuje jakieś inne działania edukacyjne skierowane do przedsiębiorców?

Ministerstwo Finansów będzie kontynuować działania informacyjno-edukacyjne. Przesunięcie terminu wdrożenia obowiązku korzystania z KSeF, nie oznacza, że nie należ  już dziś testować i przygotowywać się do pracy w tym systemie. Bezpłatne narzędzia takie jak Aplikacja Podatnika KSeF czy e-mikrofirma są do dyspozycji przedsiębiorców. W poprzednich miesiącach eksperci KAS chętnie dzielili się wiedzą dotyczącą KSeF w czasie webinariów, konferencji czy innych spotkań organizowanych przez inne podmioty, instytucje publiczne czy organizacje branżowe. Ministerstwo Finansów prowadziło i będzie prowadzić również własne działania informacyjne. Pierwsza odsłona akcji „Środy z KSeF”, cieszyła się sporym zainteresowaniem. Bezpośrednio w webinariach wzięło udział ponad 22 tys. przedsiębiorców. MF otrzymało w ich trakcie wiele pytań. Na stronie internetowej podatki.gov.pl można znaleźć najczęściej zadawane pytania wraz z odpowiedziami. Planowane jest przeprowadzenie kolejnej kampanii informacyjnej. Jak wskazano w komunikacie: Podsumowanie audytu KSeF , w drugiej połowie 2024 roku każdym z urzędów skarbowych będzie można odbyć praktyczne szkolenie z przepisów wprowadzających obowiązkowy KSeF oraz z korzystania z darmowego oprogramowania do wystawiania e-faktur. W styczniu 2025 r. zostanie uruchomiona infolinia KAS specjalnie dla spraw związanych z KSeF. Działania szkoleniowe będą wspierane szeroką akcją informacyjną.

## 27.Czy planowane jest wprowadzenie w KSeF automatycznej weryfikacji statusu kontrahenta z Wykazem Podatników VAT?

Aktualnie nie jest planowane wprowadzenie takiej funkcjonalności. Biorąc pod uwagę, że Wykaz Podatników VAT zawiera wyłącznie podatników zarejestrowanych do VAT jako podatnicy VAT czynni lub jako podatnicy VAT zwolnieni (brak podatników zwolnionych, którzy nie zarejestrowali się jako podatnicy VAT zwolnieni) takie podejście nie pozwoliłoby na realizację celu związanego z identyfikacją statusu wszystkich podmiotów objętych KSeF.

## 28.W wielu firmach rozliczanie wydatków (np. automatyczne transakcje, zamówienia przy użyciu EDI, stacje benzynowe, gastronomia, hotele, artykuły biurowe, podróże itp.) opiera się na identyfikacji zakupów na podstawie fizycznego dokumentu. W dobie KSeF pomysłem na zaadresowanie tej potrzeby są osobne dokumenty nie będące fakturami (np. pdf ze specyfikacją zamówienia lub dokument bez nazwy “faktura”). Rozumiemy, że celem MF nie jest eliminacja takich praktyk gospodarczych uznawszy je za faktury wystawiane poza KSeF (objęte sankcją)?

Wprowadzenie obowiązkowego Krajowego Systemu e-Faktur skutkuje zmianami wyłącznie w sposobie wystawiania faktur. W związku z powyższym dotychczasowe praktyki dotyczące fakturowania powinny zostać dostosowane do założeń KSeF. Celem Ministerstwa Finansów nie jest eliminacja działań polegających na wydawaniu innych niż faktury dokumentów np. specyfikacji zamówienia. Tego typu dokumenty nie będą jednak przesyłane do KSeF.

## 29.Czy planowane jest wydłużenie terminu na dosłanie do KSeF faktur wystawionych w tzw. trybie offline i w trybie awaryjnym?

Takie zmiany nie zostaną przeprowadzone. Obecne rozwiązanie zapewnia odpowiedni stopień efektywności konieczny w celu uszczelnienia systemu podatkowego. Faktury wystawione w trybie awaryjnym (zgodnie z art. 106nf ust. 1 ustawy) przesyła się do KSeF w terminie 7 dni roboczych od dnia zakończenia awarii KSeF. Faktury wystawione w trybie offline (zgodnie z art. 106nf ust. 1 ustawy) przesyła się do KSeF nie później niż w następnym dniu roboczym po dniu: 1) zakończenia okresu niedostępności KSeF, 2) ich wystawienia - w przypadku gdy podatnik nie ma możliwości wystawienia faktury ustrukturyzowanej z innego powodu niż awaria KSeF.

## 30.Dlaczego załączniki są limitowane strukturą? Dlaczego nie będzie dopuszczone dodawanie np. plików PDF?

Załącznik to integralna część faktury. Faktura ustrukturyzowana jest przesyłana w postaci pliku xml, a załącznik będzie jej elementem (dodatkowym węzłem struktury FA). W związku z powyższym nie jest możliwe przesłanie załącznika do KSeF w innej postaci niż xml, np. pliku pdf.

## 31.Czy załączniki będą jedynie w formie ustrukturyzowanej? Czy będzie również możliwość dodania załącznika  w formie nieustrukturyzowanej np. PDF z certyfikatem, zdjęcie, wykaz materiałów itp.?

Dozwolone będzie przesyłanie plików faktury z załącznikiem wyłącznie w formie ustrukturyzowanej (xml). Do KSeF nie będą przyjmowane pliki w postaci nieustrukturyzowanej tj. pdf lub jpg – tego typu załączniki  (pdf, jpg itp.) będą mogły być przekazywane nadal poza tym systemem.

## 32.Czy załącznik będzie obowiązkowy, czy dobrowolny?

Przesyłanie faktury z załącznikiem do KSeF nie będzie obowiązkowe. Nadal możliwe będzie przesyłanie faktury bez załącznika.

## 33.Czy wszystkie podmioty będą mogły przesyłać załączniki do faktur sprzedaży za pośrednictwem KSeF?

Nie jest planowane ograniczanie możliwości przesyłania załączników wyłącznie do określonych branż. Niemniej wprowadzenie możliwości przesłania do KSeF faktury z załącznikiem stanowi realizację potrzeb podmiotów, które wystawiają faktury zawierające złożone dane dotyczące jednostki miary, ilości (liczby) dostarczanych towarów lub wykonywanych usług oraz ceny jednostkowej towarów lub usług (np. dostawców mediów, przedsiębiorców świadczących usługi telekomunikacyjne, dostawców paliw wystawiających faktury zbiorcze).

## 34.Dostawcy mediów (woda, energia, gaz) zawierają w fakturach dodatkowe informacje typu: numer licznika, poprzedni i bieżący odczyt. Wystawiają w 95% faktury dla osób fizycznych nieprowadzących działalności gospodarczej - czy te faktury będą obsłużone przez KSeF?

Dane tj. numer licznika lub poprzedni i bieżący odczyt będzie można uwzględnić w treści faktury (w polu DodatkowyOpis) lub (w okresie obowiązkowego KSeF) w załączniku do faktury. Faktury na rzecz konsumentów w okresie obowiązkowego KSeF będą przesyłane do systemu fakultatywnie.

## 35.Struktura FA(2) w części podsumowania stawek VAT Faktura/Fa (np. P_13_1, P_14_1) nie pozwala nabywcy na jednoznaczną interpretację zastosowanej przez wystawiającego stawki VAT (22% i/lub 23%), Czy zostanie to poprawione w wersji struktury FA(3)?

Obowiązującą aktualnie stawką jest 23%. Przypadki dotyczące zastosowania stawki 22% są marginalne. Stawkę można zidentyfikować na poziomie wiersza faktury. Znajduje się tam pole P_12 będące polem słownikowym, w którym podatnik wskazuje konkretną stawkę podatku.

## 36.Czy struktura logiczna FA(3) będzie obowiązywała od lutego 2026 r.?

Planowane jest wdrożenie struktury FA(3) jeszcze przed terminem obowiązkowego KSeF (wcześniej niż 1 lutego 2026 r.), aby zapewnić stabilny proces jej zaimplementowania w systemach.

## 37.Jaki jest powód wprowadzenia dwóch terminów wejścia w życie obowiązkowego KSeF?

Fazowanie terminu wejścia w życie obowiązkowego KSeF wynika z wniosków i rekomendacji zawartych w raporcie z przeprowadzonego audytu informatycznego.

## 38.Czy nabywca objęty obowiązkowym e-fakturowaniem od 1 kwietnia 2026 r. (w związku z wartością sprzedaży do 200 mln zł w 2025 r.) będzie miał obowiązek odbierać faktury w KSeF w okresie 1 lutego do 31 marca 2026 r.?

Odroczenie terminu obowiązkowego KSeF będzie dotyczyło wyłącznie wystawiania faktur, a nie ich odbierania w KSeF.

## 39.Czy JST będą zwolnione z obowiązku korzystania z KSeF?

Nie

## 40.Jakie jest uzasadnienie momentu wprowadzenia obowiązku KSeF w trakcie roku, a nie z początkiem roku?

Temat był dogłębnie analizowany. Początek roku wiąże się z wieloma obowiązkami sprawozdawczymi oraz rozliczeniami w podatku dochodowym. Z tego względu została podjęta decyzja o wejściu w życie KSeF obowiązkowego w trakcie roku, a nie wraz z jego początkiem (od 1 stycznia). Termin wdrożenia obowiązkowego KSeF (1 lutego 2026 r. dla podatników, którzy osiągnęli wartość sprzedaży w 2025 r. ponad 200 mln zł, a 1 kwietnia 2026 r. dla pozostałych przedsiębiorców) wynika również z rekomendacji zawartych w raporcie, sporządzonym po zakończonym audycie systemu.

## 41.Czy w okresie obowiązkowego KSeF kwiaciarka, która wystawia faktury na niskie kwoty, będzie musiała wysyłać je wszystkie do KSeF?

Co do zasady tak, z tym zastrzeżeniem, że w okresie przejściowym po wprowadzeniu obowiązkowego KSeF, poza KSeF będą mogły być wystawiane faktury, które nie  będą przekraczać kwoty 450 zł (do limitu 10 tys. zł miesięcznie). Szczegóły tego rozwiązania zostały przedstawione w projekcie ustawy dotyczącym II etapu legislacji.

## 42.Czy nie powinniśmy najpierw rozważyć w Polsce obowiązkowego posiadania NIP dla osób prywatnych niebędących przedsiębiorcami? Pomogłoby to w transakcjach B2C. Ja mam NIP, mimo że nie prowadzę żadnej działalności.

Przepisy dotyczące obowiązku posiadania identyfikatora podatkowego NIP przez osoby prywatne zostały zniesione w 2012 r. i nie jest planowany powrót do tamtych regulacji. W KSeF możliwe jest wystawienie faktury bez wskazywania identyfikatora nabywcy w Podmiot2 (wówczas wypełniane jest pole BrakID – wartość „1”).

## 43.Jeśli ktoś będzie wystawiał faktury w których kwota należności ogółem nie przekroczy 450 zł (a łączna wartość sprzedaży wraz z podatkiem, udokumentowana tymi fakturami wystawionymi w danym miesiącu będzie mniejsza lub równa 10 000 zł) to nie musi nic wdrażać tylko wystawić je bezpośrednio w portalu MF?

Wybór narzędzia do wystawiania faktur leży po stronie podatnika. Aplikacja Podatnika KSeF umożliwia wystawienie faktur w KSeF. Natomiast w przypadku faktur do 450 zł (do 10 000 zł w miesiącu) będą mogły być one w okresie przejściowym wystawiane poza KSeF, przy użyciu dowolnego narzędzia lub papierowo. Szczegóły tego wyłączenia z KSeF zostały przedstawione w projekcie ustawy dotyczącym II etapu legislacji. Mimo zawartych przepisów epizodycznych zachęcamy, aby już wcześniej przygotować swoją firmę do KSeF. Przepis epizodyczny jedynie wydłuży termin wejścia w życie obowiązku wystawiania faktur w KSeF, co do zasady jednak każdy podmiot docelowo będzie zobowiązany do wystawiania faktur w systemie. Przygotowanie zaplecza technicznego z odpowiednim wyprzedzeniem czasu jest istotne dla terminowego wdrożenia KSeF.

## 44.Czy w przypadku wysyłki faktur w trybie offline datą wystawienia faktury będzie data jej przesłania do KSeF, czy data wystawienia faktury w systemie dostawcy?

Datą wystawienia faktury będzie data jej wystawienia w systemie dostawcy (data z pola P_1 struktury logicznej e-Faktury).

## 45.Czy w przypadku wydatków służbowych pracownik otrzyma podczas zakupu jakiś rachunek/potwierdzenie dokonania zakupu, czy nic nie otrzyma, a faktura ustrukturyzowana będzie dostępna jedynie do pobrania w KSeF?

Nie ma przeszkód, aby w okresie obligatoryjnego KSeF sprzedawca poza przesłaniem faktury do KSeF wydał pracownikowi nabywcy także jej wizualizację (z kodem QR). Dane pracownika i/lub informację, że jest to wydatek służbowy można także zawrzeć w treści e-Faktury.

## 46.Czy faktura wystawiana na rzecz podmiotu prowadzącego działalność nierejestrowaną jest fakturą konsumencką?

Nie. Faktura konsumencka to faktura dokumentująca sprzedaż na rzecz konsumenta, czyli osoby fizycznej nieprowadzącej działalności gospodarczej. Działalność nierejestrowana jest na gruncie VAT działalnością gospodarczą, a osoba prowadząca działalność nierejestrowaną jest podatnikiem (ale może korzystać ze zwolnienia podmiotowego do 200 tys. zł).

## 47.Na czym polega fakultatywność wystawiania faktur VAT RR w KSeF od 1 lutego 2026 r.?

Nabywca będzie miał obowiązek wystawienia faktur VAT RR w KSeF wyłącznie przypadku, gdy rolnik złoży w systemie oświadczenie, że jest rolnikiem ryczałtowym (z chwilą wskazania nabywcy - podatnika czynnego jako uprawnionego do wystawiania tych faktur przy użyciu KSeF). Jeżeli rolnik nie złoży takiego oświadczenia w KSeF i tym samym nie wskaże nabywcy jako uprawnionego do wystawiania faktur w KSeF, faktura VAT RR będzie mogła być wystawiona poza tym systemem. Złożenie oświadczenia i wyznaczenie nabywcy jako uprawnionego do wystawienia faktur VAT RR w KSeF będzie decyzją rolnika (na tym polega fakultatywność tego rozwiązania).

## 48.Czy w KSeF można wystawić fakturę sprzedażową nie posiadając identyfikatora podatkowego NIP?

W KSeF nie ma technicznej możliwości wystawienia faktury bez NIP sprzedawcy. Jest to pole wymagane w elemencie Podmiot1 struktury FA. Kluczowym elementem działania KSeF jest posiadanie numeru NIP przez podatnika (Podmiot1). Ma to znaczenie zarówno w kontekście wystawiania faktur, a także uwierzytelnienia i autoryzacji.

## 49.Czy planowana jest integracja KSeF i PEF?

Tak, na środowisku testowym taka integracja już nastąpiła.

## 50.Dlaczego obowiązkowe będzie podawanie numeru KSeF przy płatnościach za faktury kontrahentów?

Głównym celem regulacji jest przeciwdziałanie zatorom płatniczym. Rozwiązanie to przyczyni się także do zwiększenia poprawności dokonywania płatności pomiędzy podmiotami.

## 51.Czy planowane jest odroczenie konieczności podawania numeru KSeF w pliku JPK_VAT z deklaracją?

Pomimo wejścia w życie obligatoryjnego  KSeF od 1 lutego 2026 r. przewidziano, że w okresie  od dnia 1 lutego 2026 r. (tj. od daty odroczenia KSeF na mocy ustawy) do dnia 31 lipca 2026 r.,  podatnicy w ewidencji sprzedaży nie będą musieli wykazywać numeru KSeF faktury. Obowiązek ten będzie istniał od sierpnia 2026 r. Przepisy w tym zakresie już zostały opublikowane .

## 52.Kiedy będzie opublikowana nowa wersja struktury JPK_VAT z deklaracją?

Nowa struktura JPK_VAT zostanie udostępniona jeszcze przed wejściem w życie KSeF obligatoryjnego, aby zapewnić stabilny proces jej implementacji w narzędziach do wysyłki plików JPK. Będzie obowiązywać od 1 lutego 2026 r.

## 53.Kiedy będą wdrożone kody QR dla faktur wystawianych w KSeF, w środowisku produkcyjnym?

QR kody są rozwiązaniem dedykowanym wersji obligatoryjnej KSeF. Obecnie funkcjonuje KSeF w wersji fakultatywnej, dlatego funkcjonalność ta nie jest jeszcze dostępna na środowisku produkcyjnym. Wyrównanie środowisk planowane jest na listopad 2025 r

## 54.Czy w ramach zrównania środowisk będzie możliwość korzystania z trybów offline i awaryjnego w ramach fakultatywnego korzystania z KSeF?

Tak

## 55.Zapowiadano, że system będzie budowany od nowa. Czy zostaną udostępnione informacje na temat harmonogramu prac oraz zakresu planowanych zmian w systemie?

Harmonogram działań dotyczących KSeF jest dostępny na stronie Ministerstwa Finansów .

## 56.Jesteśmy producentem systemu ERP, mamy wdrożoną obsługę KSeF, ale potrzebujemy przetestować wysyłkę faktur do KSeF w trybie produkcyjnym. Czy w ramach testów technicznych możemy wysłać na środowisko produkcyjne fakturę na 1 zł i następnie jej korektę do zera? Czy po takiej jednej wysyłce mamy obowiązek obligatoryjnie korzystać z KSeF przed 01.02.2026 r. czy możemy tylko tę jedną FV wysłać, przetestować środowisko produkcyjne, a obligatoryjnie korzystać dopiero od 01.02.2026 r.?

Każda faktura wysłana do KSeF (do środowiska produkcyjnego) rodzi skutki podatkowe. Po wystawieniu w KSeF faktury na środowisku produkcyjnym nie ma możliwości jej anulowania, ponieważ weszła ona do obiegu prawnego. W tym przypadku należy wystawić fakturę korygującą „do zera”. Do testowania KSeF służy środowisko testowe oraz przedprodukcyjne (Demo). Wysłanie do KSeF faktury w okresie fakultatywnego funkcjonowania systemu (do środowiska produkcyjnego) nie oznacza, że od tego momentu wszystkie faktury należy wystawiać w tym systemie.

## 57.Czy docelowy KSeF nadal będzie wymagał przesyłania danych z faktur w czasie rzeczywistym? Czy MF planuje pójście w stronę "stałego" trybu offline - czyli np. 24 lub 48 godz. na dostarczenie faktury do KSeF?

Generalną zasadą jest, że faktury będą wystawiane w czasie rzeczywistym. Wyjątkiem będą tryby określone w art. 106nh oraz 106nf ustawy. Tryb offline będzie mógł być także stosowany w okresie przejściowym po wprowadzeniu obowiązkowego KSeF. Nie jest planowane wprowadzenie zasady powszechnego i stałego fakturowania w trybie offline.

## 58.Czy certyfikaty dla kodów QR offline będą po określonym czasie wygasać? Czy będą one wieczne?

Certyfikaty dla kodów QR m.in. ze względów bezpieczeństwa będą wygasały po określonym czasie. Szczegóły techniczne zostaną opublikowane w Specyfikacji Oprogramowania Interfejsowego KSeF.

## 59.Gdzie w systemie KSeF jest widoczna informacja, kiedy fakturze został nadany numer KSeF (czyli data otrzymania faktury)?

Informacja ta jest podana w UPO w polu "Data przyjęcia dokumentu do systemu teleinformatycznego MF”. Dane te są także dostępne u nabywcy w poszczególnych narzędziach zintegrowanych z API KSeF.

## 60.Czy istnieje strona, na której znajduje się więcej szczegółowych informacji dla firm tworzących oprogramowanie i integrujących je z KSeF?

Oficjalną stroną, na której można znaleźć szczegółowe informacje dla firm tworzących oprogramowanie dla KSeF jest strona ksef.podatki.gov.pl. Na stronie tej są również dostępne linki do technicznych webinariów dotyczących KSeF. Dokumentacja techniczna znajduje się pod poniższymi adresami: w zakresie środowiska produkcyjnego: https://ksef.mf.gov.pl/ , w zakresie środowiska przedprodukcyjnego (Demo): https://ksef-demo.mf.gov.pl/ , w zakresie środowiska testowego: https://ksef-test.mf.gov.pl/ .

## 61.W jakim celu będą wprowadzone i utrzymywane różne tryby postępowania dla różnych awarii/niedostępności KSeF?

Potrzeba wprowadzenia trybu offline i trybu awaryjnego została zgłoszona w toku konsultacji społecznych. Regulacje w tym zakresie, opracowane przez MF, zostały skonsultowane ze stroną społeczną. Różne terminy dosłania do KSeF, faktur wystawionych w tych trybach, wynikają ze specyfiki zaistniałych okoliczności.

## 62.Czy rozwiązania dot. IDWew są zaadresowane tylko do JST czy również do jednostek wewnętrznych?

JST posiadają dedykowany model uprawnień. Niemniej wykorzystanie IDWew jest możliwe zarówno przez jednostki wewnętrzne (np. oddziały), jak również przez JST. Funkcjonowanie IDWew ułatwia podatnikom korzystanie z KSeF. Jego użycie zależne jest od potrzeb podatników oraz indywidualnych okoliczności zaistniałych przy wystawianiu/otrzymywaniu faktury.

## 63.Samofakturowanie przez podmioty zagraniczne: czy przewidziane będzie jakieś rozwiązanie umożliwiające logowanie podmiotów zagranicznych się do KSeF i wystawianie faktur w imieniu polskich podmiotów?

Prace legislacyjne i techniczne nad rozwiązaniem dotyczącym samofakturowania przez podmioty zagraniczne są w toku.

## 64.Czy są planowane zmiany w obsłudze podmiotów wielooddziałowych, ich uprawnień w zakresie wystawiania faktur sprzedaży jak i dostępu do otrzymanych faktur?

Z myślą o takich podmiotach wprowadzony został model uprawnień wykorzystujący IDWew. Nie są planowane zmiany w obsłudze podmiotów wielooddziałowych oraz ich uprawnień w zakresie wystawiania faktur sprzedaży jak i dostępu do otrzymanych faktur.

## 65.Czy spółka które weszła do grupy VAT (która posiada odrębny NIP) traci dostęp do faktur wystawionych lub otrzymanych przez wejściem do grupy VAT?

Nie, wejście do grupy VAT nie oznacza utraty dostępu do faktur wystawionych lub otrzymanych przed wejściem do grupy VAT. W KSeF, w zakresie grup VAT funkcjonuje rozwiązanie pozwalające na sprawne zarządzanie procesem wystawiania i odbierania faktur przez poszczególnych członków jak i samą grupę VAT

## 66.Czy jest rozważana zmiana zasad zarządzania uprawnieniami w KSeF? Potrzebujemy nadawać dostęp do wystawiania faktur na KSeF systemom, a nie osobom fizycznym.

Uprawnienia w KSeF można nadawać osobom fizycznym lub podmiotom. KSeF opiera się na zasadzie poświadczeń i identyfikacji osób/podmiotów wykonujących czynności w systemie. Ta zasada się nie zmieni.

## 67.Kiedy wystartują prace nad strukturą załącznika do faktury dla dostawców mediów?

Załącznik stanowi integralną część faktury, w związku z czym struktura logiczna e-Faktury będzie zawierała nowy, fakultatywny węzeł Zalacznik. Struktura logiczna FA(3) obejmująca załącznik, w wersji przekazanej do konsultacji podatkowych jest dostępna na stronie Ministerstwa Finansów.

## 68.Czy zostanie dodana w strukturze e-faktury, w wierszu faktury, informacja o rabacie procentowym?

Nie jest planowane uwzględnienie takiej zmiany. Udzielenie rabatu procentowego do faktury jako całości nie wymaga powielania zapisów do wszystkich wierszy faktury. Rabat może zostać dodany jako osobna pozycja faktury.

## 69.W jaki sposób przesyłane będą dokumenty dodatkowe np. list przewozowy, które do tej pory wysłano razem z fakturą w jednym e-mailu, a których nie da się przenieść do struktury xml załącznika?

Tego typu dokumenty nie są częścią faktury. Będą przesyłane w dalszym ciągu na dotychczasowych zasadach (poza KSeF).

## 70.Czy KSeF będzie obejmował inne niż faktury dokumenty np. zamówienia?

KSeF obejmuje wyłącznie faktury. Zamówienie w rozumieniu art. 106f ust. 1 pkt 4 ustawy VAT jest elementem wymaganym w przypadku faktury zaliczkowej i znajduje swoje odzwierciedlenie w strukturze faktury KSeF.

## 71.W jaki sposób oprócz numerów zamówienia nadawanych przez system dostawcy będą podawać także numery zamówień generowane przez system nabywcy?

Struktura e-Faktury KSeF umożliwia podawanie dodatkowych danych niewymaganych przepisami ustawy o VAT. Do ich prezentacji służy element DodatkowyOpis. Dane te mogą być podawane w odniesieniu do konkretnego wiersza faktury lub w odniesieniu do faktury jako całości.

## 72.Czy wizualizacja faktury może odbywać się na innych formularzach niż ten zaproponowany przez Ministerstwo Finansów dla faktury ustrukturyzowanej? Czy może nie zawierać wszystkich danych, które zawiera faktura ustrukturyzowana?

Kwestia wizualizacji faktury leży w gestii wystawcy. Istnieje w tym zakresie dowolność. Wizualizacja powinna odzwierciedlać pod względem merytorycznym zawartość oryginału faktury, tak aby nie wprowadzać w błąd co do warunków transakcji osoby, która taką wizualizację otrzymuje.

## 73.Jakie rozwiązania przewidziano dla identyfikacji tzw. zakupów pracowniczych?

W celu identyfikacji zakupów pracowniczych możliwe jest wykorzystanie funkcjonalności związanych z modelem uprawnień wykorzystującym tzw. identyfikator wewnętrzny. Wystawiana faktura może zawierać dane pracownika – w elemencie Podmiot3. Drugim możliwym rozwiązaniem jest pobieranie przez pracownika od sprzedawcy wizualizacji faktury opatrzonej kodem QR w celu przedstawienia pracodawcy. Pracodawca na tej podstawie ma możliwość jednoznacznej identyfikacji faktury pośród innych faktur do których ma dostęp w KSeF.

## 74.Struktura FA(1) zawierała nadrzędny element grupujący FaWiersze obejmujący wiele pozycji faktury określonych elementem FaWiersz. Element FaWiersze z nowej wersji schemy został usunięty, co spowodowało, że elementy pozycji faktur FaWiersz zostały umieszczone pod elementem Fa.  Według nas takie podejście może sprawiać problemy podczas generowania XML KSeF. Naszym zdaniem element grupujący FaWiersze powinien zostać zachowany dla kompatybilności z językiem SQL który używamy do generowania XML faktur KSeF. Czy planowana jest zmiana przywracająca rozwiązanie z pierwszej wersji struktury FA?

Element grupujący powodował dużo pomyłek i błędów, dlatego został usunięty. Nie stwierdzono dotychczas w zgłoszeniach, żadnych problemów z generowaniem XML z powodu usunięcia elementu grupującego. Dzięki tej zmianie nie pojawiają się błędy zidentyfikowane przy wysyłce struktury FA(1).

## 75.Czy jest rozważane wprowadzenie funkcjonalności pozwalającej na jednoznaczne odróżnienie faktur wystawianych w KSeF w trybie zwykłym od faktur "dosyłanych" do KSeF, a wystawionych w trybie offline lub w trakcie awarii?

Dla wysyłki faktur online oraz dla wysyłki w trybie offline/awarii będą przewidziane odrębne rozwiązania techniczne przy ich wysyłce do KSeF. Ich szczegóły zostaną przedstawione w Specyfikacji Oprogramowania Interfejsowego KSeF.

## 76.Czy MF może rekomendować wystawcom FV lekowych właściwe pola, w których należy podawać serię i daty ważności produktów? Aktualnie obsługujemy około 450 dostawców, gdzie w dobie KSeF każdy może wskazać te dane nieobowiązkowo i w polach wybranych przez siebie.

Tego typu dane można umieszczać np. w polu DodatkowyOpis.

## 77.Kiedy będzie uruchomiona infolinia KSeF?

Uruchomienie infolinii KSeF jest planowane na początek 2025 r.

## 78.Czy KSeF przewiduje jakieś mechanizmy przeciwdziałania oszustwom i nadużyciom?

W KSeF jest przygotowywane rozwiązanie techniczne pozwalające na identyfikację działań niepożądanych, w tym zgłaszanie faktur w stosunku do których zachodzi podejrzenie oszustwa. W związku z tym przygotowane zostaną również odpowiednie wyjaśnienia dotyczące tej funkcjonalności.

## 79.Czy zostanie utworzony poradnik pomagający wdrożyć KSeF w swoim przedsiębiorstwie?

Trwają prace nad stworzeniem podręcznika, w którym zostaną omówione kluczowe kwestie związane z funkcjonalnościami KSeF.

## 80.W schemie FA(2) oznaczenie „np” odnosi się wyłącznie do transakcji dostaw towarów i świadczenia usług poza terytorium kraju. W praktyce na fakturach takie oznaczenie stosuje się często dla sprzedaży bonów (innych niż bony jednego przeznaczenia) lub kart podarunkowych (lub innych transakcji, które nie podlegają ustawie o VAT). W jaki sposób wykazywać na fakturze KSeF takie operacje lub korygować tego typu operacje udokumentowane wcześniej fakturami wystawionymi poza KSeF?

W przypadku dokumentowania wyłącznie czynności niepodlegającej ustawie VAT tj. sprzedaży bonu różnego przeznaczenia – nie wystawia się faktury. Tego typu czynności i ich korekty niepodlegające ustawie VAT nie powinny być prezentowane na fakturze jako pozycje (wiersze) z oznaczeniem „np.”. Mogą one zostać zaprezentowane w ramach informacji dodatkowych na fakturze, przy wykorzystaniu węzła fakultatywnego „Rozliczenie” (przy założeniu, że faktura zawiera także pozycje podlegające ustawie, a czynności niepodlegające stanowią dodatkowy element transakcji).

## 81.Kiedy planowane jest zamknięcie dokumentacji technicznej i udostępnienie jej jako ostateczna wersja?

Dokumentacja techniczna zostanie udostępniona w terminie umożliwiającym dostawcom oprogramowania, stabilne i odpowiednio wczesne przeprowadzenie integracji z KSeF. Harmonogram działań dotyczących KSeF jest dostępny w wiadomości "Finalne konsultacje KSeF" umieszczonej w Aktualnościach na stronie Ministerstwa Finansów .

## 82.Kiedy zostaną udostępnione przykłady kodu, ułatwiające integracje systemu informatycznego z systemem KSeF?

Nie jest planowane udostępnienie przykładów użycia. Dostępna jest dokumentacja techniczna – Specyfikacja Oprogramowania Interfejsowego KSeF.

## 83.Czy powstaną oficjalne biblioteki lub przykłady komunikacji API w jednym z popularnych języku programowania?

Takie działania nie są planowane. Dostępna jest dokumentacja techniczna – Specyfikacja Oprogramowania Interfejsowego KSeF.

## 84.Czy dokumentacja zostanie rozszerzona o nagłówki oraz przesyłane podczas odpytywania API?

Nagłówki zawarte są w kontrakcie.

## 85.Czy powstanie wersja SOAP API pomagająca w integracji programów firm trzecich w celu wysyłki i pobierania faktur z systemu KSeF? Powstaną dodatkowe opisy i przykłady w dokumentacji na temat komunikacji z REST API?

Takie działania nie są planowane. Dostępna jest dokumentacja techniczna – specyfikacja interfejsów KSeF.

## 86.Kiedy nastąpi wyrównanie różnić między wersjami środowisk TEST a DEMO/PROD?

Wyrównanie środowisk nastąpi w listopadzie 2025 r. Harmonogram działań dotyczących KSeF jest dostępny w wiadomości "Finalne konsultacje KSeF" umieszczonej w Aktualnościach na stronie Ministerstwa Finansów .

## 87.Jakie rozwiązania od strony serwerowej (wydajność, częstość awarii) zostaną/zostały przedsięwzięte w ramach realizowania wniosków z audytu? Czy w tym zakresie planowana jest zmiana sposobu komunikacji? (np. większa/mniejsza ilość asynchronicznych funkcji, uproszczenia w mechanizmach weryfikacji statusów, limity zapytań i możliwość blokowania komuś dostępu przez wyczerpywanie limitów)?

Trwa budowa nowej architektury systemu. Dokumentacja techniczna ze wszystkimi zmianami także zostanie udostępniona.

## 88.Czy przewidywane jest udostępnienie oficjalnej metody API pobierania wizualizacji tworzonej po stronie KSeF?

Nie jest planowane udostępnienie metody API dot. wizualizacji.

## 89.Czy MF planuje przygotowanie oficjalnego rejestru awarii na niezależnym środowisku + API, żeby umożliwić przedsiębiorcom przygotowanie rozwiązań technicznych do automatycznego sprawdzania czy w danym momencie występuje awaria, od którego momentu w czasie awaria występuje, czy już się zakończyła i kiedy dokładnie się zakończyła?

Planowane jest wdrożenie niezależnego serwisu informującego o awarii.

## 90.Czy w API KSeF będzie możliwość pobierania faktur przyrostowo bez stronicowania?

Nie.

## 91.Czy tokeny będą nadal jedną z metod używanych do uwierzytelnienia się w KSeF?

Tokeny docelowo zostaną zastąpione certyfikatami.

## 1.W jaki sposób nadawane jest pierwotne uprawnienie w KSeF w przypadku podatnika, który jest osobą fizyczną?

W przypadku podatników, którzy są osobami fizycznymi pierwotne uprawnienie o charakterze właścicielskim jest przypisane do osoby będącej podatnikiem automatycznie. Osoba taka nie musi nic zgłaszać. Może korzystać z systemu autoryzując się Podpisem Zaufanym lub kwalifikowanym podpisem elektronicznym. W przypadkach szczególnych, gdy osoba posiada kwalifikowany podpis elektroniczny, który nie zawiera w sobie NIP i PESEL istnieje możliwość zgłoszenia tzw. odcisku palca podpisu za pośrednictwem zawiadomienia ZAW-FA, w celu przypisania podpisu do danego podatnika. Zmiana czy odnowienie podpisu, na kolejny niezawierający NIP i PESEL wymagać będzie kolejnego zawiadomienia.

## 2.W jaki sposób jest nadawane pierwotne uprawnienie w KSeF w przypadku podatnika niebędącego osobą fizyczną?

W przypadku podatników niebędących osobami fizycznymi, którzy posiadają elektroniczną pieczęć kwalifikowaną zawierającą NIP istnieje możliwość korzystania z KSeF na podstawie pierwotnych uprawnień właścicielskich bez zgłaszania w urzędzie skarbowym. W pozostałych przypadkach podatnik niebędący osobą fizyczną w celu korzystania z KSeF musi za pośrednictwem zawiadomienia ZAW-FA wskazać osobę fizyczną uprawnioną w imieniu podatnika do korzystania z KSeF. Osoba ta będzie miała także możliwość nadawania dalszych uprawnień drogą elektroniczną w ramach KSeF.

## 3.Jak technicznie nadać uprawnienie innej osobie do wystawiania faktury w imieniu podatnika/firmy?

W celu umożliwienia wystawienia faktury w imieniu podmiotu lub innej osoby fizycznej prowadzącej działalność gospodarczą należy udzielić dedykowanego w tym zakresie uprawnienia do wystawiania faktur. Udzielenie uprawnienia będzie możliwe za pomocą programów komercyjnych (przy użyciu API), jak również w przygotowywanej przez Ministerstwo Finansów webowej aplikacji KSeF dla podatników.

## 4.Czy w KSeF przewidziana jest procedura samofakturowania?

Tak. Sprzedawca uprawniający nabywcę do samofakturowania będzie musiał nadać nabywcy to uprawnienie w KSeF. Faktury w ramach tej procedury będą mogły być wystawiane bezpośrednio przez nabywcę oraz przez podmioty uprawnione przez niego do wystawiania faktur w KSeF.

## 5.Chciałabym poprzez API KSeF nadać osobie fizycznej uprawnienie do wystawiania faktur w moim imieniu. Czy osoba uprawniona musi założyć w związku z tym konto w KSeF? W jaki sposób ma to zrobić?

Aby uprawniona przez podatnika osoba fizyczna mogła w imieniu podatnika wystawiać faktury ustrukturyzowane nie jest konieczne założenie przez nią konta w KSeF. Wyznaczona osoba uprawniona będzie mogła wystawiać faktury w imieniu podatnika, po uwierzytelnieniu się w systemie jedną z metod przewidzianych w § 5 rozporządzenia Ministra Finansów w sprawie korzystania z Krajowego Systemu e-Faktur.

## 6.Czy konta w KSeF są zakładane tylko na osoby fizyczne? Czy mogą być również konta zakładane na firmy?

Z KSeF korzystać mogą zarówno osoby fizyczne jak i podmioty inne niż osoby fizyczne. Aby korzystać z KSeF niezbędne jest uwierzytelnienie się podatnika w systemie. Podmiot niebędący osobą fizyczną może uwierzytelnić się w systemie pieczęcią kwalifikowaną. W innym przypadku konieczne jest złożenie np. przez spółkę zawiadomienia ZAW-FA, w którym podmiot wyznaczy określoną osobę fizyczną do korzystania z KSeF (w tym do nadawania uprawnień, odbierania uprawnień, wystawiania faktur w imieniu podmiotu oraz dostępu do faktur).

## 7.Czy jeśli moje faktury sprzedażowe wystawia w moim imieniu biuro rachunkowe, to czy będę musiał każdorazowo upoważniać do wystawiania faktur poszczególnych pracowników tego biura rachunkowego?

W KSeF przewidziana jest możliwość aby podatnik wskazał podmiot uprawniony do wystawiania faktur np. biuro rachunkowe. W takim przypadku faktury podatnika mogą wystawiać osoby fizyczne uprawnione do wystawiania faktur w imieniu tego podmiotu, czyli pracownicy tego biura.

## 8.Czy mogę wskazywać jako osoby uprawnione do wystawiania faktur w moim imieniu osoby spoza mojej firmy np. bezpośrednio pracowników biura rachunkowego, czy muszę wskazywać to biuro?

W ramach KSeF podatnik ma wybór czy chce sam bezpośrednio nadawać uprawnienia konkretnym osobom fizycznym, także spoza własnej organizacji, czy wskazać podmiot uprawniony do wystawiania i/lub otrzymywania faktur i umożliwiać pośrednie przekazywanie uprawnień.

## 9.Czy w przypadku podatników niebędących osobami fizycznymi jest możliwość zgłaszania więcej niż jednej osoby fizycznej o najszerszym zakresie uprawnień umożliwiającym nadawanie dalszych uprawnień kolejnym osobom za pośrednictwem ZAW-FA?

Nie, zawiadomieniem ZAW-FA można zgłosić tylko pierwszą osobę. Kolejne osoby o najszerszym zakresie uprawnień zgłaszane mogą być drogą elektroniczną przez osobę uprawnioną do nadawania uprawnień.

## 10.Co w przypadku gdy podatnik niebędący osobą fizyczną z różnych przyczyn w sposób nagły zakończy współpracę z osobą fizyczną zgłoszoną za pomocą zawiadomienia ZAW-FA i nie zgłoszono wcześniej innych osób o najszerszym zakresie uprawnień umożliwiającym nadawanie dalszych uprawnień kolejnym osobom?

W takiej sytuacji będzie możliwość zgłoszenia za pomocą zawiadomienia ZAW-FA kolejnej osoby w miejsce dotychczasowej.

## 11.W jakich sytuacjach należy ponownie zgłaszać uprawnienia nadane w powiązaniu z tzw. odciskiem palca podpisu?

Uprawnienia nadane w powiązaniu z tzw. odciskiem palca podpisu należy zgłaszać ponownie w przypadku przedłużenia ważności podpisu lub uzyskania nowego podpisu, mimo, że posługuje się nim cały czas ta sama osoba.

## 12.Czy trzeba dokonywać aktualizacji zgłaszanych uprawnień w przypadku gdy dana osoba uprawniona przedłuża ważności podpisu lub uzyskuje inny podpis kwalifikowany, ale podpis cały czas zawiera jeden z atrybutów NIP lub PESEL?

Nie. W takich sytuacjach nie jest wymagana aktualizacja uprawnień.

## 13.Czy przewidziana jest jakaś forma aktualizacji danych zgłoszonych w ZAW-FA w przypadku ich późniejszej zmiany?

Nie. W ZAW-FA podaje się dane aktualne na moment składania zgłoszenia. Przy założeniu, że NIP podmiotu składającego oraz NIP lub PESEL osoby uprawnionej nie ulegają zmianie, nie jest konieczna aktualizacja pozostałych danych.

## 14.Od jakiego momentu nadane osobie uprawnienia umożliwiają jej uwierzytelnienie w systemie? Co w przypadku nadawania zawiadomienia ZAW-FA drogą pocztową?

Aby uprawnienia zaczęły działać muszą zostać wprowadzone do systemu. W przypadku zgłoszeń elektronicznych uprawnienia będą skuteczne od razu po przetworzeniu dyspozycji. Uprawnienie nadawane za pośrednictwem zawiadomienia ZAW-FA będzie wprowadzane do systemu przez właściwy urząd skarbowy, który w pierwszej kolejności zweryfikuje zawiadomienie pod względem formalnym, w szczególności czy zawiadomienie jest podpisane przez odpowiednią liczbę osób uprawnionych do reprezentacji. Właściwy urząd skarbowy będzie wprowadzał zawiadomienie niezwłocznie po jego otrzymaniu. W przypadku wysyłki zawiadomienia drogą pocztową należy z przyczyn oczywistych brać pod uwagę opóźnienie wynikające z konieczności doręczenia przesyłki do urzędu skarbowego. W ZAW-FA znajdują się pola dotyczące obowiązkowych adresów e-mail, na które wysyłane będą powiadomienia o nadaniu uprawnień.

## 15.Co powinien zrobić komornik oraz organ egzekucyjny aby korzystać z KSeF?

Komornik jest osobą fizyczną i może korzystać z systemu bez dokonywania zgłoszeń. Fakt, że dana osoba jest komornikiem jest w systemie odnotowany automatycznie na podstawie dostępnych rejestrów. Komornik będzie mógł nadawać dalsze uprawnienia wyłącznie elektronicznie w systemie. Organ egzekucyjny, aby zacząć korzystać z KSeF będzie musiał złożyć zawiadomienie o nadaniu lub odebraniu uprawnień (ZAW-FA) do właściwego naczelnika urzędu skarbowego obsługującego ten organ.

## 16.Czy autoryzacja musi być per osoba czy może być per firma?

Z KSeF korzystać mogą zarówno osoby fizyczne jak i podmioty inne niż osoby fizyczne. Aby korzystać z KSeF niezbędne jest uwierzytelnienie się podatnika w systemie. Podmiot niebędący osobą fizyczną może uwierzytelnić się w systemie pieczęcią kwalifikowaną. W innym przypadku konieczne jest złożenie np. przez spółkę zawiadomienia ZAW-FA, w którym podmiot wyznaczy określoną osobę fizyczną do korzystania z KSeF (w tym do nadawania uprawnień, odbierania uprawnień, wystawiania faktur w imieniu podmiotu oraz dostępu do faktur). Natomiast, w przypadku osób fizycznych (również w przypadku uwierzytelnienia się osoby fizycznej w ramach podmiotu) autoryzacja jest możliwa za pomocą kwalifikowanego podpisu elektronicznego, podpisu zaufanego lub za pośrednictwem API za pomocą wygenerowano wcześniej tokenu.

## 17.Co z podmiotami zagranicznymi, którzy działają w Polsce za pośrednictwem pełnomocników i nie mają żadnych podpisów elektronicznych? Czy pełnomocnik będzie mógł działać w imieniu podatnika w KSeF i udzielać dalszych pełnomocnictw?

Podmiot zagraniczny posiadający polski identyfikator NIP może działać za pośrednictwem pełnomocnika. W takim przypadku konieczne jest złożenie przez ten podmiot, zawiadomienia ZAW-FA, w którym podmiot wyznaczy określoną osobę fizyczną do korzystania z KSeF (w tym do nadawania uprawnień, odbierania uprawnień, wystawiania faktur w imieniu podmiotu oraz dostępu do faktur).

## 18.Czy w ZAW-FA mogę upoważnić dwóch członków zarządu czy tylko jednego?

W ZAW-FA można upoważnić tylko jedną osobę. Może, ale nie musi to być członek zarządu. Osoba wyznaczona w ZAW-FA może nadać kolejnym osobom uprawnienia elektronicznie.

## 19.Czy wspólnik sp.jawnej może się uwierzytelnić poprzez profil zaufany czy druk ZAW-FA?

Spółka jawna (jako podatnik niebędący osobą fizyczną) może uwierzytelnić się w KSeF pieczęcią kwalifikowaną. Jeżeli spółka nie posiada pieczęci kwalifikowanej to może złożyć ZAW-FA. Jeśli wspólnik spółki jawnej zostanie wyznaczony w ZAW-FA, to będzie mógł się uwierzytelnić w kontekście spółki np. swoim profilem zaufanym.

## 20.Co z nadawaniem uprawnień w przypadku sp z o.o.? Czy wystarczy, że w przypadku jednoosobowego zarządu prezes przez ZAW-FA nada wszelkie uprawnienia do KSeF dla dyrektora finansowego, a potem dyrektor już w samym systemie KSeF może nadawać dalsze uprawnienia np. dla księgowych do wystawiania faktur? Czy już sam prezes musi nadać przez ZAW-FA uprawnienia księgowym?

Spółka z o.o. (jako podatnik niebędący osobą fizyczną) może uwierzytelnić się w KSeF pieczęcią kwalifikowaną. Jeżeli spółka nie posiada pieczęci kwalifikowanej, to będzie mogła złożyć ZAW-FA. ZAW-FA podpisuje osoba reprezentująca spółkę. W zawiadomieniu wskazuje się osobę uprawnioną np. dyrektora finansowego. Osoba wyznaczona w ZAW-FA będzie mogła także nadać dalsze uprawnienia elektronicznie w systemie (np. do wystawiania faktur) kolejnym osobom fizycznym np. księgowym.

## 21.Czy FV wystawiona w KSeF będzie widoczna dla osoby uprawnionej/biura rachunkowego od razu, czy dopiero po zatwierdzeniu jej przez nabywcę?

Faktura jest widoczna w momencie jej przetworzenia przez system KSeF. Dzieję się to co do zasady automatycznie bez opóźnień.

## 22.Generujemy token i wgrywamy go do programu komercyjnego. Czy możemy wysyłać i pobierać faktury z KSeF bez dodatkowych podpisów (Profil Zaufany)?

TAK, pod warunkiem że generując token posiadamy właściwe uprawnienia np. do wysyłania faktur w KSeF i w ramach tych uprawnień ten token wygenerujemy.

## 23.Czy rozwiązania dot. IDWew są zaadresowane tylko do JST czy również do jednostek wewnętrznych?

JST posiadają dedykowany model uprawnień. Niemniej wykorzystanie IDWew jest możliwe zarówno przez jednostki wewnętrzne (np. oddziały), jak również przez JST. Funkcjonowanie IDWew ułatwia podatnikom korzystanie z KSeF. Jego użycie zależne jest od potrzeb podatników oraz indywidualnych okoliczności zaistniałych przy wystawianiu/otrzymywaniu faktury.

## 24.Czy spółka które weszła do grupy VAT (która posiada odrębny NIP) traci dostęp do faktur wystawionych lub otrzymanych przez wejściem do grupy VAT?

Nie, wejście do grupy VAT nie oznacza utraty dostępu do faktur wystawionych lub otrzymanych przed wejściem do grupy VAT. W KSeF, w zakresie grup VAT funkcjonuje rozwiązanie pozwalające na sprawne zarządzanie procesem wystawiania i odbierania faktur przez poszczególnych członków jak i samą grupę VAT

## 1.Czy istnieje możliwość wykorzystania Podpisu Zaufanego we własnej aplikacji, żeby przedsiębiorca nie musiał generować samodzielnie tokenu w aplikacji Ministerstwa Finansów?

Autoryzacja użytkownika wymagana jest niezależnie czy wykorzystuje się narzędzia komercyjne, czy aplikację udostępnioną przez Ministerstwo Finansów. Jedną z metod uwierzytelnienia, w celu korzystania z Krajowego Systemu e-Faktur, jest Podpis Zaufany.

## 2.Czy wysyłając faktury lub paczki faktur wymagane jest posiadanie podpisu?

Wysyłkę można dokonać w ramach sesji interaktywnej lub wsadowej (paczki faktur). Wysyłka faktury bądź paczki faktur zostanie dokonana przez podatnika lub osobę uprawnioną, po prawidłowo zakończonym procesie autoryzacji tego użytkownika np. za pomocą kwalifikowanego podpisu elektronicznego.

## 3.Prowadzę jednoosobową działalność gospodarczą i jednocześnie jestem członkiem rady nadzorczej. Mój PESEL jest widoczny w ogólnodostępnych rejestrach (np. KRS). Czy w związku z tym nie będę narażony na nieautoryzowane próby uwierzytelnienia się w systemie KSeF, w moim imieniu przez inne podmioty?

Nie, ponieważ wymagane jest uwierzytelnienie w sposób określony w § 5 rozporządzenia Ministra Finansów w sprawie korzystania z Krajowego Systemu e-Faktur tj.: 1) kwalifikowanym podpisem elektronicznym albo 2) kwalifikowaną pieczęcią elektroniczną, albo 3) podpisem zaufanym, albo 4) wygenerowanym przez Krajowy System e-Faktur, po uwierzytelnieniu się podatnika lub podmiotu uprawnionego w sposób, o którym mowa w pkt 1–3, ciągiem znaków alfanumerycznych, z wyłączeniem znaków interpunkcyjnych, przypisanym do podatnika lub podmiotu uprawnionego i jego uprawnień – oraz weryfikacji posiadanych uprawnień. Oznacza to, że wskazanie wyłącznie numeru PESEL danej osoby fizycznej nie pozwoli na uwierzytelnienie się w systemie.

## 4.Jakich przypadków dotyczy zgłaszanie tzw. odcisku palca podpisu kwalifikowanego? W jaki sposób jest to zgłaszane?

Dotyczy to trzech przypadków, które łączy wspólna cecha, czyli jednoczesny brak w elektronicznym podpisie kwalifikowanym atrybutów w postaci NIP i PESEL: a) Zgłoszenie podpisu kwalifikowanego, którego właścicielem jest sam podatnik będący osobą fizyczną. Dokonywane wyłącznie za pośrednictwem ZAW-FA. b) Zgłoszenie podpisu kwalifikowanego osoby uprawnionej przez podatnika, posiadającej PESEL i/lub NIP ale posługującej się podpisem niezawierającym tych atrybutów. Dokonywane za pośrednictwem ZAW-FA w przypadku zgłaszania pierwszej osoby o najszerszych uprawnieniach lub drogą elektroniczną w przypadku kolejnych osób. c) Zgłoszenie podpisu kwalifikowanego osoby uprawnionej przez podatnika, nieposiadającej NIP i PESEL. Dokonywane za pośrednictwem ZAW-FA w przypadku zgłaszania pierwszej osoby o najszerszych uprawnieniach lub drogą elektroniczną w przypadku kolejnych osób. Procedura ta nie jest konieczna gdy podpis kwalifikowany zawiera jeden z tych atrybutów.

## 5.Czy możliwe będzie wykonywanie operacji administracyjnych tj. np. wyznaczenie osób fakturujących oraz wygenerowanie tokenów autoryzacyjnych poprzez aplikację dostarczoną przez Ministerstwo Finansów? Innymi słowy czy aplikacja systemu ERP może autoryzować się wyłącznie tokenem?

Tak

## 6.Czy trzeba dokonywać aktualizacji zgłaszanych uprawnień w przypadku gdy dana osoba uprawniona przedłuża ważności podpisu lub uzyskuje inny podpis kwalifikowany, ale podpis cały czas zawiera jeden z atrybutów NIP lub PESEL?

Nie. W takich sytuacjach nie jest wymagana aktualizacja uprawnień.

## 7.W jakich sytuacjach należy ponownie zgłaszać uprawnienia nadane w powiązaniu z tzw. odciskiem palca podpisu?

Uprawnienia nadane w powiązaniu z tzw. odciskiem palca podpisu należy zgłaszać ponownie w przypadku przedłużenia ważności podpisu lub uzyskania nowego podpisu, mimo, że posługuje się nim cały czas ta sama osoba.

## 8.Czy tokeny są wieczne, czy wygasają?

KSeF nie określa czasu w jakim token jest ważny. Wygenerowany token pozostaje ważny do czasu jego unieważnienia przez użytkownika lub do dnia odebrania uprawnień użytkownikowi.

## 9.Czy autoryzacja musi być per osoba czy może być per firma?

Z KSeF korzystać mogą zarówno osoby fizyczne jak i podmioty inne niż osoby fizyczne. Aby korzystać z KSeF niezbędne jest uwierzytelnienie się podatnika w systemie. Podmiot niebędący osobą fizyczną może uwierzytelnić się w systemie pieczęcią kwalifikowaną. W innym przypadku konieczne jest złożenie np. przez spółkę zawiadomienia ZAW-FA, w którym podmiot wyznaczy określoną osobę fizyczną do korzystania z KSeF (w tym do nadawania uprawnień, odbierania uprawnień, wystawiania faktur w imieniu podmiotu oraz dostępu do faktur). Natomiast, w przypadku osób fizycznych (również w przypadku uwierzytelnienia się osoby fizycznej w ramach podmiotu) autoryzacja jest możliwa za pomocą kwalifikowanego podpisu elektronicznego, podpisu zaufanego lub za pośrednictwem API za pomocą wygenerowano wcześniej tokenu.

## 10.Czy istnieje możliwość wykorzystania Profilu Zaufanego w swojej aplikacji, żeby przedsiębiorca nie musiał generować samodzielnie tokenu w aplikacji Ministerstwa Finansów?

Niezależnie od wykorzystywanego systemu komercyjnego czy aplikacji udostępnionej przez Ministerstwo Finansów wymagana jest autoryzacja użytkownika. Jedną z metod uwierzytelnienia w celu korzystania z KSeF jest podpis zaufany.

## 11.Czy jeśli spółka z o.o. posiada firmowe oprogramowanie księgowe i tam jest możliwość wysyłki faktur do KSeF, to mimo tego trzeba się gdzieś logować?

Autoryzacja będzie w takim przypadku odbywać się wewnątrz wykorzystywanej aplikacji zintegrowanej z KSeF. Reguły autoryzacji są takie same niezależnie z jakiego programu się korzysta. W przypadku podatników niebędących osobami fizycznymi, nieposiadającymi elektronicznej pieczęci kwalifikowanej, w celu dokonania pierwszej autoryzacji w systemie koniecznie jest złożenie zgłoszenia ZAW-FA do urzędu skarbowego.

## 1.Czy system będzie przyjmował faktury bez elementów nieobowiązkowych (inne niż z ustawy o VAT), ale wynikających ze struktury?

Przesyłana faktura musi być zgodna z obowiązującą w chwili wystawienia strukturą logiczną. W przypadku, gdy faktura będzie zawierała błędy np. nie wszystkie wymagane przez strukturę pola zostaną wypełnione, faktura zostanie odrzucona. Należy podkreślić, że w strukturze istnieją pola, które stają się obowiązkowe w momencie wypełniania węzłów lub sekwencji o charakterze fakultatywnym, w których pola te są zawarte mimo, że dotyczą elementów których nie wymaga ustawa o VAT. W tego typu sytuacjach fakultatywność osiągana jest na poziomie węzła lub sekwencji. Zatem w przypadku wypełniania fakultatywnych węzłów zawartych w fakturze, pola obowiązkowe w tym węźle muszą zostać wypełnione dla skuteczności wysyłki pliku faktury.

## 2.Co to jest uniwersalny unikalny numer wiersza faktury (UU_ID)? Jak bardzo ma być on unikalny? Czy na fakturze korygującej ten numer ma być taki sam jak na korygowanej?

Wykorzystanie pola UU_ID lub UU_IDZ jest dobrowolne i umożliwia nadawanie wierszom faktury unikalnych numerów, które może ułatwiać ich identyfikację w wykorzystywanych systemach księgowych oraz pozwala na jednoznaczne wiązanie numerów wierszy faktury pierwotnej z numerami wierszy w fakturach korygujących. Pola przyjmują do 50 znaków. Pożądaną unikalnością jest unikalność w skali danego podatnika lub danego systemu wykorzystywanego przez danego podatnika.

## 3.Czy dokument musi zostać wysłany do KSeF w dniu wystawienia (jeśli data wystawienia dokumentu w pliku ma być tożsama z datą bieżącą)? Nie ma możliwości wysłania np. następnego dnia?

Dokument może zostać wysłany kolejnego dnia, przy zachowaniu ustawowo określonych terminów dotyczących wystawiania faktur. Wskazanie w polu P_1 konkretnej daty nie obliguje podatnika do wysłania w tym dniu faktury do KSeF.

## 4.Jak się ma data i czas wytworzenia dokumentu e-faktury do pola data wystawienia (P_1) z elementu <Fa> ?

Data podana w polu P_1 to wskazana przez wystawcę faktury data jej wystawienia. Natomiast pole DataWytworzeniaFa ma jedynie charakter techniczny, to generowana przez system data i czas wytworzenia faktury.

## 5.Posiadam w systemie finansowo-księgowym więcej informacji niż chciałbym prezentować na fakturze, czy pola oznaczone w schemie xsd jako nieobligatoryjne mogą pozostać niewypełnione?

Obligatoryjny charakter danego pola wynika w szczególności z treści obowiązujących przepisów. Struktura logiczna e-Faktury oprócz elementów, których występowanie regulowane jest art. 106a - 106q ustawy o VAT, zawiera także elementy, których stosowanie jest całkowicie dobrowolne i dowolne. Uwzględnienie ich w strukturze wynika z praktyki biznesowej obserwowanej na rynku. To tzw. dodatkowe elementy faktury, które nie wynikają z przepisów VAT, a których stosowanie w fakturze nie jest zabronione. Pola te mogą pozostać niewypełnione, nawet w przypadku posiadania takich danych.

## 6.Struktura logiczna e-Faktury zawiera szereg nowych pól, których nie było do tej pory w strukturach JPK_FA. Czy to oznacza, że rozszerzono zakres danych wymaganych w fakturach?

Struktura logiczna e-Faktury oprócz elementów, których występowanie regulowane jest art. 106a - 106q ustawy o VAT, zawiera także elementy, których stosowanie jest całkowicie dobrowolne i dowolne. Uwzględnienie ich w strukturze wynika z praktyki biznesowej obserwowanej na rynku, w tym na skutek uwag zgłaszanych w trakcie konsultacji społecznych struktury. To tzw. dodatkowe elementy faktury, które nie wynikają z przepisów VAT, a których stosowanie w fakturze nie jest zabronione. Przepisy wprowadzające KSeF nie nakładają zatem nowych obowiązków co do zawartości faktury.

## 7.Faktura została przesłana do KSeF i został jej nadany numer identyfikujący w systemie. Sprzedawca chciałby dodatkowo przesłać nabywcy wydruk tej faktury. Czy na wydruku należy zawrzeć numer KSeF?

W strukturze logicznej e-Faktury nie jest przewidziane pole zawierające numer KSeF faktury ustrukturyzowanej. Nie ma konieczności umieszczania numeru identyfikującego fakturę w KSeF na wydruku faktury.

## 8.Ile faktur korygujących można wystawić w KSeF do jednej faktury sprzedaży?

KSeF nie przewiduje ograniczeń pod kątem liczby faktur korygujących wystawionych do jednej faktury sprzedaży.

## 9.Jakich sytuacji dotyczą pola KursUmowny, WalutaUmowna?

Pola KursUmowny i WalutaUmowna dotyczą przypadków gdy faktura wystawiona jest w złotówkach, co oznacza, że określone w art. 106e ust. 1 – 10 ustawy o VAT kwoty w fakturze wyrażone są w złotych, względnie faktura jest tzw. fakturą dwuwalutową, gdzie wszystkie te kwoty są wyrażone jednocześnie w złotówkach i walucie obcej, a strony transakcji chcą w fakturze zawrzeć informację o kursie waluty w oparciu, o który dokonano takiego umownego przeliczenia. Jest to sytuacja odmienna od przypadku gdy kwoty w fakturze określone są wyłącznie w walucie obcej i jedynie kwota podatku przeliczona jest na złotówki zgodnie z art. 106e ust. 11 ustawy o VAT. Wówczas wypełniane są pola KodWaluty i KursWaluty.

## 10.Czy w fakturze przesyłanej do KSeF należy wypełnić pole P_1 (data wystawienia), skoro fakturę ustrukturyzowaną uznaje się za wystawioną w dniu jej przesłania? Czy będzie mogło dojść do sytuacji, w której faktura ustrukturyzowana przesłana o 23:59 danego dnia (z perspektywy wysyłającego) zostanie uznana przez KSeF za przesłaną o 0:01 następnego dnia? Czy w sytuacji, gdy KSeF uzna fakturę ustrukturyzowaną za wystawioną (przesłaną) w innym dniu, niż data wskazana w polu P_1, faktura taka zostanie przez KSeF odrzucona?

Pole P_1 dotyczące daty wystawienia jest polem obowiązkowym, które musi zostać wypełnione aby faktura mogła być przyjęta przez KSeF. Faktura będzie uznana za wystawioną w dniu jej przesłania do KSeF zgodnie z art. 106na ust. 1 ustawy o VAT, czyli w momencie, w którym trafi do systemu niezależnie od późniejszego momentu jej przetworzenia. Informacja o dacie przesłania będzie znajdowała się w UPO. Data ta jest zawarta również w numerze nadanym przez KSeF. W przypadku gdy data wskazana w polu P_1 jest inna niż data przesłania faktura nie zostanie odrzucona przez KSeF

## 11.Jak i czy przesłać korektę błędnego NIP-u nabywcy? Jak rozumieć opis dla pola Podmiot2K – „Korekcie nie podlegają błędne numery identyfikujące nabywcę oraz dodatkowego nabywcę”?

W przypadku przesłania do systemu KSeF faktury z błędnym NIP nabywcy, w celu skorygowania zaistniałej sytuacji, należy przesłać fakturę korygującą "do zera" z tym błędnym NIP nabywcy i dodatkowo przesłać odrębną fakturę (pierwotną) z prawidłowym numerem NIP nabywcy. Wynika to z uwarunkowań systemowych. Faktura z błędnym NIP nabywcy zostanie po przetworzeniu udostępniona podmiotowi o takim numerze NIP. Zatem z przytoczonego opisu wynika, że w takich przypadkach nie należy wystawiać faktury korygującej błędny numer NIP na inny prawidłowy, gdyż w KSeF nie wystąpi sytuacja, że fakturę odebrał podmiot będący rzeczywistą stroną transakcji, a jedynie numer NIP podany w fakturze był błędny.

## 12.Jak powinna wyglądać korekta, jeżeli chcemy skorygować informacje niewpływające na wartość korekty, np. data sprzedaży, FP, MPP, TP, GTU itp. – czy to należy zrobić standardową korektą?

W przedstawionej sytuacji w KSeF można wystawić fakturę korygującą. W przypadku korekt niewpływających na wartość podstawy opodatkowania i kwotę podatku (np. data sprzedaży, oznaczenie FP, TP, adnotacja MPP, symbole GTU) w fakturze korygującej należy wskazać prawidłową treść korygowanych pozycji. W okresie fakultatywnego KSeF istnieje również możliwość wystawienia w tym zakresie noty korygującej przez nabywcę (poza KSeF).

## 13.Czy struktura logiczna e-Faktury przewiduje pole do swobodnego wykorzystania w korespondencji do nabywcy?

Nie. Natomiast, jest możliwość zamieszczania w fakturze dodatkowych informacji w polach: - DodatkowyOpis – pole rezerwowe przeznaczone dla wykazywania dodatkowych informacji na fakturze, w tym wymaganych przepisami prawa, dla których nie przewidziano innych pól/elementów, - StopkaFaktury- pozostałe informacje na fakturze (maks. 3500 znaków).

## 14.Istnieją systemy, w których wygenerowanie numeru faktury wiąże się z faktycznym wystawieniem tej faktury z określoną datą. Nie ma możliwości zmiany daty wystawienia faktury, jeśli faktura nie zostanie przesłana do systemu w tym samym dniu. Tym samym data wystawienia wskazana w polu P_1 będzie inna niż data faktycznej wysyłki do KSeF. Jak rozwiązać powyższy problem?

Okoliczność, iż w polu P_1 wskazana jest inna data niż data przesłania faktury do KSeF nie spowoduje odrzucenia faktury przez system. W tym przypadku, zgodnie z art. 106na ust. 1 ustawy o VAT przyjmuje się, że faktura została wystawiona w dniu przesłania jej do KSeF, pomimo że w polu P_1 wskazano inną datę. Powyższe należy uwzględnić w systemach księgowych w przypadkach, w których data wystawienia faktury ma wpływ na datę ujęcia zdarzenia w ewidencji.

## 15.Struktura logiczna e-Faktury zawiera pole dobrowolne StatusInfoPodatnika. Czy informacja np. o tym, że sprzedawca znajduje się stanie likwidacji powinna być przechowywana i odkładana w systemie finansowo-księgowym nabywcy, który otrzymał taką fakturę, czy można ją pominąć?

Faktura ustrukturyzowana, którą pobierze nabywca ze swojego systemu finansowo-księgowego (za pośrednictwem API) zawiera identyczną treść w porównaniu do faktury przesłanej do KSeF przez sprzedawcę w formacie xml. Przepisy wprowadzające KSeF nie przewidują nowych, dodatkowych obowiązków ewidencyjnych po stronie nabywcy.

## 16.Jak będą wyglądały faktury wystawiane w walucie obcej dla kontrahentów polskich?

W takiej fakturze kwoty określone są wyłącznie w walucie obcej i jedynie kwota podatku w polu P_14_xW przeliczona jest na złotówki zgodnie z art. 106e ust. 11 ustawy o VAT. Wówczas oprócz pola KodWaluty wypełniane jest pole KursWaluty, względnie pole KursWalutyZ.

## 17.Czy jest dostępna lista pól obowiązkowych i nieobowiązkowych w strukturze logicznej e-Faktury?

Dobrowolnymi węzłami są węzły Rozliczenie, Płatnosc, WarunkiTransakcji oraz Stopka. Przy czym wypełniając węzły dobrowolne, może zachodzić konieczność wypełnienia pól obowiązkowych zawartych w tych węzłach. Węzeł Zamowienie dotyczy wyłącznie faktur zaliczkowych i ich korekt. W przypadku takich faktur nie wypełnia się węzła FaWiersze. Pozostałe pola wypełniane są w zależności od wymogów przewidzianych w ustawie dla danego dokumentowanego fakturą przypadku.

## 18.Czy istnieje możliwość dołączania do e-Faktury załączników, np. protokołów odbioru?

W okresie fakultatywnego KSeF nie jest możliwe dołączanie do faktur ustrukturyzowanych załączników. Natomiast istnieje możliwość zawarcia w treści faktury stosownego linka (w formie tekstowej) do takiej dokumentacji. Dodatkowe informacje można wpisać w polach DodatkowyOpis lub ewentualnie w stopce faktury. Załączniki mogą być również przekazywane w sposób odrębny poza KSeF. Na okres obowiązkowego KSeF planowane jest umożliwienie przesyłania do KSeF faktury z załącznikiem, w przypadku faktur o złożonym zakresie ceny, ilości i miary.

## 19.Struktura FA(2) w części podsumowania stawek VAT Faktura/Fa (np. P_13_1, P_14_1) nie pozwala nabywcy na jednoznaczną interpretację zastosowanej przez wystawiającego stawki VAT (22% i/lub 23%), Czy zostanie to poprawione w wersji struktury FA(3)?

Obowiązującą aktualnie stawką jest 23%. Przypadki dotyczące zastosowania stawki 22% są marginalne. Stawkę można zidentyfikować na poziomie wiersza faktury. Znajduje się tam pole P_12 będące polem słownikowym, w którym podatnik wskazuje konkretną stawkę podatku.

## 20.W jaki sposób oprócz numerów zamówienia nadawanych przez system dostawcy będą podawać także numery zamówień generowane przez system nabywcy?

Struktura e-Faktury KSeF umożliwia podawanie dodatkowych danych niewymaganych przepisami ustawy o VAT. Do ich prezentacji służy element DodatkowyOpis. Dane te mogą być podawane w odniesieniu do konkretnego wiersza faktury lub w odniesieniu do faktury jako całości.

## 21.Czy MF może rekomendować wystawcom FV lekowych właściwe pola, w których należy podawać serię i daty ważności produktów? Aktualnie obsługujemy około 450 dostawców, gdzie w dobie KSeF każdy może wskazać te dane nieobowiązkowo i w polach wybranych przez siebie.

Tego typu dane można umieszczać np. w polu DodatkowyOpis.

## 22.W schemie FA(2) oznaczenie „np” odnosi się wyłącznie do transakcji dostaw towarów i świadczenia usług poza terytorium kraju. W praktyce na fakturach takie oznaczenie stosuje się często dla sprzedaży bonów (innych niż bony jednego przeznaczenia) lub kart podarunkowych (lub innych transakcji, które nie podlegają ustawie o VAT). W jaki sposób wykazywać na fakturze KSeF takie operacje lub korygować tego typu operacje udokumentowane wcześniej fakturami wystawionymi poza KSeF?

W przypadku dokumentowania wyłącznie czynności niepodlegającej ustawie VAT tj. sprzedaży bonu różnego przeznaczenia – nie wystawia się faktury. Tego typu czynności i ich korekty niepodlegające ustawie VAT nie powinny być prezentowane na fakturze jako pozycje (wiersze) z oznaczeniem „np”. Mogą one zostać zaprezentowane w ramach informacji dodatkowych na fakturze, przy wykorzystaniu węzła fakultatywnego „Rozliczenie” (przy założeniu, że faktura zawiera także pozycje podlegające ustawie, a czynności niepodlegające stanowią dodatkowy element transakcji).

## 1.Czy system będzie przyjmował faktury bez elementów nieobowiązkowych (inne niż z ustawy o VAT), ale wynikających ze struktury?

Przesyłana faktura musi być zgodna z obowiązującą w chwili wystawienia strukturą logiczną e-Faktury. W przypadku, gdy faktura będzie zawierała błędy np. nie wszystkie wymagane przez strukturę pola zostaną wypełnione, faktura zostanie odrzucona. Należy podkreślić, że w strukturze istnieją pola, które stają się obowiązkowe w momencie wypełniania węzłów lub sekwencji o charakterze fakultatywnym, w których pola te są zawarte mimo, że dotyczą elementów których nie wymaga ustawa o VAT. W tego typu sytuacjach fakultatywność osiągana jest na poziomie węzła lub sekwencji. Zatem w przypadku wypełniania fakultatywnych węzłów zawartych w fakturze, pola obowiązkowe w tym węźle muszą zostać wypełnione dla skuteczności wysyłki pliku faktury.

## 2.Co się stanie jeśli wystawca prześle fakturę z błędami rachunkowymi - czyli nie bilansującą się?

Faktura zostanie przyjęta do KSeF, system nie weryfikuje błędów rachunkowych zawartych w fakturze. W przypadku wystąpienia takich błędów konieczne jest wystawienie faktury korygującej.

## 3.Czy w przypadku obowiązkowego KSeF wymagana będzie akceptacja odbiorcy faktury?

Jeśli KSeF będzie obowiązkowy zakłada się, że akceptacja odbiorcy faktury nie będzie wymagana.

## 4.W jaki sposób przekazać nabywcy fakturę w przypadku, o którym mowa w art. 106g ust. 3b ustawy o VAT, gdy sprzedawca z uwagi na brak akceptacji nabywcy przekazuje poza KSeF fakturę, którą wprowadził do systemu?

Przepisy ustawy o VAT nie ingerują w tę kwestię. Istotne jest aby dane przekazane nabywcy były zgodne z danymi wprowadzonymi do KSeF, tak aby obie strony transakcji posługiwały się dokumentem o tożsamej zawartości pod względem merytorycznym. Faktura taka może mieć tradycyjną postać papierową lub elektroniczną jeśli nabywca wyraził zgodę na otrzymywanie faktur elektronicznych, mimo że nie wyraził zgody na otrzymywanie faktur w KSeF.

## 5.Co się dzieje w przypadku gdy wysłana faktura do KSeF jest odrzucona, czy taką fakturę poprawiamy i wysyłamy ponownie ? Czy fakturę, która została odrzucona w KSeF można anulować lub wystawić korektę?

Faktura, która została odrzucona nie jest uznawana za wystawioną, zatem nie można do niej wystawić korekty ani jej anulować. W przypadku odrzucenia faktury przez system do decyzji podatnika należy, czy będzie chciał ją poprawić i wysłać ponownie do KSeF. Odrzucenie faktury przez system może wystąpić jedynie z powodu niezgodności struktury pliku z wzorem logicznym lub z powodu wprowadzania jej do systemu przez osobę nieuprawnioną. Zachęcamy do implementacji w systemach służących do fakturowania mechanizmów sprawdzających zgodność pliku xml ze wzorem struktury logicznej przed wysyłką pliku, co w praktyce wyeliminuje opisaną w pytaniu sytuację.

## 6.Czy wysyłając faktury lub paczki faktur wymagane jest posiadanie podpisu?

Wysyłkę można dokonać w ramach sesji interaktywnej lub wsadowej (paczki faktur). Wysyłka faktury bądź paczki faktur zostanie dokonana przez podatnika lub osobę uprawnioną, po prawidłowo zakończonym procesie autoryzacji tego użytkownika np. za pomocą kwalifikowanego podpisu elektronicznego.

## 7.Czy dokument musi zostać wysłany do KSeF w dniu wystawienia (jeśli data wystawienia dokumentu w pliku ma być tożsama z datą bieżącą)? Nie ma możliwości wysłania np. następnego dnia?

Dokument może zostać wysłany kolejnego dnia, przy zachowaniu ustawowo określonych terminów dotyczących wystawiania faktur. Wskazanie w polu P_1 konkretnej daty nie obliguje podatnika do wysłania w tym dniu faktury do KSeF.

## 8.Czy może być więcej wskazanych odbiorców faktury np. faktor?

Tak, struktura e-Faktury pozwala na wskazywanie dodatkowych podmiotów w tym m.in. faktorów. Wszystkie wskazane podmioty będą miały dostęp do faktury w ramach KSeF.

## 9.Czy numer faktury nadany przez KSeF powinien być zwrotnie przechowywany w systemach księgowych? Czy istnieją jakieś formy, obowiązki związane z raportowaniem nr KSeF?

W przypadku sprzedawcy istnieje konieczność przechowywania numeru KSeF, z uwagi na wymóg podawania go w ewentualnie wystawianych fakturach korygujących. W przypadku nabywcy przepisy nie zakładają takiego obowiązku. W celach dowodowych warto jednak ten numer przechowywać, gdyż fakt nadania tego numeru przesądza o tym, że faktura została wystawiona. Numer KSeF docelowo (w okresie obowiązkowego KSeF) będzie wykorzystywany także podczas tworzenia plików JPK_VAT z deklaracją.

## 10.Czy KSeF pozwoli na odrzucenie faktury w przypadku błędnie wystawionej faktury przez podatnika np. na niewłaściwego nabywcę?

Nie, w takim wypadku wystawca faktury będzie zobligowany do wystawienia korekty faktury.

## 11.Czy będzie możliwość masowego pobierania faktur w postaci plików xml oraz PDF poprzez API?

Tak, jest przewidziana możliwość masowego pobierania faktur, ale wyłącznie w postaci XML.

## 12.Faktura została przesłana do KSeF i został jej nadany numer identyfikujący w systemie. Sprzedawca chciałby dodatkowo przesłać nabywcy wydruk tej faktury. Czy na wydruku należy zawrzeć numer KSeF?

W strukturze logicznej e-Faktury nie jest przewidziane pole zawierające numer KSeF faktury ustrukturyzowanej. Nie ma konieczności umieszczania numeru identyfikującego fakturę w KSeF na wydruku faktury.

## 13.Czy w fakturze przesyłanej do KSeF należy wypełnić pole P_1 (data wystawienia), skoro fakturę ustrukturyzowaną uznaje się za wystawioną w dniu jej przesłania? Czy będzie mogło dojść do sytuacji, w której faktura ustrukturyzowana przesłana o 23:59 danego dnia (z perspektywy wysyłającego) zostanie uznana przez KSeF za przesłaną o 0:01 następnego dnia? Czy w sytuacji, gdy KSeF uzna fakturę ustrukturyzowaną za wystawioną (przesłaną) w innym dniu, niż data wskazana w polu P_1, faktura taka zostanie przez KSeF odrzucona?

Pole P_1 dotyczące daty wystawienia jest polem obowiązkowym, które musi zostać wypełnione aby faktura mogła być przyjęta przez KSeF. Faktura będzie uznana za wystawioną w dniu jej przesłania do KSeF zgodnie z art. 106na ust. 1 ustawy o VAT, czyli w momencie, w którym trafi do systemu niezależnie od późniejszego momentu jej przetworzenia. Informacja o dacie przesłania będzie znajdowała się w UPO. Data ta jest zawarta również w numerze nadanym przez KSeF. W przypadku gdy data wskazana w polu P_1 jest inna niż data przesłania faktura nie zostanie odrzucona przez KSeF

## 14.Jak i czy przesłać korektę błędnego NIP-u nabywcy? Jak rozumieć opis dla pola Podmiot2K – „Korekcie nie podlegają błędne numery identyfikujące nabywcę oraz dodatkowego nabywcę”?

W przypadku przesłania do systemu KSeF faktury z błędnym NIP nabywcy, w celu skorygowania zaistniałej sytuacji, należy przesłać fakturę korygującą "do zera" z tym błędnym NIP nabywcy i dodatkowo przesłać odrębną fakturę (pierwotną) z prawidłowym numerem NIP nabywcy. Wynika to z uwarunkowań systemowych. Faktura z błędnym NIP nabywcy zostanie po przetworzeniu udostępniona podmiotowi o takim numerze NIP. Zatem z przytoczonego opisu wynika, że w takich przypadkach nie należy wystawiać faktury korygującej błędny numer NIP na inny prawidłowy, gdyż w KSeF nie wystąpi sytuacja, że fakturę odebrał podmiot będący rzeczywistą stroną transakcji, a jedynie numer NIP podany w fakturze był błędny.

## 15.Zgodnie z przepisami ustawy o VAT warunkiem uznania faktury ustrukturyzowanej za wystawioną jest nadanie fakturze numeru KSeF. Czy oznacza to, że systemy księgowe muszą wstrzymać się z wprowadzaniem faktur sprzedażowych do momentu nadania numeru KSeF?

Zgodnie z art. 106na ust. 1 ustawy o VAT faktura jest uznana za wystawioną w dniu jej przesłania do Krajowego Systemu e-Faktur. W systemach księgowych w przypadkach, w których data wystawienia faktury ma wpływ na datę ujęcia zdarzenia w ewidencji, powyższe należy uwzględnić.

## 16.Czy papierowa forma faktury lub PDF formalnie będą całkowicie zbędne? Będą jedynie uprzejmością sprzedawcy względem nabywcy?

Tak papierowa forma faktury będzie zbędna. Obecnie nabywca może zażądać przekazania faktury w inny sposób np. papierowo lub elektronicznie.

## 17.Czy w KSeF można również wystawiać faktury dla osób prywatnych?

KSeF przewiduje możliwość wystawiania faktur dla podatników (B2B) jak również na rzecz osób nieprowadzących działalności gospodarczej (B2C) oraz umożliwia dostęp do tych faktur, m.in. poprzez tzw. dostęp anonimowy.

## 18.Data nadania numeru KSeF to według ustawy o VAT data dostarczenia faktury do odbiorcy. Jednak kontrahent nie dał nam zgody, ale my jako wystawca chcemy korzystać z systemu. Jak to wpływa na nas jako na wystawcę faktury? Jakie ma znaczenie data wysłania i czy ma ona jakiś związek z datą wystawienia faktury (pola z nagłówka z systemu do fakturowania)

W przypadku braku zgody nabywcy na otrzymywanie faktur ustrukturyzowanych w ramach KSeF, sprzedawca może przekazać, po uprzednim wystawieniu faktury ustrukturyzowanej w KSeF, w inny sposób, np. e-mailem (PDF), pocztą (wydruk). W takiej sytuacji dla sprzedawcy wiążąca jest data przesłania faktury do KSeF, natomiast nabywca ma prawo odliczenia nie wcześniej niż otrzyma fakturę poza KSeF.

## 19.Czy od kontrahenta, któremu wystawiam fakturę muszę otrzymać zgodę na przesłanie faktury przez KSeF? Czy zgoda jest domniemana?

Dla wystawienia faktury w KSeF nie jest konieczna zgoda kontrahenta. Kontrahent natomiast może nie wyrazić zgody na otrzymywanie faktur w KSeF. W przypadku braku zgody na otrzymywanie faktur w KSeF przez kontrahenta, taką fakturę należy dostarczyć do odbiorcy w inny uzgodniony sposób.

## 20.Czy numery nadane przez KSeF do naszych faktur będą musiały być przesyłane do odbiorców, aby ci mogli sobie pobrać faktury z KSeF?

Nie, odebranie faktury przez nabywcę nie wymaga posiadania przez niego nr KSeF faktury. Wyjątkiem jest tzw. anonimowy dostęp do faktury.

## 21.Czy będzie możliwe automatyczne pobieranie nowych faktury otrzymanych z systemu KSeF?

Automatyczne otrzymywanie nowych faktur z systemu KSeF jest możliwe. Szczegóły funkcjonalności uzależnione są od rozwiązań zaproponowanych przez dostawcę oprogramowania.

## 22.Proszę o informację co z fakturami wystawionymi błędnie na danego nabywcę, który ich nie akceptuje?

W przypadku wprowadzenia do systemu faktury na błędnego nabywcę (np. błędny NIP) w celu skorygowania zaistniałej sytuacji należy wystawić fakturę korygującą do zera z tym błędnym NIP nabywcy i odrębną fakturę (pierwotną) z prawidłowym numerem NIP nabywcy. Wynika to z uwarunkowań systemowych. Faktura z błędnym NIP nabywcy zostanie po przetworzeniu udostępniona podmiotowi o takim numerze NIP (o ile podmiot taki istnieje). Zatem z przytoczonego opisu wynika, że w takich przypadkach nie należy wystawiać faktury korygującej błędny numer NIP na inny prawidłowy, gdyż w systemie KSeF nie wystąpi sytuacja, że fakturę odebrał podmiot będący rzeczywistą stroną transakcji, a jedynie numer NIP podany w fakturze był błędny.

## 23.Czy po wystawieniu faktury w KSeF muszę wysłać do odbiorcy ten nr KSeF danej faktury? Czy dana faktura automatycznie pojawi się na koncie danego odbiorcy?

Nie ma konieczności wysyłania numeru KSeF e-faktury do odbiorcy, faktura będzie automatycznie dostępna w KSeF dla nabywcy. Nabywca może również uzyskać anonimowy dostęp do faktury, po wskazaniu zestawu określonych danych.

## 24.Czy odbiorca dostanie informację z KSeF, że jakiś podmiot wystawił dla niego fakturę?

Nie. Taka funkcjonalność nie jest zakładana, z uwagi na to, że dla podatników otrzymujących bardzo duże ilości faktur mogłoby to być utrudnieniem, a nie ułatwieniem. W celu uzyskania informacji o dostępnych fakturach program wykorzystywany przez podatnika będzie musiał „odpytywać” KSeF. Nie jest wiec wykluczone wprowadzanie takiej funkcjonalności na poziomie poszczególnych programów finansowo-księgowych. Zarówno wystawione jak i otrzymane faktury będą dostępne w narzędziu, które zostanie udostępnione przez Ministerstwo Finansów.

## 25.Co dokładnie jest sprawdzane przez system przed nadaniem nr KSeF?

Przed nadaniem numeru KSeF system weryfikuje poprawność semantyczną dokumentu oraz czy osoba wystawiająca fakturę posiada stosowne uprawnienie.

## 26.Czy KSeF umożliwia sprawdzenie, że faktura została pobrana przez nabywcę?

KSeF nie umożliwia sprawdzenia, że faktura została pobrana przez nabywcę.

## 27.Istnieją systemy, w których wygenerowanie numeru faktury wiąże się z faktycznym wystawieniem tej faktury z określoną datą. Nie ma możliwości zmiany daty wystawienia faktury, jeśli faktura nie zostanie przesłana do systemu w tym samym dniu. Tym samym data wystawienia wskazana w polu P_1 będzie inna niż data faktycznej wysyłki do KSeF. Jak rozwiązać powyższy problem?

Okoliczność, iż w polu P_1 wskazana jest inna data niż data przesłania faktury do KSeF nie spowoduje odrzucenia faktury przez system. W tym przypadku, zgodnie z art. 106na ust. 1 ustawy o VAT przyjmuje się, że faktura została wystawiona w dniu przesłania jej do KSeF, pomimo że w polu P_1 wskazano inną datę. Powyższe należy uwzględnić w systemach księgowych w przypadkach, w których data wystawienia faktury ma wpływ na datę ujęcia zdarzenia w ewidencji.

## 28.„Datą wystawienia faktury jest data przesłania jej do KSeF” - co w przypadku gdy podatnik wystawi  fakturę w swoim systemie, ale przesłanie jej do KSeF będzie niemożliwe z uwagi na awarię np. z powodu aktualizacji czy awarii technicznej?

W KSeF fakultatywnym, w czasie niedostępności KSeF nie jest możliwe korzystanie z systemu. Zatem faktury mogą być wystawiane wyłącznie w czasie dostępności systemu. W przypadku, gdy data wystawienia zawarta w fakturze (pole P_1) jest inna niż data przesłania do systemu, fakturę uznaje się za wystawioną w momencie jej przesłania zgodnie z art. 106na ust. 1 ustawy o VAT. Zgodnie z obowiązującym od 1 stycznia 2022 r. art. 106ne ustawy o VAT,  Minister właściwy do spraw finansów publicznych zamieszcza w Biuletynie Informacji Publicznej na stronie podmiotowej urzędu obsługującego tego ministra komunikaty dotyczące niedostępności Krajowego Systemu e-Faktur. W tym celu na stronie Ministerstwa Finansów pod adresem https://www.gov.pl/web/kas/krajowy-system-e-faktur opublikowano zakładkę „Komunikaty” gdzie publikowane będą informacje dotyczące między innymi niedostępności systemu. W okresie dobrowolnego stosowania KSeF fakturę można wystawić na dotychczasowych zasadach poza systemem. Na okres obligatoryjnego KSeF są przygotowane dedykowane dla tej sytuacji rozwiązania (art. 106nh oraz art. 106nf ustawy).

## 29.Czy wystawca faktury otrzyma zwrotnie nr nadany przez KSeF?

Tak, Nr KSeF jest zwracany w urzędowym poświadczeniu odbioru (UPO).

## 30.Co należy rozumieć pod pojęciem wysłania? Co jeżeli faktura nie zostanie prawidłowo zwalidowana?

Przez pojęcie wysłania należy rozumień zainicjowanie wysyłki e-Faktury w ramach otwartej sesji. W przypadku odrzucenia faktury przez system nie zostanie ona przesłana do KSeF. W takim wypadku należy zweryfikować poprawność wprowadzonych danych i ponowić wysyłkę.

## 31.Czy planowany jest jakiś mechanizm akceptacji faktury przez przedsiębiorcę zanim możliwe będzie jej pobranie przez księgowego? Albo inny mechanizm kwestionowania otrzymanej faktury przez przedsiębiorcę zanim zostanie zaksięgowana?

W przypadku wysyłki przez wystawcę faktury jest ona weryfikowana semantycznie przez KSeF.  Nie ma mechanizmu akceptacji e-Faktury przez nabywcę w KSeF. Przepisy ustawy o podatku od towarów i usług nie regulują tej kwestii. Kwalifikacja otrzymanej faktury pod kątem prawa do odliczenia spoczywa na nabywcy. Pobranie e-Faktury nie oznacza automatycznego wprowadzenia jej do ewidencji.

## 32.Jakie walidacje będzie zapewniał KSeF dla przekazywanej faktury?

System będzie walidował zgodność struktury pliku XML ze wzorem logicznym e-Faktury w formacie XSD oraz posiadane uprawnienia do korzystania z KSeF.

## 33.Czy uzyskane numery KSeF w ramach samofakturowania będą musiały być wysyłane do dostawcy? Kto będzie przesyłał te dane do KSeF: odbiorca (samofakturujący się) czy sprzedawca?

Sprzedawca będzie miał w systemie KSeF dostęp do faktur wystawionych przez nabywcę w ramach procedury samofakturowania. Nie ma konieczności przekazywania sprzedawcy nr KSeF wystawionych faktur.

## 34.Czy istnieje możliwość dołączania do e-Faktury załączników, np. protokołów odbioru?

W okresie fakultatywnego KSeF nie jest możliwe dołączanie do faktur ustrukturyzowanych załączników. Natomiast istnieje możliwość zawarcia w treści faktury stosownego linka (w formie tekstowej) do takiej dokumentacji. Dodatkowe informacje można wpisać w polach DodatkowyOpis lub ewentualnie w stopce faktury. Załączniki mogą być również przekazywane w sposób odrębny poza KSeF.

## 35.Czy faktury musimy wysyłać w tym samym dniu, w którym ją wystawiliśmy? Co w sytuacji jeżeli faktura zostanie wysłana przed północą, a data jej przyjęcia przez KSeF już będzie następnego dnia? Skoro teoretycznie data wystawienia jest datą przyjęcia przez KSeF?

Datą wystawienia faktury ustrukturyzowanej jest data przesłania faktury do KSeF, nawet jeśli w polu P_1 została wskazana inna data niż data przesłania. Jeżeli w polu P_1 podatnik wskaże np. 2024-07-01, ale do KSeF plik xml wyśle dopiero 2024-07-02 to plik nie zostanie z tego powodu odrzucony przez KSeF, ale faktura jest wystawiona z dniem 2 lipca 2024 r. Natomiast jeśli faktura zostanie przesłana do KSeF przed północą to datą wystawienia faktury w KSeF jest data rozpoczęcia przesyłania pliku (2024-07-01), nawet jeśli numer zostanie efektywnie nadany po północy (2024-07-02).

## 36.Czy wersja KSeF demo i przedprodukcyjna nie wysyła faktur do KSeF tylko jest to wersja testowa, a wersja produkcyjna KSeF wysyła faktury do KSeF?

Faktury wysyłane w wersji testowej i przedprodukcyjnej (Demo) trafiają do środowisk, które z założenia nie są środowiskami wywołującymi skutki prawne. Należy jednak pamiętać, że w przypadku podawania w takich fakturach numerów NIP nawet losowo generowanych, podmioty o tych NIP mają potencjalny dostęp do danych zawartych w takich fakturach. Jednocześnie przypominamy, że w środowisku testowym API oraz testowej wersji Aplikacji Podatnika nie należy używać rzeczywistych danych firmy. W wersji produkcyjnej faktury trafiają do obiegu prawnego – są wystawione w KSeF, są to faktury ustrukturyzowane w rozumieniu ustawy VAT.

## 37.Czym różni się wersja KSeF testowa, przedprodukcyjna (Demo) od wersji produkcyjnej?

W wersji produkcyjnej faktury trafiają do obiegu prawnego – są wystawione w KSeF, są to faktury ustrukturyzowane w rozumieniu ustawy VAT. W wersji testowej i przedprodukcyjnej (Demo) faktury nie wywołują skutków prawnych. W wersji testowej możliwa jest symulacja poświadczeń co oznacza możliwość autoryzacji w kontekście dowolnego NIP. W wersji Demo poświadczenia działają tak samo jak na środowisku produkcyjnym, czyli oparte są o rzeczywiste narzędzia autoryzacyjne.

## 38.Co w przypadku wystawienia faktury dla klienta spoza UE? Czy należy ją wystawić w wersji papierowej?

W przypadku wystawiania faktury dla podmiotu gospodarczego spoza UE, faktura będzie wystawiana za pośrednictwem KSeF i przekazywana nabywcy w sposób z nim uzgodniony. Faktura taka opatrywana będzie kodem QR.

## 39.W jakim terminie należy przekazać fakturę do KSeF?

KSeF służy do wystawiania faktur, a nie do ich ewidencjonowania. Zatem za fakturę będzie uznawany dokument elektroniczny wystawiony w KSeF z nadanym numerem KSeF. KSeF nie wprowadził zmian w terminach wystawiania faktur. Terminy wystawiania faktur reguluje ustawa VAT. Jedynie w sytuacji awarii KSeF lub niedostępności systemu, ustawa reguluje terminy przekazania do KSeF faktur wystawionych w tym okresie.

## 1.Co się dzieje w przypadku gdy wysłana faktura do KSeF jest odrzucona, czy taka fakturę poprawiamy i wysyłamy ponownie ? Czy fakturę, która została odrzucona w KSeF można anulować lub wystawić korektę?

Faktura, która została odrzucona nie jest uznawana za wystawioną, zatem nie można do niej wystawić korekty ani jej anulować. W przypadku odrzucenia faktury przez system do decyzji podatnika należy, czy będzie chciał ją poprawić i wysłać ponownie do KSeF. Odrzucenie faktury przez system może wystąpić jedynie z powodu niezgodności struktury pliku z wzorem logicznym lub z powodu wprowadzania jej do systemu przez osobę nieuprawnioną. Zachęcamy do implementacji w systemach służących do fakturowania mechanizmów sprawdzających zgodność pliku xml ze wzorem struktury logicznej przed wysyłką pliku, co w praktyce wyeliminuje opisaną w pytaniu sytuację.

## 2.Czy w KSeF przewidziana jest procedura samofakturowania?

Tak. Sprzedawca uprawniający nabywcę do samofakturowania będzie musiał nadać nabywcy to uprawnienie w KSeF. Faktury w ramach tej procedury będą mogły być wystawiane bezpośrednio przez nabywcę oraz przez podmioty uprawnione przez niego do wystawiania faktur w KSeF.

## 3.Czy może być więcej wskazanych odbiorców faktury np. faktor?

Tak, struktura e-Faktury pozwala na wskazywanie dodatkowych podmiotów w tym m.in. faktorów. Wszystkie wskazane podmioty będą miały dostęp do faktury w ramach KSeF.

## 4.Czy numer faktury nadany przez KSeF powinien być zwrotnie przechowywany w systemach księgowych? Czy istnieją jakieś formy, obowiązki związane z raportowaniem nr KSeF?

W przypadku sprzedawcy istnieje konieczność przechowywania numeru KSeF z uwagi na wymóg podawania go w ewentualnie wystawianych fakturach korygujących. W przypadku nabywcy przepisy nie zakładają takiego obowiązku jednak w celach dowodowych warto ten numer przechowywać, gdyż fakt nadania tego numeru przesądza o tym, że faktura została wystawiona. Nie przewiduje się dodatkowych obowiązków związanych z raportowaniem numerów KSeF.

## 5.Czy KSeF pozwoli na odrzucenie faktury w przypadku błędnie wystawionej faktury przez podatnika np. na niewłaściwego nabywcę?

Nie, w takim wypadku wystawca faktury będzie zobligowany do wystawienia korekty faktury.

## 6.Faktura została przesłana do KSeF i został jej nadany numer identyfikujący w systemie. Sprzedawca chciałby dodatkowo przesłać nabywcy wydruk tej faktury. Czy na wydruku należy zawrzeć numer KSeF?

W strukturze logicznej e-Faktury nie jest przewidziane pole zawierające numer KSeF faktury ustrukturyzowanej. Nie ma konieczności umieszczania numeru identyfikującego fakturę w KSeF na wydruku faktury.

## 7.Ile faktur korygujących można wystawić w KSeF do jednej faktury sprzedaży?

KSeF nie przewiduje ograniczeń pod kątem liczby faktur korygujących wystawionych do jednej faktury sprzedaży.

## 8.Czy faktury proforma mogą być wystawiane w KSeF?

Tzw. „proforma” nie jest fakturą w rozumieniu ustawy VAT. Zatem wystawianie takich dokumentów nie jest przewidziane w KSeF.

## 9.Zgodnie z przepisami ustawy o VAT warunkiem uznania faktury ustrukturyzowanej za wystawioną jest nadanie fakturze numeru KSeF. Czy oznacza to, że systemy księgowe muszą wstrzymać się z wprowadzaniem faktur sprzedażowych do momentu nadania numeru KSeF?

Zgodnie z art. 106na ust. 1 ustawy o VAT faktura jest uznana za wystawioną w dniu jej przesłania do Krajowego Systemu e-Faktur. W systemach księgowych w przypadkach, w których data wystawienia faktury ma wpływ na datę ujęcia zdarzenia w ewidencji, powyższe należy uwzględnić.

## 10.Jak powinna wyglądać korekta, jeżeli chcemy skorygować informacje niewpływające na wartość korekty, np. data sprzedaży, FP, MPP, TP, GTU itp. – czy to należy zrobić standardową korektą?

W przedstawionej sytuacji w KSeF można wystawić fakturę korygującą. W przypadku korekt niewpływających na wartość podstawy opodatkowania i kwotę podatku (np. data sprzedaży, oznaczenie FP, TP, adnotacja MPP, symbole GTU) w fakturze korygującej należy wskazać prawidłową treść korygowanych pozycji. W okresie fakultatywnego KSeF istnieje również możliwość wystawienia w tym zakresie noty korygującej przez nabywcę (poza KSeF).

## 11.Czy błędy formalne na fakturach będą wymagały wystawienia faktury korygującej?

Obecne brzmienie art. 106j ust. 1 ustawy o VAT obliguje do wystawienia faktury korygującej m. in. w sytuacji, gdy podatnik stwierdził pomyłkę w jakiejkolwiek pozycji faktury. W okresie dobrowolności KSeF, w określonych przypadkach istnieje możliwość wystawienia przez nabywcę noty korygującej poza systemem.

## 12.Czy papierowa forma faktury lub PDF formalnie będą całkowicie zbędne? Będą jedynie uprzejmością sprzedawcy względem nabywcy?

Tak papierowa forma faktury będzie zbędna. Obecnie nabywca może zażądać przekazania faktury w inny sposób np. papierowo lub elektronicznie.

## 13.Czy w KSeF można również wystawiać faktury dla osób prywatnych?

KSeF przewiduje możliwość wystawiania faktur dla podatników (B2B) jak również na rzecz osób nieprowadzących działalności gospodarczej (B2C) oraz umożliwia dostęp do tych faktur, m.in. poprzez tzw. dostęp anonimowy.

## 14.Data nadania numeru KSeF to według ustawy o VAT data dostarczenia faktury do odbiorcy. Jednak kontrahent nie dał nam zgody, ale my jako wystawca chcemy korzystać z systemu. Jak to wpływa na nas jako na wystawcę faktury? Jakie ma znaczenie data wysłania i czy ma ona jakiś związek z datą wystawienia faktury (pola z nagłówka z systemu do fakturowania)

W przypadku braku zgody nabywcy na otrzymywanie faktur ustrukturyzowanych w ramach KSeF, sprzedawca może przekazać, po uprzednim wystawieniu faktury ustrukturyzowanej w KSeF, w inny sposób, np. e-mailem (PDF), pocztą (wydruk). W takiej sytuacji dla sprzedawcy wiążąca jest data przesłania faktury do KSeF, natomiast nabywca ma prawo odliczenia nie wcześniej niż otrzyma fakturę poza KSeF.

## 15.Czy od kontrahenta, któremu wystawiam fakturę muszę otrzymać zgodę na przesłanie faktury przez KSeF? Czy zgoda jest domniemana?

Dla wystawienia faktury w KSeF nie jest konieczna zgoda kontrahenta. Kontrahent natomiast może nie wyrazić zgody na otrzymywanie faktur w KSeF. W przypadku braku zgody na otrzymywanie faktur w KSeF przez kontrahenta, taką fakturę należy dostarczyć do odbiorcy w inny uzgodniony sposób.

## 16.Czy numery nadane przez KSeF do naszych faktur będą musiały być przesyłane do odbiorców, aby ci mogli sobie pobrać faktury z KSeF?

Nie, odebranie faktury przez nabywcę nie wymaga posiadania przez niego nr KSeF faktury. Wyjątkiem jest tzw. anonimowy dostęp do faktury.

## 17.Czy będzie możliwe automatyczne pobieranie nowych faktury otrzymanych z systemu KSeF?

Automatyczne otrzymywanie nowych faktur z systemu KSeF jest możliwe. Szczegóły funkcjonalności uzależnione są od rozwiązań zaproponowanych przez dostawcę oprogramowania.

## 18.Proszę o informację co z fakturami wystawionymi błędnie na danego nabywcę, który ich nie akceptuje?

W przypadku wprowadzenia do systemu faktury na błędnego nabywcę (np. błędny NIP) w celu skorygowania zaistniałej sytuacji należy wystawić fakturę korygującą do zera z tym błędnym NIP nabywcy i odrębną fakturę (pierwotną) z prawidłowym numerem NIP nabywcy. Wynika to z uwarunkowań systemowych. Faktura z błędnym NIP nabywcy zostanie po przetworzeniu udostępniona podmiotowi o takim numerze NIP (o ile podmiot taki istnieje). Zatem z przytoczonego opisu wynika, że w takich przypadkach nie należy wystawiać faktury korygującej błędny numer NIP na inny prawidłowy, gdyż w systemie KSeF nie wystąpi sytuacja, że fakturę odebrał podmiot będący rzeczywistą stroną transakcji, a jedynie numer NIP podany w fakturze był błędny.

## 19.Czy po wystawieniu faktury w KSeF muszę wysłać do odbiorcy ten nr KSeF danej faktury? Czy dana faktura automatycznie pojawi się na koncie danego odbiorcy?

Nie ma konieczności wysyłania numeru KSeF e-faktury do odbiorcy, faktura będzie automatycznie dostępna w KSeF dla nabywcy. Nabywca może również uzyskać anonimowy dostęp do faktury, po wskazaniu zestawu określonych danych.

## 20.Czy odbiorca dostanie informację z KSeF, że jakiś podmiot wystawił dla niego fakturę?

Nie. Taka funkcjonalność nie jest zakładana, z uwagi na to, że dla podatników otrzymujących bardzo duże ilości faktur mogłoby to być utrudnieniem, a nie ułatwieniem. W celu uzyskania informacji o dostępnych fakturach program wykorzystywany przez podatnika będzie musiał „odpytywać” KSeF. Nie jest wiec wykluczone wprowadzanie takiej funkcjonalności na poziomie poszczególnych programów finansowo-księgowych. Zarówno wystawione jak i otrzymane faktury będą dostępne w narzędziu, które zostanie udostępnione przez Ministerstwo Finansów.

## 21.Co dokładnie jest sprawdzane przez system przed nadaniem nr KSeF?

Przed nadaniem numeru KSeF system weryfikuje poprawność semantyczną dokumentu oraz czy osoba wystawiająca fakturę posiada stosowne uprawnienie.

## 22.Jak będą wyglądały faktury wystawiane w walucie obcej dla kontrahentów polskich?

W takiej fakturze kwoty określone są wyłącznie w walucie obcej i jedynie kwota podatku w polu P_14_xW przeliczona jest na złotówki zgodnie z art. 106e ust. 11 ustawy o VAT. Wówczas oprócz pola KodWaluty wypełniane jest pole KursWaluty, względnie pole KursWalutyZ.

## 23.Czy wystawca faktury otrzyma zwrotnie nr nadany przez KSeF?

Tak, Nr KSeF jest zwracany w urzędowym poświadczeniu odbioru (UPO).

## 24.Co należy rozumieć pod pojęciem wysłania? Co jeżeli faktura nie zostanie prawidłowo zwalidowana?

Przez pojęcie wysłania należy rozumień zainicjowanie wysyłki e-Faktury w ramach otwartej sesji. W przypadku odrzucenia faktury przez system nie zostanie ona przesłana do KSeF. W takim wypadku należy zweryfikować poprawność wprowadzonych danych i ponowić wysyłkę.

## 25.Czy planowany jest jakiś mechanizm akceptacji faktury przez przedsiębiorcę zanim możliwe będzie jej pobranie przez księgowego? Albo inny mechanizm kwestionowania otrzymanej faktury przez przedsiębiorcę zanim zostanie zaksięgowana?

W przypadku wysyłki przez wystawcę faktury jest ona weryfikowana semantycznie przez KSeF.  Nie ma mechanizmu akceptacji e-Faktury przez nabywcę w KSeF. Przepisy ustawy o podatku od towarów i usług nie regulują tej kwestii. Kwalifikacja otrzymanej faktury pod kątem prawa do odliczenia spoczywa na nabywcy. Pobranie e-Faktury nie oznacza automatycznego wprowadzenia jej do ewidencji.

## 26.Jakie walidacje będzie zapewniał KSeF dla przekazywanej faktury?

System będzie walidował zgodność struktury pliku XML ze wzorem logicznym e-Faktury w formacie XSD oraz posiadane uprawnienia do korzystania z KSeF.

## 27.Czy uzyskane numery KSeF w ramach samofakturowania będą musiały być wysyłane do dostawcy? Kto będzie przesyłał te dane do KSeF: odbiorca (samofakturujący się) czy sprzedawca?

Sprzedawca będzie miał w systemie KSeF dostęp do faktur wystawionych przez nabywcę w ramach procedury samofakturowania. Nie ma konieczności przekazywania sprzedawcy nr KSeF wystawionych faktur.

## 28.Czy istnieje możliwość dołączania do e-Faktury załączników, np. protokołów odbioru?

W okresie fakultatywnego KSeF nie jest możliwe dołączanie do faktur ustrukturyzowanych załączników. Natomiast istnieje możliwość zawarcia w treści faktury stosownego linka (w formie tekstowej) do takiej dokumentacji. Dodatkowe informacje można wpisać w polach DodatkowyOpis lub ewentualnie w stopce faktury. Załączniki mogą być również przekazywane w sposób odrębny poza KSeF.

## 29.Czy będzie możliwość edytowania wystawionej faktury? W razie jakiegoś błędu?

Jeżeli fakturze został już nadany numer KSeF to jedyną formą poprawienia danych w tej fakturze jest wystawienie faktury korygującej przez sprzedawcę

## 30.Jeśli jako przedsiębiorca zatankuję na stacji paliw służbowy samochód, zapłacę gotówką i poproszę o fakturę na firmę, to czy wystawią mi jakieś potwierdzenie? Wystawią fakturę w czasie rzeczywistym?

Faktury w KSeF są wystawiane w czasie rzeczywistym. Fakturę wystawia się nie później niż 15. dnia kolejnego miesiąca po miesiącu w którym nastąpiła dostawa towarów. KSeF nie zmienia tych terminów. Jeżeli nabywcą będzie podatnik, to faktura będzie wystawiona obowiązkowo w KSeF. Nabywca otrzyma fakturę (plik xml) w KSeF. Nie ma przeszkód aby sprzedawca wydał nabywcy dodatkowo wizualizację tej faktury.

## 31.Czy jeżeli osoba fizyczna, nieprowadząca działalności gospodarczej wynajmuje firmie lokal to od 01.04.2026 r. będzie musiała wystawiać faktury w KSeF-ie (nie jest zarejestrowana do VAT)?

Osoba wynajmująca mieszkanie na gruncie ustawy VAT jest podatnikiem prowadzącym działalność gospodarczą. Jeżeli wartość jej sprzedaży w 2025 r. nie przekroczy 200 mln zł., wówczas obowiązkowym KSeF będzie objęta od 1 kwietnia 2026 r.

## 32.Osoba prowadząca gospodarstwo rolne (rozlicza VAT) wystawia faktury za sprzedaż swoich plonów. Niekiedy kontrahentem jest firma. Czy takie gospodarstwo będzie musiało wystawiać fakturę w KSeF?

Rolnik będący podatnikiem VAT czynnym dokonując sprzedaży na rzecz innego podatnika będzie zobowiązany wystawiać faktury w KSeF od 1 kwietnia 2026 r., jeżeli wartość osiągniętej przez niego sprzedaży w 2025 r. nie przekroczy 200 mln zł. W przypadku przekroczenia 200 mln zł., będzie zobowiązany wystawiać faktury w KSeF już od 1 lutego 2026 r.

## 33.Czy wizualizacja faktury może być w języku obcym lub dwujęzyczna?

Wizualizacja faktury (pliku xml) może być dokonana w języku obcym (lub może być dwujęzykowa). Kluczowe jest jednak aby treść faktury pod względem merytorycznym (po przetłumaczeniu) odpowiadała zawartości pliku xml przesłanego do KSeF.

## 34.Prowadzę wynajem lokalu jako osoba prywatna. Jestem podatnikiem VAT i wystawiam faktury dla firmy. Czy też takie faktury muszę wystawić w KSeF?

Jeżeli sprzedawcą jest podatnik, którego wartość sprzedaży w 2025 r. nie przekroczyła 200 mln zł., to od 1 kwietnia 2026 r. będzie on wystawiał faktury w KSeF na rzecz innych podatników. Natomiast w przypadku przekroczenia w 2025 r. wartości sprzedaży 200 mln zł., będzie zobowiązany wystawiać faktury w KSeF już od 1 lutego 2026 r.

## 35.Co to jest kod QR i co on zawiera? Czy jest obowiązkowe umieszczanie go na fakturze KSeF?

Kod QR jest to kod weryfikujący, który pozwoli zidentyfikować daną fakturę w KSeF.  Oznaczanie wizualizacji kodem QR będzie obowiązkowe w okresie obligatoryjnego KSeF. Przypadki w których będzie konieczne dokonanie oznaczenia faktury kodem QR są wskazane w szczególności w art. 106gb ust. 5 i 6 ustawy, art. 106nf ust. 3, ust. 8 oraz art. 106nh ust. 4 ustawy wchodzącymi z życie z dniem 1 lutego 2026 r. Szczegóły techniczne dotyczące kodów QR są przedstawione w projekcie rozporządzenia wykonawczego dostępne na stronie Rządowego Centrum Legislacji .

## 36.Podatnik wystawia faktury za wykonane usługi specjalistyczne i będzie chciał, aby obszerny opis docierał do odbiorcy. Czy będzie mógł wystawić fakturę w formie papierowej?

Wystawianie faktur w KSeF będzie obowiązkowe od 1 lutego 2026 r. W celu ujęcia dodatkowych informacji na fakturze nadal będzie można także wykorzystać pola DodatkowyOpis lub pole StopkaFaktury (zawiera maksymalnie 3500 znaków). Dodatkowo planowane jest umożliwienie przesyłania faktury z załącznikiem, w przypadku potrzeby zawarcia w załączniku złożonych danych w zakresie ceny, ilości i miary (szczególnie istotne dla dostawców mediów i firm świadczących usługi telekomunikacyjne).

## 37.Czy FV wystawiona w KSeF będzie widoczna dla osoby uprawnionej/biura rachunkowego od razu, czy dopiero po zatwierdzeniu jej przez nabywcę?

Faktura jest widoczna w momencie jej przetworzenia przez system KSeF. Dzieję się to co do zasady automatycznie bez opóźnień.

## 38.Czy mimo tego, że nabywca dostanie od nas fakturę w KSeF i tak musimy mu przesłać fakturę mailowo lub papierowo?

W okresie fakultatywnym KSeF – do końca stycznia 2026 r., jeżeli nabywca nie wyraził zgody na otrzymywanie faktur w KSeF, to należy jemu taką fakturę udostępnić w uzgodniony z nim sposób. Natomiast w okresie obligatoryjnym KSeF, do faktur wystawionych od 1 lutego 2026 r. nie ma obowiązku dodatkowego przekazywania nabywcy wizualizacji takiej faktury. Wyjątkiem jest sytuacja m.in. obowiązkowego przekazania faktury kontrahentowi zagranicznemu w sposób z nim uzgodniony, z tym że podatnik może uzgodnić z takim kontrahentem „zagranicznym”, że przekazanie mu faktury nastąpi w KSeF. Wówczas zapewnia jedynie dane niezbędne do dostępu nabywcy do faktury w KSeF. Szczegóły zaproponowano w projekcie rozporządzenia w sprawie korzystania z KSeF dostępnego na stronie Rządowego Centrum Legislacji .

## 39.Jak będą mogły wystawić fakturę osoby prowadzące działalność gospodarczą, a nie posiadające dostępu do Internetu, profilu zaufanego, nie obsługujące komputera, etc.?

Obowiązek wprowadzenia KSeF został wydłużony m.in. w celu stworzenia zaplecza technicznego pozwalającego na korzystanie z KSeF. Warto wykorzystać ten czas na dostosowanie posiadanych narzędzi do wymagań KSeF. Warto podkreślić, że korzystanie z Profilu Zaufanego jest bezpłatne, a Ministerstwo Finansów udostępnia bezpłatne narzędzia (Aplikację Podatnika KSeF, Aplikację Mobilną KSeF) pozwalające na korzystanie z KSeF. Prosimy o zapoznanie się z materiałami na stronie: https://www.podatki.gov.pl/KSeF/aplikacja-podatnika-KSeF-i-inne-narzedzia/ Możliwe jest także uprawnienie innej osoby do wystawiania faktur w KSeF Dodatkowo w okresie przejściowym, po wprowadzeniu obowiązkowego KSeF zostaną przewidziane dodatkowe rozwiązania związane z możliwością wystawiania poza KSeF faktur do 450 zł (maks. 10 tys. w skali  miesiąca) czy stosowanie trybu offline.

## 40.Czy wizualizacja faktur może być dowolna, skonfigurowana we własnym systemie FK? Czy powinna zawierać wszystkie dane z faktury i czy kod QR będzie obligatoryjny na wizualizacji?

Faktury w API KSeF dostępne są wyłącznie w postaci XML. Wizualizacja może być dowolna. Kwestia ta leży w gestii integratorów. Istotne jest tylko aby wizualizacja zawierała dane przesłane do KSeF w pliku xml. Wizualizacja powinna zawierać także kod QR.

## 41.Czy wizualizacja faktur może być dowolna, skonfigurowana we własnym systemie FK? Oczywiście wizualizacja zawierać będzie wszystkie dane z faktury. Czy kod QR będzie obligatoryjny na wizualizacji?

Faktury w API KSeF dostępne są wyłącznie w postaci XML. Wizualizacja może być dowolna. Kwestia ta leży w gestii integratorów. Istotne tylko, aby wizualizacja zawierała dane przesłane do KSeF w pliku xml. Wizualizacja powinna zawierać także kod QR.

## 42.Czy w przypadku wysyłki faktur w trybie offline datą wystawienia faktury będzie data jej przesłania do KSeF, czy data wystawienia faktury w systemie dostawcy?

Datą wystawienia faktury będzie data jej wystawienia w systemie dostawcy (data z pola P_1 struktury logicznej e-Faktury).

## 43.Czy w KSeF można wystawić fakturę sprzedażową nie posiadając identyfikatora podatkowego NIP?

W KSeF nie ma technicznej możliwości wystawienia faktury bez NIP sprzedawcy. Jest to pole wymagane w elemencie Podmiot1 struktury FA. Kluczowym elementem działania KSeF jest posiadanie numeru NIP przez podatnika (Podmiot1). Ma to znaczenie zarówno w kontekście wystawiania faktur, a także uwierzytelnienia i autoryzacji.

## 44.Jesteśmy producentem systemu ERP, mamy wdrożoną obsługę KSeF, ale potrzebujemy przetestować wysyłkę faktur do KSeF w trybie produkcyjnym. Czy w ramach testów technicznych możemy wysłać na środowisko produkcyjne fakturę na 1 zł i następnie jej korektę do zera? Czy po takiej jednej wysyłce mamy obowiązek obligatoryjnie korzystać z KSeF przed 01.02.2026 r. czy możemy tylko tę jedną FV wysłać, przetestować środowisko produkcyjne, a obligatoryjnie korzystać dopiero od 01.02.2026 r.?

Każda faktura wysłana do KSeF (do środowiska produkcyjnego) rodzi skutki podatkowe. Po wystawieniu w KSeF faktury na środowisku produkcyjnym nie ma możliwości jej anulowania, ponieważ weszła ona do obiegu prawnego. W tym przypadku należy wystawić fakturę korygującą „do zera”. Do testowania KSeF służy środowisko testowe oraz przedprodukcyjne (Demo). Wysłanie do KSeF faktury w okresie fakultatywnego funkcjonowania systemu (do środowiska produkcyjnego) nie oznacza, że od tego momentu wszystkie faktury należy wystawiać w tym systemie.

## 45.W jakim celu będą wprowadzone i utrzymywane różne tryby postępowania dla różnych awarii/niedostępności KSeF?

Potrzeba wprowadzenia trybu offline i trybu awaryjnego została zgłoszona w toku konsultacji społecznych. Regulacje w tym zakresie, opracowane przez MF, zostały skonsultowane ze stroną społeczną. Różne terminy dosłania do KSeF, faktur wystawionych w tych trybach, wynikają ze specyfiki zaistniałych okoliczności.

## 46.Czy wizualizacja faktury może odbywać się na innych formularzach niż ten zaproponowany przez Ministerstwo Finansów dla faktury ustrukturyzowanej? Czy może nie zawierać wszystkich danych, które zawiera faktura ustrukturyzowana?

Kwestia wizualizacji faktury leży w gestii wystawcy. Istnieje w tym zakresie dowolność. Wizualizacja powinna odzwierciedlać pod względem merytorycznym zawartość oryginału faktury, tak aby nie wprowadzać w błąd co do warunków transakcji osoby, która taką wizualizację otrzymuje.

## 1.Czy faktury od dostawców zagranicznych bez polskiego NIP będą musiały być raportowane do KSeF?

KSeF nie służy do raportowania faktur od dostawców zagranicznych.

## 2.Czy faktury proforma mogą być wystawiane w KSeF?

Tzw. „proforma” nie jest fakturą w rozumieniu ustawy VAT. Zatem wystawianie takich dokumentów nie jest przewidziane w KSeF.

## 3.Czy KSeF będzie obejmował faktury wystawiane na kasach fiskalnych online?

W okresie dobrowolności KSeF nie obejmuje faktur wystawianych przy użyciu kasy rejestrującej.

## 4.Czy faktury PDF dostarczane do konsumentów lub nabywców są równoważne (w rozumieniu prawnym/księgowym) z fakturami ustrukturyzowanymi?

Faktury wystawione w formacie PDF (wystawione poza KSeF) nie są tożsame z fakturą ustrukturyzowaną. Przez fakturę elektroniczną rozumie się fakturę w formie elektronicznej wystawioną i otrzymaną w dowolnym formacie elektronicznym. Natomiast faktura ustrukturyzowana jest przesyłana w formie pliku xml i wystawiona przy użyciu Krajowego Systemu e-Faktur wraz z przydzielonym numerem identyfikującym tę fakturę w tym systemie, która dodatkowo może być przekazywana po nadaniu numeru KSeF poza systemem w innej formie np. PDF (a w okresie obligatoryjności systemu będzie dodatkowo opatrywana kodem QR). W okresie dobrowolności systemu, faktury ustrukturyzowane funkcjonują w obrocie gospodarczym jako jedna z dopuszczanych form dokumentowania transakcji, obok faktur papierowych i obecnie występujących w obrocie gospodarczym faktur elektronicznych.

## 5.Czy i kiedy KSeF wskaże platformy brokerów?

W KSeF przyjęto inne rozwiązanie w porównaniu do PEF. KSeF nie potrzebuje wskazywania platformy brokerów, a dostarczanie przez podmioty komercyjne rozwiązań umożliwiających korzystanie z KSeF nie wymaga podpisywania umów z Ministerstwem Finansów. Zaznaczyć należy, że w okresie obligatoryjnym, KSeF i PEF zostaną odpowiednio zintegrowane.

## 6.Czy jeżeli osoba fizyczna, nieprowadząca działalności gospodarczej wynajmuje firmie lokal to od 01.04.2026 r. będzie musiała wystawiać faktury w KSeF-ie (nie jest zarejestrowana do VAT)?

Osoba wynajmująca mieszkanie na gruncie ustawy VAT jest podatnikiem prowadzącym działalność gospodarczą. Jeżeli wartość jej sprzedaży w 2025 r. nie przekroczy 200 mln, wówczas obowiązkowym KSeF będzie objęta od 1 kwietnia 2026 r.

## 7.Osoba prowadząca gospodarstwo rolne (rozlicza VAT) wystawia faktury za sprzedaż swoich plonów. Niekiedy kontrahentem jest firma. Czy takie gospodarstwo będzie musiało wystawiać fakturę w KSeF?

Rolnik będący podatnikiem VAT czynnym dokonując sprzedaży na rzecz innego podatnika będzie zobowiązany wystawiać faktury w KSeF od 1 kwietnia 2026 r., jeżeli wartość osiągniętej przez niego sprzedaży w 2025 r. nie przekroczy 200 mln zł. W przypadku przekroczenia 200 mln zł, będzie zobowiązany wystawiać faktury w KSeF już od 1 lutego 2026 r.

## 8.Jestem lekarzem na kontrakcie cywilno-prawnym pracującym w szpitalu. Od kiedy mam obowiązek KSeF?

Przewidziane pierwotnie regulacje, uzależniające termin wejścia w obowiązkowego KSeF w zależności od statusu podatnika zostały zniesione. Planowane jest etapowe wejście w życie obowiązkowego KSeF: Od 1 lutego 2026 r. dla przedsiębiorców, których wartość sprzedaży (wraz z kwotą podatku) przekroczyła w 2025 r. 200 mln zł, Od 1 kwietnia 2026 r. dla pozostałych przedsiębiorców.

## 9.Czy jak powiążę konto z KSeF i wystawię 2-3 faktury już dziś, a potem stwierdzę, że jednak nie chcę wystawiać i zacznę od 1 lutego 2026 r. tj. jak będzie obowiązek, to czy mogę wrócić z powrotem do trybu wystawiania jak do tej pory bez powiązania z KSeF?

Tak, w okresie fakultatywnym KSeF jest to możliwe. Należy jednak pamiętać, że faktury wystawione w KSeF trafią do obiegu prawnego.

## 10.Jak będą mogły wystawić fakturę osoby prowadzące działalność gospodarczą, a nie posiadające dostępu do Internetu, profilu zaufanego, nie obsługujące komputera, etc.?

Obowiązek wprowadzenia KSeF został wydłużony m.in. w celu stworzenia zaplecza technicznego pozwalającego na korzystanie z KSeF. Warto wykorzystać ten czas na dostosowanie posiadanych narzędzi do wymagań KSeF. Warto podkreślić, że korzystanie z Profilu Zaufanego jest bezpłatne, a Ministerstwo Finansów udostępnia bezpłatne narzędzia (Aplikację Podatnika KSeF, Aplikację Mobilną KSeF) pozwalające na korzystanie z KSeF. Prosimy o zapoznanie się z materiałami na stronie: https://www.podatki.gov.pl/KSeF/aplikacja-podatnika-KSeF-i-inne-narzedzia/ Możliwe jest także uprawnienie innej osoby do wystawiania faktur w KSeF Dodatkowo w okresie przejściowym, po wprowadzeniu obowiązkowego KSeF zostaną przewidziane dodatkowe rozwiązania związane z możliwością wystawiania poza KSeF faktur do 450 zł (maks. 10 tys. w skali  miesiąca), czy stosowanie trybu offline.

## 11.Czy spółki cywilne będą mogły zarejestrować się w KSeF i wystawiać faktury w tym systemie?

Tak, jeżeli posiadają kwalifikowaną pieczęć elektroniczną, to za pomocą tej pieczęci mogą uwierzytelnić się w KSeF i wystawiać faktury ustrukturyzowane. Jeżeli takiej pieczęci nie posiadają, w KSeF mogą uwierzytelnić się za pośrednictwem uprawnionej osoby, wskazanej w złożonym do US zawiadomieniu ZAW-FA.

## 1.Czy będzie możliwość masowego pobierania faktur w postaci plików xml oraz PDF poprzez API?

Tak, jest przewidziana możliwość masowego pobierania faktur, ale wyłącznie w postaci XML.

## 2.Czy możliwe będzie wykonywanie operacji administracyjnych tj. np. wyznaczenie osób fakturujących oraz wygenerowanie tokenów autoryzacyjnych poprzez aplikację dostarczoną przez Ministerstwo Finansów? Innymi słowy czy aplikacja systemu ERP może autoryzować się wyłącznie tokenem?

Tak

## 3.Czy tokeny są wieczne, czy wygasają?

KSeF nie określa czasu w jakim token jest ważny. Wygenerowany token pozostaje ważny do czasu jego unieważnienia przez użytkownika lub do dnia odebrania uprawnień użytkownikowi.

## 4.Czy KSeF przeszedł lub przejdzie audyt bezpieczeństwa przeprowadzony przez niezależną zewnętrzną firmę?

TAK, KSeF przeszedł audyt bezpieczeństwa.

## 5.Czy KSeF umożliwia sprawdzenie, że faktura została pobrana przez nabywcę?

KSeF nie umożliwia sprawdzenia, że faktura została pobrana przez nabywcę.

## 6.Czy na środowisku testowym istnieje możliwość wygenerowania pieczęci?

W wersji testowej API możliwe jest zastosowanie samodzielnie wygenerowanych podpisów i pieczęci: Za podpis można uznać certyfikat Który posiada w opisie podmiotu obowiązkowo pola imiona (OID.2.5.4.42) i nazwisko (OID.2.5.4.4) oraz opcjonalnie numer seryjny (OID.2.5.4.5) zgodnie z formatem: (PNOPL|PESEL).*?(?<number>\\d{11}) lub (TINPL|NIP).*?(?<number>\\d{10}) Za pieczęć można uznać certyfikat Który posiada w opisie podmiotu obowiązkowe pole identyfikatora organizacji (OID.2.5.4.97) zgodnie z formatem: (VATPL).*?(?<number>\\d{10})

## 7.Czy jest przewidziana redundancja aplikacji na wypadek jej awarii? Jaka jest przewidywana dostępność aplikacji?

Tak, jest przewidziana redundancja systemu na wypadek jej awarii. System będzie działał 24/7/365 (24 godziny na dobę, 7 dni w tygodniu i 365 dni w roku).

## 8.Czy serwery Ministerstwa Finansów są już gotowe na przyjmowanie dużych ilości faktur i ich archiwizowanie?

Tak, infrastruktura techniczna KSeF jest adekwatna do jego zakresu i skali.

## 9.Czy i kiedy KSeF wskaże platformy brokerów?

W KSeF przyjęto inne rozwiązanie w porównaniu do PEF. KSeF nie potrzebuje wskazywania platformy brokerów, a dostarczanie przez podmioty komercyjne rozwiązań umożliwiających korzystanie z KSeF nie wymaga podpisywania umów z Ministerstwem Finansów.

## 10.Czy wersja KSeF demo i przedprodukcyjna nie wysyła faktur do KSeF tylko jest to wersja testowa, a wersja produkcyjna KSeF wysyła faktury do KSeF?

Faktury wysyłane w wersji testowej i przedprodukcyjnej (Demo) trafiają do środowisk, które z założenia nie są środowiskami wywołującymi skutki prawne. Należy jednak pamiętać, że w przypadku podawania w takich fakturach numerów NIP nawet losowo generowanych, podmioty o tych NIP mają potencjalny dostęp do danych zawartych w takich fakturach. Jednocześnie przypominamy, że w środowisku testowym API oraz testowej wersji Aplikacji Podatnika nie należy używać rzeczywistych danych firmy. (link do środowiska testowego: <a href=" https://ksef-test.mf.gov.pl/web/login "> https://ksef-test.mf.gov.pl/web/login</a>) W wersji produkcyjnej faktury trafiają do obiegu prawnego – są wystawione w KSeF, są to faktury ustrukturyzowane w rozumieniu ustawy VAT.

## 11.Czym różni się wersja KSeF testowa, przedprodukcyjna (Demo) od wersji produkcyjnej?

W wersji produkcyjnej faktury trafiają do obiegu prawnego – są wystawione w KSeF, są to faktury ustrukturyzowane w rozumieniu ustawy VAT. W wersji testowej i przedprodukcyjnej (Demo) faktury nie wywołują skutków prawnych. W wersji testowej możliwa jest symulacja poświadczeń co oznacza możliwość autoryzacji w kontekście dowolnego NIP. W wersji Demo poświadczenia działają tak samo jak na środowisku produkcyjnym, czyli oparte są o rzeczywiste narzędzia autoryzacyjne.

## 12.Jesteśmy producentem systemu ERP, mamy wdrożoną obsługę KSeF, ale potrzebujemy przetestować wysyłkę faktur do KSeF w trybie produkcyjnym. Czy w ramach testów technicznych możemy wysłać na środowisko produkcyjne fakturę na 1 zł i następnie jej korektę do zera? Czy po takiej jednej wysyłce mamy obowiązek obligatoryjnie korzystać z KSeF przed 01.02.2026 r. czy możemy tylko tę jedną FV wysłać, przetestować środowisko produkcyjne, a obligatoryjnie korzystać dopiero od 01.02.2026 r.?

Każda faktura wysłana do KSeF (do środowiska produkcyjnego) rodzi skutki podatkowe. Po wystawieniu w KSeF faktury na środowisku produkcyjnym nie ma możliwości jej anulowania, ponieważ weszła ona do obiegu prawnego. W tym przypadku należy wystawić fakturę korygującą „do zera”. Do testowania KSeF służy środowisko testowe oraz przedprodukcyjne (Demo). Wysłanie do KSeF faktury w okresie fakultatywnego funkcjonowania systemu (do środowiska produkcyjnego) nie oznacza, że od tego momentu wszystkie faktury należy wystawiać w tym systemie.

## 13.Gdzie w systemie KSeF jest widoczna informacja, kiedy fakturze został nadany numer KSeF (czyli data otrzymania faktury)?

Informacja ta jest podana w UPO w polu "Data przyjęcia dokumentu do systemu teleinformatycznego MF”. Dane te są także dostępne u nabywcy w poszczególnych narzędziach zintegrowanych z API KSeF.

## 14.Czy istnieje strona, na której znajduje się więcej szczegółowych informacji dla firm tworzących oprogramowanie i integrujących je z KSeF?

Oficjalną stroną, na której można znaleźć szczegółowe informacje dla firm tworzących oprogramowanie dla KSeF jest strona ksef.podatki.gov.pl. Na stronie tej są również dostępne linki do technicznych webinariów dotyczących KSeF. Dokumentacja techniczna znajduje się pod poniższymi adresami: w zakresie środowiska produkcyjnego: https://ksef.mf.gov.pl/ , w zakresie środowiska przedprodukcyjnego (Demo): https://ksef-demo.mf.gov.pl/ , w zakresie środowiska testowego: https://ksef-test.mf.gov.pl/ .

## 15.Kiedy zostaną udostępnione przykłady kodu, ułatwiające integracje systemu informatycznego z systemem KSeF?

Nie jest planowane udostępnienie przykładów użycia. Dostępna jest dokumentacja techniczna – Specyfikacja Oprogramowania Interfejsowego KSeF.

## 16.Czy powstaną oficjalne biblioteki lub przykłady komunikacji API w jednym z popularnych języku programowania?

Takie działania nie są planowane. Dostępna jest dokumentacja techniczna – Specyfikacja Oprogramowania Interfejsowego KSeF.

## 17.Czy dokumentacja zostanie rozszerzona o nagłówki oraz przesyłane podczas odpytywania API?

Nagłówki zawarte są w kontrakcie.

## 18.Czy powstanie wersja SOAP API pomagająca w integracji programów firm trzecich w celu wysyłki i pobierania faktur z systemu KSeF? Powstaną dodatkowe opisy i przykłady w dokumentacji na temat komunikacji z REST API?

Takie działania nie są planowane. Dostępna jest dokumentacja techniczna – specyfikacja interfejsów KSeF.

## 19.Czy w API KSeF będzie możliwość pobierania faktur przyrostowo bez stronicowania?

Nie.

## 1.Czy zamieszczanie numeru KSeF w przelewie zgodnie z ustawą VAT będzie obowiązkowe dopiero od 1 sierpnia 2026 r.?

Przepis dodawanego art. 108g ustawy VAT wchodzi w życie z dniem 1 lutego 2026 r. Jednak zgodnie z przepisem przejściowym (art. 17 ustawy zmieniającej) przepis art. 108g ustawy stosuje się do płatności dokonanych od dnia 1 sierpnia 2026 r. Planowane jest aby w tym samym terminie zaczął obowiązywać znowelizowany art. 108a ust. 3 pkt 3 wprowadzający obowiązkowe zamieszczenie numeru KSeF w przelewie w zakresie faktur, których płatność regulowana jest w mechanizmie podzielonej płatności (kwoty VAT wpłacane na odrębny rachunek techniczny podatnika).

## 2.Czy JPK FA będzie dalej obowiązywać, ale będzie wyłączony z raportowania?

Rozwiązanie jakim jest przesyłanie na żądanie organu podatkowego plików JPK_FA pozostanie, ale nie będzie dotyczyło faktur, które znajdują się w KSeF.

## 3.Czy do wystawiania faktur konieczne jest posiadanie programu do wystawiania faktur z płatną subskrypcją, czy można wystawiać poprzez KSeF?

Ministerstwo Finansów udostępnia bezpłatne narzędzia pozwalające na korzystanie z KSeF. Prosimy o zapoznanie się z materiałami na stronie Portalu podatkowego w zakładce Bezpłatne narzędzia KSeF .

## 4.Czy KSeF przewiduje jakieś mechanizmy przeciwdziałania oszustwom i nadużyciom?

W KSeF jest przygotowywane rozwiązanie techniczne pozwalające na identyfikację działań niepożądanych, w tym zgłaszanie faktur w stosunku do których zachodzi podejrzenie oszustwa. W związku z tym przygotowane zostaną również odpowiednie wyjaśnienia dotyczące tej funkcjonalności.

