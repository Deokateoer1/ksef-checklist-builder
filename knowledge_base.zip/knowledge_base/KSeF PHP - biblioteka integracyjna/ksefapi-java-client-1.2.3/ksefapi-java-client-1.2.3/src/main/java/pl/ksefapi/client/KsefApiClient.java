/**
 * Copyright 2025 NETCAT (www.netcat.pl)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * @author NETCAT <firma@netcat.pl>
 * @copyright 2025 NETCAT (www.netcat.pl)
 * @license http://www.apache.org/licenses/LICENSE-2.0
 */

package pl.ksefapi.client;

import com.fasterxml.jackson.databind.*;
import pl.ksefapi.client.model.*;
import pl.ksefapi.client.model.Error;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSocketFactory;
import java.io.InputStream;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.X509EncodedKeySpec;
import java.time.LocalDateTime;
import java.util.*;

/**
 * KSEF API service client
 */
public class KsefApiClient {
	
	public final static String VERSION = "1.2.3";

	public final static String PRODUCTION_URL = "https://ksefapi.pl/api";
	public final static String TEST_URL = "https://ksefapi.pl/api-test";
	public final static String NIP24_URL = "https://www.nip24.pl/api/ksef";

	public final static String ENC_ALG = "AES/CBC/PKCS5Padding";
	public final static int ENC_ALG_BLOCK_SIZE = 16;
	public final static int ENC_ALG_KEY_SIZE = 32;
	
	private SSLSocketFactory ssf;
	private HostnameVerifier hv;
	private SecureRandom sr;
	private WebProxy wp;

	private String url;
	private final String id;
	private final String key;
	
	private Error error;

	/**
	 * Create new client object
	 * @param url VIES API service URL address
	 * @param id API key identifier
	 * @param key API key
	 */
	public KsefApiClient(String url, String id, String key) {
		this.url = url;
		this.id = id;
		this.key = key;
		
		try {
			this.sr = SecureRandom.getInstance("SHA1PRNG");
			
			String seed = (System.getProperties().toString() + new Date().toString() + this.hashCode()
				+ url + id + key);
			
			this.sr.setSeed(seed.getBytes());
		} catch (NoSuchAlgorithmException ignored) {
		}
	}

	/**
	 * Create new client object
	 * @param url VIES API service URL address
	 * @param id API key identifier
	 * @param key API key
	 */
	public KsefApiClient(URL url, String id, String key) {
		this(url.toString(), id, key);
	}

	/**
	 * Set non default service URL
	 * @param url service URL
	 */
	public void setURL(String url) {
		this.url = url;
	}
	
	/**
	 * Set custom SSL socker factory
	 * @param ssf obiekt fabryki SSL
	 */
	public void setSSLSocketFactory(SSLSocketFactory ssf) {
		this.ssf = ssf;
	}
	
	/**
	 * Set custom hostname verifier
	 * @param hv hostname verifier
	 */
	public void setHostnameVerifier(HostnameVerifier hv) {
		this.hv = hv;
	}

	/**
	 * Set custom web proxy
	 * @param wp web proxy
	 */
	public void setWebProxy(WebProxy wp) {
		this.wp = wp;
	}
	
	/**
	 * Get last error details
	 * @return error object
	 */
	public Error getLastError() {
		return error;
	}

	/**
	 * Generate new init vector for AES256
	 * @return init vector or null
	 */
	public byte[] generateInitVector() {
		try {
			clear();

			byte[] b = new byte[ENC_ALG_BLOCK_SIZE];
			sr.nextBytes(b);

			return b;
		}
		catch (Exception e) {
			set(ClientError.CLI_EXCEPTION, e.getMessage());
		}

		return null;
	}

	/**
	 * Generate new AES256 key
	 * @return AES key or null
	 */
	public byte[] generateKey() {
		try {
			clear();

			byte[] b = new byte[ENC_ALG_KEY_SIZE];
			sr.nextBytes(b);

			return b;
		}
		catch (Exception e) {
			set(ClientError.CLI_EXCEPTION, e.getMessage());
		}

		return null;
	}

	/**
	 * Encrypt AES256 key with KSeF public key
	 * @param publicKey KSeF public key
	 * @param key AES256 key to encrypt
	 * @return encrypted AES256 key
	 */
	public byte[] encryptKey(KsefPublicKeyResponse publicKey, byte[] key) {
		try {
			clear();

			if (publicKey == null || key == null || key.length != ENC_ALG_KEY_SIZE) {
				set(ClientError.CLI_INPUT);
				return null;
			}

			// load public key
			KeyFactory kf = KeyFactory.getInstance("RSA");
			PublicKey pk = kf.generatePublic(new X509EncodedKeySpec(publicKey.getPublicKey()));

			// encrypt
			Cipher cipher = Cipher.getInstance("RSA");
			cipher.init(Cipher.ENCRYPT_MODE, pk);

			return cipher.doFinal(key);
		}
		catch (Exception e) {
			set(ClientError.CLI_EXCEPTION, e.getMessage());
		}

		return null;
	}

	/**
	 * Encrypt data with AES256 key
	 * @param iv init vector
	 * @param key AES256 key
	 * @param data data to encrypt
	 * @return encrypted data
	 */
	public byte[] encryptData(byte[] iv, byte[] key, byte[] data) {
		try {
			clear();

			if (iv == null || iv.length != ENC_ALG_BLOCK_SIZE || key == null || key.length != ENC_ALG_KEY_SIZE
				|| data == null || data.length == 0) {

				set(ClientError.CLI_INPUT);
				return null;
			}

			// aes encryption
			SecretKeySpec sks = new SecretKeySpec(key, "AES");
			IvParameterSpec ivps = new IvParameterSpec(iv);

			Cipher cipher = Cipher.getInstance(ENC_ALG);
			cipher.init(Cipher.ENCRYPT_MODE, sks, ivps);

			return cipher.doFinal(data);
		}
		catch (Exception e) {
			set(ClientError.CLI_EXCEPTION, e.getMessage());
		}

		return null;
	}

	/**
	 * Decrypt data with AES256 key
	 * @param iv init vector
	 * @param key AES256 key
	 * @param encrypted encrypted data
	 * @return decrypted plain data
	 */
	public byte[] decryptData(byte[] iv, byte[] key, byte[] encrypted) {
		try {
			clear();

			if (iv == null || iv.length != ENC_ALG_BLOCK_SIZE || key == null || key.length != ENC_ALG_KEY_SIZE
				|| encrypted == null || encrypted.length == 0) {

				set(ClientError.CLI_INPUT);
				return null;
			}

			// aes decryption
			SecretKeySpec sks = new SecretKeySpec(key, "AES");
			IvParameterSpec ivps = new IvParameterSpec(iv);

			Cipher cipher = Cipher.getInstance(ENC_ALG);
			cipher.init(Cipher.DECRYPT_MODE, sks, ivps);

			return cipher.doFinal(encrypted);
		}
		catch (Exception e) {
			set(ClientError.CLI_EXCEPTION, e.getMessage());
		}

		return null;
	}

	/**
	 * Get SHA256 hash
	 * @param data input data
	 * @return output hash as raw binary
	 */
	public byte[] getHash(byte[] data) {
		try {
			clear();

			if (data == null || data.length == 0) {
				set(ClientError.CLI_INPUT);
				return null;
			}

			// hash
			MessageDigest md = MessageDigest.getInstance("SHA-256");

			return md.digest(data);
		}
		catch (Exception e) {
			set(ClientError.CLI_EXCEPTION, e.getMessage());
		}

		return null;
	}

	/**
	 * Get KSeF public key
	 * @return KSeF public key for encryption or null in case of error
	 */
	public KsefPublicKeyResponse ksefPublicKey() {
		try {
			clear();

			// send
			return getObject(url + "/invoice/public/key", null, KsefPublicKeyResponse.class);
		}
		catch (Exception e) {
			set(ClientError.CLI_EXCEPTION, e.getMessage());
		}

		return null;
	}

	/**
	 * Open a new KSeF session (with encryption)
	 * @param invoiceVersion requested invoice schema version
	 * @param initVector AES256 init vector
	 * @param encryptedKey encrypted AES256 key
	 * @return new session data or null
	 */
	public KsefSessionOpenResponse ksefSessionOpen(KsefInvoiceVersion invoiceVersion, byte[] initVector, byte[] encryptedKey) {
		try {
			clear();

			// req
			KsefSessionOpenRequest req = new KsefSessionOpenRequest();
			req.setInvoiceVersion(invoiceVersion);
			req.setInitVector(initVector);
			req.setEncryptedKey(encryptedKey);

			byte[] json = Utils.getJsonMapper().writeValueAsBytes(req);

			if (json == null) {
				set(ClientError.CLI_JSON);
				return null;
			}

			// send
			return getObject(url + "/invoice/session/open", "application/json", json, null, KsefSessionOpenResponse.class);
		}
		catch (Exception e) {
			set(ClientError.CLI_EXCEPTION, e.getMessage());
		}

		return null;
	}

	/**
	 * Open a new KSeF session (without encryption)
	 * @param invoiceVersion requested invoice schema version
	 * @return new session data or null
	 */
	public KsefSessionOpenResponse ksefSessionOpen(KsefInvoiceVersion invoiceVersion) {
		return ksefSessionOpen(invoiceVersion, null, null);
	}

	/**
	 * Get KSeF session status
	 * @param sessionId session id
	 * @return session status or null
	 */
	public KsefSessionStatusResponse.StatusEnum ksefSessionStatus(String sessionId) {
		try {
			clear();

			// send
			KsefSessionStatusResponse res = getObject(url + "/invoice/session/status/" + URLEncoder.encode(sessionId,
					StandardCharsets.UTF_8), null, KsefSessionStatusResponse.class);

			if (res == null) {
				return null;
			}

			return res.getStatus();
		}
		catch (Exception e) {
			set(ClientError.CLI_EXCEPTION, e.getMessage());
		}

		return null;
	}

	/**
	 * Close KSeF session
	 * @param sessionId session id
	 * @return closing result
	 */
	public boolean ksefSessionClose(String sessionId) {
		try {
			clear();

			// send
			KsefSessionCloseResponse res = getObject(url + "/invoice/session/close/" + URLEncoder.encode(sessionId,
					StandardCharsets.UTF_8), null, KsefSessionCloseResponse.class);

			if (res == null) {
				return false;
			}

			return res.getResult();
		}
		catch (Exception e) {
			set(ClientError.CLI_EXCEPTION, e.getMessage());
		}

		return false;
	}

	/**
	 * Get UPO for specified session (session must be closed)
	 * @param sessionId session id
	 * @return XML with UPO or null
	 */
	public String ksefSessionUpo(String sessionId) {
		try {
			clear();

			// sned
			byte[] res = send(url + "/invoice/session/upo/" + URLEncoder.encode(sessionId, StandardCharsets.UTF_8),
					"text/xml");

			if (res == null) {
				return null;
			}

			return new String(res, StandardCharsets.UTF_8);
		} catch (Exception e) {
			set(ClientError.CLI_EXCEPTION, e.getMessage());
		}

		return null;
	}

	/**
	 * Generate an invoice XML
	 * @param invoice invoice object
	 * @return invoice XML or null
	 */
	public String ksefInvoiceGenerate(Faktura invoice) {
		try {
			clear();

			// req
			KsefInvoiceGenerateRequest req = new KsefInvoiceGenerateRequest();
			req.setInvoice(invoice);

			byte[] json = Utils.getJsonMapper().writeValueAsBytes(req);

			if (json == null) {
				set(ClientError.CLI_JSON);
				return null;
			}

			// send
			byte[] res = send(url + "/invoice/generate", "application/json", json, "text/xml");

			if (res == null) {
				return null;
			}

			return new String(res, StandardCharsets.UTF_8);
		} catch (Exception e) {
			set(ClientError.CLI_EXCEPTION, e.getMessage());
		}

		return null;
	}

	/**
	 * Validate invoice XML against XSD schema
	 * @param invoiceXml invoice XML
	 * @return validation result or null
	 */
	public KsefInvoiceValidateResponse ksefInvoiceValidate(String invoiceXml) {
		try {
			clear();

			// send
			return getObject(url + "/invoice/validate", "text/xml", invoiceXml.getBytes(StandardCharsets.UTF_8),
					null, KsefInvoiceValidateResponse.class);
		} catch (Exception e) {
			set(ClientError.CLI_EXCEPTION, e.getMessage());
		}

		return null;
	}

	/**
	 * Send an invoice
	 * @param sessionId session id
	 * @param size plain invoice size in bytes (only for encrypted data)
	 * @param hash plain invoice SHA256 hash (only for encrypted data)
	 * @param data plain or encrypted invoice data
	 * @return sending result with invoice id or null
	 */
	public KsefInvoiceSendResponse ksefInvoiceSend(String sessionId, int size, byte[] hash, byte[] data) {
		try {
			clear();

			// req
			KsefInvoiceSendRequest req = new KsefInvoiceSendRequest();
			req.setSessionId(sessionId);

			if (size <= 0 && hash == null) {
				KsefInvoicePlain plain = new KsefInvoicePlain();
				plain.setInvoice(data);

				req.setPlain(plain);
			} else {
				KsefInvoiceEncrypted enc = new KsefInvoiceEncrypted();
				enc.setInvoiceSize(size);
				enc.setInvoiceHash(hash);
				enc.setEncryptedInvoice(data);

				req.setEncrypted(enc);
			}

			byte[] json = Utils.getJsonMapper().writeValueAsBytes(req);

			if (json == null) {
				set(ClientError.CLI_JSON);
				return null;
			}

			// sned
			return getObject(url + "/invoice/send", "application/json", json, null,
					KsefInvoiceSendResponse.class);
		} catch (Exception e) {
			set(ClientError.CLI_EXCEPTION, e.getMessage());
		}

		return null;
	}

	/**
	 * Get status of specified invoice
	 * @param invoiceId invoice id
	 * @return invoice status including KSeF ref number and acquisition timestamp or null
	 */
	public KsefInvoiceStatusResponse ksefInvoiceStatus(String invoiceId) {
		try {
			clear();

			// send
			return getObject(url + "/invoice/status/" + URLEncoder.encode(invoiceId, StandardCharsets.UTF_8),
					null, KsefInvoiceStatusResponse.class);
		} catch (Exception e) {
			set(ClientError.CLI_EXCEPTION, e.getMessage());
		}

		return null;
	}

	/**
	 * Get an invoice
	 * @param sessionId session id
	 * @param ksefRefNumber invoice KSeF reference number
	 * @return invoice XML as plain or encrypted data (depends on session type)
	 */
	public byte[] ksefInvoiceGet(String sessionId, String ksefRefNumber) {
		try {
			clear();

			// send
			byte[] res = send(url + "/invoice/get/" + URLEncoder.encode(sessionId, StandardCharsets.UTF_8)
					+ "/" + URLEncoder.encode(ksefRefNumber, StandardCharsets.UTF_8), "application/octet-stream");

			if (res == null) {
				return null;
			}

			return res;
		} catch (Exception e) {
			set(ClientError.CLI_EXCEPTION, e.getMessage());
		}

		return null;
	}

	/**
	 * Start new invoice query
	 * @param sessionId session id
	 * @param subjectType invoice subject type (subject1, subject2, subject3, subjectAuthorized)
	 * @param from begin of range
	 * @param to end of range
	 * @return new query id or null
	 */
	public String ksefInvoiceQueryStart(String sessionId, KsefInvoiceQueryStartRequest.SubjectTypeEnum subjectType,
										LocalDateTime from, LocalDateTime to) {
		try {
			clear();

			// req
			KsefInvoiceQueryStartRange range = new KsefInvoiceQueryStartRange();
			range.setFrom(from);
			range.setTo(to);

			KsefInvoiceQueryStartRequest req = new KsefInvoiceQueryStartRequest();
			req.setSessionId(sessionId);
			req.setSubjectType(subjectType);
			req.setRange(range);

			byte[] json = Utils.getJsonMapper().writeValueAsBytes(req);

			if (json == null) {
				set(ClientError.CLI_JSON);
				return null;
			}

			// send
			KsefInvoiceQueryStartResponse res = getObject(url + "/invoice/query/start", "application/json",
					json, null, KsefInvoiceQueryStartResponse.class);

			if (res == null) {
				return null;
			}

			return res.getQueryId();
		} catch (Exception e) {
			set(ClientError.CLI_EXCEPTION, e.getMessage());
		}

		return null;
	}

	/**
	 * Get current status of query
	 * @param sessionId session id
	 * @param queryId query id
	 * @return array of result parts numbers
	 */
	public String[] ksefInvoiceQueryStatus(String sessionId, String queryId) {
		try {
			clear();

			// send
			return getObject(url + "/invoice/query/status/" + URLEncoder.encode(sessionId, StandardCharsets.UTF_8)
					+ "/" + URLEncoder.encode(queryId, StandardCharsets.UTF_8), null, String[].class);
		} catch (Exception e) {
			set(ClientError.CLI_EXCEPTION, e.getMessage());
		}

		return null;
	}

	/**
	 * Get data for specified query part
	 * @param sessionId session id
	 * @param queryId query id
	 * @param partNumber query part number
	 * @return plain or encrypted ZIP archive with invoices (depends on session type)
	 */
	public byte[] ksefInvoiceQueryResult(String sessionId, String queryId, String partNumber) {
		try {
			clear();

			// send
			return send(url + "/invoice/query/result/" + URLEncoder.encode(sessionId, StandardCharsets.UTF_8)
					+ "/" + URLEncoder.encode(queryId, StandardCharsets.UTF_8) + "/" + URLEncoder.encode(partNumber,
					StandardCharsets.UTF_8), "application/octet-stream");
		} catch (Exception e) {
			set(ClientError.CLI_EXCEPTION, e.getMessage());
		}

		return null;
	}

	/**
	 * Generate visualization of an invoice
	 * @param ksefRefNumber KSeF reference number
	 * @param invoice invoice XML data
	 * @param logo include logo
	 * @param qrcode include qr-code
	 * @param format output format (html or pdf)
	 * @param lang output language (pl)
	 * @return invoice visualization in requested format
	 */
	public byte[] ksefInvoiceVisualize(String ksefRefNumber, byte[] invoice, boolean logo, boolean qrcode,
									   KsefInvoiceVisualizeRequest.OutputFormatEnum format,
									   KsefInvoiceVisualizeRequest.OutputLanguageEnum lang) {
		try {
			clear();

			// req
			KsefInvoiceVisualizeRequest req = new KsefInvoiceVisualizeRequest();
			req.setIncludeLogo(logo);
			req.setIncludeQrCode(qrcode);
			req.setOutputFormat(format);
			req.setOutputLanguage(lang);
			req.setInvoiceKsefNumber(ksefRefNumber);
			req.setInvoiceData(invoice);

			byte[] json = Utils.getJsonMapper().writeValueAsBytes(req);

			if (json == null) {
				set(ClientError.CLI_JSON);
				return null;
			}

			// send
			return send(url + "/invoice/visualize", "application/json", json, "text/html, application/pdf, application/json");
		} catch (Exception e) {
			set(ClientError.CLI_EXCEPTION, e.getMessage());
		}

		return null;
	}

	/**
	 * Clear last error
	 */
	private void clear() {
		error = null;
	}

	/**
	 * Set last error information
	 * @param code error code
	 * @param description error description
	 * @param details error details
	 */
	private void set(int code, String description, String details) {
		error = new Error();
		error.setCode(code);
		error.setDescription(description);
		error.setDetails(details);
	}

	/**
	 * Set last error information
	 * @param code error code
	 * @param details error details
	 */
	private void set(int code, String details) {
		set(code, ClientError.message(code), details);
	}

	/**
	 * Set last error information
	 * @param code error code
	 */
	private void set(int code) {
		set(code, ClientError.message(code), null);
	}

	/**
	 * Create authorization header
	 * @param headers object with HTTP headers
	 * @return true if succeeded
	 */
	private boolean auth(Properties headers)
	{
		try {
			// prepare auth header
			String creds = (id + ":" + key);

			// prepare request
			headers.setProperty("Authorization", "Basic " + Base64.getEncoder().encodeToString(creds.getBytes(StandardCharsets.UTF_8)));
			
			return true;
		} catch (Exception ignored) {
		}
		
		return false;
	}

	/**
	 * Create user agent header
	 * @param headers object with HTTP headers
	 */
	private void userAgent(Properties headers)
	{
		headers.setProperty("User-Agent", "KsefApiClient/" + VERSION + " Java/" + System.getProperty("java.version"));
	}

	/**
	 * Send HTTP POST request and read server's response
	 * @param url request URL
	 * @param type request content type
	 * @param body request body
	 * @param accept requested response MIME types
	 * @return response data or null
	 */
	private byte[] send(String url, String type, byte[] body, String accept)
	{
		boolean set = false;
		
		try {
			if (url == null || url.isEmpty()) {
				set(ClientError.CLI_CONNECT);
				return null;
			}

			URL u = new URL(url);
			Proxy p = null;

			if (wp != null && !wp.isExcluded(u.getHost())) {
				p = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(wp.getHost(), wp.getPort()));
				
				Authenticator.setDefault(wp);
				set = true;
			}

			boolean post = (type != null && !type.isEmpty() && body != null && body.length > 0);

			// headers
			Properties headers = new Properties();

			headers.setProperty("Accept", accept);

			if (!auth(headers)) {
				set(ClientError.CLI_CONNECT);
				return null;
			}

			if (post) {
				headers.setProperty("Content-Type", type);
				headers.setProperty("Content-Length", "" + body.length);
			}

			userAgent(headers);

			// connect
			HttpURLConnection huc;

			if (url.toLowerCase().startsWith("https://")) {
				// https
				if (p != null) {
					huc = (HttpsURLConnection)u.openConnection(p);
				} else {
					huc = (HttpsURLConnection)u.openConnection();
				}
	
				if (hv != null) {
					((HttpsURLConnection)huc).setHostnameVerifier(hv);
				}
				
				if (ssf != null) {
					((HttpsURLConnection)huc).setSSLSocketFactory(ssf);
				}
			} else if (url.toLowerCase().startsWith("http://")) {
				// http
				if (p != null) {
					huc = (HttpURLConnection)u.openConnection(p);
				} else {
					huc = (HttpURLConnection)u.openConnection();
				}
			} else {
				set(ClientError.CLI_CONNECT);
				return null;
			}
				
			huc.setRequestMethod(post ? "POST" : "GET");

			Enumeration<?> keys = headers.keys();

			while (keys.hasMoreElements()) {
				String key = (String)keys.nextElement();
				huc.setRequestProperty(key, headers.getProperty(key));
			}

			huc.setUseCaches(false);
			huc.setDoInput(true);
			huc.setDoOutput(post);

			if (post) {
				// request
				huc.getOutputStream().write(body);
			}

			// response
			int code = huc.getResponseCode();

			if (code != 200) {
				InputStream is = huc.getErrorStream();

				if (is != null) {
					byte[] b = is.readAllBytes();
					is.close();

					if (b.length > 0) {
						parse(b);
						return null;
					}
				}

				set(ClientError.CLI_RESPONSE);
				return null;
			}

			InputStream is = huc.getInputStream();

			if (is == null) {
				set(ClientError.CLI_RESPONSE);
				return null;
			}

			byte[] b = is.readAllBytes();
			is.close();

			return b;
		} catch (Exception e) {
			set(ClientError.CLI_EXCEPTION, e.getMessage());
		} finally {
    		if (set) {
    			Authenticator.setDefault(null);
    		}
		}
		
		return null;
	}

	/**
	 * Send HTTP GET request and read server's response
	 * @param url request URL
	 * @param accept requested response MIME types
	 * @return response data or null
	 */
	private byte[] send(String url, String accept) {
		return send(url, null, null, accept);
	}

	/**
	 * Get response as object
	 * @param url request URL
	 * @param contentType request content type
	 * @param content request content bytes
	 * @param attr JSON attribute name to return (null - root element)
	 * @param type object type to return
	 * @return response object lub null
	 */
	private <T> T getObject(String url, String contentType, byte[] content, String attr, Class<T> type) {
		try {
			byte[] b = send(url, contentType, content, "application/json");

			if (b == null) {
				return null;
			}

			JsonNode node = parse(b);

			if (node == null) {
				return null;
			}

			return Utils.getJsonMapper().treeToValue(attr != null && !attr.isEmpty() ? node.get(attr) : node, type);
		} catch (Exception e) {
			set(ClientError.CLI_EXCEPTION, e.getMessage());
		}

		return null;
	}

	/**
	 * Get response as object
	 * @param url request URL
	 * @param attr JSON attribute name to return (null - root element)
	 * @param type object type to return
	 * @return response object lub null
	 */
	private <T> T getObject(String url, String attr, Class<T> type) {
		return getObject(url, null, null, attr, type);
	}

	/**
	 * Try to parse response as JSON and check for an error
	 * @param b response bytes
	 * @return JSON object or null in case of error
	 */
	private JsonNode parse(byte[] b) {
		try {
			JsonNode node = Utils.getJsonMapper().readTree(b);

			if (node == null) {
				set(ClientError.CLI_RESPONSE);
				return null;
			}

			if (node.hasNonNull("error")) {
				JsonNode err = node.get("error");
				set(err.get("code").asInt(), err.get("description").asText(), err.hasNonNull("details")
						? err.get("details").asText() : null);
				return null;
			}

			return node;
		} catch (Exception e) {
			set(ClientError.CLI_EXCEPTION, e.getMessage());
		}

		return null;
	}
}
