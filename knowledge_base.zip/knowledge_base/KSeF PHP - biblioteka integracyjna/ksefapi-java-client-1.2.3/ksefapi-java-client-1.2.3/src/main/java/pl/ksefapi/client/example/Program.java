/**
 * Copyright 2025 NETCAT (www.netcat.pl)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @author NETCAT <firma@netcat.pl>
 * @copyright 2025 NETCAT (www.netcat.pl)
 * @license http://www.apache.org/licenses/LICENSE-2.0
 */

package pl.ksefapi.client.example;

import pl.ksefapi.client.KsefApiClient;
import pl.ksefapi.client.Utils;
import pl.ksefapi.client.model.*;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;

/**
 * Example program
 */
public class Program {

    private static String sellerNIP;
    private static String sellerName;

    private static KsefApiClient ksefapi;
    private static LocalDateTime now;

    private static String ksefRefNumber;

    public static void main(String[] args) {
        try {
            // set some basic data
            now = LocalDateTime.now();

            // seller NIP and name (this data must match yours data at KSeF portal)
            sellerNIP = "enter your company's NIP here";
            sellerName = "enter your company's name here";

            // KSEF API client object
            ksefapi = new KsefApiClient(KsefApiClient.TEST_URL, "enter valid API id here", "enter valid API key here");


            // test some typical use cases
            validateInvoiceXml();
            createAndSendInvoice();
            createAndSendInvoiceWithEncryption();
            getInvoiceByKsefNumber();
            getInvoicesByTimeRange();
            visualizeInvoiceXml();
        } catch (Exception e) {
            System.err.println("main: " + e);
        }
    }

    private static Faktura createInvoice() {
        System.out.println("createInvoice");

        // create new invoice object (adapt the data to your needs)
        Faktura invoice = new Faktura();

        invoice.setNaglowek(new TNaglowek()
            .kodFormularza(new TKodFormularza()
                .kodFormularza(TKodFormularza.KodFormularzaEnum.FA)
                .kodSystemowy(TKodFormularza.KodSystemowyEnum.FA_V2)
                .wersjaSchemy(TKodFormularza.WersjaSchemyEnum._1_0_E))
            .wariantFormularza(WariantFormularza.NUMBER_2)
            .dataWytworzeniaFa(now)
            .systemInfo("KSEF API")
        );

        // seller data
        invoice.podmiot1(new Podmiot1()
            .daneIdentyfikacyjne(new TPodmiot1()
                .NIP(sellerNIP)
                .nazwa(sellerName)
            )
            .adres(new TAdres()
                .kodKraju(TKodKraju.PL)
                .adresL1("ul. Kwiatowa 1 m. 2")
                .adresL2("00-001 Warszawa")
            )
        );

        // buyer data
        invoice.podmiot2(new Podmiot2()
            .daneIdentyfikacyjne(new TPodmiot2()
                .NIP("1111111111")
                .nazwa("F.H.U. Jan Kowalski")
            )
            .adres(new TAdres()
                .kodKraju(TKodKraju.PL)
                .adresL1("ul. Polna 1")
                .adresL2("00-001 Warszawa")
            )
        );

        invoice.fa(new Fa()
            .kodWaluty(TKodWaluty.PLN)
            .P_1(now.toLocalDate())     // date of issue
            .P_1M("Warszawa")
            .P_2("001/01/2025")         // invoice number
            .P_6(now.toLocalDate())     // date of sale
            .P_13_1(1666.66)            // total net amount
            .P_14_1(383.33)             // total VAT amount
            .P_13_3(0.95)
            .P_14_3(0.05)
            .P_15(2051.0)               // total gross amount
            .adnotacje(new Adnotacje()
                .P_16(2)
                .P_17(2)
                .P_18(2)
                .P_18A(2)
                .zwolnienie(new Zwolnienie()
                    .P_19N(1)
                )
                .noweSrodkiTransportu(new NoweSrodkiTransportu()
                    .P_22N(1)
                )
                .P_23(2)
                .pmarzy(new PMarzy()
                    .pPMarzyN(1)
                )
            )
            .rodzajFaktury(TRodzajFaktury.VAT)
            .FP(1)
            .platnosc(new Platnosc()
                .zaplacono(1)
                .dataZaplaty(now.toLocalDate())
                .formaPlatnosci(TFormaPlatnosci.NUMBER_6)
            )
            .addFaWierszItem(new FaWiersz()
                .nrWierszaFa(1)
                .UU_ID("aaaa111133339990")
                .P_7("lodówka Zimnotech mk1")
                .P_8A("szt.")
                .P_8B(1.0)
                .P_9A(1626.01)
                .P_11(1626.01)
                .P_12(TStawkaPodatku._23)
            )
            .addFaWierszItem(new FaWiersz()
                .nrWierszaFa(2)
                .UU_ID("aaaa111133339991")
                .P_7("wniesienie sprzętu")
                .P_8A("szt.")
                .P_8B(1.0)
                .P_9A(40.65)
                .P_11(40.65)
                .P_12(TStawkaPodatku._23)
            )
            .addFaWierszItem(new FaWiersz()
                .nrWierszaFa(3)
                .UU_ID("aaaa111133339992")
                .P_7("promocja lodówka pełna mleka")
                .P_8A("szt.")
                .P_8B(1.0)
                .P_9A(0.95)
                .P_11(0.95)
                .P_12(TStawkaPodatku._5)
            )
        );

        return invoice;
    }

    private static String getInvoiceXml() {
        System.out.println("getInvoiceXml");

        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" +
            "<Faktura xmlns:etd=\"http://crd.gov.pl/xml/schematy/dziedzinowe/mf/2022/01/05/eD/DefinicjeTypy/\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\"\n" +
            "xmlns=\"http://crd.gov.pl/wzor/2023/06/29/12648/\">\n" +
            "\t<Naglowek>\n" +
            "\t\t<KodFormularza kodSystemowy=\"FA (2)\" wersjaSchemy=\"1-0E\">FA</KodFormularza>\n" +
            "\t\t<WariantFormularza>2</WariantFormularza>\n" +
            "\t\t<DataWytworzeniaFa>" + Utils.toIsoString(now) + "</DataWytworzeniaFa>\n" +
            "\t\t<SystemInfo>KSEF API</SystemInfo>\n" +
            "\t</Naglowek>\n" +
            "\t<Podmiot1>\n" +
            "\t\t<DaneIdentyfikacyjne>\n" +
            "\t\t\t<NIP>" + sellerNIP + "</NIP>\n" +
            "\t\t\t<Nazwa>" + sellerName + "</Nazwa>\n" +
            "\t\t</DaneIdentyfikacyjne>\n" +
            "\t\t<Adres>\n" +
            "\t\t\t<KodKraju>PL</KodKraju>\n" +
            "\t\t\t<AdresL1>ul. Kwiatowa 1 m. 2</AdresL1>\n" +
            "\t\t\t<AdresL2>00-001 Warszawa</AdresL2>\n" +
            "\t\t</Adres>\n" +
            "\t\t<DaneKontaktowe>\n" +
            "\t\t\t<Email>abc@abc.pl</Email>\n" +
            "\t\t\t<Telefon>667444555</Telefon>\n" +
            "\t\t</DaneKontaktowe>\n" +
            "\t</Podmiot1>\n" +
            "\t<Podmiot2>\n" +
            "\t\t<DaneIdentyfikacyjne>\n" +
            "\t\t\t<NIP>1111111111</NIP>\n" +
            "\t\t\t<Nazwa>F.H.U. Jan Kowalski</Nazwa>\n" +
            "\t\t</DaneIdentyfikacyjne>\n" +
            "\t\t<Adres>\n" +
            "\t\t\t<KodKraju>PL</KodKraju>\n" +
            "\t\t\t<AdresL1>ul. Polna 1</AdresL1>\n" +
            "\t\t\t<AdresL2>00-001 Warszawa</AdresL2>\n" +
            "\t\t</Adres>\n" +
            "\t\t<DaneKontaktowe>\n" +
            "\t\t\t<Email>jan@kowalski.pl</Email>\n" +
            "\t\t\t<Telefon>555777999</Telefon>\n" +
            "\t\t</DaneKontaktowe>\n" +
            "\t\t<NrKlienta>fdfd778343</NrKlienta>\n" +
            "\t</Podmiot2>\n" +
            "\t<Fa>\n" +
            "\t\t<KodWaluty>PLN</KodWaluty>\n" +
            "\t\t<P_1>2022-02-15</P_1>\n" +
            "\t\t<P_1M>Warszawa</P_1M>\n" +
            "\t\t<P_2>FV2022/02/150</P_2>\n" +
            "\t\t<P_6>" + Utils.toString(now.toLocalDate()) + "</P_6>\n" +
            "\t\t<P_13_1>1666.66</P_13_1>\n" +
            "\t\t<P_14_1>383.33</P_14_1>\n" +
            "\t\t<P_13_3>0.95</P_13_3>\n" +
            "\t\t<P_14_3>0.05</P_14_3>\n" +
            "\t\t<P_15>2051</P_15>\n" +
            "\t\t<Adnotacje>\n" +
            "\t\t\t<P_16>2</P_16>\n" +
            "\t\t\t<P_17>2</P_17>\n" +
            "\t\t\t<P_18>2</P_18>\n" +
            "\t\t\t<P_18A>2</P_18A>\n" +
            "\t\t\t<Zwolnienie>\n" +
            "\t\t\t\t<P_19N>1</P_19N>\n" +
            "\t\t\t</Zwolnienie>\n" +
            "\t\t\t<NoweSrodkiTransportu>\n" +
            "\t\t\t\t<P_22N>1</P_22N>\n" +
            "\t\t\t</NoweSrodkiTransportu>\n" +
            "\t\t\t<P_23>2</P_23>\n" +
            "\t\t\t<PMarzy>\n" +
            "\t\t\t\t<P_PMarzyN>1</P_PMarzyN>\n" +
            "\t\t\t</PMarzy>\n" +
            "\t\t</Adnotacje>\n" +
            "\t\t<RodzajFaktury>VAT</RodzajFaktury>\n" +
            "\t\t<FP>1</FP>\n" +
            "\t\t<DodatkowyOpis>\n" +
            "\t\t\t<Klucz>preferowane godziny dowozu</Klucz>\n" +
            "\t\t\t<Wartosc>dni robocze 17:00 - 20:00</Wartosc>\n" +
            "\t\t</DodatkowyOpis>\n" +
            "\t\t<FaWiersz>\n" +
            "\t\t\t<NrWierszaFa>1</NrWierszaFa>\n" +
            "\t\t\t<UU_ID>aaaa111133339990</UU_ID>\n" +
            "\t\t\t<P_7>lodówka Zimnotech mk1</P_7>\n" +
            "\t\t\t<P_8A>szt.</P_8A>\n" +
            "\t\t\t<P_8B>1</P_8B>\n" +
            "\t\t\t<P_9A>1626.01</P_9A>\n" +
            "\t\t\t<P_11>1626.01</P_11>\n" +
            "\t\t\t<P_12>23</P_12>\n" +
            "\t\t</FaWiersz>\n" +
            "\t\t<FaWiersz>\n" +
            "\t\t\t<NrWierszaFa>2</NrWierszaFa>\n" +
            "\t\t\t<UU_ID>aaaa111133339991</UU_ID>\n" +
            "\t\t\t<P_7>wniesienie sprzętu</P_7>\n" +
            "\t\t\t<P_8A>szt.</P_8A>\n" +
            "\t\t\t<P_8B>1</P_8B>\n" +
            "\t\t\t<P_9A>40.65</P_9A>\n" +
            "\t\t\t<P_11>40.65</P_11>\n" +
            "\t\t\t<P_12>23</P_12>\n" +
            "\t\t</FaWiersz>\n" +
            "\t\t<FaWiersz>\n" +
            "\t\t\t<NrWierszaFa>3</NrWierszaFa>\n" +
            "\t\t\t<UU_ID>aaaa111133339992</UU_ID>\n" +
            "\t\t\t<P_7>promocja lodówka pełna mleka</P_7>\n" +
            "\t\t\t<P_8A>szt.</P_8A>\n" +
            "\t\t\t<P_8B>1</P_8B>\n" +
            "\t\t\t<P_9A>0.95</P_9A>\n" +
            "\t\t\t<P_11>0.95</P_11>\n" +
            "\t\t\t<P_12>5</P_12>\n" +
            "\t\t</FaWiersz>\n" +
            "\t\t<Platnosc>\n" +
            "\t\t\t<Zaplacono>1</Zaplacono>\n" +
            "\t\t\t<DataZaplaty>" + Utils.toString(now.toLocalDate()) + "</DataZaplaty>\n" +
            "\t\t\t<FormaPlatnosci>6</FormaPlatnosci>\n" +
            "\t\t</Platnosc>\n" +
            "\t\t<WarunkiTransakcji>\n" +
            "\t\t\t<Zamowienia>\n" +
            "\t\t\t\t<DataZamowienia>" + Utils.toString(now.toLocalDate()) + "</DataZamowienia>\n" +
            "\t\t\t\t<NrZamowienia>4354343</NrZamowienia>\n" +
            "\t\t\t</Zamowienia>\n" +
            "\t\t</WarunkiTransakcji>\n" +
            "\t</Fa>\n" +
            "\t<Stopka>\n" +
            "\t\t<Informacje>\n" +
            "\t\t\t<StopkaFaktury>Kapitał zakładowy 5 000 000</StopkaFaktury>\n" +
            "\t\t</Informacje>\n" +
            "\t\t<Rejestry>\n" +
            "\t\t\t<KRS>0000099999</KRS>\n" +
            "\t\t\t<REGON>999999999</REGON>\n" +
            "\t\t\t<BDO>000099999</BDO>\n" +
            "\t\t</Rejestry>\n" +
            "\t</Stopka>\n" +
            "</Faktura>\n";
    }

    private static void validateInvoiceXml() {
        System.out.println("validateInvoiceXml");

        try {
            // validate xml
            String xml = getInvoiceXml();

            KsefInvoiceValidateResponse res = ksefapi.ksefInvoiceValidate(xml);

            if (res == null) {
                System.err.println("ERR: ksefInvoiceValidate failed: " + ksefapi.getLastError());
                return;
            }

            System.out.println("Validation result: " + res);

            System.out.println("validateInvoiceXml: done");
        } catch (Exception e) {
            System.err.println("validateInvoiceXml: " + e);
        }
    }

    private static void createAndSendInvoice() {
        System.out.println("createAndSendInvoice");

        try {
            // create new invoice object
            Faktura invoice = createInvoice();

            // get invoice as xml
            String xml = ksefapi.ksefInvoiceGenerate(invoice);

            if (xml == null) {
                System.err.println("ERR: ksefInvoiceGenerate failed: " + ksefapi.getLastError());
                return;
            }

            System.out.println("Invoice XML: " + xml);

            // open new session
            KsefSessionOpenResponse sor = ksefapi.ksefSessionOpen(KsefInvoiceVersion.V2);

            if (sor == null) {
                System.err.println("ERR: ksefSessionOpen failed: " + ksefapi.getLastError());
                return;
            }

            System.out.println("KSeF session id: " + sor.getId());

            // send an invoice
            byte[] data = xml.getBytes(StandardCharsets.UTF_8);

            KsefInvoiceSendResponse isr = ksefapi.ksefInvoiceSend(sor.getId(), 0, null, data);

            if (isr == null) {
                System.err.println("ERR: ksefInvoiceSend failed: " + ksefapi.getLastError());
                return;
            }

            System.out.println("KSeF invoice id: " + isr.getId());

            // check an invoice status (and fetch KSeF reference number and date)
            KsefInvoiceStatusResponse str = ksefapi.ksefInvoiceStatus(isr.getId());

            if (str == null) {
                System.err.println("ERR: ksefInvoiceStatus failed: " + ksefapi.getLastError());
                return;
            }

            System.out.println("KSeF invoice number: " + str.getKsefReferenceNumber());
            System.out.println("KSeF invoice date: " + str.getAcquisitionTimestamp());

            // save for other tests
            ksefRefNumber = str.getKsefReferenceNumber();

            // close session
            boolean sc = ksefapi.ksefSessionClose(sor.getId());

            if (!sc) {
                System.err.println("ERR: ksefSessionClose failed: " + ksefapi.getLastError());
                return;
            }

            // get UPO
            String upo = ksefapi.ksefSessionUpo(sor.getId());

            if (upo == null) {
                System.err.println("ERR: ksefSessionUpo failed: " + ksefapi.getLastError());
                return;
            }

            System.out.println("UPO: " + upo);

            Files.write(Path.of("UPO-" + str.getKsefReferenceNumber() + ".xml"), upo.getBytes(StandardCharsets.UTF_8),
                StandardOpenOption.CREATE);

            System.out.println("createAndSendInvoice: done");
        } catch (Exception e) {
            System.err.println("createAndSendInvoice: " + e);
        }
    }

    private static void createAndSendInvoiceWithEncryption() {
        System.out.println("createAndSendInvoiceWithEncryption");

        try {
            // create new invoice object
            Faktura invoice = createInvoice();

            // get invoice as xml
            String xml = ksefapi.ksefInvoiceGenerate(invoice);

            if (xml == null) {
                System.err.println("ERR: ksefInvoiceGenerate failed: " + ksefapi.getLastError());
                return;
            }

            System.out.println("Invoice XML: " + xml);

            // get new init vector for session with encryption
            byte[] iv = ksefapi.generateInitVector();

            if (iv == null) {
                System.err.println("ERR: generateInitVector failed: " + ksefapi.getLastError());
                return;
            }

            // gen new symmetric key for session with encryption
            byte[] skey = ksefapi.generateKey();

            if (skey == null) {
                System.err.println("ERR: generateKey failed: " + ksefapi.getLastError());
                return;
            }

            // encrypt symmetric key with KSeF public key
            KsefPublicKeyResponse pkr = ksefapi.ksefPublicKey();

            if (pkr == null) {
                System.err.println("ERR: ksefPublicKey failed: " + ksefapi.getLastError());
                return;
            }

            System.out.println("KSeF public key: " + pkr);

            byte[] encKey = ksefapi.encryptKey(pkr, skey);

            if (encKey == null) {
                System.err.println("ERR: encryptKey failed: " + ksefapi.getLastError());
                return;
            }

            // open new session
            KsefSessionOpenResponse sor = ksefapi.ksefSessionOpen(KsefInvoiceVersion.V2, iv, encKey);

            if (sor == null) {
                System.err.println("ERR: ksefSessionOpen failed: " + ksefapi.getLastError());
                return;
            }

            System.out.println("KSeF session id: " + sor.getId());

            // encrypt an invoice
            byte[] data = xml.getBytes(StandardCharsets.UTF_8);
            int size = data.length;

            byte[] hash = ksefapi.getHash(data);

            if (hash == null) {
                System.err.println("ERR: getHash failed: " + ksefapi.getLastError());
                return;
            }

            byte[] encData = ksefapi.encryptData(iv, skey, data);

            if (encData == null) {
                System.err.println("ERR: encryptData failed: " + ksefapi.getLastError());
                return;
            }

            // send an encrypted invoice
            KsefInvoiceSendResponse isr = ksefapi.ksefInvoiceSend(sor.getId(), size, hash, encData);

            if (isr == null) {
                System.err.println("ERR: ksefInvoiceSend failed: " + ksefapi.getLastError());
                return;
            }

            System.out.println("KSeF invoice id: " + isr.getId());

            // check an invoice status (and fetch KSeF reference number and date)
            KsefInvoiceStatusResponse str = ksefapi.ksefInvoiceStatus(isr.getId());

            if (str == null) {
                System.err.println("ERR: ksefInvoiceStatus failed: " + ksefapi.getLastError());
                return;
            }

            System.out.println("KSeF invoice number: " + str.getKsefReferenceNumber());
            System.out.println("KSeF invoice date: " + str.getAcquisitionTimestamp());

            // save for other tests
            ksefRefNumber = str.getKsefReferenceNumber();

            // close session
            boolean sc = ksefapi.ksefSessionClose(sor.getId());

            if (!sc) {
                System.err.println("ERR: ksefSessionClose failed: " + ksefapi.getLastError());
                return;
            }

            // get UPO
            String upo = ksefapi.ksefSessionUpo(sor.getId());

            if (upo == null) {
                System.err.println("ERR: ksefSessionUpo failed: " + ksefapi.getLastError());
                return;
            }

            System.out.println("UPO: " + upo);

            Files.write(Path.of("UPO-" + str.getKsefReferenceNumber() + ".xml"), upo.getBytes(StandardCharsets.UTF_8),
                    StandardOpenOption.CREATE);

            System.out.println("createAndSendInvoiceWithEncryption: done");
        } catch (Exception e) {
            System.err.println("createAndSendInvoiceWithEncryption: " + e);
        }
    }

    private static void getInvoiceByKsefNumber() {
        System.out.println("getInvoiceByKsefNumber");

        try {
            // open new session
            KsefSessionOpenResponse sor = ksefapi.ksefSessionOpen(KsefInvoiceVersion.V2);

            if (sor == null) {
                System.err.println("ERR: ksefSessionOpen failed: " + ksefapi.getLastError());
                return;
            }

            System.out.println("KSeF session id: " + sor.getId());

            // get by number (we're using number from previous test)
            byte[] xml = ksefapi.ksefInvoiceGet(sor.getId(), ksefRefNumber);

            if (xml == null) {
                System.err.println("ERR: ksefInvoiceGet failed: " + ksefapi.getLastError());
                return;
            }

            System.out.println("Invoice XML: " + new String(xml, StandardCharsets.UTF_8));

            Files.write(Path.of("invoice-" + ksefRefNumber + ".xml"), xml, StandardOpenOption.CREATE);

            // close session
            boolean sc = ksefapi.ksefSessionClose(sor.getId());

            if (!sc) {
                System.err.println("ERR: ksefSessionClose failed: " + ksefapi.getLastError());
                return;
            }

            System.out.println("getInvoiceByKsefNumber: done");
        } catch (Exception e) {
            System.err.println("getInvoiceByKsefNumber: " + e);
        }
    }

    private static void getInvoicesByTimeRange() {
        System.out.println("getInvoicesByTimeRange");

        try {
            // open new session
            KsefSessionOpenResponse sor = ksefapi.ksefSessionOpen(KsefInvoiceVersion.V2);

            if (sor == null) {
                System.err.println("ERR: ksefSessionOpen failed: " + ksefapi.getLastError());
                return;
            }

            System.out.println("KSeF session id: " + sor.getId());

            // start query (get all invoices from last 3 days, SUBJECT2 - means cost invoices)
            LocalDateTime from = now.minusDays(3);
            LocalDateTime to = now;

            String queryId = ksefapi.ksefInvoiceQueryStart(sor.getId(), KsefInvoiceQueryStartRequest.SubjectTypeEnum.SUBJECT2,
                from, to);

            if (queryId == null) {
                System.err.println("ERR: ksefInvoiceQueryStart failed: " + ksefapi.getLastError());
                return;
            }

            System.out.println("Query id: " + queryId);

            // wait for result (we're using a simple loop here, in real life you should use a more sophisticated method)
            String[] partNumbers = null;

            for (int i = 0; i < 10; i++) {
                if ((partNumbers = ksefapi.ksefInvoiceQueryStatus(sor.getId(), queryId)) != null) {
                    System.out.println("Query result is ready");
                    break;
                }

                System.out.println("WARNING: ksefInvoiceQueryStart returned: " + ksefapi.getLastError());
                Thread.sleep(5000);
            }

            if (partNumbers == null) {
                System.err.println("Timed out, no query result");
                return;
            }

            // get results
            for (String partNumber : partNumbers) {
                byte[] data = ksefapi.ksefInvoiceQueryResult(sor.getId(), queryId, partNumber);

                if (data == null) {
                    System.err.println("ERR: ksefInvoiceQueryResult failed: " + ksefapi.getLastError());
                    return;
                }

                Files.write(Path.of("invoices-" + partNumber + ".zip"), data, StandardOpenOption.CREATE);
            }

            // close session
            boolean sc = ksefapi.ksefSessionClose(sor.getId());

            if (!sc) {
                System.err.println("ERR: ksefSessionClose failed: " + ksefapi.getLastError());
                return;
            }

            System.out.println("getInvoicesByTimeRange: done");
        } catch (Exception e) {
            System.err.println("getInvoicesByTimeRange: " + e);
        }
    }

    private static void visualizeInvoiceXml() {
        System.out.println("visualizeInvoiceXml");

        try {
            String xml = getInvoiceXml();

            byte[] data = xml.getBytes(StandardCharsets.UTF_8);

            // visualize invoice xml as html (official layout from MF)
            byte[] html = ksefapi.ksefInvoiceVisualize(ksefRefNumber, data, true, true,
                KsefInvoiceVisualizeRequest.OutputFormatEnum.HTML, KsefInvoiceVisualizeRequest.OutputLanguageEnum.PL);

            if (html == null) {
                System.err.println("ERR: ksefInvoiceVisualize failed: " + ksefapi.getLastError());
                return;
            }

            Files.write(Path.of("invoice.html"), html, StandardOpenOption.CREATE);

            // visualize invoice xml as pdf (still needs improvements)
            byte[] pdf = ksefapi.ksefInvoiceVisualize(ksefRefNumber, data, true, true,
                KsefInvoiceVisualizeRequest.OutputFormatEnum.PDF, KsefInvoiceVisualizeRequest.OutputLanguageEnum.PL);

            if (pdf == null) {
                System.err.println("ERR: ksefInvoiceVisualize failed: " + ksefapi.getLastError());
                return;
            }

            Files.write(Path.of("invoice.pdf"), pdf, StandardOpenOption.CREATE);

            System.out.println("visualizeInvoiceXml: done");
        } catch (Exception e) {
            System.err.println("visualizeInvoiceXml: " + e);
        }
    }
}
