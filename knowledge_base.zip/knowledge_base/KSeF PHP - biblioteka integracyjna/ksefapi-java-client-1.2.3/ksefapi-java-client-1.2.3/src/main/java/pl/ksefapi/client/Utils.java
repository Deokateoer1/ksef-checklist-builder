/**
 * Copyright 2025 NETCAT (www.netcat.pl)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @author NETCAT <firma@netcat.pl>
 * @copyright 2025 NETCAT (www.netcat.pl)
 * @license http://www.apache.org/licenses/LICENSE-2.0
 */

package pl.ksefapi.client;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JacksonException;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.openapitools.jackson.nullable.JsonNullableModule;

import java.io.IOException;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

/**
 * Some helper functions
 */
public class Utils {

    public static final String DATETIME_FMT = "yyyy-MM-dd HH:mm:ss";
    public static final String DATE_FMT = "yyyy-MM-dd";
    public static final String TIME_FMT = "HH:mm:ss";

    /**
     * Get system zone ID
     * @return zone ID object
     */
    public static ZoneId getZoneId() {
        return ZoneId.systemDefault();
    }

    /**
     * Format local date time to string
     * @param ldt input date
     * @return formatted string
     */
    public static String toIsoString(LocalDateTime ldt) {
        if (ldt == null) {
            return null;
        }

        ZonedDateTime local = ldt.atZone(getZoneId());
        DateTimeFormatter dtf = DateTimeFormatter.ISO_INSTANT;

        return local.format(dtf);
    }

    /**
     * Format local date to string
     * @param ld input date
     * @return formatted string
     */
    public static String toString(LocalDate ld) {
        if (ld == null) {
            return null;
        }

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern(DATE_FMT);

        return ld.format(dtf);
    }

    /**
     * Parse date time string in ISO8601 format into local date object
     * @param str input string in ISO8601 format
     * @return local date
     */
    public static LocalDateTime parseIsoLocalDateTime(String str) {
        if (str == null || str.isEmpty()) {
            return null;
        }

        try {
            Instant i = Instant.parse(str);
            return i.atZone(getZoneId()).toLocalDateTime();
        } catch (DateTimeParseException ignored) {
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss[.SSS]");
            return LocalDateTime.parse(str, dtf);
        }
    }

    /**
     * Parse date string into local date object
     * @param str input string
     * @return local date
     */
    public static LocalDate parseLocalDate(String str) {
        if (str == null) {
            return null;
        }

        DateTimeFormatter dtf = DateTimeFormatter.ofPattern(DATE_FMT);

        return LocalDate.parse(str, dtf);
    }

    /**
     * Pobranie mappera JSON.
     * @return obiekt mapper'a
     */
    public static ObjectMapper getJsonMapper() {
        return new ObjectMapper()
            .registerModule(new JavaTimeModule()
                .addSerializer(LocalDateTime.class, new CustomLocalDateTimeSerializer())
                .addSerializer(LocalDate.class, new CustomLocalDateSerializer())
                .addDeserializer(LocalDateTime.class, new CustomLocalDateTimeDeserializer())
                .addDeserializer(LocalDate.class, new CustomLocalDateDeserializer()))
            .registerModule(new JsonNullableModule())
            .setSerializationInclusion(JsonInclude.Include.NON_NULL)
            .configure(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS, false)
            .configure(SerializationFeature.WRITE_DATE_TIMESTAMPS_AS_NANOSECONDS, false)
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
            .configure(DeserializationFeature.FAIL_ON_INVALID_SUBTYPE, false)
            .enable(DeserializationFeature.READ_ENUMS_USING_TO_STRING)
            .enable(SerializationFeature.WRITE_ENUMS_USING_TO_STRING);
    }

    /**
     * Custom Jackson serializer
     */
    static class CustomLocalDateTimeSerializer extends JsonSerializer<LocalDateTime> {
        @Override
        public void serialize(LocalDateTime value, JsonGenerator gen, SerializerProvider serializers) throws IOException {
            gen.writeString(toIsoString(value));
        }
    }

    /**
     * Custom Jackson serializer
     */
    static class CustomLocalDateSerializer extends JsonSerializer<LocalDate> {
        @Override
        public void serialize(LocalDate value, JsonGenerator gen, SerializerProvider serializers) throws IOException {
            gen.writeString(Utils.toString(value));
        }
    }

    /**
     * Custom Jackson deserializer
     */
    static class CustomLocalDateTimeDeserializer extends JsonDeserializer<LocalDateTime> {
        @Override
        public LocalDateTime deserialize(JsonParser p, DeserializationContext ctxt) throws IOException, JacksonException {
            String s = p.getText();
            return (s != null ? parseIsoLocalDateTime(s.strip()) : null);
        }
    }

    /**
     * Custom Jackson deserializer
     */
    static class CustomLocalDateDeserializer extends JsonDeserializer<LocalDate> {
        @Override
        public LocalDate deserialize(JsonParser p, DeserializationContext ctxt) throws IOException, JacksonException {
            String s = p.getText();
            return (s != null ? parseLocalDate(s.strip()) : null);
        }
    }
}
