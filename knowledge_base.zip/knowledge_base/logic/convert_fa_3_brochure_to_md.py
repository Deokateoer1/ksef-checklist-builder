#!/usr/bin/env python3
"""
PDF to Markdown Converter
Uruchom: python convert_pdf.py
"""

import pdfplumber
from pathlib import Path

def convert_pdf_to_md(pdf_path, output_md_path):
    """Konwertuj PDF na markdown"""
    
    print(f"📄 Converting: {pdf_path}")
    
    with pdfplumber.open(pdf_path) as pdf:
        markdown = f"# {Path(pdf_path).stem}\n\n"
        
        for page_num, page in enumerate(pdf.pages, 1):
            text = page.extract_text()
            
            if text:
                markdown += f"## Strona {page_num}\n\n"
                markdown += text + "\n\n---\n\n"
        
        with open(output_md_path, 'w', encoding='utf-8') as f:
            f.write(markdown)
    
    print(f"✅ Zapisano: {output_md_path}")

# URUCHOM:
if __name__ == "__main__":
    # Dwa pliki do konwersji:
    convert_pdf_to_md(
        "fa_3_brochure.pdf",
        "business/fa_3_brochure.md"
    )
    
    convert_pdf_to_md(
        "Opisy-przykladow-dla-struktury-logicznej-FA-3.pdf",
        "business/fa3_examples_description.md"
    )
    
    print("\n✅ ALL DONE!")
