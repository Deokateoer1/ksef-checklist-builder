import os
from textwrap import dedent

BASE_DIR = r"D:\Ollama_VScode\knowledge_base"
PROCEDURES_DIR = os.path.join(BASE_DIR, "procedures")

FILES = {
    "offline24_procedure.md": dedent("""
        # Procedura trybu offline24 (KSeF 2.0)

        ## Kiedy używać

        - Brak lub słaba jakość internetu po stronie podatnika.
        - Problemy po stronie oprogramowania wystawcy, uniemożliwiające wysyłkę do KSeF.
        - Opóźnienia w działaniu KSeF, ale brak oficjalnie ogłoszonej awarii.

        Tryb offline24 jest dostępny stale, niezależnie od komunikatów MF.

        ## Zasady ogólne

        - Fakturę wystawia się lokalnie (poza KSeF), zgodnie ze strukturą FA3.
        - Na fakturze muszą być wymagane oznaczenia dla trybu offline24 (zgodnie z przepisami – w tym kody QR, jeśli wymagane w danym scenariuszu).
        - Fakturę trzeba przesłać do KSeF najpóźniej do końca następnego dnia roboczego po jej wystawieniu.

        ## Różnica: awaria KSeF vs offline24

        - Awaria KSeF lub niedostępność systemu (ogłoszona w BIP MF / komunikatach MF):
          - Faktury wystawione offline przesyła się do KSeF po ustaniu awarii.
          - Termin dosłania: co do zasady następny dzień roboczy, w przypadku awarii całkowitej nawet do 7 dni roboczych (zgodnie z komunikatem MF).

        - Tryb offline24 bez awarii KSeF:
          - Brak komunikatu o awarii.
          - Faktury muszą być dosłane do KSeF do końca następnego dnia roboczego.

        ## Minimalna procedura dla systemu

        1. Sprawdź status API KSeF (healthcheck / brak odpowiedzi).
        2. Jeśli brak połączenia lub własny system padł:
           - Przełącz wystawianie na tryb offline24.
           - Wystawiaj faktury lokalnie, logując dokładny czas wystawienia.
        3. Zaplanuj proces dosłania:
           - Batch upload do KSeF po przywróceniu łączności.
           - Walidacja struktury (FA3, XSD) przed wysyłką.
        4. Monitoruj terminy:
           - Ostrzeżenia, jeśli faktura nie została dosłana do końca następnego dnia roboczego.
    """).lstrip(),

    "rate_limit_handling.md": dedent("""
        # Obsługa limitów (rate limiting) KSeF API 2.0

        ## Limity na poziomie API

        - Przykładowe limity na podstawie dokumentacji OpenAPI:
          - 100 żądań na sekundę.
          - 300 żądań na minutę.
          - 1200 żądań na godzinę (dla niektórych grup operacji).

        W przypadku przekroczenia limitu KSeF zwraca status `429 Too Many Requests` z nagłówkiem `Retry-After`.

        ## Strategia po stronie integracji

        1. Globalny throttling:
           - Ustaw limity na poziomie klienta HTTP:
             - np. max 80–90% oficjalnych wartości per token / IP.
           - Rozróżniaj:
             - operacje masowe (upload, statusy),
             - operacje interaktywne (pojedyncze faktury).

        2. Obsługa odpowiedzi 429:
           - Odczytaj nagłówek `Retry-After`.
           - Wstrzymaj żądania dla danej grupy/tokenu na tyle sekund, ile wskazuje `Retry-After`.
           - Zapisz zdarzenie do logów (z kodem wyjątku, jeśli jest w treści).

        3. Kolejki i priorytety:
           - Wysyłka faktur w paczkach (wsadowo) z kolejką FIFO.
           - Priorytet wyższy dla:
             - faktur bliskich terminowi wysyłki (np. tryb offline/offline24),
             - korekt krytycznych dla rozliczeń VAT.

        4. Monitoring:
           - Licznik wywołań per:
             - token JWT,
             - IP (dla endpointów otwartych),
             - typ operacji (statusy, upload, sesje).
    """).lstrip(),

    "invoice_correction.md": dedent("""
        # Procedura obsługi faktur korygujących w KSeF (FA2/FA3)

        ## Struktura FA2 vs FA3

        - Do 31.01.2026:
          - dla nowych i korygujących faktur można używać struktury FA2.
        - Od 01.02.2026:
          - obowiązującym wzorem jest struktura FA3 (również dla korekt faktur wystawionych wcześniej w FA1/FA2).

        ## Zasady korekt w FA3

        - Korekta musi odnosić się do konkretnej faktury pierwotnej (identyfikator KSeF, dane nagłówkowe).
        - Korekty wystawia się już w FA3, nawet jeśli faktura pierwotna była w FA2/FA1.
        - Struktura FA3 zawiera pola do:
          - powiązania z dokumentem pierwotnym,
          - korekt pozycji (FaWiersz) i podsumowań (Rozliczenie).

        ## Procedura biznesowa

        1. Identyfikacja faktury pierwotnej:
           - Pobierz dane faktury z KSeF (status + treść).
           - Ustal, czy była w FA2 czy FA3 (historycznie ważne, ale korekta i tak idzie w FA3).

        2. Przygotowanie korekty:
           - Użyj schematu FA3 (FA_3_schema.xsd) do walidacji.
           - Wypełnij:
             - powiązanie z dokumentem pierwotnym,
             - zmienione pozycje / kwoty,
             - ewentualne dodatkowe adnotacje (FaAdnotacje).

        3. Wysłanie do KSeF:
           - Prześlij plik XML FA3.
           - Sprawdź wynik walidacji schematu i biznesowej (kody 214xx/212xx).

        4. Udostępnienie nabywcy:
           - Nabywca odbiera korektę w KSeF.
           - Dane są widoczne w historii transakcji dla obu stron.

        ## Uwagi

        - Przy korektach „do zera” i zbiorczych:
          - stosować odpowiednie pola FA3 zgodnie z broszurą informacyjną (sekcja Fa/Rozliczenie, przykłady w dokumentacji).
    """).lstrip(),

    "b2c_filtering.md": dedent("""
        # Filtrowanie faktur B2C w KSeF

        ## Jak rozpoznać fakturę B2C

        - W strukturze FA3 (Podmiot2):
          - pole `BrakID = 1` – nabywca bez NIP (konsument).
          - brak pola NIP w `Podmiot2DaneIdentyfikacyjne`.
          - imię i nazwisko nabywcy w polu `Nazwa`.

        ## Zastosowanie w Robocie-Zwiadowcy

        1. Filtr B2C:
           - B2C = `Podmiot2DaneIdentyfikacyjne.BrakID == 1`.
           - B2B = `Podmiot2DaneIdentyfikacyjne.NIP` wypełniony.

        2. Ograniczenie zakresu analizy:
           - raporty tylko B2B: filtruj po obecności NIP.
           - raporty konsumenckie (np. sprzedaż detaliczna): filtruj po `BrakID == 1`.

        3. Ostrożność przy danych osobowych:
           - B2C → imię i nazwisko + adres to dane osobowe.
           - Wewnętrzne logi/systemy powinny być zgodne z RODO (minimalizacja danych, maskowanie, retencja).
    """).lstrip(),

    "gtu_codes.md": dedent("""
        # Kody GTU w kontekście KSeF

        ## Status GTU w KSeF

        - Umieszczenie kodów GTU i oznaczeń procedur (TP, FP itp.) na fakturze w KSeF jest fakultatywne – nie ma obowiązku ich stosowania.
        - Kody GTU pomagają później przy przygotowaniu pliku JPK_V7 (JPK_VAT z deklaracją).

        ## Zakres GTU (JPK_V7)

        Przykładowe kody GTU używane w JPK_V7:

        - GTU_01 – dostawa napojów alkoholowych.
        - GTU_02 – dostawa paliw.
        - GTU_03 – dostawa oleju opałowego.
        - GTU_04 – dostawa wyrobów tytoniowych.
        - GTU_05 – dostawa odpadów.
        - GTU_06 – dostawa urządzeń elektronicznych.
        - GTU_07 – dostawa pojazdów oraz części.
        - GTU_08 – dostawa metali szlachetnych i nieszlachetnych.
        - GTU_09 – dostawa leków i wyrobów medycznych.
        - GTU_10 – dostawa budynków, budowli, gruntów.
        - GTU_11 – świadczenie usług w zakresie przenoszenia uprawnień do emisji.
        - GTU_12 – świadczenie usług niematerialnych (doradczych, reklamowych itp.).
        - GTU_13 – pozostałe towary/usługi wymagające oznaczenia.

        ## Rola GTU w Twoim systemie

        - W strukturze FA (FA2/FA3) kody GTU są polami fakultatywnymi, ale:
          - warto przechowywać GTU na poziomie pozycji faktury,
          - to ułatwia:
            - automatyczne budowanie JPK_V7,
            - analizy sprzedaży wg GTU (Robot-Zwiadowca).

        - Przy pobieraniu danych z KSeF:
          - jeśli GTU są obecne w XML, można je wykorzystać do:
            - filtrowania (np. wszystkie faktury z GTU_12),
            - kontroli poprawności klasyfikacji towarów/usług.
    """).lstrip(),
}


def main() -> None:
    os.makedirs(PROCEDURES_DIR, exist_ok=True)
    print(f"[INFO] Katalog procedures: {PROCEDURES_DIR}")

    for filename, content in FILES.items():
        path = os.path.join(PROCEDURES_DIR, filename)
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"[OK] Zapisano: {path}")


if __name__ == "__main__":
    main()
