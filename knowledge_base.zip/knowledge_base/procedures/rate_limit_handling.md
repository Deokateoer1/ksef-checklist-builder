# Obsługa limitów (rate limiting) KSeF API 2.0

## Limity na poziomie API

- Przykładowe limity z dokumentacji OpenAPI:
  - 100 żądań na sekundę.
  - 300 żądań na minutę.
  - 1200 żądań na godzinę (dla niektórych grup operacji).[file:173][web:15][web:61]
- Limity mogą być różne dla grup (np. invoiceStatus, inne endpointy).[web:61][web:206]

W przypadku przekroczenia limitu KSeF zwraca status `429 Too Many Requests` z nagłówkiem `Retry-After`.[file:173][web:15]

## Strategia po stronie integracji

1. **Globalny throttling**:
   - Ustaw limity na poziomie klienta HTTP:
     - np. max 80–90% oficjalnych wartości per token / IP.
   - Rozróżniaj:
     - operacje masowe (upload, statusy),
     - operacje interaktywne (pojedyncze faktury).[web:206][web:205]

2. **Obsługa odpowiedzi 429**:
   - Odczytaj nagłówek `Retry-After`.
   - Wstrzymaj żądania dla danej grupy/tokenu na tyle sekund, ile wskazuje `Retry-After`.
   - Zapisz zdarzenie do logów (z kodem wyjątku, jeśli jest w treści).[file:173][web:15]

3. **Kolejki i priorytety**:
   - Wysyłka faktur w paczkach (wsadowo) z kolejką FIFO.
   - Priorytet wyższy dla:
     - faktur bliskich terminowi wysyłki (np. tryb offline/offline24),
     - korekt krytycznych dla rozliczeń VAT.

4. **Monitoring**:
   - Licznik wywołań per:
     - token JWT,
     - IP (dla endpointów otwartych),
     - typ operacji (statusy, upload, sesje).[web:206][web:215]
