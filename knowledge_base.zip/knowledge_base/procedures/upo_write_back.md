# UPO Write-Back (Synchronizacja Zwrotna)

## Problem
Po wysłaniu faktury do KSeF, numer UPO (Urzędowe Potwierdzenie Odbioru) MUSI wrócić do ERP.
Bez tego:
- JPK_V7 będzie niekompletny
- Nie można zamknąć miesiąca VAT
- Audytor: "Gdzie numery KSeF?"

## Rozwiązanie
1. Robot wysyła fakturę → dostaje numer KSeF (35 znaków)
2. Robot NATYCHMIAST zapisuje numer w bazie ERP (invoice.ksef_number)
3. Status zmienia się na "POSTED_TO_KSEF"
4. Faktura jest "locked" do dalszych modyfikacji

## Implementacja
- Endpoint: POST /api/invoice/save-upo
- Input: invoice_id, ksef_number
- Output: Potwierdzenie zapisu w bazie
- Walidacja: SELECT invoice WHERE ksef_number IS NOT NULL

## Test
- Wyślij 10 testowych faktur
- Weryfikuj w bazie: SELECT * FROM invoices WHERE date > NOW()-10m
- Każda powinna mieć ksef_number
