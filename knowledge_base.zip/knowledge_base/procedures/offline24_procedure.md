# Procedura trybu offline24 (KSeF 2.0)

## Kiedy używać

- Brak lub słaba jakość internetu po stronie podatnika.
- Problemy po stronie oprogramowania wystawcy, uniemożliwiające wysyłkę do KSeF.
- Opóźnienia w działaniu KSeF, ale brak oficjalnie ogłoszonej awarii.[web:207][web:213]

Tryb offline24 jest dostępny stale, niezależnie od komunikatów MF.[web:207][web:213]

## Zasady ogólne

- Fakturę wystawia się lokalnie (poza KSeF), zgodnie ze strukturą FA3.
- Na fakturze muszą być wymagane oznaczenia dla trybu offline24 (zgodnie z przepisami – w tym kody QR, jeśli wymagane w danym scenariuszu).[web:207][web:216]
- Fakturę trzeba przesłać do KSeF **najpóźniej do końca następnego dnia roboczego** po jej wystawieniu.[web:207][web:213]

## Różnica: awaria KSeF vs offline24

- **Awaria KSeF lub niedostępność systemu** (ogłoszona w BIP MF / komunikatach MF):
  - Faktury wystawione offline przesyła się do KSeF po ustaniu awarii.
  - Termin dosłania: co do zasady **następny dzień roboczy**, w przypadku awarii całkowitej nawet do 7 dni roboczych (zgodnie z komunikatem MF).[web:207][web:216][web:218]

- **Tryb offline24 bez awarii KSeF**:
  - Brak komunikatu o awarii.
  - Faktury muszą być dosłane do KSeF **do końca następnego dnia roboczego**.[web:207][web:213]

## Minimalna procedura dla systemu

1. Sprawdź status API KSeF (healthcheck / brak odpowiedzi).
2. Jeśli brak połączenia lub własny system padł:
   - Przełącz wystawianie na tryb offline24.
   - Wystawiaj faktury lokalnie, logując dokładny czas wystawienia.
3. Zaplanuj proces dosłania:
   - Batch upload do KSeF po przywróceniu łączności.
   - Walidacja struktury (FA3, XSD) przed wysyłką.
4. Monitoruj terminy:
   - Ostrzeżenia, jeśli faktura nie została dosłana do końca następnego dnia roboczego.
