# Kody GTU w kontekście KSeF

## Status GTU w KSeF

- Umieszczenie kodów GTU i oznaczeń procedur (TP, FP itp.) na fakturze w KSeF jest **fakultatywne** – nie ma obowiązku ich stosowania.[web:208]
- Kody GTU pomagają później przy przygotowaniu pliku JPK_V7 (JPK_VAT z deklaracją).[web:208][web:211]

## Zakres GTU (JPK_V7)

Przykładowe kody GTU używane w JPK_V7:[web:211][web:217]

- GTU_01 – dostawa napojów alkoholowych.
- GTU_02 – dostawa paliw.
- GTU_03 – dostawa oleju opałowego.
- GTU_04 – dostawa wyrobów tytoniowych.
- GTU_05 – dostawa odpadów.
- GTU_06 – dostawa urządzeń elektronicznych.
- GTU_07 – dostawa pojazdów oraz części.
- GTU_08 – dostawa metali szlachetnych i nieszlachetnych.
- GTU_09 – dostawa leków i wyrobów medycznych.
- GTU_10 – dostawa budynków, budowli, gruntów.
- GTU_11 – świadczenie usług w zakresie przenoszenia uprawnień do emisji.
- GTU_12 – świadczenie usług niematerialnych (doradczych, reklamowych itp.).
- GTU_13 – pozostałe towary/usługi wymagające oznaczenia.

## Rola GTU w Twoim systemie

- W strukturze FA (FA2/FA3) kody GTU są polami fakultatywnymi, ale:
  - warto przechowywać GTU na poziomie pozycji faktury,
  - to ułatwia:
    - automatyczne budowanie JPK_V7,
    - analizy sprzedaży wg GTU (Robot-Zwiadowca).[web:208][web:211]

- Przy pobieraniu danych z KSeF:
  - jeśli GTU są obecne w XML, można je wykorzystać do:
    - filtrowania (np. wszystkie faktury z GTU_12),
    - kontroli poprawności klasyfikacji towarów/usług.
