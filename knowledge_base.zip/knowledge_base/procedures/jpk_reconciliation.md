# JPK_V7 Reconciliation

## Problem
1000 faktur wysłano do KSeF. Tylko 995 ma numery. 5 zagubiło się.
JPK zawiera tylko 995. Brakuje 5 faktur.

## Rozwiązanie
Raport différential: Faktury w ERP bez numeru KSeF.

## Procedura
1. Co miesiąc (przed zamknięciem): Uruchom raport
2. Filtr: invoices WHERE ksef_number IS NULL AND date BETWEEN start AND end
3. Dla każdej: Czy pending? Czy failed?
4. Akcja:
   - Pending → Retry (może sieć była słaba)
   - Failed → Investigate + Manual fix
5. Zero discrepancies = OK do JPK

## Runbook
- Raport: GET /api/reports/reconciliation-ksef-vs-erp?start=2026-02-01&end=2026-02-28
- Export: CSV dla audytora
- Deadline: Przed złożeniem JPK (zawsze D+20 miesiąca)
