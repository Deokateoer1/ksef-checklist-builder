# Procedura obsługi faktur korygujących w KSeF (FA2/FA3)

## Struktura FA2 vs FA3

- Do 31.01.2026:
  - dla nowych i korygujących faktur można używać struktury FA2.[file:115]
- Od 01.02.2026:
  - obowiązującym wzorem jest struktura FA3 (również dla korekt faktur wystawionych wcześniej w FA1/FA2).[file:115]

## Zasady korekt w FA3

- Korekta musi odnosić się do konkretnej faktury pierwotnej (identyfikator KSeF, dane nagłówkowe).[file:115]
- Korekty wystawia się już w FA3, nawet jeśli faktura pierwotna była w FA2/FA1.[file:115]
- Struktura FA3 zawiera pola do:
  - powiązania z dokumentem pierwotnym,
  - korekt pozycji (FaWiersz) i podsumowań (Rozliczenie).[file:115]

## Procedura biznesowa

1. **Identyfikacja faktury pierwotnej**:
   - Pobierz dane faktury z KSeF (status + treść).
   - Ustal, czy była w FA2 czy FA3 (historycznie ważne, ale korekta i tak idzie w FA3).[file:115]

2. **Przygotowanie korekty**:
   - Użyj schematu FA3 (FA_3_schema.xsd) do walidacji.
   - Wypełnij:
     - powiązanie z dokumentem pierwotnym,
     - zmienione pozycje / kwoty,
     - ewentualne dodatkowe adnotacje (FaAdnotacje).[file:115]

3. **Wysłanie do KSeF**:
   - Prześlij plik XML FA3.
   - Sprawdź wynik walidacji schematu i biznesowej (kody 214xx/212xx).[file:173][file:173]

4. **Udostępnienie nabywcy**:
   - Nabywca odbiera korektę w KSeF.
   - Dane są widoczne w historii transakcji dla obu stron.

## Uwagi

- Przy korektach „do zera” i zbiorczych:
  - stosować odpowiednie pola FA3 zgodnie z broszurą informacyjną (sekcja Fa/Rozliczenie, przykłady w dokumentacji).[file:115]
