# Filtrowanie faktur B2C w KSeF

## Jak rozpoznać fakturę B2C

- W strukturze FA3 (Podmiot2):
  - pole `BrakID = 1` – nabywca bez NIP (konsument).[file:115]
  - brak pola NIP w `Podmiot2DaneIdentyfikacyjne`.
  - imię i nazwisko nabywcy w polu `Nazwa`.[file:115]

## Zastosowanie w Robocie-Zwiadowcy

1. **Filtr B2C**:
   - B2C = `Podmiot2DaneIdentyfikacyjne.BrakID == 1`.
   - B2B = `Podmiot2DaneIdentyfikacyjne.NIP` wypełniony.[file:115]

2. **Ograniczenie zakresu analizy**:
   - raporty tylko B2B: filtruj po obecności NIP.
   - raporty konsumenckie (np. sprzedaż detaliczna): filtruj po `BrakID == 1`.

3. **Ostrożność przy danych osobowych**:
   - B2C → imię i nazwisko + adres to dane osobowe.
   - Wewnętrzne logi/systemy powinny być zgodne z RODO (minimalizacja danych, maskowanie, retencja).
