Konwerter PDF na Markdown
Widok debugowania
Widok wyników
Faktura
ustrukturyzowana
Broszura informacyjna dotycząca struktury
logicznej FA( 3 )
Warszawa, wrzesień 2025 r.
Spis treści
Wstęp
Definicja faktury ustrukturyzowanej
Wzór faktury ustrukturyzowanej
Jak wystawić e-Fakturę?
Formaty pól (danych) plików faktury ustrukturyzowanej
Schemat struktury rynku dla FA(3)
Opis schematu struktury handlowej dla FA(3)
Naglowek dla FA(3)
Struktura elementu Nagłowek dla FA(3)
Podmiot1 dla FA(3)
Struktura elementu Podmiot1 dla FA(3)
Podmiot2 dla FA(3)
Struktura elementu Podmiot2 dla FA(3)
Podmiot3 dla FA(3)
Struktura elementu Podmiot3 dla FA(3)
PodmiotUpoważniony dla FA(3)............................................................................................
Struktura elementu PodmiotUpowaniony dla FA(3)
Fa dla FA(3)
Struktura elementu Fa dla FA(3)
Element FaWiersz dla Fa
Element Rozliczenie dla Fa
Element Platnosc dla Fa
Element WarunkiTransakcji dla Fa
Element Transport dla WarunkiTransakcji
Element Zamowienie dla Fa
Stopka dla FA(3)
Struktura elementu Stopka dla FA(3)
Zalacznik dla FA(3)
Struktura elementu Zalacznik dla FA(3)
Spis punktów
Spis schematów
Spis tabel
Ilekroć w kolejnym broszurze jest mowa o:

a) GV – rozumie się przez to grupę VAT,
b) JST – rozumie się przez to jednostkę samorządu terytorialnego,
c) KSeF - rozumie się przez to Krajowy System e-Faktur, o którym mowa w art. 106nd ust. 2
ustawy z dnia 11 marca 2004 r. o podatku od towarów i usług,
d) rozporządzeniu w sprawie JPK_VAT z deklaracją – rozumie się przez to rozporządzenie
Ministra Finansów, Inwestycji i Rozwoju z dnia 15 października 2019 r. w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług (Dz. U. z 2019 r. poz. 1988 ze zm.),
e) ustawie - rozumie się przez to ustawę z dnia 11 marca 2004 r. o podatku od towarów i
usług (Dz. U. z 2025 r. poz. 775 ze zm.).
Wstęp
Definicja faktury ustrukturyzowanej
Przez fakturę ustrukturyzowaną (e-fakturę) rozumie się fakturę wystawioną przy użyciu KSeF
wraz z przydzielonym numerem identyfikacyjnym tej faktury w tym systemie (art. 2 pkt 32a
ustawy).

Faktura ustrukturyzowana jest stosowana przy użyciu KSeF za pomocą
oprogramowania interfejsuowego, w postaci elektronicznej i będącej częścią zestawu
elektronicznego w wersji opublikowanej z dnia 17 lutego 2005 r. o informatyzacji działalności
podmiotów realizujących zadania publiczne^1.

Wzór faktury ustrukturyzowanej
Struktura logiczna w wersji FA(2) Organizacjaca od 1 września 2023 r. będzie aktywny do
31 stycznia 2026 r. Od 1 lutego 2026 r. obowiązującym faktury ustrukturyzowanej
będzie struktura logiczna FA(3). Nowy wzór faktury ustrukturyzowanej,
która zostanie zastosowana przez dostawców oprogramowania oraz
oprogramowanie księgowe podczas stosowania w 2024 r. punkt KSeF.

Struktury logiczne FA(3) w wersji produkcyjnej są dostępne pod adresem:
https://crd.gov.pl/wzor/2025/06/25/13775/.

WAŻNE

Czy wszyscy faktury ustrukturyzowane są stosowane od 1 lutego 2026 r. stosuje się
strukturę logiczną FA( 3 ).

(^1) Dz. U. z 2024 r. poz. 1557 ze zm.

to, że struktura logiczna e-faktury w wersji FA( 3 ) wykorzystuje się także do
wydawnictw (od 1 lutego 2026 r.):

faktura korygująca, w sytuacji, gdy faktura pierwotna, której dotyczy faktura
korygująca, została wystawiona przed 1 lutego 2026 r. przy użyciu struktury FA(2) lub
FA(1),
faktura rozliczająca, w przypadku gdy faktura zaliczkowa została wystawiona przed 1
lutego 2026 r. przy użyciu struktury FA(2) lub FA(1).
Jak wystawić e-Fakturę?
Ministerstwo Finansów udostępniło bezpłatne narzędzia, za pomocą których możliwe jest
wystawienie faktury ustrukturyzowanej. Należą do nich:

Aplikacja Podatnika KSeF wyprowadzana z KSeF podmiot i podmiotom
uprawnionym przez te jednostki, zarządzanie władzami, zastosowanie i
odbieranie e-faktur w KSeF, podgląd e-faktury oraz jej pobranie, weryfikacja
stosowania i możliwość pobrania UPO KSeF (https://www.podatki.gov.pl/ksef/aplikacja-
podmiota-ksef-i-inne-narzedzia/);
Aplikacja Mobilna KSeF, która pozwala na wygodne i szybkie korzystanie z faktur
ustrukturyzowanych, odbieranie ich w czasie oraz zarządzanie nimi z
dowolnego miejsca (https://ksef.podatki.gov.pl/aplikacja-podatnika-ksef-i-inne-narzedzia/aplikacja-mobilna-ksef/
);
Aplikacja e-mikrofirma połączona z powiązaniem konta z KSeF,
wydaniem faktury w KSeF, odbieraniem faktur ustrukturyzowanych z KSeF oraz
przenoszeniem ich bezpośrednio do ewidencji VAT, bez konieczności ręcznego
przepisywania danych. Aplikacja dostępna jest w e-Urzędzie Skarbowym:
https://urzadskarbowy.gov.pl.
Fakturę ustrukturyzowaną można wystawić przy użyciu programów
finansowych finansowo-księgowych z API KSeF.

Formaty pól (danych) plików faktury ustrukturyzowanej
Ogólne założenia dotyczące formatu pól:

Formatem pliku jest XML.
Pola (elementy) w pliku XML następującym charakter:
obligatoryjny - zapisów określonych się obowiązkowo (np. NIP w elemencie
Podmiot1/DaneIdentyfikacyjne); obowiązkowy charakter treści dotyczący pola, które
następuje w następstwie przepisów ustawy i jest warunkową strukturą
logiczną,
opcjonalny - zapisów spełniony obowiązekkowo, jeśli jest spełnienie warunku
ustawowego (np. P_11A w elemencie Fa/FaWiersz); Wymaganie pola nie jest
wymagane dla poprawności pliku semantycznego,
fakultatywny - podanie pola nie jest wymagane dla poprawności semantycznej
pliku, ani nie jest wymagane na podstawie przepisów ustawy (np. pole PKWiU w
elemencie Fa/FaWiersz); Zamiast tego może być wymagane na podstawie przepisów
innych aktów prawnych.
(^)
WAŻNE
Analizując obowiązkowe informacje dotyczące pola, należy badać także charakter elementu, w
którym dane pole wykorzystywane.
wykorzystuje, element Fa/Platnosc oraz wchodzący w jego skład elementu RachunekBankowy
mają charakter fakultatywny.
Jeżeli wystąpią:

Dostępność elementu RachunekBankowy – wówczas konieczne jest
dodanie dodatku do jego składu, pola obowiązkowego NrRB;
nie dotyczy zastosowania elementu RachunekBankowy, do pola NrRB również
nie jest wypełniane.
Powyższa głębokość obrazuje następujący schemat:

Schemat 1. Rodzaje elementów w składzie FA( 3 ) na element
Platnosc/RachunekBankowy

Pola znakowe są polami alfanumerycznymi. Dopuszczalne jest zastosowanie małych i dużych
liter oraz cyfr. Informacje o postaciach wynoszą co do zasad 256.
W odpowiednich polach GTIN, GTINZ dopuszczalna ilość znaków wynosi 20.

W tytule pól CN, CNZ, Indeks, IndeksZ, OpisInnegoLadunku, OpisInnegoTransportu,
PKOB, PKOBZ, PKWiU, PKWiUZ, UU_ID, UU_IDZ, jednostka dopuszczalna wielkość znaków

W uzasadnieniu pola IDNabywcy dopuszczalne znaczenie wynosi 32, aw przypadku pola
IPKSeF 13.

W nazwach pól Nazwa, AdresL1 oraz AdresL2, P_7, P_7Z, LinkDoPlatnosci oraz
wpływ na element Zalacznik pól ZNaglowek, Akapit, Opis maksymalnej ilości
znaków wynosi 512.

Polskie znaki diakrytyczne muszą być stosowane przy użyciu kodowania UTF-8. W polach
znakowych stosuje się znaki specjalne, np. „/”, „–”, „+”.
Pola kwotowe (numeryczne) wyznaczające wartości liczbowe. Wartość należy wprowadzić
jako ciąg cyfrowy, nie można zastosować separatorów dla tysięcy (np. spacji). Jako separator miejsc
dziesiętnych można zastosować wyłącznie kropki („ ” ).
Kwoty są co do zasad z określonymi do 2 miejsc po kropce – o ile występują
(np. 12345.56).
W przypadku pól P_8B, P_12_XII, P_8BZ, P_12Z_XII, KursWaluty, KursWalutyZK,
KursWalutyZW, KursWalutyZ, KursUmowny, Udział, wartości wynikające są z następująceą do
6 miejsc po kropce – o ile występują.

Cenę jednostkową w polach P_9A, P_9B, P_9AZ oraz wysokość opustów lub obniżek
końcowych w polu P_10 można uzyskać z notatką do 8 miejsc po kropce.

Wszystkie dodatkowe wielkości mogą być oznaczone minusem („ –”).
Data ważności jest w formacie RRRR-MM-DD (np. 202 6 - 02 - 01 ).
Wymóg podawania daty i czasu dotyczy tylko jednego pola. Jest to pole opisujące datę i czas
wytworzenia faktury. Data i czas podany w RRRR-MM-DDTGG:MM:SS (np.: 202 6 -
02 - 01 T09:30:47Z; gdzie T oznacza „Czas”). Przy podawaniu czasu uniwersalnego (UTC) na
końcu należy dodać literę „Z” (ZULU).
Należy zachować ostrożność w zakresie obowiązywania umowy
o transporcie (DataGodzRozpTransportu, DataGodzZakTransportu) uzupełniającej
w takim przypadku.

Numery pochodzenia podatkowego są ujęte w strukturze faktury ustrukturyzowanej, należy
zapisywać jako ciąg dalszy po sobie cyfr lub litera, bez spacji i innych znaków
rozdzielających oraz poprzez wyodrębnienie kodu literowego kraju do
przeznaczonego na dziesięć kodów.
WAŻNE

Polski identyfikator podatkowy NIP należy uwzględnić w polu NIP w elemencie
Podmiot2/DaneIdentyfikacyjne. Nie należy prowadzić go w polu NrVatUE, ani w polu NrID.
Faktura jest odpowiednio udostępniana nabywcy w KSeF wyłącznie, gdy jego
identyfikator podatkowy NIP jest przekazywany w polu NIP, a nie w polu NrVatUE lub NrID.

Tabela 1. Wykaz oznaczeń w diagramie XSD

WAŻNE
Elementy modułu i fakultatywne, które znajdują się w broszurach graficznych, wyglądają
identycznie tzn. Urządzenie obramowania w postaci przerywacza. Elementy obowiązkowe,
zamiast obramowania, są dostępne w postaci linii.

ujawnienie, do którego kategorii należy dany element, który powinien zostać dokonany w oparciu o
wytyczne zawarte w broszurze, w spisie formatów pól (danych) pliku faktury
ustrukturyzowanej (pkt 2).

Schemat struktury rynku dla FA(3)
Struktura schematu głównego dla FA( 3 ) składa się z elementu: Naglowek,
Podmiot1, Podmiot2, Podmiot3, PodmiotUpowazniony, Fa, Stopka, Zalacznik.

Nagłowek, Podmiot1, Podmiot2 oraz Fa zawierają obowiązkowe elementy e-faktury.
Podmiot3, Stopka i Zalacznik są elementami fakultatywnymi, a PodmiotUpowazniony
element opcjonalny e-faktury.

Schemat 2. Schemat struktury źródła dla FA( 3 )

Opis schematu struktury handlowej dla FA(3)
Tabela 2. Opis schematu struktury handlowej dla FA( 3 )

Nazwa pola
Opis pola
Naglowek Zawiera m. in. dane dotyczące daty i czasu wytworzenia faktury
oraz nazwy systemu teleinformatycznego, z którego korzysta
podatnik.
Podmiot1 Zawiera informacje, które charakteryzują podatnika
(sprzedawcę).
Podmiot2 Zawiera informacje, które charakteryzują nabywcę towaru lub
usługi.
Podmiot3 Zawiera dane podmiotu/-ów trzeciego/-ich (innego/-ych niż
sprzedawca (Podmiot1) i nabywca wymieniony w części
Podmiot2), związanego/-ych z fakturą [element fakultatywny].
Maksymalna ilość wystąpień: 100
PodmiotUpowazniony Zawiera informacje, które charakteryzują podmiot upoważniony
związany z fakturą [element opcjonalny].
Fa Zawiera szczegółowe informacje dotyczące transakcji
dokumentowanej fakturą. W szczególności są to elementy
faktury wynikające z treści obowiązujących przepisów, jak
również elementy dotyczące m.in. rozliczenia, płatności oraz
warunków transakcji.
Stopka Zawiera pozostałe informacje na fakturze. m.in. stopkę faktury,
numer KRS, REGON [element fakultatywny].
Zalacznik
Zawiera załącznik do faktury dotyczącej czynności o złożonej
liczbie danych w zakresie jednostek miary i ilości (liczby)
dostarczanych towarów lub wykonywanych usług lub cen
jednostkowych netto [element fakultatywny].
Naglowek dla FA(3)
Struktura elementu Nagłowek dla FA(3)
Schemat 3. Struktura elementu Nagłowek dla FA( 3 )

Tabela 3. Opis struktury elementu Nagłowek dla FA( 3 )

Nazwa pola Opis pola
KodFormularza
Pole przechowuje dwa atrybuty elementu KodFormularza:
kodSystemowy: FA ( 3 )
wersjaSchematy: 1-0E.
WariantFormularza
Pole zawiera oznaczenie schematu. Obecnie jest to wartość:
3. Jest to trzeci wariant schemy - FA( 3 ).
DataWytworzeniaFa
Data i czas wytworzenia faktury
Podaje się datę i godzinę wytworzenia faktury (pliku xml), w
formacie RRRR-MM-DDTGG:MM:SS (np.: 202 6 - 02 -
01 T09:30:47Z; gdzie T oznacza „Time”).
Z – ZULU – jest to określenie strefy czasowej, odpowiadającej
uniwersalnemu czasowi koordynowanemu (UTC).
Uwaga!
DataWytworzeniaFa może być inna niż data wskazana w polu
P_1 oraz może być inna niż data faktycznego przesłania
faktury do KSeF.
SystemInfo
Nazwa systemu teleinformatycznego, z którego korzysta
podatnik [pole fakultatywne]
Podmiot1 dla FA(3)
Struktura elementu Podmiot1 dla FA(3)
WAŻNE
Element Podmiot1 stanowi obowiązkowy element faktury ustrukturyzowanej. Kluczowym
polem w elemencie Podmiot1, zostaniem na autoryzację ataku w KSeF jest
identyfikator podatkowy NIP.

Bez konieczności sprawdzania identyfikatora NIP, wystawienie faktury w ramach KSeF
nie będzie możliwe.

Schemat 4. Struktura elementu Podmiot1 dla FA( 3 )

Tabela 4. Opis struktury elementu Podmiot1 dla FA( 3 )

Nazwa pola Opis pola
PrefiksPodatnika Kod (prefiks) podatnika VAT UE dla przypadków
określonych w art. 97 ust. 10 pkt 2 i 3 ustawy oraz w
przypadku, o którym mowa w art. 136 ust. 1 pkt 3
ustawy [pole opcjonalne]
Należy podać literowy kod kraju „PL” podatnika w
przypadku wystawienia faktury dokumentującej:
wewnątrzwspólnotową dostawę dostawy,
doświadczenie usług, do których stosuje się art. 100 ust. 1
pkt 4 ustawy, dla podlegających podatkowi od wartości
dodanej lub osób prawnych nienależących do dotyczyjących
, określonych na temat podatku
od wartości dodanej,
dostawa kluczowa w ramach transakcji trójstronnej
uproszczonej, przez drugą w kolejności, o
której mowa w art. 135 ust. 1 pkt 4 lit. ustawa bic.
NrEORI Numer EORI podatnika [pole fakultatywne]
Numer EORI jest to numer w Unijnym Systemie
Rejestracji i Identyfikacji Podmiotów Gospodarczych.
DaneIdentyfikacyjne Element zawierający dane identyfikujące podatnika
(sprzedawcę): jego NIP oraz imię, nazwisko lub nazwę
Adres Element zawierający dane dotyczące adresu podatnika
AdresKoresp Element zawierający dane dotyczące adresu
korespondencyjnego podatnika [element fakultatywny]
DaneKontaktowe Element zawierający dane kontaktowe podatnika: adres
e-mail oraz numer telefonu [element fakultatywny]
Maksymalna ilość wystąpień: 3
StatusInfoPodatnika Status podatnika [pole fakultatywne]
Podaje się:
„1” - w przypadku dotyczącym zastosowania w stanie
likwidacji,
„2” - w przypadku, który jest w trakcie
postępowania restrukturyzacyjnego,
„3” - w przypadku, gdy znajduje się w stanie
upadłości,
„4” - w przypadku przedsiębiorstwa w spadku.
Kwestia wypełnienia pola należy do decyzji podatnika,
niezależnie czy podatnik ten posiada jeden z
wymienionych wyżej statusów.
Schemat 5. Struktura elementu DaneIdentyfikacyjne dla Podmiot

Tabela 5. Opis struktury elementu DaneIdentyfikacyjne dla Podmiot

Nazwa pola Opis pola
NIP Identyfikator podatkowy NIP podatnika
Podaje się numer, za pomocą którego sprzedawca jest
zidentyfikowany na potrzeby podatku (bez literowego
kodu kraju).
Nazwa Imię i nazwisko lub nazwa podatnika
Maksymalna ilość znaków: 512
Uwaga!
W polu Nazwa można również wskazać nazwę handlową
podatnika.
Przykład wypełnienia:
Jan Kowalski, Sklep Motoryzacyjny XYZ
Schemat 6. Struktura elementu Adres dla Podmiot

Tabela 6. Opis struktury elementu Adres dla Podmiot

Nazwa pola Opis pola
KodKraju Kod kraju
AdresL1 Adres podatnika – linia pierwsza
Maksymalna ilość znaków: 512
Przykład wypełnienia:
ul. Błękitna 14, 11-111 Warszawa
AdresL2 Adres podatnika – linia druga [pole fakultatywne]
Maksymalna ilość znaków: 512
Uwaga!
Pole AdresL2 można wykorzystać np. w sytuacji, gdy
adres podatnika nie mieści się w polu AdresL1 lub w celu
zwiększenia czytelności danych (np. ulica i nr domu w
polu AdresL1, a kod pocztowy i miejscowość w AdresL2).
GLN Globalny Numer Lokalizacyjny [pole fakultatywne]
GLN jest to numer umożliwiający m.in. zidentyfikowanie
jednostek fizycznych lub funkcjonalnych w obrębie
firmy.
Przykładowo w elemencie Adres dla Podmiot1, numer
GLN może oznaczać fizyczną lokalizację danego obiektu,
(np. budynku siedziby podatnika, piętra, oddziału firmy).
Schemat 7. Struktura elementu AdresKoresp dla Podmiot

Tabela 7. Opis struktury elementu AdresKoresp dla Podmiot

Nazwa pola Opis pola
KodKraju Kod kraju
AdresL1 Adres korespondencyjny podatnika – linia pierwsza
Maksymalna ilość znaków: 512
AdresL2 Adres korespondencyjny podatnika – linia druga [pole
fakultatywne]
Maksymalna ilość znaków: 512
GLN Globalny Numer Lokalizacyjny [pole fakultatywne]
GLN jest to numer umożliwiający m.in. zidentyfikowanie
jednostek fizycznych lub funkcjonalnych w obrębie
firmy.
Przykładowo w elemencie AdresKoresp dla Podmiot1,
numer GLN może oznaczać fizyczną lokalizację danego
obiektu lub budynku, do którego powinna być kierowana
korespondencja podatnika.
Schemat 8. Struktura elementu DaneKontaktowe dla Podmiot

Tabela 8. Opis struktury elementu DaneKontaktowe dla Podmiot

Nazwa pola Opis pola
Email Adres e-mail podatnika (np. abc@xyz.pl) [pole
fakultatywne]
Telefon Numer telefonu podatnika (np. 801055055) [pole
fakultatywne]
Przykład 1. Sposób wypełnienia Podmiot1 dla FA( 3 )

Stan faktyczny:

XXX Sp. z oo w likwidacji jest odrębnym VAT, objętym działaniem
wewnątrzwspólnotowym (PL 9999999999). Siedziba firmy znajduje się w Krakowie (55-555)
przy ul. Błękitnej 16/3. Spółka zintegrowana wewnątrzwspólnotowej dostawy danych na rzecz
podatku od wartości dodanych, również wchodzącego do transakcji
wewnątrzwspólnotowych. Sprzedawca, w celu kontaktu, podaj na fakturze swój
numer telefonu (801055055), adres e-mail (podatnik@xyz.pl) oraz swój adres
korespondencyjny (ul. Turkusowa 12, 55-555 Kraków).

Dane dodatkowe uwzględniają w składzie FA( 3 ) w sposób:

Nazwa pola Sposób wypełnienia
Podmiot1 PrefiksPodatnika PL
Podmiot1/
DaneIdentyfikacyjne
NIP 9999999999
Nazwa XXX Sp. z o.o. w likwidacji
Podmiot1/Adres
KodKraju PL
AdresL1 ul. Błękitna 16/3, 55-555 Kraków
Podmiot1/AdresKoresp KodKraju PL
AdresL1 ul. Turkusowa 12, 55-555 Kraków
Podmiot1/
DaneKontaktowe
Email podatnik@xyz.pl
Telefon 801055055
Podmiot1 StatusInfoPodatnika 1
Podmiot2 dla FA(3)
Struktura elementu Podmiot2 dla FA(3)
Schemat 9. Struktura elementu Podmiot2 dla FA( 3 )

Tabela 9. Opis struktury elementu Podmiot2 dla FA( 3 )

Nazwa pola Opis pola
NrEORI Numer EORI nabywcy towarów [pole fakultatywne]
Numer EORI jest to numer w Unijnym Systemie
Rejestracji i Identyfikacji Podmiotów Gospodarczych.
DaneIdentyfikacyjne Element zawierający dane identyfikujące nabywcę, m.
in. NIP, imię i nazwisko lub nazwę nabywcy
Adres Element zawierający dane dotyczące adresu nabywcy,
opcjonalny dla przypadków określonych w art. 106e ust.
5 pkt 3 ustawy (tzw. faktura uproszczona)
AdresKoresp Element zawierający dane dotyczące adresu
korespondencyjnego nabywcy [element fakultatywny]
DaneKontaktowe
Element zawierający dane kontaktowe nabywcy: adres
e-mail oraz numer telefonu [element fakultatywny]
Maksymalna ilość wystąpień: 3
NrKlienta Numer klienta dla przypadku, w którym kupujący
posługuje się nim w realizacji lub zamówieniu [pole
fakultatywne]

IDNabywcy Unikalny klucz powiązania danych kupujących na fakturach
korygujących, w przypadku gdy dane kupujące na
fakturze korygującej zmieniły się w odniesieniu do danych
na fakturze korygowanej [pole fakultatywne]

Maksymalna ilość znaków: 32
Uwaga!
Praktyczne zastosowanie pola IDNabywcy zostało
przedstawione w przykładzie nr 15.
JST
Znacznik jednostki podrzędnej JST
Podaje się:
„1” - w przypadku, gdy faktura dotyczy jednostki
podrzędnej JST,
„2” - w przypadku, gdy faktura nie dotyczy jednostki
podrzędnej JST.
Uwaga!
W przypadku wskazania „ 1 ” w polu JST należy wypełnić
sekcję Podmiot3, aby fakturę w KSeF otrzymała także
jednostka podrzędna JST. W szczególności należy
pamiętać o podaniu jej numeru NIP lub IDWew oraz
określeniu roli w polu Rola jako „8” - JST – odbiorca.
GV
Znacznik członka GV
Podaje się:
„1” - w przypadku, gdy faktura dotyczy GV,
„2” - w przypadku, gdy faktura nie dotyczy GV.
Uwaga!
W przypadku wskazania „ 1 ” w polu GV należy wypełnić
sekcję Podmiot3, aby fakturę w KSeF otrzymał także
członek GV. W szczególności należy pamiętać o podaniu
jego numeru NIP lub IDWew oraz określeniu roli w polu
Rola jako „10” - członek GV – odbiorca.
WAŻNE
Wprowadzenie w FA(3) w elemencie Podmiot2 obowiązkowych pól JST oraz GV
stanowi realizację postulatów szczegółowych w ramach określonych celów KSeF.

Zgodnie z opisem rozwiązań w dokumentacji struktury logicznej, w przypadku stosowania w
Podmiot2, faktura dotyczy jednostki podrzędnej JST (wartość „1” w polu JST) lub zasady
GV (wartość „1” w polu GV) należy uwzględnić dodatkowe dane tej jednostki podrzędnej JST
lub powiązanej GV w Podmiot3 (w tym NIP lub IDWew i licencji). Dostępne, aby udostępnić je
na rynku narzędzi, wyposażonych z API KSeF i służących do e-fakturowania, stwarzających
mechanizmy udostępniające, które zapewniają podanie ww. dane. Dzięki temu dostępowi do
faktur zakupowych w KSeF poza samym nabywcą (JST, GV) będziesz mieć zapewniony także
jednostkom podrzędnym JST i członkom GV, których te zakupy są warte.

Schemat 10. Struktura elementu DaneIdentyfikacyjne dla Podmiot

Tabela 10. Opis struktury elementu DaneIdentyfikacyjne dla Podmiot

Nazwa pola Opis pola
NIP
Identyfikator podatkowy NIP nabywcy
Numer, za pomocą którego nabywca towarów lub usług
jest zidentyfikowany na potrzeby podatku, pod którym
otrzymał on towary lub usługi
KodUE
Kod (prefiks) nabywcy VAT UE, o którym mowa w art.
106e ust. 1 pkt 24 ustawy oraz w przypadku, o którym
mowa w art. 136 ust. 1 pkt 4 ustawy
Podaje się literowy kod kraju w przypadku wystawienia
faktury dokumentującej:
wewnątrzwspólnotową dostawę dostawy,
doświadczenie usług, do których stosuje się art. 100 ust. 1
pkt 4 ustawy, dla podlegających podatkowi od wartości
dodanej lub osób prawnych nienależących do dotyczyjących
, określonych na temat podatku
od wartości dodanej.
dostawa kluczowa w ramach transakcji trójstronnej
uproszczonej, przez drugą w kolejności, o
której mowa w art. 135 ust. 1 pkt 4 lit. ustawa bic.
NrVatUE Numer identyfikacyjny VAT nabywcy (bez literowego
kodu kraju, który został wskazano w polu KodUE) w przypadku
wystawienia faktury dokumentującej:

wewnątrzwspólnotową dostawę dostawy,
doświadczenie usług, do których stosuje się art. 100 ust. 1
pkt 4 ustawy, dla podlegających podatkowi od wartości
dodanej lub osób prawnych nienależących do dotyczyjących
, określonych na temat podatku
od wartości dodanej.
W przypadku faktur wystawianych w procedurze
uproszczonej przez drugiego w kolejności podatnika, o
którym mowa w art. 135 ust. 1 pkt 4 lit. b i c oraz ust. 2
ustawy, wskazuje się numer, o którym mowa w art. 136
ust. 1 pkt 4 ustawy (bez literowego kodu kraju).
Uwaga!
W polach NrVatUE oraz NrID nie należy podawać
polskiego identyfikatora podatkowego NIP nabywcy, dla
którego przeznaczone jest pole NIP. Faktura zostanie
odpowiednio udostępniona nabywcy wyłącznie gdy jego
NIP wskazano w polu NIP, a nie w polach NrVatUE lub
NrID.
KodKraju
Kod kraju nadania inny identyfikatora podatkowego
[pole fakultatywne]

NrID
Identyfikator podatkowy inny niż NIP oraz NrVatUE

Przykład:
Podatnik polski świadczy usługę tłumaczeniową na rzecz
podatnika mającego siedzibę działalności gospodarczej
w Szwajcarii. Nabywca posiada identyfikator podatkowy
nadany na cele podatku o podobnym charakterze w
kraju swojej siedziby.
Identyfikator ten można wskazać w strukturze FA( 3 ), w
polu NrID. Dodatkowo w polu KodKraju można wskazać
„CH” (tj. kod kraju – Szwajcaria).
Przykład:
Polski podatnik dokonuje sprzedaży na rzecz
kontrahenta z innego kraju UE, który posługuje się
indywidualnym numerem identyfikacyjnym
zawierającym kod EX. W tej sytuacji należy ten numer
wskazać w polu NrID, wraz z kodem EX. Natomiast w
polu KodKraju można wskazać dodatkowo kod kraju
tego kontrahenta.
BrakID Podmiot nieposiadający identyfikatora podatkowego lub
podmiotu, którego identyfikator nie jest sprawdzany na
fakturze

Podaje się „1”w przypadku, gdy nabywca nie posiada
identyfikatora podatkowego lub gdy identyfikator
podatkowy nabywcy nie występuje na fakturze (np. w
przypadku, gdy nabywcą jest osoba fizyczna
nieprowadząca działalności gospodarczej - konsument).
W przypadku określonym w art. 106e ust. 5 pkt 2
ustawy faktura może nie zawierać identyfikatora
podatkowego nabywcy. W takiej sytuacji wskazuje się
„1” w polu BrakID.
Nazwa Imię i nazwisko lub nazwa kupującego

Maksymalna ilość znaków: 512
Uwaga!
W polu Nazwa można również wskazać nazwę handlową
nabywcy.
Przykład wypełnienia:
Jan Kowalski, Sklep spożywczy XYZ
Schemat 11. Struktura elementu Adres dla Podmiot2

Tabela 11. Opis struktury elementu Adres dla Podmiot2

Nazwa pola Opis pola
KodKraju Kod kraju
AdresL1
Adres nabywcy – linia pierwsza
Maksymalna ilość znaków: 512
Przykład wypełnienia:
ul. Błękitna 14, 11-111 Warszawa
AdresL2
Adres nabywcy – linia druga [pole fakultatywne]
Maksymalna ilość znaków: 512
Uwaga!
Pole AdresL2 można wykorzystać np. w sytuacji gdy
adres nabywcy nie mieści się w polu AdresL1 lub w celu
zwiększenia czytelności danych (np. ulica i nr domu w
polu AdresL1, a kod pocztowy i miejscowość w AdresL2).
GLN Globalny Numer Lokalizacyjny [pole fakultatywne]
GLN jest to numer umożliwiający m.in. zidentyfikowanie
jednostek fizycznych lub funkcjonalnych w obrębie
firmy.
Przykładowo w elemencie Adres dla Podmiot2, numer
GLN może oznaczać fizyczną lokalizację danego obiektu
(np. budynku - siedziby nabywcy, piętra, oddziału firmy).
Schemat 12. Struktura elementu AdresKoresp dla Podmiot2

Tabela 12. Opis struktury elementu AdresKoresp dla Podmiot2

Nazwa pola Opis pola
KodKraju Kod kraju
AdresL1
Adres korespondencyjny nabywcy – linia pierwsza
Maksymalna ilość znaków: 512
AdresL2
Adres korespondencyjny nabywcy – linia druga [pole
fakultatywne]
Maksymalna ilość znaków: 512
GLN Globalny Numer Lokalizacyjny [pole fakultatywne]
GLN jest to numer umożliwiający m.in. zidentyfikowanie
jednostek fizycznych lub funkcjonalnych w obrębie
firmy.
Przykładowo w elemencie AdresKoresp dla Podmiot2,
numer GLN może oznaczać fizyczną lokalizację danego
obiektu lub budynku, do którego powinna być kierowana
korespondencja nabywcy.
Schemat 13. Struktura elementu DaneKontaktowe dla Podmiot2

Tabela 13. Opis struktury elementu DaneKontaktowe dla Podmiot2

Nazwa pola Opis pola
Email Adres e-mail nabywcy (np. abc@xyz.pl) [pole
fakultatywne]
Telefon Numer telefonu nabywcy (np. 801055055) [pole
fakultatywne]
Przykład 2. Sposób wypełnienia Podmiot2 dla FA( 3 )

Stan faktyczny:

Podatnik VAT Wykonał usługę tłumaczeniową na rzecz firmy XXX Sp. z oo z siedzibą we
Wrocławiu (46-666) przy ul. Pomarańczowej 5. Nabywca jest określony na
podatek od usług i usług pod numerem NIP 1111111111. W związku z zawartą pomiędzy
stronami umowy oraz w celu sprawnej obsługi transakcji, kupujący został nadany numer
klienta (KL/128/202 6 ). Faktura nie przerwana 450 zł brutto. Sprzedawca dokumentuje
fakturę sprzedaży, o której mowa w art. 106e ust. 5 pkt 3 ustawy.

W analizowanej sytuacji element Podmiot2 wypełnia się w sposób:

Nazwa pola Sposób wypełnienia
Podmiot2/DaneIdentyfikacyjne NIP 1111111111
Podmiot2 NrKlienta KL/128/202 6
JST 2
GV 2
WAŻNE
W myślach art. 106e ust. 5 pkt 3 ustawy, w tym przypadku, faktura może nie zawierać m.in.
dane źródłowe w art. 106e ust. 1 pkt 3 ustawy dotyczącej nabywców, tj. jego imienia i
nazwy lub adresu. W odniesieniu do danych zakupu jest to
podanie w elemencie Podmiot2 jego numeru ubezpieczenia podatkowego.

W innych fakturach niż wskazane w art. 106e ust. 5 pkt 3 ustawy (gdy kwota
należności na fakturze przekraczającej 450 zł), wystawienie faktury z pominięciem ww. dane,
mimo że jest możliwe, od strony dodatkowej będzie dostępne.

Przykład 3. Sposób wypełnienia Podmiot2 dla FA( 3 )

Stan faktyczny:

Podatnik VAT sprzedał osobie zależnej od działalności. Dane
skupujące: Jan Kowalski (NIP 3333333333), ul. Szara 4b/13, 44 - 444 Katowice. W celu
kontaktu, sprzedawca zawiera numer faktury telefonu kupującego (801055055)
oraz jego adres e-mail (abc@xyz.pl).

Dane dodatkowe uwzględniają w składzie FA( 3 ) w sposób:

Nazwa pola Sposób wypełnienia
Podmiot2/DaneIdentyfikacyjne NIP 3333333333
Nazwa Jan Kowalski
Podmiot2/Adres KodKraju PL
AdresL1 ul. Szara 4b/13, 44-444 Katowice
Podmiot2/DaneKontaktowe Email abc@xyz.pl
Telefon 801055055
Podmiot2 JST 2
GV 2
Przykład 4. Sposób wypełnienia Podmiot2 dla FA( 3 )

Stan faktyczny:

Podatnik VAT sprzedał osobie nieprowadzącej działalności gospodarczej
(konsumentowi). Dane skupu: Anna Nowak, ul. Biała 52a, 11 - 111 Poznań. Sprzedawca
dokonuje płatności płatniczej w KSeF.

Dane dodatkowe uwzględniają w końcu FA(3) w sposobie:

Nazwa pola Sposób wypełnienia
Podmiot2/DaneIdentyfikacyjne BrakID 1
Nazwa Anna Nowak
Podmiot2/Adres KodKraju PL
AdresL1 ul. Biała 52a, 11 - 111 Poznań
Podmiot2 JST 2
GV 2
Przykład 5. Sposób wypełnienia Podmiot2 dla FA( 3 )

Stan faktyczny:

Podatnik VAT sprzedał na rzecz GV o nazwie „XYZ GV” (NIP 99999999999, adres ul.
Fioletowa 5, 77-777 Gdańsk) regulowanyj się ze spółki X, spółki Y oraz spółki Z. Nabycie
jest dostępne na potrzeby spółki X.

Dane dodatkowe uwzględniają w końcu FA(3) w sposobie:

Nazwa pola Sposób wypełnienia
Podmiot2/DaneIdentyfikacyjne NIP 9999999999
Nazwa XYZ GV
Podmiot2/Adres KodKraju PL
AdresL1 ul. Fioletowa 5, 77 - 777 Gdańsk
Podmiot2 JST 2
GV 1
WAŻNE
W przypadku zgłoszenia, gdy nabywca jest GV o nazwie „XYZ GV”, faktura dotyczy
zakupu na korzystanie z GV - spółki X, należy w Podmiot2 wskazane dane GV oraz
„1” w polu GV. Podmiot3 powinien być określony przez spółkę X (w następnym
numerze identyfikacyjnym NIP spółki X), aby otrzymać ją w KSeF powyższą fakturę
ustrukturyzowaną.

Podmiot3 dla FA(3)
Element fakultatywny Podmiot3 zawiera dane umożliwiające współpracę, inne niż
Podmiot1 i Podmiot2, które są związane z fakturą. Celem raportującego
rozwiązania jest kontynuacja działań, pobranie na pokrycie
wskazywaniu na fakturze danych np.:

płatnika lub odbiorcy towaru,
faktora,
Podmiot odrębny (np. spółka przejmowana w ramach działań spółki).
W Podmiot3 można również wskazać dane:

wejście do grupy VAT (jako wystawcy faktury lub odbiorcy),
jednostka podrzędnej JST np. samorządowej jednostki budżetowej podległej JST (jako
wystawcy faktury lub odbiorcy),
zakładu (oddziału) osoby prawnej lub innej wyodrębnionej jednostki wewnętrznej
podatnika, w tym jej unikalnego identyfikatora, wytworzonego w KSeF, zawierającego
numer identyfikacji podatkowej (NIP) podatnika i ciąg znaków numerycznych (pole
IDWew).
Nowym rozwiązaniem, które pojawiło się w strukturze logicznej w wersji FA(3) jest rola 11 -
„Pracownik”. Jej wprowadzenie ma na celu usprawnienie rozliczania tzw. wydatków
pracowniczych (gdy np. pracownik firmy dokonuje zakupu towaru lub usługi w imieniu
swojego pracodawcy). W takim przypadku, poza wskazaniem wartości „11” w polu Rola:

w elemencie DaneIdentyfikacyjne w polu BrakID podaje się „1”, a w polu Nazwa imię
i nazwisko pracownika,
fakultatywnie można wskazać dane adresowe pracownika (element Adres,
AdresKoresp) i jego dane kontaktowe (element DaneKontaktowe, zawierający pola
Email i Telefon).
Element Podmiot3, w strukturze faktury ustrukturyzowanej, może wystąpić maksymalnie
100 razy. W związku z tym możliwe jest wskazanie w jednej fakturze ustrukturyzowanej
danych wielu podmiotów trzecich.

Struktura elementu Podmiot3 dla FA(3)
Schemat 14. Struktura elementu Podmiot3 dla FA( 3 )

Tabela 14. Opis struktury elementu Podmiot3 dla FA( 3 )

Nazwa pola Opis pola
IDNabywcy
Unikalny klucz powiązania danych nabywcy na fakturach
korygujących, w przypadku, gdy dane nabywcy na fakturze
korygującej zmieniły się w stosunku do danych na fakturze
korygowanej [pole fakultatywne]
Maksymalna ilość znaków: 32
Uwaga!
Praktyczne zastosowanie pola IDNabywcy zostało
przedstawione w przykładzie nr 15.
NrEORI Numer EORI podmiotu trzeciego [pole fakultatywne]
Numer EORI jest to numer w Unijnym Systemie Rejestracji i
Identyfikacji Podmiotów Gospodarczych.
DaneIdentyfikacyjne Element zawierający dane identyfikujące podmiot trzeci, m.in.
jego NIP oraz imię i nazwisko lub nazwę
Adres Element zawierający dane dotyczące adresu podmiotu trzeciego
[element fakultatywny]
AdresKoresp Element zawierający dane dotyczące adresu
korespondencyjnego podmiotu trzeciego [element
fakultatywny]
DaneKontaktaktowe
Element zawierający dane kontaktowe podmiotu trzeciego:
adres e-mail oraz numer telefonu [element fakultatywny]
Maksymalna ilość wystąpień: 3
Rola Rola podmiotu trzeciego:
Podaje się:
„1” - Faktor – w przypadku gdy na fakturze występują dane
faktora,
„2” - Odbiorca - w przypadku gdy na fakturze występują dane
jednostek wewnętrznych, oddziałów, wyodrębnionych w
ramach nabywcy, które same nie stanowią nabywcy w
rozumieniu ustawy,
„3” - Podmiot pierwotny - w przypadku gdy na fakturze
występują dane podmiotu będącego w stosunku do podatnika
podmiotem przejętym lub przekształconym, który dokonywał
dostawy lub świadczył usługę (z wyłączeniem przypadków, o
których mowa w art. 106j ust. 2 pkt 3 ustawy, gdy dane te
wykazywane są w części Podmiot1K),
„4” - Dodatkowy nabywca - w przypadku gdy na fakturze
występują dane kolejnych (innych niż wymieniony w części
Podmiot2) nabywców,
„5” - Wystawca faktury - w przypadku gdy na fakturze
występują dane podmiotu wystawiającego fakturę w imieniu
podatnika,
„6” - Dokonujący płatności - w przypadku gdy na fakturze
występują dane podmiotu regulującego zobowiązanie w miejsce
nabywcy,
„7” - JST – wystawca,
„8” - JST – odbiorca,
„9” - Członek GV – wystawca,
„10” - Członek GV – odbiorca,
„11” - Pracownik.
W przypadku wystąpienia na fakturze danych podmiotu
trzeciego, o roli innej niż jedna z wyżej wymienionych, pole Rola
pomija się. W tej sytuacji wypełnia się pola: RolaInna oraz
OpisRoli.
Uwaga!
Rola „5” – wystawca faktury - nie dotyczy:
przypadku, gdy wystawcą faktury jest nabywca
(samofakturowanie),
sytuacji, gdy fakturę wystawia komornik, organ egzekucyjny
lub przedstawiciel podatkowy, którego dane wskazuje się w
elemencie PodmiotUpowazniony, a nie w Podmiot3.
Uwaga!
W przypadku samofakturowania, dane nabywcy należy
uwzględnić w elemencie Podmiot2. Dodatkowo na fakturze
powinna znaleźć się adnotacja „samofakturowanie” (element
Fa/Adnotacje/P_17 – należy wskazać wartość „1”).
Uwaga!
W przypadku wystąpienia jednocześnie dwóch ról tego samego
Podmiotu3 możliwe jest:
dwukrotne wypełnienie elementu Podmiot3 (dla każdej z ról
odrębnie) lub
jednokrotne wypełnienie elementu Podmiot3 i skorzystanie z
pól RolaInna oraz OpisRoli (wskazanie dwóch ról w jednym
opisie).
RolaInna Znacznik inny podmiotu

W przypadku wystąpienia na fakturze danych podmiotu
trzeciego, o roli innej niż możliwa do wyboru w polu Rola,
podaje się wartość „1” w polu RolaInna - inny podmiot.
W przypadku wskazania odpowiedniej roli podmiotu trzeciego w
polu Rola (tj. braku wystąpienia innego podmiotu trzeciego),
pole RolaInna pomija się.
OpisRoli Opis roli innego podmiotu

W przypadku wystąpienia na fakturze danych podmiotu
trzeciego, o roli innej niż możliwa do wyboru w polu Rola,
podaje się opis roli podmiotu trzeciego (dotyczy przypadku, gdy
w polu RolaInna wskazano „1” - inny podmiot).
W przypadku wskazania odpowiedniej roli podmiotu trzeciego w
polu Rola (tj. braku wystąpienia innego podmiotu trzeciego),
pole OpisRoli pomija się.
Oddział udziału dodatkowego właściciela

Podaje się procentowy udział dodatkowego nabywcy. Różnica
pomiędzy wartością 100%, a sumą udziałów dodatkowych
nabywców jest udziałem nabywcy wymienionego w części
Podmiot2. W przypadku niewypełnienia pola przyjmuje się, że
udziały występujących na fakturze nabywców są równe [pole
fakultatywne].
Uwaga!
Udzial może być wskazany wyłącznie w przypadku, gdy pole
Rola przyjmuje wartość „4”.
NrKlienta Numer klienta dla przypadków, których podmiot jest
podmiotem trzecim posługuje się nim w projekcie lub
zamówieniu [pole fakultatywne]

Schemat 15. Struktura elementu DaneIdentyfikacyjne dla Podmiot3

Tabela 15. Opis struktury elementu DaneIdentyfikacyjne dla Podmiot3

Nazwa pola Opis pola
NIP
Identyfikator podatkowy NIP podmiotu trzeciego
Numer, za pomocą którego podmiot trzeci jest
zidentyfikowany na potrzeby podatku.
IDWew
Identyfikator wewnętrzny z NIP
Przez unikalny identyfikator zakładu (oddziału) osoby
prawnej lub innej wyodrębnionej jednostki wewnętrznej
podatnika, rozumie się identyfikator wytworzony w
KSeF, zawierający numer identyfikacji podatkowej (NIP)
podatnika i ciąg znaków numerycznych.
Uwaga!
Identyfikator wewnętrzny można wygenerować
korzystając np. z Aplikacji Podatnika KSeF.
KodUE
Kod (prefiks) nabywcy VAT UE, o którym mowa w art.
106e ust. 1 pkt 24 ustawy oraz w przypadku, o którym
mowa w art. 136 ust. 1 pkt 4 ustawy
NrVatUE Numer identyfikacyjny VAT nabywcy (bez literowego
kodu kraju, który wskazano w polu KodUE)
KodKraju
Kod kraju nadania innego identyfikatora podatkowego
podmiotu trzeciego [pole fakultatywne]
NrID
Inny identyfikator podatkowy podmiotu trzeciego
BrakID
Podmiot trzeci nieposiadający identyfikatora
podatkowego lub podmiot trzeci, którego identyfikator
nie występuje na fakturze
Podaje się „1” w przypadku, gdy podmiot trzeci nie
posiada identyfikatora podatkowego lub gdy
identyfikator podatkowy podmiotu trzeciego nie
występuje na fakturze.
Nazwa Imię i nazwisko lub nazwa podmiotu trzeciego
Maksymalna ilość znaków: 512
Uwaga!
W polu Nazwa można również wskazać nazwę handlową
podmiotu trzeciego.
Schemat 16. Struktura elementu Adres dla Podmiot3

Tabela 16. Opis struktury elementu Adres dla Podmiot3

Nazwa pola Opis pola
KodKraju Kod kraju
AdresL1
Adres podmiotu trzeciego – linia pierwsza
Maksymalna ilość znaków: 512
AdresL2
Adres podmiotu trzeciego – linia druga [pole
fakultatywne]
Maksymalna ilość znaków: 512
GLN Globalny Numer Lokalizacyjny [pole fakultatywne]
GLN jest to numer umożliwiający m.in. zidentyfikowanie
jednostek fizycznych lub funkcjonalnych w obrębie
firmy.
Przykładowo w elemencie Adres dla Podmiot3, numer
GLN może oznaczać fizyczną lokalizację danego obiektu,
(np. budynku siedziby podmiotu trzeciego, piętra,
oddziału firmy).
Schemat 17. Struktura elementu AdresKoresp dla Podmiot3

Tabela 17. Opis struktury elementu AdresKoresp dla Podmiot3

Nazwa pola Opis pola
KodKraju Kod kraju
AdresL1
Adres korespondencyjny podmiotu trzeciego – linia
pierwsza
Maksymalna ilość znaków: 512
AdresL2
Adres korespondencyjny podmiotu trzeciego – linia
druga [pole fakultatywne]
Maksymalna ilość znaków: 512
GLN Globalny Numer Lokalizacyjny [pole fakultatywne]
GLN jest to numer umożliwiający m.in. zidentyfikowanie
jednostek fizycznych lub funkcjonalnych w obrębie
firmy.
Przykładowo w elemencie AdresKoresp dla Podmiot3,
numer GLN może oznaczać fizyczną lokalizację danego
obiektu lub budynku, do którego powinna być
kierowana korespondencja podmiotu trzeciego.
Schemat 18. Struktura elementu DaneKontaktowe dla Podmiot3

Tabela 18. Opis struktury elementu DaneKontaktowe dla Podmiot3

Nazwa pola Opis pola
Email Adres e-mail podmiotu trzeciego (np. abc@xyz.pl) [pole
fakultatywne]
Telefon Numer telefonu podmiotu trzeciego (np. 801055055)
[pole fakultatywne]
Przykład 6. Sposób wykonania Podmiot3 dla FA( 3 )

Stan faktyczny:

Podatnik VAT sprzedaje:

60% udziału w płycie na rzecz firmy AAA Sp. z oo (NIP 9999999999), z
siedzibą w Warszawie (88-888), przy ul. Szarej 10 oraz,
40% udziału w tym ceramicznym na rzecz firmy BBB Sp. z oo (NIP 7777777777) z
siedzibą w Katowicach (99-999), przy ul. Fioletowej 20.
Administrator faktury, ubezpieczenia na fakturze danych dwóch kupujących.

Uwaga!

W przypadku danej sytuacji do ustalenia, dane podmiotu umieści w
elemencie Podmiot2 (tj. firmy AAA Sp. z oo czy firmy BBB Sp. z oo).

W przypadku, gdy w elemencie Podmiot2 bierze dane firmy AAA Sp. z oo, wówczas w
elemencie Podmiot3 Pomiń dane firmy BBB Sp. z oo w pozycjach zawodnika
40 (% udziału w nabywanym pojeździe). Pole udziału ma charakter
fakultatywny, należy jednak przyjąć, że w razie jego niewyjęcia się, że
udziały należące do fakturze posiadaczy są równe.

Element Podmiot3 w analizowanej sytuacji (gdy w elemencie Podmiot2 ujęto dane firmy
AAA Sp. z oo) wypełnia założenia:

Nazwa pola Sposób wypełnienia
Podmiot3/
DaneIdentyfikacyjne
NIP 7777777777
Nazwa BBB Sp. z o.o.
Podmiot3/Adres
KodKraju PL
AdresL1 ul. Fioletowa 20, 99-999 Katowice
Podmiot3
Rola 4
Udzial 40
Gdyby zastosować (wystawca) zastosować w elemencie Podmiot2 dane firmy BBB Sp. z oo,
wówczas w elemencie Podmiot3 zostałby uwzględnione dane firmy AAA Sp. z oo w
pozycjach udzialby 60 (tj. % udziału firmy AAA Sp. z oo w nabywanym
pojeździe).

Przykład 7. Sposób wypełnienia Podmiot3 dla FA( 3 )

Stan faktyczny:

Podatnik VAT sprzedał firmie XXX Sp. z oo Płatnik faktury będzie spółka PPP Sp. z
oo, z siedzibą w Chorzowie (11-111), przy ulicy Niebieskiej 13 (NIP 3333333333).
Sprzedawca otrzymał fakturę za dane podmiotu dokonującego płatności.

Element Podmiot3 w analizowanej sytuacji spełnia założenia:

Nazwa pola Sposób wypełnienia
Podmiot3/
DaneIdentyfikacyjne
NIP 3333333333
Nazwa PPP Sp. z o.o.
Podmiot3/Adres KodKraju PL
AdresL1 ul. Niebieska 13, 11-111 Chorzów
Podmiot3 Rola 6
Przykład 8. Sposób wykonania Podmiot2 i Podmiot3 dla FA( 3 )

Stan faktyczny:

Podatnik VAT wprowadzony do sprzedaży na rzecz gminy Abc (NIP 9999999999, ul. Biała 15,
22 - 222 Abc). Pomimo tego, że podatek VAT jest gminą, to
jest przeznaczone dla jej jednostki budżetowej - Szkoła podstawowa nr 5 (NIP 1111111111, ul.
Żółta 33 , 22 - 222 Abc).

W celu zapewnienia faktury odbiorcy – tj. szkoły podstawowe (w tym także np. pozycja
wskazana przez JST jako przedstawiciel samorządowej jednostki budżetowej), dane
nabywców (gminy) uwzględniają za znaczenie w elemencie Podmiot2, natomiast dane odbiorcy (szkoły
podstawowe) zamieszczają się w elemencie Podmiot3.

Dane wstępne uwzględniają sposób, w jaki:

Nazwa pola Sposób wypełnienia
Podmiot2/
DaneIdentyfikacyjne
NIP 9999999999
Nazwa Gmina Abc
Podmiot2/Adres KodKraju PL
AdresL1 ul. Biała 15, 22-222 Abc
Podmiot2 JST 1
GV 2
WAŻNE
Wskazując dane nabywcy – JST (gminy) w Podmiot2 należy stosować podstawowe o podaniu wartości „ 1 ”
w polu JST, co oznacza, że ​​faktura dotyczy jednostki podrzędnej JST (szkoły podstawowe).

Nazwa pola Sposób wypełnienia
Podmiot3/
DaneIdentyfikacyjne
NIP 1111111111
Nazwa Szkoła Podstawowa nr 5
Podmiot3/Adres
KodKraju PL
AdresL1 ul. Żółta 33, 22-222 Abc
Podmiot3
Rola 8
Przykład 9. Sposób wykonania Podmiot1 i Podmiot3 dla FA( 3 )

Stan faktyczny:

Gmina Abc (NIP 9999999999, ul. Grafitowa 15/9, 77-777 Abc) wzmocniona sprzedaż towarów na
rzecz innej a poprzez swoje dostawy budżetowe – Szkołę Podstawową nr 1 (NIP
3333333333, ul. Zielona 72/13, 11-111 Abc). Na podstawie podatku VAT sprzedawcą jest gmina.
Rozwiązanie to polega na tym, że Podmiot1 może znaleźć się w danych gminach (podatnika w wersji
legalnej). Jednakże, w oparciu o specjalny model uprawnień dla JST,
fakturę za jednostkę podległą gminie – np. szkoła podstawowa (w tym np. osoba
fizyczna wskazana przez JST jako jednostka samorządowa jednostka finansowa),
wtedy zostanie podjęte działanie w elemencie Podmiot3, dane wystawcy – tj.
samorządowej jednostki budżetowej (w tym przypadku szkoły podstawowej).

Dane wstępne uwzględniają sposób, w jaki:

Nazwa pola Sposób wypełnienia
Podmiot1/
DaneIdentyfikacyjne
NIP 9999999999
Nazwa Gmina Abc
Podmiot1/Adres KodKraju PL
AdresL1 ul. Grafitowa 15/9, 77-777 Abc
Nazwa pola Sposób wypełnienia
Podmiot3/
DaneIdentyfikacyjne
NIP 3333333333
Nazwa Szkoła Podstawowa nr 1
Podmiot3/Adres KodKraju PL
AdresL1 ul. Zielona 72/13, 11-111 Abc
Podmiot3 Rola 7
Przykład 10. Sposób wypełnienia Podmiot3 dla FA( 3 )

Stan faktyczny:

Podatnik XXX Sp. z oo (NIP 3333333333, ul. Zielona 5, 22-222 Wrocław) nabył usługę.
Przejęcie dostępu do konta użytkownika przez jej pracownika Jana Kowalskiego, w związku z
objęciem podróży służbowej. W celu rozliczenia i wyprowadzenia wydatku
pracowniczego, na fakturze poza bazą danych w Podmiot2, dostępne
dodatkowe dane podmiotu – w tym przypadku pracownika.

W podsumowaniu sytuacji dane nabywcy – kontroli XXX Sp. z oo wskazuje się w Podmiot2 w
sposób:

Nazwa pola Sposób wypełnienia
Podmiot 2 /
DaneIdentyfikacyjne
NIP 3333333333
Nazwa XXX Sp. z o.o.
Podmiot2/Adres KodKraju PL
AdresL1 Ul. Zielona 5, 22-222 Wrocław
Podmiot2 JST 2
GV 2
Element Podmiot3 podany przez pracownika dane w analizowanej sytuacji wypełnia się
hipotezami:

Nazwa pola Sposób wypełnienia
Podmiot3/
DaneIdentyfikacyjne
BrakID 1
Nazwa Jan Kowalski
Podmiot3 Rola 11
PodmiotUpoważniony dla FA(3)............................................................................................
Element PodmiotUpoważniony ma charakter opcjonalny. to, że zgłoszenie na
fakturze dotyczy podmiotu (przedstawiciela podatkowego,
komornika, organu egzekucyjnego) jest od zaistnienia przesłanego z
treści art. 106c i art. 106d ustawy.

W myślach art. 106c ustawy, faktury dokumentujące dostawę, które są dostarczane w ramach
egzekucji, z tytułem, który znajduje się na liście administracyjnej, umieszczanej w magazynie i na
rzecz kontrolowanej:

1) organy egzekucyjne określone w ustawie z dnia 17 czerwca 1966 r. o postępowaniu
egzekucyjnym w administracji^2 ;
2) komornicy sądowi wykonujący czynności egzekucyjne w rozumieniu przepisów
Kodeksu postępowania cywilnego^3.
Następnie, zgodnie z art. 106e ust. 1 pkt 20 ustawy, faktura zawiera identyfikator i adres
organu egzekucyjnego lub imię i nazwisko komornika sądowego oraz jego adres, aw miejscu
określonym dla urzędu – imię i nazwisko lub dane wymagane a także jego adres.

w tej sytuacji w elemencie Podmiot1 jest dostępny do danych ataku – kontroli,
w elemencie Podmiot2 – danych kupujących, aw elemencie PodmiotUpowazniony – dane
komornika sądowego lub organu egzekucyjnego.

Z kolei w myśl art. 106d ust. 2 ustawy, faktury mogą być dołączone do konta
użytkownika, a także powiązane z nim, trzecia osoba, z jego
członkiem podatkowym, o którym mowa w art. 18a ustawy.

Zgodnie z art. 106e ust. 1 pkt 21 ustawy w odniesieniu do faktury podatkowej, abonent i na rzecz głównej
przez jego przedstawiciela podatkowego faktura zawiera
lub imię i nazwisko i nazwisko podatkowego, adres oraz numer, za pomocą
którego jest określony na podstawie podatku.

(^2) Dz. U. z 2025 r. poz. 132 ze zm.
(^3) Ustawa z dnia 17 listopada 1964 r. Kodeks postępowania cywilnego, Dz. U. z 2024 r. poz. 15 68 ze zm.

Reasumując, w sytuacji w elemencie Podmiot1 wyprowadza się dane wycieka, w elemencie
Podmiot2 – dane zakupuy, aw elemencie PodmiotUpowazniony – dane charakterystycza
podatkowego.

W przypadku wystąpienia elementu PodmiotUpowazniony, wymagany zakres
danych dodaje: element DaneIdentyfikacyjne, element Adres oraz pole RolaPU. W związku
z tym, że faktura jest ustrukturyzowana, konieczne jest wskazanie również identyfikatora
podatkowego NIP podmiotu określonego.

Struktura elementu PodmiotUpowaniony dla FA(3)
Schemat 19. Struktura elementu PodmiotUpowazniony dla FA( 3 )

Tabela 19. Opis struktury elementu PodmiotUpowazniony dla FA( 3 )

Nazwa pola Opis pola
NrEORI Numer EORI podmiotu upoważnionego [pole
fakultatywne]
Numer EORI jest to numer w Unijnym Systemie
Rejestracji i Identyfikacji Podmiotów Gospodarczych.
DaneIdentyfikacyjne Element zawierający dane identyfikacyjne podmiotu
upoważnionego, m.in. NIP, imię i nazwisko lub nazwę
podmiotu upoważnionego
Adres Element zawierający dane dotyczące adresu podmiotu
upoważnionego
AdresKoresp Element zawierający dane dotyczące adresu
korespondencyjnego podmiotu upoważnionego
[element fakultatywny]
DaneKontaktowe
Element zawierający dane kontaktowe podmiotu
upoważnionego: adres e-mail oraz numer telefonu
[element fakultatywny]
Maksymalna ilość wystąpień: 3
RolaPU Rola podmiotu upoważnionego wystawiającego
fakturę
Podaje się:
„1” - Organ egzekucyjny - w przypadku, o którym
mowa w art. 106c pkt 1 ustawy,
„2” - Komornik sądowy - w przypadku, o którym
mowa w art. 106c pkt 2 ustawy,
„3" - Przedstawiciel podatkowy - w przypadku gdy na
fakturze występują dane przedstawiciela
podatkowego, o którym mowa w art. 18a – 18d
ustawy.
Schemat 20. Struktura elementu DaneIdentyfikacyjne dla PodmiotUpowazniony

Tabela 20. Opis struktury elementu DaneIdentyfikacyjne dla PodmiotUpowazniony

Nazwa pola Opis pola
NIP
Identyfikator podatkowy NIP podmiotu upoważnionego
Nazwa
Imię i nazwisko lub nazwa podmiotu upoważnionego
Maksymalna ilość znaków: 512
Schemat 21. Struktura elementu Adres dla PodmiotUpowazniony

Tabela 21. Opis struktury elementu Adres dla PodmiotUpowazniony

Nazwa pola Opis pola
KodKraju Kod kraju
AdresL1
Adres podmiotu upoważnionego – linia pierwsza
Maksymalna ilość znaków: 512
AdresL2
Adres podmiotu upoważnionego – linia druga [pole
fakultatywne]
Maksymalna ilość znaków: 512
GLN
Globalny Numer Lokalizacyjny [pole fakultatywne]
GLN jest to numer umożliwiający m.in. zidentyfikowanie
jednostek fizycznych lub funkcjonalnych w obrębie
firmy.
Przykładowo w elemencie Adres dla
PodmiotUpowazniony, numer GLN może oznaczać
fizyczną lokalizację danego obiektu (np. budynku
siedziby podmiotu upoważnionego, piętra, oddziału
firmy podmiotu upoważnionego).
Schemat 22. Struktura elementu AdresKoresp dla PodmiotUpowazniony

Tabela 22. Opis struktury elementu AdresKoresp dla PodmiotUpowazniony

Nazwa pola Opis pola
KodKraju Kod kraju
AdresL1
Adres korespondencyjny podmiotu upoważnionego –
linia pierwsza
Maksymalna ilość znaków: 512
AdresL2
Adres korespondencyjny podmiotu upoważnionego –
linia druga [pole fakultatywne]
Maksymalna ilość znaków: 512
GLN
Globalny Numer Lokalizacyjny [pole fakultatywne]
GLN jest to numer umożliwiający m.in. zidentyfikowanie
jednostek fizycznych lub funkcjonalnych w obrębie
firmy.
Przykładowo w elemencie AdresKoresp dla
PodmiotUpowazniony, numer GLN może oznaczać
fizyczną lokalizację danego obiektu lub budynku, do
którego powinna być kierowana korespondencja
podmiotu upoważnionego.
Schemat 23. Struktura elementu DaneKontaktowe dla PodmiotUpowazniony

Tabela 23. Opis struktury elementu DaneKontaktowe dla PodmiotUpowazniony

Nazwa pola Opis pola
EmailPU Adres e-mail podmiotu upoważnionego (np.
abc@xyz.pl) [pole fakultatywne]
TelefonPU Numer telefonu podmiotu upoważnionego (np.
801055055 ) [pole fakultatywne]
Przykład 11. Sposób wypełnienia elementu PodmiotUpowazniony dla FA( 3 )

Stan faktyczny:

Komornik sądowy (Jan Kowalski, NIP 5555555555, ul. Szmaragdowa 25, 88-888 Wrocław)
wystawia fakturę dokumentującą dostawę towarów, o której mowa w art. 18 ustawy, z
tytułu której na dłużniku ciąży obowiązek podatkowy. Faktura jest wystawiana przez
komornika w imieniu i na rzecz dłużnika.

W powyższej sytuacji element PodmiotUpowazniony wypełnia się następująco:

Nazwa pola Sposób wypełnienia
PodmiotUpowazniony/
DaneIdentyfikacyjne
NIP 5555555555
Nazwa Jan Kowalski
PodmiotUpowazniony/Adres KodKraju PL
AdresL1 ul. Szmaragdowa 25, 88 - 888 Wrocław
PodmiotUpowazniony RolaPU 2
Fa dla FA(3)
W elemencie Fa pola dotyczące wartości sprzedaży i podatku wypełnia się w walucie, w
której wystawiono fakturę, z wyjątkiem pól dotyczących podatku przeliczonego zgodnie z
przepisami działu VI w związku z art. 106e ust. 11 ustawy.

W przypadku wystawienia faktury korygującej wypełnia się wszystkie pola wg stanu po
korekcie, a pola dotyczące podstaw opodatkowania, podatku oraz należności ogółem
wypełnia się poprzez różnicę.

Struktura elementu Fa dla FA(3)
Schemat 24. Struktura elementu Fa (od pola KodWaluty do pola OkresFa)

Tabela 24. Opis struktury elementu Fa (od pola KodWaluty do pola OkresFa)

Nazwa pola Opis pola
KodWaluty Kod waluty (ISO 4217)
Podaje się kod waluty (ISO 4217).
W przypadku faktury wystawianej w polskiej walucie
należy podać kod waluty: „PLN”.
P_1 Data wystawienia faktury, z zastrzeżeniem art. 106na
ust. 1 ustawy

Podaje się datę wystawienia faktury, o której mowa w
art. 106e ust. 1 pkt 1 ustawy.
Uwaga!
Art. 106na ust. 1 ustawy stanowi, że fakturę
ustrukturyzowaną uznaje się za wystawioną w dniu jej
przesłania do KSeF. Dotyczy to sytuacji gdy data
wystawienia faktury ustrukturyzowanej (w trybie
„online”) wskazana przez podatnika w polu P_1 jest
zgodna z datą przesłania faktury do KSeF.
Przykład:
Podatnik wystawia fakturę w trybie „online”. W polu
P_1 podatnik wskazał 2026- 02 - 01 i fakturę przesłał do
KSeF w tym samym dniu tj. 2026 - 02 - 01. Fakturze został
nadany numer KSeF w dniu 2026- 02 - 02.
Zgodnie z art. 106na ust. 1 ustawy, uznaje się, że faktura
została wystawiona w dniu 1 lutego 2026 r. czyli w dacie
jej przesłania do KSeF.
Istnieje szereg przypadków, w których data wystawienia
faktury, o której mowa w art. 106e ust. 1 pkt 1 ustawy,
wskazana przez podatnika w polu P_1 stanowi formalną
datę wystawienia faktury (kluczową dla weryfikacji
terminowości wystawienia faktury).
Mowa tu jest o:
fakturze wystawionej w trybie „offline24” (art. 106nda
ust. 10 ustawy),
fakturze wystawionej w trybie „online”, gdy data
przesłania faktury do KSeF będzie późniejsza niż data
wystawienia faktury, wskazana przez podatnika w polu
P_1 (art. 106nda ust. 1 6 ustawy),
fakturze wystawionej w trybie „offline” w związku z
niedostępnością KSeF (art. 106nda ust. 10 w związku z
art. 106nh ust. 4 ustawy),
fakturze wystawionej w trybie awaryjnym w związku z
awarią KSeF (art. 106nf ust. 9 ustawy).
Przykład:
Podatnik wystawia fakturę w trybie „offline24”. W polu
P_1 podatnik wskazał 202 6 - 02 - 01 , natomiast fakturę
przesłał do KSeF w kolejnym dniu roboczym 2026 - 02 - 02.
Fakturze został nadany numer KSeF w dniu 2026 - 02 - 02.
Zgodnie z art. 106nda ust. 10 ustawy, uznaje się, że
faktura została wystawiona w dniu 1 lutego 2026 r. czyli
w dacie wskazanej przez podatnika w polu P_1.
Przykład:
Podatnik wystawia fakturę w trybie „online”. W polu
P_1 podatnik wskazał 2026- 02 - 01 i fakturę przesłał do
KSeF dwa dni później tj. 2026 - 02 - 03. Fakturze został
nadany numer KSeF w dniu 2026 - 02 - 0 3.
Zgodnie z art. 106nda ust. 1 6 ustawy (z uwagi na
stosowanie art. 106nda ust. 10 ustawy), uznaje się, że
faktura została wystawiona w dniu 1 lutego 2026 r. czyli
w dacie wskazanej przez podatnika w polu P_1.
Uwaga!
Z perspektywy interfejsu API będzie możliwość
deklaracji trybu „offline”. W przypadku braku takiej
deklaracji system domyślnie zakłada, że jest to tryb
„online”. Z perspektywy systemu wyróżniamy tryb
„online” i tryb „offline”.
W przypadku weryfikacji faktury za pomocą linku
podatnik może zobaczyć tryby „online”/”offline”.
Tryb „offline24” jest w tym wypadku rozpoznawany jako
„offline” dla przypadku gdy data przesłania do KSeF =
data z pola P_1 +1 dzień.
P_1M Miejsce wystawienia faktury [pole fakultatywne]

P_2 Kolejny numer faktury, nadany w ramach jednej lub
więcej serii, który w sposób jednoznaczny identyfikuje
fakturę

Uwaga!
Nie należy utożsamiać kolejnego numeru faktury, o
którym mowa w polu P_2 z numerem identyfikującym
fakturę w KSeF. Są to dwa różne numery.
WZ Numer dokumentu magazynowego WZ (wydanie na
zewnątrz) związanego z fakturą [pole fakultatywne]

Maksymalna ilość wystąpień: 1000
P_6 Data dokonania lub zakończenia dostawy towarów lub
wykonania usługi lub data otrzymania zapłaty, o której
mowa w art. 106b ust. 1 pkt 4 ustawy, o ile taka data
jest określona i różni się od daty wystawienia faktury
Uwaga!
Pole wypełnia się w przypadku, gdy dla wszystkich
pozycji faktury data jest wspólna.
W przypadku, gdy dla poszczególnych pozycji występują
różne daty sprzedaży – wypełnia się pole P_6A.
OkresFa Element zawierający okres, którego dotyczy faktura - w
przypadkach, o których mowa w art. 19a ust. 3 zdanie
pierwsze i ust. 4 oraz ust. 5 pkt 4 ustawy. Element
składa się z pól: P_6_Od oraz P_6_Do.
Schemat 25. Struktura elementu OkresFa dla Fa

Tabela 25. Opis struktury elementu OkresFa dla Fa

Nazwa pola Opis pola
P_6_Od Data początkowa okresu, którego dotyczy faktura
Podaje się datę w formacie RRRR-MM-DD (np.: 202 6 - 02 -
01 ).
P_6_Do Data końcowa okresu, którego dotyczy faktura - data
dokonania lub zakończenia dostawy towarów lub
wykonania usługi
Podaje się datę w formacie RRRR-MM-DD (np.: 202 6 - 02 -
28 ).
Schemat 26. Struktura elementu Fa (od pola P_13_1 do pola P_14_5)

Tabela 26. Opis struktury elementu Fa (od pola P_13_1 do pola P_14_5)

Nazwa pola Opis pola
P_13_1
Suma wartości sprzedaży netto objętej stawką
podstawową - aktualnie 23% albo 22%. W przypadku
faktur zaliczkowych - wartość zaliczki netto. W
przypadku faktur korygujących - kwota różnicy, o której
mowa w art. 106j ust. 2 pkt 5 ustawy
Sekwencję złożoną z pól P_13_1, P_14_1 oraz P_14_1W
wypełnia się w przypadku wystąpienia na fakturze
sprzedaży objętej stawką podstawową - aktualnie 23%
albo 22%. Sekwencja nie dotyczy procedury marży.
P_14_1
Kwota podatku od sumy wartości sprzedaży netto
objętej stawką podstawową - aktualnie 23% albo 22%.
W przypadku faktur zaliczkowych - kwota podatku
wyliczona według wzoru, o którym mowa w art. 106f
ust. 1 pkt 3 ustawy. W przypadku faktur korygujących -
kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5
ustawy
Sekwencję złożoną z pól P_13_1, P_14_1 oraz P_14_1W
wypełnia się w przypadku wystąpienia na fakturze
sprzedaży objętej stawką podstawową - aktualnie 23%
albo 22%. Sekwencja nie dotyczy procedury marży.
P_14_1W
W przypadku, gdy faktura jest wystawiona w walucie
obcej - kwota podatku od sumy wartości sprzedaży
netto objętej stawką podstawową, przeliczona zgodnie z
przepisami działu VI w związku z art. 106e ust. 11
ustawy - aktualnie 23% albo 22%. W przypadku faktur
zaliczkowych - kwota podatku wyliczona według wzoru,
o którym mowa w art. 106f ust. 1 pkt 3 ustawy. W
przypadku faktur korygujących - kwota różnicy, o której
mowa w art. 106j ust. 2 pkt 5 ustawy [pole opcjonalne]
Sekwencję złożoną z pól P_13_1, P_14_1 oraz P_14_1W
wypełnia się w przypadku wystąpienia na fakturze
sprzedaży objętej stawką podstawową - aktualnie 23%
albo 22%. Sekwencja nie dotyczy procedury marży.
P_13_2
Suma wartości sprzedaży netto objętej stawką obniżoną
pierwszą - aktualnie 8% albo 7%. W przypadku faktur
zaliczkowych - wartość zaliczki netto. W przypadku
faktur korygujących - kwota różnicy, o której mowa w
art. 106j ust. 2 pkt 5 ustawy
Sekwencję złożoną z pól P_13_2, P_14_2 oraz P_14_2W
wypełnia się w przypadku wystąpienia na fakturze
sprzedaży objętej stawką obniżoną pierwszą - aktualnie
8 % albo 7%. Sekwencja nie dotyczy procedury marży.
P_14_2
Kwota podatku od sumy wartości sprzedaży netto
objętej stawką obniżoną pierwszą - aktualnie 8% albo
7%. W przypadku faktur zaliczkowych - kwota podatku
wyliczona według wzoru, o którym mowa w art. 106f
ust. 1 pkt 3 ustawy. W przypadku faktur korygujących -
kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5
ustawy
Sekwencję złożoną z pól P_13_2, P_14_2 oraz P_14_2W
wypełnia się w przypadku wystąpienia na fakturze
sprzedaży objętej stawką obniżoną pierwszą - aktualnie
8 % albo 7%. Sekwencja nie dotyczy procedury marży.
P_14_2W
W przypadku, gdy faktura jest wystawiona w walucie
obcej - kwota podatku od sumy wartości sprzedaży
netto objętej stawką obniżoną pierwszą, przeliczona
zgodnie z przepisami działu VI w związku z art. 106e ust.
11 ustawy - aktualnie 8% albo 7%. W przypadku faktur
zaliczkowych - kwota podatku wyliczona według wzoru,
o którym mowa w art. 106f ust. 1 pkt 3 ustawy. W
przypadku faktur korygujących - kwota różnicy, o której
mowa w art. 106j ust. 2 pkt 5 ustawy [pole opcjonalne]
Sekwencję złożoną z pól P_13_2, P_14_2 oraz P_14_2W
wypełnia się w przypadku wystąpienia na fakturze
sprzedaży objętej stawką obniżoną pierwszą - aktualnie
8 % albo 7%. Sekwencja nie dotyczy procedury marży.
P_13_3
Suma wartości sprzedaży netto objętej stawką obniżoną
drugą - aktualnie 5%. W przypadku faktur zaliczkowych -
wartość zaliczki netto. W przypadku faktur korygujących
kwota, o której mowa w art. 106j ust. 2 pkt 5
ustawy
Sekwencję złożoną z pól P_13_3, P_14_3 oraz P_14_3W
wypełnia się w przypadku wystąpienia na fakturze
sprzedaży objętej stawką obniżoną drugą - aktualnie 5%.
Sekwencja nie dotyczy procedury marży.
P_14_3
Kwota podatku od sumy wartości sprzedaży netto
podlegającej stawce niższej drugiej - aktualnej 5%. W
przypadku faktury zaliczkowej - kwota podatku
wyliczona według, o której mowa w art. 106f
ust. 1 pkt 3 ustawy. W przypadku faktury korygującej -
kwoty drobnej, o której mowa w art. 106j ust. 2 pkt 5
ustawy

Sekwencję złożoną z pól P_13_3, P_14_3 oraz P_14_3W
wypełnia się w przypadku wystąpienia na fakturze
sprzedaży objętej stawką obniżoną drugą - aktualnie 5%.
Sekwencja nie dotyczy procedury marży.
P_14_3W
W przypadku, gdy faktura jest wystawiona w walucie
obcej - kwota podatku od sumy wartości sprzedaży
netto, o której mowa
w art. 106e ust.
11 ustawy - aktualne 5%. W przypadku faktury
zaliczkowej - kwota podatku wyliczona według,
o której mowa w art. 106f ust. 1 pkt 3 ustawy. W
przypadku faktury korygującej - kwoty drobnej, o której
mowa w art. 106j ust. 2 pkt 5 ustawy [pole odrębne]

Sekwencję złożoną z pól P_13_3, P_14_3 oraz P_14_3W
wypełnia się w przypadku wystąpienia na fakturze
sprzedaży objętej stawką obniżoną drugą - aktualnie 5%.
Sekwencja nie dotyczy procedury marży.
P_13_4
Suma wartości sprzedaży netto objętej ryczałtem dla
taksówek osobowych. W przypadku faktur zaliczkowych
wartość zaliczki netto. W przypadku faktury
korygującej - kwoty drobnej, o której mowa w art. 106j
ust. 2 pkt 5 ustawy
Sekwencję złożoną z pól P_13_4, P_14_4 oraz P_14_4W
wypełnia się w przypadku wystąpienia na fakturze
sprzedaży objętej stawką obniżoną trzecią – ryczałtem
dla taksówek osobowych.
P_14_4
Kwota podatku od sumy wartości sprzedaży netto w
przypadku ryczałtu dla taksówek osobowych. W
przypadku faktur zaliczkowych - kwota podatku
wyliczona według wzoru, o którym mowa w art. 106f
ust. 1 pkt 3 ustawy. W przypadku faktur korygujących -
kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5
ustawy
Sekwencję złożoną z pól P_13_4, P_14_4 oraz P_14_4W
wypełnia się w przypadku wystąpienia na fakturze
sprzedaży objętej stawką obniżoną trzecią – ryczałtem
dla taksówek osobowych.
P_14_4W
W przypadku, gdy faktura jest wystawiona w walucie
obcej – wysokość ryczałtu dla taksówek osobowych,
przeliczona zgodnie z przepisami działu VI w związku z
art. 106e ust. 11 ustawy. W przypadku faktur
zaliczkowych - kwota podatku wyliczona według wzoru,
o którym mowa w art. 106f ust. 1 pkt 3 ustawy. W
przypadku faktur korygujących - kwota różnicy, o której
mowa w art. 106j ust. 2 pkt 5 ustawy [pole opcjonalne]
Sekwencję złożoną z pól P_13_4, P_14_4 oraz P_14_4W
wypełnia się w przypadku wystąpienia na fakturze
sprzedaży objętej stawką obniżoną trzecią – ryczałtem
dla taksówek osobowych.
P_13_5
Suma wartości sprzedaży netto w przypadku procedury
szczególnej, o której mowa w dziale XII w rozdziale 6a
ustawy. W przypadku faktur zaliczkowych – wartość
zaliczki netto. W przypadku faktur korygujących - kwota
różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy
Sekwencję złożoną z pól P_13_5 oraz P_14_5 wypełnia
się w przypadku wystąpienia na fakturze sprzedaży w
procedurze szczególnej, o której mowa w dziale XII w
rozdziale 6a ustawy.
P_14_5
Kwota podatku od wartości dodanej w przypadku
procedury szczególnej, o której mowa w dziale XII w
rozdziale 6a ustawy. W przypadku faktur zaliczkowych -
kwota podatku wyliczona według wzoru, o którym
mowa w art. 106f ust. 1 pkt 3 ustawy. W przypadku
faktur korygujących - kwota różnicy, o której mowa w
art. 106j ust. 2 pkt 5 ustawy [pole opcjonalne]
Sekwencję złożoną z pól P_13_5 oraz P_14_5 wypełnia
się w przypadku wystąpienia na fakturze sprzedaży w
procedurze szczególnej, o której mowa w dziale XII w
rozdziale 6a ustawy.
Schemat 27. Struktura elementu Fa (od pola P_13_6_1 do pola P_15)

Tabela 27. Opis struktury elementu Fa (od pola P_13_6_1 do pola P_15)

Nazwa pola Opis pola
P_13_6_1 Suma wartości sprzedaży objętej stawką 0% z
wyłączeniem wewnątrzwspólnotowej dostawy towarów
i eksportu. W przypadku faktur zaliczkowych - wartość
zaliczki. W przypadku faktur korygujących - kwota
różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy
[pole opcjonalne]
Przykładowo w polu P_13_6_1 ujmuje się m.in. sumę
wartości sprzedaży objętej stawką 0% na podstawie art.
83 ust. 1 ustawy.
P_13_6_2 Suma wartości sprzedaży objętej stawką 0% w
przypadku wewnątrzwspólnotowej dostawy towarów.
W przypadku faktur korygujących - kwota różnicy, o
której mowa w art. 106j ust. 2 pkt 5 ustawy [pole
opcjonalne]
P_13_6_3 Suma wartości sprzedaży objętej stawką 0% w
przypadku eksportu. W przypadku faktur zaliczkowych -
wartość zaliczki. W przypadku faktur korygujących -
kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5
ustawy [pole opcjonalne]
P_13_7 Suma wartości sprzedaży zwolnionej od podatku. W
przypadku faktur zaliczkowych - wartość zaliczki. W
przypadku faktur korygujących - kwota różnicy wartości
sprzedaży [pole opcjonalne]
P_13_8 Suma wartości sprzedaży w przypadku dostawy
towarów oraz świadczenia usług poza terytorium kraju,
z wyłączeniem kwot wykazanych w polach P_13_5 i
P_13_9. W przypadku faktur zaliczkowych - wartość
zaliczki. W przypadku faktur korygujących - kwota
różnicy wartości sprzedaży [pole opcjonalne]
Przykład:
W polu P_13_ 8 ujmuje się m.in. sumę wartości
świadczenia usług poza terytorium kraju w przypadku,
gdy miejsce opodatkowania ustala się na podstawie art.
28e ustawy i transakcja nie podlega rozliczeniu w
ramach procedury unijnej OSS.
P_13_9 Suma wartości świadczenia usług, o których mowa w
art. 100 ust. 1 pkt 4 ustawy. W przypadku faktur
zaliczkowych - wartość zaliczki. W przypadku faktur
korygujących - kwota różnicy wartości sprzedaży [pole
opcjonalne]
P_13_10 Suma wartości sprzedaży w procedurze odwrotnego
obciążenia, dla której podatnikiem jest nabywca zgodnie
z uchylonym art. 17 ust. 1 pkt 7 i 8 ustawy oraz innych
przypadków odwrotnego obciążenia występujących w
obrocie krajowym. W przypadku faktur zaliczkowych -
wartość zaliczki. W przypadku faktur korygujących -
kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5
ustawy [pole opcjonalne]
Przykład:
W polu P_13_ 10 ujmuje się m. in. sumę wartości
sprzedaży w procedurze odwrotnego obciążenia
występującego w obrocie krajowym na podstawie
przepisu epizodycznego - art. 145e ust. 1 ustawy.
P_13_11 Suma wartości sprzedaży w procedurze marży, o której
mowa w art. 119 i art. 120 ustawy. W przypadku faktur
zaliczkowych - wartość zaliczki. W przypadku faktur
korygujących - kwota różnicy wartości sprzedaży [pole
opcjonalne]
P_15 Kwota należności ogółem. W przypadku faktur
zaliczkowych - kwota zapłaty dokumentowana fakturą.
W przypadku faktur, o których mowa w art. 106f ust. 3
ustawy - kwota pozostała do zapłaty. W przypadku
faktur korygujących - korekta kwoty wynikającej z
faktury korygowanej. W przypadku, o którym mowa w
art. 106j ust. 3 ustawy - korekta kwot wynikających z
faktur korygowanych
Schemat 28. Struktura elementu Fa (pola od KursWalutyZ do pola RodzajFaktury)

Tabela 28. Opis struktury elementu Fa (pola od KursWalutyZ do pola RodzajFaktury)

Nazwa pola
Opis pola
KursWalutyZ Kurs waluty stosowany do wyliczenia kwoty podatku w
przypadkach, o których mowa w dziale VI ustawy na
fakturach, o których mowa w art. 106b ust. 1 pkt 4
ustawy [pole fakultatywne]
Adnotacje
Adnotacje na fakturze
Element zawierający adnotacje na fakturze wynikające
ze specyfiki danej transakcji (np. odwrotne obciążenie,
samofakturowanie, podstawa prawna zastosowanego
zwolnienia itp.)
RodzajFaktury
Rodzaj faktury
Podaje się:
„VAT” – w przypadku faktury podstawowej,
„KOR” – w przypadku faktury korygującej,
„ZAL” - w przypadku faktury dokumentującej
otrzymanie zapłaty lub jej części przed wykonaniem
czynności oraz w przypadku faktury wystawionej w
związku z art. 106f ust. 4 ustawy (faktura zaliczkowa),
„ROZ” – w przypadku faktury wystawionej w związku z
art. 106f ust. 3 ustawy,
„UPR” – w przypadku faktury, o której mowa w art.
106e ust. 5 pkt 3 ustawy,
„KOR_ZAL” - w przypadku faktury korygującej faktury
dokumentującej otrzymanie zapłaty lub jej część przedniem
czynności oraz fakturę wystawioną w
związku z art. 106f ust. 4 ustawy (faktura korygująca
fakturę zaliczkową),
„KOR_ROZ” – w przypadku faktury korygującej fakturę
wystawioną w związku z art. 106f ust. 3 ustawy.
Uwaga!
W przypadku wystawienia faktury korygującej do
faktury uproszczonej, o której mowa w art. 106e ust. 5
pkt 3 ustawy należy wskazać „KOR”.
Uwaga!
Z dniem 1 września 2023 r. wszedł w życie art. 106b ust.
1a ustawy, w myśl którego podatnik nie jest obowiązany
do wystawienia faktury, o której mowa w art. 106b ust.
1 pkt 4 ustawy, jeżeli całość lub część zapłaty, o której
mowa w tym przepisie, otrzymał w tym samym
miesiącu, w którym dokonał czynności, na poczet
których otrzymał całość lub część tej zapłaty.
W przypadku niewystawienia przez podatnika faktury, o
której mowa w art. 106b ust. 1 pkt 4 ustawy, z
powodów określonych w art. 106b ust. 1a, wystawiona
przez podatnika po wydaniu towaru lub wykonaniu
usługi faktura, zawierająca dodatkowo elementy
wskazane w art. 106e ust. 1a ustawy, powinna posiadać
oznaczenie „ROZ”.
Schemat 29. Struktura elementu Adnotacje dla Fa

Tabela 29. Opis struktury elementu Adnotacje dla Fa

Nazwa pola Opis pola
P_16 Adnotacja „metoda kasowa”
W przypadku faktury zawierającej adnotację „metoda
kasowa”, dokumentującej dostawę towarów lub
świadczenie usług, w odniesieniu do których obowiązek
podatkowy powstaje zgodnie z art. 19a ust. 5 pkt 1 lub
art. 21 ust. 1 ustawy - należy podać wartość „1"; w
przeciwnym przypadku - wartość „2".
P_17 Adnotacja „samofakturowanie”
W przypadku faktury, o której mowa w art. 106d ust. 1
ustawy, zawierającej adnotację „samofakturowanie” -
należy podać wartość „1"; w przeciwnym przypadku -
wartość „2".
Uwaga!
Procedura zatwierdzania poszczególnych faktur
(wystawianych przez nabywcę w ramach
samofakturowania) przez podatnika dokonującego
czynności opodatkowanej, odbywa się poza KSeF.
Uwaga!
W przypadku samofakturowania, tj. gdy fakturę
wystawia nabywca, w elemencie Podmiot1 powinny
znaleźć się dane sprzedawcy, a w elemencie Podmiot2
dane nabywcy. Nie należy wypełniać elementu
Podmiot3 danymi nabywcy w roli „5” - wystawiający
fakturę.
P_18 Adnotacja „odwrotne obciążenie”

W przypadku faktury zawierającej adnotację „odwrotne
obciążenie”, dokumentującej dostawę towarów lub
wykonanie usługi, dla których obowiązanym do
rozliczenia podatku od wartości dodanej lub podatku o
podobnym charakterze jest nabywca towaru lub usługi -
należy podać wartość „1"; w przeciwnym przypadku -
wartość „2".
Uwaga!
Pole P_18 dotyczy także przypadków odwrotnego
obciążenia w obrocie krajowym:
w oparciu o art. 145e ustawy, w nawiązaniu do
którego (zgodnie z art. 145g pkt 2 ustawy), faktura
dokumentująca ww. konieczne, zawierają
wyrazy, o których mowa w art. 106e ust. 1 pkt 18
ustawy tj. adnotacja „odwrotne obciążenie
w oparciu o art. 17 ust. 1 pkt 7 lub pkt 8 ustawy,
(obowiązujący przed 1 listopada 2019 r.).
P_18A Adnotacja „mechanizm podzielonej płatności”

W przypadku faktury zawierającej adnotację
„mechanizm podzielonej płatności”, w której kwota
należności ogółem przekracza kwotę 15.000 zł lub jej
równowartość wyrażoną w walucie obcej, obejmującej
dokonaną na rzecz podatnika dostawę towarów lub
świadczenie usług wymienionych w załączniku nr 15 do
ustawy, przy czym do przeliczania na złote kwot
wyrażonych w walucie obcej stosuje się zasady
przeliczania kwot stosowane w celu określenia
podstawy opodatkowania - należy podać wartość „1"; w
przeciwnym przypadku - wartość „2”.
Zwolnienie
Element zawierający dane dotyczące wystąpienia lub
braku wystąpienia na fakturze sprzedaży zwolnionej
oraz podstawy prawnej zastosowanego zwolnienia od
podatku
NoweSrodkiTransportu
Element zawierający dane dotyczące wystąpienia lub
braku wystąpienia na fakturze wewnątrzwspólnotowej
dostawy nowych środków transportu oraz dane
szczegółowe charakteryzujące ww. nowe środki
transportu
P_23
Adnotacja "VAT: Faktura WE uproszczona na mocy art.
135 - 138 ustawy o ptu" lub "VAT: Faktura WE
uproszczona na mocy artykułu 141 dyrektywy
2006/112/WE" i stwierdzenie, że podatek z tytułu
dokonanej dostawy zostanie rozliczony przez ostatniego
w kolejności podatnika podatku od wartości dodanej
W przypadku faktury wystawianej w procedurze
uproszczonej przez drugiego w kolejności podatnika, o
którym mowa w art. 135 ust. 1 pkt 4 lit. b i c oraz ust. 2
ustawy, zawierającej adnotację, o której mowa w art.
136 ust. 1 pkt 1 ustawy i stwierdzenie, o którym mowa
w art. 136 ust. 1 pkt 2 ustawy - należy podać wartość
„1”; w przeciwnym przypadku - wartość „2”.
PMarzy
Element zawierający dane dotyczące wystąpienia na
fakturze procedury VAT marża oraz adnotacje
odnoszące się do ww. procedury
Schemat 30. Struktura elementu Zwolnienie dla Adnotacji

Tabela 30. Opis struktury elementu Zwolnienie dla Adnotacji

Nazwa pola
Opis pola
P_19 Znacznik dostawy towarów lub świadczenia usług
zwolnionych od podatku na podstawie art. 43 ust. 1
ustawy, art. 113 ust. 1 i 9 ustawy albo przepisów
wydanych na podstawie art. 82 ust. 3 ustawy lub na
podstawie innych przepisów
W przypadku faktury dokumentującej dostawę towarów
lub świadczenie usług zwolnionych od podatku na
podstawie art. 43 ust. 1 ustawy, art. 113 ust. 1 i 9
ustawy albo przepisów wydanych na podstawie art. 82
ust. 3 ustawy lub na podstawie innych przepisów -
należy podać wartość „1”.
W przypadku, gdy pole P_19 równa się „1”, należy
wypełnić dodatkowo jedno z pól: P_19A, P_19B lub
P_19C.
P_19A Jeśli pole P_19 równa się „1" - należy wskazać przepis
ustawy albo aktu wydanego na podstawie ustawy, na
podstawie którego podatnik stosuje zwolnienie od
podatku.
Przykład: „Art. 43 ust. 1 pkt 37 ustawy o podatku od
towarów i usług (Dz. U. z 2024 poz. 361 ze zm.)”
P_19B Jeśli pole P_19 równa się „1" - należy wskazać przepis
dyrektywy 2006/112/WE, który zwalnia od podatku taką
dostawę towarów lub takie świadczenie usług.
P_19C Jeśli pole P_19 równa się „1" - należy wskazać inną
podstawę prawną wskazującą na to, że dostawa
towarów lub świadczenie usług korzysta ze zwolnienia
od podatku.
P_19N Znacznik braku dostawy towarów lub świadczenia usług
zwolnionych od podatku na podstawie art. 43 ust. 1, art.
113 ust. 1 i 9 ustawy albo przepisów wydanych na
podstawie art. 82 ust. 3 ustawy lub na podstawie innych
przepisów
W przypadku faktury, która nie dokumentuje dostawy
towarów lub świadczenia usług zwolnionych od podatku
na podstawie art. 43 ust. 1, art. 113 ust. 1 i 9 ustawy
albo przepisów wydanych na podstawie art. 82 ust. 3
ustawy lub na podstawie innych przepisów, należy
podać wartość „1”.
W przypadku, gdy pole P_19N równa się „1”, pola: P_19,
P_19A, P_19B, P_19C pomija się.
Schemat 31. Struktura elementu NoweSrodkiTransportu dla Adnotacji

Tabela 31. Opis struktury elementu NoweŚrodkiTransportu dla Adnotacji

Nazwa pola
Opis pola
P_22 Znacznik wewnątrzwspólnotowej dostawy nowych
środków transportu
W przypadku faktury dokumentującej dostawę nowych
środków transportu, należy podać wartość „1”.
P_42_5 Jeśli występuje obowiązek, o którym mowa w art. 42
ust. 5 ustawy, należy podać wartość „1", w przeciwnym
przypadku należy podać wartość „2".
NowySrodekTransportu
Element zawierający dane dotyczące nowego środka
transportu, którego sprzedaż jest dokumentowana
fakturą
Maksymalna ilość wystąpień: 10 000.
P_22N Znacznik braku wewnątrzwspólnotowej dostawy
nowych środków transportu
W przypadku faktury, która nie dokumentuje
wewnątrzwspólnotowej dostawy nowych środków
transportu, należy podać wartość „1”.
W przypadku, gdy pole P_22N równa się „1”, pola: P_22,
P_42_5 oraz NowySrodekTransportu pomija się.
Schemat 32. Struktura elementu NowySrodekTransportu dla NoweSrodkiTransportu

Tabela 32. Opis struktury elementu NowySrodekTransportu dla NoweSrodkiTransportu

Nazwa pola Opis pola
P_22A Jeśli pole P_22 równa się „1” - należy podać datę
dopuszczenia nowego środka transportu do użytku w
formacie RRRR-MM-DD (np.: 202 6 - 02 - 22).
Za moment dopuszczenia do użytku pojazdu lądowego
uznaje się dzień, w którym został on pierwszy raz
zarejestrowany w celu dopuszczenia do ruchu
drogowego lub w którym po raz pierwszy podlegał on
obowiązkowi rejestracji w celu dopuszczenia do ruchu
drogowego w zależności od tego, która z tych dat jest
wcześniejsza; jeżeli nie można ustalić dnia pierwszej
rejestracji pojazdu lądowego lub dnia, w którym
podlegał on pierwszej rejestracji, za moment
dopuszczenia do użytku tego pojazdu uznaje się dzień, w
którym został on wydany przez producenta pierwszemu
nabywcy, lub dzień, w którym został po raz pierwszy
użyty dla celów demonstracyjnych przez producenta.
Za moment dopuszczenia do użytku jednostki pływającej
uznaje się dzień, w którym została ona wydana przez
producenta pierwszemu nabywcy, lub dzień, w którym
została po raz pierwszy użyta dla celów
demonstracyjnych przez producenta.
Za moment dopuszczenia do użytku statku
powietrznego uznaje się dzień, w którym został on
wydany przez producenta pierwszemu nabywcy, lub
dzień, w którym został po raz pierwszy użyty dla celów
demonstracyjnych przez producenta.
P_NrWierszaNST
Numer wiersza faktury, który zawiera dostawę
nowego środka transportu

P_22BMK Marka nowego środka transportu [pole fakultatywne]

Jeśli pole P_22 równa się „1”, można podać markę
nowego środka transportu.
P_22BMD Model nowego środkowego transportu [pole fakultatywne]

Jeśli pole P_22 równa się „1”, można podać model
nowego środka transportu.
P_22BK Kolor nowego środka transportu [pole fakultatywne]

Jeśli pole P_22 równa się „1”, można podać kolor
nowego środka transportu.
P_22BNR Numer rejestracyjny nowego środka transportu [pole
fakultatywne]

Jeśli pole P_22 równa się „1”, można podać numer
rejestracyjny nowego środka transportu.
P_22BRP Rok produkcji nowego środka transportu [pole
fakultatywne]

Jeśli pole P_22 równa się „1”, można podać rok
produkcji nowego środka transportu.
P_22B Jeżeli pole P_22 równa się „1”, a dostawa dotyczy
pojazdów lądowych, o których mowa w art. 2 pkt 10 lit.
a ustawa - należy wziąć pod uwagę przebieg jazdy.

P_22B1 Jeżeli pole P_22 równa się „1”, to dostawa dotyczy
pojazdów lądowych, o których mowa w art. 2 pkt 10 lit.
a ustawy, można zastosować numer VIN [pole fakultatywne].

Uwaga!
Pola P_22B1, P_22B2, P_22B3 oraz P_22B4 wchodzą w
skład sekwencji typu „wybór”, co oznacza, że można
wypełnić tylko jedno pole spośród ww. pól.
P_22B2 Jeżeli pole P_22 równa się „1”, to dostawa dotyczy
pojazdów lądowych, o których mowa w art. 2 pkt 10 lit.
a ustawy, można zastosować numer ubezpieczenia [pole
fakultatywne].

Uwaga!
Pola P_22B1, P_22B2, P_22B3 oraz P_22B4 wchodzą w
skład sekwencji typu „wybór”, co oznacza, że można
wypełnić tylko jedno pole spośród ww. pól.
P_22B3 Jeżeli pole P_22 równa się „1”, a dostawa dotyczy
pojazdów lądowych, o których mowa w art. 2 pkt 10 lit.
a ustawy, można zastosować numer podwozia [pole
fakultatywne].

Uwaga!
Pola P_22B1, P_22B2, P_22B3 oraz P_22B4 wchodzą w
skład sekwencji typu „wybór”, co oznacza, że można
wypełnić tylko jedno pole spośród ww. pól.
P_22B4 Jeżeli pole P_22 równa się „1”, a dostawa dotyczy
pojazdów lądowych, o których mowa w art. 2 pkt 10 lit.
a ustawy, można zastosować numer ramy [pole
fakultatywne].

Uwaga!
Pola P_22B1, P_22B2, P_22B3 oraz P_22B4 wchodzą w
skład sekwencji typu „wybór”, co oznacza, że można
wypełnić tylko jedno pole spośród ww. pól.
P_22BT Jeżeli pole P_22 równa się „1”, a dostawa dotyczy
pojazdów lądowych, o których mowa w art. 2 pkt 10 lit.
a ustawy, można zastosować typ nowego środka transportu
[pole fakultatywne].

P_22C Jeśli pole P_22 równa się „1” a dostawa dotyczy
jednostek pływających, o których mowa w art. 2 pkt 10
lit. b ustawy, należy podać liczbę godzin roboczych
używania nowego środka transportu.
P_22C1 Jeśli pole P_22 równa się „1” a dostawa dotyczy
jednostek pływających, o których mowa w art. 2 pkt 10
lit. b ustawy, można podać numer kadłuba nowego
środka transportu [pole fakultatywne].
P_22D Jeśli pole P_22 równa się „1” a dostawa dotyczy statków
powietrznych, o których mowa w art. 2 pkt 10 lit. c
ustawy, należy podać liczbę godzin roboczych używania
nowego środka transportu.
P_22D1 Jeśli pole P_22 równa się „1” a dostawa dotyczy statków
powietrznych, o których mowa w art. 2 pkt 10 lit. c
ustawy, można podać numer fabryczny nowego środka
transportu [pole fakultatywne].
Schemat 33. Struktura elementu PMarzy dla Adnotacji

Tabela 33. Struktura elementu PMarzy dla Adnotacji

Nazwa pola Opis pola
P_PMarzy Znacznik wystąpienia procedur marży, o których mowa
w art. 119 lub art. 120 ustawy
W przypadku faktury dokumentującej dostawę towarów
lub świadczenie usług opodatkowane w procedurze
marży, o której mowa w art. 119 lub art. 120 ustawy,
należy podać wartość „1”.
W przypadku, gdy pole P_PMarzy równa się „1”, należy
wypełnić dodatkowo jedno z pól: P_PMarzy_2,
P_PMarzy_3_1, P_PMarzy_3_2, P_PMarzy_3_3.
P_PMarzy_2 Znacznik „procedura marży dla biura podróży”

W przypadku świadczenia usług turystyki, dla których
podstawę opodatkowania stanowi marża, zgodnie z art.
119 ust. 1 ustawy, a faktura dokumentująca świadczenie
zawiera wyrazy "procedura marży dla biur podróży",
należy podać wartość „1”.
Uwaga!
W przypadku wskazania „1” w polu P_PMarzy_2
(znajdującej się w sekwencji typu „wybór”) pola:
P_PMarzy_3_1, P_PMarzy_3_2, P_PMarzy_3_3 pomija
się.
P_PMarzy_3_1 Znacznik „procedura marży - importer”

W przypadku dostawy towarów używanych, dla których
podstawę opodatkowania stanowi marża, zgodnie z art.
120 ustawy, a faktura dokumentująca dostawę zawiera
wyrazy "procedura marży - towary używane", należy
podać wartość „1”.
Uwaga!
W przypadku wskazania „1” w polu P_PMarzy_3_1
(znajdującej się w sekwencji typu „wybór”) pola:
P_PMarzy_2, P_PMarzy_3_2, P_PMarzy_3_3 pomija się.
P_PMarzy_3_2 Znacznik „procedura marży - dzieło sztuki”

W przypadku dostawy dzieł sztuki, dla których podstawę
opodatkowania stanowi marża, zgodnie z art. 120
ustawy, a faktura dokumentująca dostawę zawiera
wyrazy "procedura marży - dzieła sztuki", należy podać
wartość „1”.
Uwaga!
W przypadku wskazania „1” w polu P_PMarzy_3_2
(znajdującej się w sekwencji typu „wybór”) pola:
P_PMarzy_2, P_PMarzy_3_1, P_PMarzy_3_3 pomija się.
P_PMarzy_3_3 Znacznik „procedura marży - przedmioty kolekcjonerskie
i antyki”

W przypadku dostawy przedmiotów kolekcjonerskich i
antyków, dla których podstawę opodatkowania stanowi
marża, zgodnie z art. 120 ustawy, a faktura
dokumentująca dostawę zawiera wyrazy "procedura
marży - przedmioty kolekcjonerskie i antyki", należy
podać wartość „1”.
Uwaga!
W przypadku wskazania „1” w polu P_PMarzy_3_3
(znajdującej się w sekwencji typu „wybór”) pola:
P_PMarzy_2, P_PMarzy_3_1, P_PMarzy_3_2 pomija się.
P_PMarzyN
Znacznik braku wystąpienia procedur marży, o których
mowa w art. 119 lub art. 120 ustawy
W przypadku faktury, która nie dokumentuje dostawy
towarów lub świadczenia usług opodatkowanych w
procedurze marży, o której mowa w art. 119 lub art. 120
ustawy, należy podać wartość „1”.
W przypadku wskazania „1” w polu P_PMarzyN
(znajdującej się w sekwencji typu „wybór”) pola:
P_PMarzy, P_PMarzy_2, P_PMarzy_3_ 1 , P_PMarzy_3_2,
P_PMarzy_3_3 pomija się.
Przykład 12. Sposób wypełnienia Adnotacji dla Fa

Stan faktyczny:

Podatnik VAT dokonuje wewnątrzwspólnotowej dostawy nowego środka transportu na rzecz
podatnika podatku od wartości dodanej, zidentyfikowanego na cele transakcji
wewnątrzwspólnotowych. Pojazd z terytorium Polski, do kraju UE wyjeżdża na lawecie.
Przedmiotem sprzedaży są:

samochód osobowy marki „XXX”, model „abc”, kolor czerwony, o przebiegu 1000 km
i numerze rejestracyjnym SD11111. Pojazd został wyprodukowany w 202 6 r. i
dopuszczony do użytku 20.0 4 .202 6 r.
samochód osobowy marki „YYY”, model „xyz”, kolor zielony, o przebiegu 2300 km i
numerze rejestracyjnym SD33333. Pojazd został wyprodukowany w 202 6 r. i
dopuszczony do użytku 10 .0 5 .202 6 r.
Sprzedawca poza danymi obligatoryjnymi (tj. data dopuszczenia do użytku nowego środka
transportu oraz przebieg pojazdu) chce podać na fakturze również dodatkowe dane
identyfikujące pojazd.

W powyższej sytuacji element Adnotacje wypełnia się następująco:

Nazwa pola Sposób wypełnienia
Fa/Adnotacje
P_16 2
P_17 2
P_18 2
P_18A 2
Fa/Adnotacje/Zwolnienie P_19N 1
Fa/Adnotacje/
NoweSrodkiTransportu
P_22 1
P_42_5 2
Fa/Adnotacje/
NoweSrodkiTransportu/
NowySrodekTransportu
P_22A 2026 - 04 - 20
P_NrWierszaNST 1
P_22BMK XXX
P_22BMD abc
P_22BK czerwony
P_22BNR SD 11111
P_22BRP 2026
P_22B 1000 km
Fa/Adnotacje/
NoweSrodkiTransportu/
NowySrodekTransportu
P_22A 2026 - 05 - 10
P_NrWierszaNST 2
P_22BMK YYY
P_22BMD xyz
P_22BK zielony
P_22BNR SD33333
P_22BRP 2026
P_22B 2300 km
Fa/Adnotacje P_23 2
Fa/Adnotacje/PMarzy
P_PMarzyN 1
Przykład 13. Sposób wypełnienia elementu Adnotacje dla Fa

Stan faktyczny:

Podatnik VAT dokonuje dostawy samochodu używanego, nabytego od osoby prywatnej w
celu dalszej odsprzedaży. Sprzedawca, określając podstawę opodatkowania powyższej
transakcji, stosuje procedurę VAT marża, o której mowa w art. 120 ust. 4 ustawy.

W powyższej sytuacji element Adnotacje wypełnia się następująco:

Nazwa pola Sposób wypełnienia
Fa/Adnotacje P_16 2
P_17 2
P_18 2
P_18A 2
Fa/Adnotacje/Zwolnienie P_19N 1
Fa/Adnotacje/
NoweSrodkiTransportu
P_22N 1
Fa/Adnotacje P_23 2
Fa/Adnotacje/PMarzy P_PMarzy 1
P_PMarzy_3_1 1
Schemat 34. Struktura elementu Fa (od pola PrzyczynaKorekty do pola KursWalutyZK)

Tabela 34. Opis struktury elementu Fa (od pola PrzyczynaKorekty do pola KursWalutyZK)

Nazwa pola Opis pola
PrzyczynaKorekty
Przyczyna korekty [pole fakultatywne]
Zgodnie z art. 106j ust. 2a pkt 2 ustawy faktura
korygująca może zawierać przyczynę wystawienia
faktury korygującej.
Uwaga!
Fakturę korygującą można wystawić w przypadku
korygowania obligatoryjnych, opcjonalnych jak i
fakultatywnych elementów faktury.
TypKorekty Typ skutku korekty w ewidencji dla podatku od towarów
i usług [pole fakultatywne]
Podaje się:
„1” - w przypadku korekty skutkującej w dacie ujęcia
faktury pierwotnej,
„2” - korekta skutkująca w dacie wystawienia faktury
korygującej,
„3” - korekta skutkująca w dacie innej, w tym, gdy dla
różnych pozycji faktury korygującej daty te są różne.
DaneFaKorygowanej Element zawierający dane faktury korygowanej, m. in.
datę wystawienia faktury korygowanej, numer faktury
korygowanej, numer KSeF faktury korygowanej
Maksymalna ilość wystąpień: 50 000
Uwaga!
W przypadku wystawienia faktury korygującej
dotyczącej więcej niż jednej faktury, należy podać dane
odrębnie dla każdej korygowanej faktury pierwotnej.
OkresFaKorygowanej
Okres, do którego odnosi się udzielany opust lub
udzielana obniżka, w przypadku, gdy podatnik udziela
opustu lub obniżki ceny w odniesieniu do dostaw
towarów lub usług dokonanych lub świadczonych na
rzecz jednego odbiorcy w danym okresie [pole
opcjonalne, dotyczące faktury korygującej, o której
mowa w art. 106j ust. 3 ustawy]
NrFaKorygowany Poprawny numer faktury korygowanej w przypadku, gdy
przyczyną korekty jest błędny numer faktury
korygowanej [pole opcjonalne]
Uwaga!
Błędny numer faktury należy wskazać w polu
NrFaKorygowanej.
Podmiot1K Element zawierający dane Podmiot1 ujęte na fakturze
korygowanej [element opcjonalny]

W przypadku korekty danych sprzedawcy, należy podać
pełne dane sprzedawcy, występujące na fakturze
korygowanej. Pole nie dotyczy przypadku korekty
błędnego NIP występującego na fakturze pierwotnej.
Wówczas wymagana jest korekta faktury do wartości
zerowych.
Podmiot2K
Element zawierający dane nabywcy występującego jako
Podmiot 2 lub Podmiot3 (rola „4”), ujęte na fakturze
korygowanej [element opcjonalny]

W przypadku korekty danych nabywcy występującego
jako Podmiot2 lub dodatkowego nabywcy
występującego jako Podmiot3, należy podać pełne dane
tego podmiotu występujące na fakturze korygowanej.
Korekcie nie podlegają błędne numery NIP
identyfikujące nabywcę oraz dodatkowego nabywcę -
wówczas wymagana jest korekta faktury do wartości
zerowych. W przypadku korygowania pozostałych
danych nabywcy lub dodatkowego nabywcy wskazany
numer identyfikacyjny ma być tożsamy z numerem w
części Podmiot2 względnie Podmiot3 faktury
korygującej
Maksymalna ilość wystąpień: 101
P_15ZK
W przypadku korekt faktur zaliczkowych - kwota zapłaty
przed korektą. W przypadku korekt faktur, o których
mowa w art. 106f ust. 3 ustawy - kwota pozostała do
zapłaty przed korektą.

KursWalutyZK
Kurs waluty stosowany do wyliczenia kwoty podatku w
przypadkach, o których mowa w dziale VI ustawy, przed
korektą, w przypadku gdy podatnik wystawia fakturę
korygującą do faktury zaliczkowej [pole fakultatywne]

Schemat 35. Struktura elementu DaneFaKorygowanej dla Fa

Tabela 35. Opis struktury elementu DaneFaKorygowanej dla Fa

Nazwa pola Opis pola
DataWystFaKorygowanej Data wystawienia faktury korygowanej (pierwotnej)
W przypadku, gdy:
faktura korygowana była wystawiona poza KSeF,
podaje się datę wystawienia faktury, o której mowa w
art. 106e ust. 1 pkt 1 ustawy,
faktura korygowana była wystawiona zgodnie z art.
106nda ust. 1 lub ust. 1 6 ustawy, 106nh ust. 1 ustawy,
art. 106nf ust. 1 ustawy podaje się datę wystawienia
faktury, o której mowa w art. 106e ust. 1 pkt 1 ustawy
wskazaną przez podatnika w polu P_1 (a nie datę
przesłania faktury do KSeF),
faktura korygowana była wystawiona w KSeF w trybie
„online”, za datę wystawienia faktury korygowanej
uznaje się datę jej przesłania do KSeF, zgodnie z art.
106na ust. 1 ustawy (o ile data przesłania faktury do
KSeF jest zgodna z datą wystawienia faktury, wskazaną
przez podatnika w polu P_1).
NrFaKorygowanej Numer faktury korygowanej (pierwotnej)
Podaje się numer faktury korygowanej, o którym mowa
w art. 106e ust. 1 pkt 2 ustawy.
Uwaga!
Pole wypełnia się niezależnie od tego, czy faktura
korygowana była wystawiona w KSeF czy poza KSeF.
NrKSeF
Znacznik numeru KSeF faktury korygowanej (pierwotnej)
W przypadku, gdy faktura korygowana była wystawiona
w KSeF, należy wskazać „1”.
Uwaga!
Jeżeli faktura korygowana była wystawiona w KSeF,
wówczas dodatkowo, w polu NrKSeFFaKorygowanej,
należy podać numer KSeF faktury korygowanej.
Uwaga!
Obowiązek podawania numeru KSeF faktury
korygowanej dotyczy także faktur wystawionych
zgodnie z art. 106nda ust. 1 lub ust. 1 6 ustawy, 106nh
ust. 1 ustawy, art. 106nf ust. 1 ustawy.
NrKSeFFaKorygowanej Numer identyfikujący fakturę korygowaną (pierwotną)
w KSeF
Należy wskazać numer KSeF faktury korygowanej
(pierwotnej), w przypadku, gdy w polu NrKSeF wskazano
wartość „1”.
NrKSeFN
Znacznik faktury korygowanej (pierwotnej) wystawionej
poza KSeF
W przypadku, gdy faktura korygowana była wystawiona
poza KSeF należy wskazać „1”.
Uwaga!
W przypadku, gdy pole NrKSeFN przyjmuje wartość „1”,
pola NrKSeF oraz NrKSeFFaKorygowanej pomija się.
Przykład 14. Sposób wypełnienia elementu DaneFaKorygowanej

Stan faktyczny:

Podatnik VAT wystawił w dniu 14 lipca 202 6 r. fakturę pierwotną nr FV/110/07/202 6 w KSeF.
Numer identyfikujący tę fakturę w KSeF to: 9999999999 - 20260714 - D5FB0C-9ED490-9A.

Następnie, ze względu na stwierdzoną pomyłkę w fakturze pierwotnej, podatnik 10 września
2026 r. wystawia fakturę korygującą (w KSeF), w której uwzględnia m. in. dane wcześniej
wystawionej faktury pierwotnej.

Element DaneFaKorygowanej w powyższej sytuacji wypełnia się następująco:

Nazwa pola Sposób wypełnienia
Fa/DaneFaKorygowanej DataWystFaKorygowanej 2026 - 07 - 14
NrFaKorygowanej FV/110/07/202 6
NrKSeF 1
NrKSeFFaKorygowanej 9999999999 - 20260714 - D5FB0C-
9ED490-9A
Schemat 36. Struktura elementu Podmiot1K dla Fa

Tabela 36. Opis struktury elementu Podmiot1K dla Fa

Nazwa pola Opis pola
PrefiksPodatnika Kod (prefiks) podatnika VAT UE dla przypadków
określonych w art. 97 ust. 10 pkt 2 i 3 ustawy oraz w
przypadku, o którym mowa w art. 136 ust. 1 pkt 3
ustawy, który został wskazany na fakturze korygowanej
[pole opcjonalne]
DaneIdentyfikacyjne Element zawierający dane identyfikujące podatnika,
wskazane na fakturze korygowanej
Adres Adres podatnika, który został wskazany na fakturze
korygowanej
Schemat 37. Struktura elementu DaneIdentyfikacyjne dla Podmiot1K

Tabela 37. Opis struktury elementu DaneIdentyfikacyjne dla Podmiot1K

Nazwa pola Opis pola
NIP Identyfikator podatkowy NIP podatnika, który został
wskazany na fakturze korygowanej
Nazwa Imię i nazwisko lub nazwa podatnika, które zostały
wskazane na fakturze korygowanej
Schemat 38. Struktura elementu Adres dla Podmiot1K

Tabela 38. Opis struktury elementu Adres dla Podmiot1K

Nazwa pola Opis pola
KodKraju Kod kraju, który został wskazany na fakturze
korygowanej
AdresL1 Adres podatnika (linia pierwsza), który został wskazany
na fakturze korygowanej
AdresL2 Adres podatnika (linia druga), który został wskazany na
fakturze korygowanej [pole fakultatywne]
GLN Globalny Numer Lokalizacyjny, który został wskazany na
fakturze korygowanej [pole fakultatywne]
Schemat 39. Struktura elementu Podmiot2K dla Fa

Tabela 39. Opis struktury elementu Podmiot2K dla Fa

Nazwa pola Opis pola
DaneIdentyfikacyjne Element zawierający dane identyfikujące nabywcę,
wskazane na fakturze korygowanej
Adres Element zawierający dane dotyczące adresu nabywcy
zawarte na fakturze korygowanej
Element opcjonalny dla przypadków określonych w art.
106e ust. 5 pkt 3 ustawy.
IDNabywcy
Unikalny klucz powiązania danych nabywcy na fakturach
korygujących, w przypadku, gdy dane nabywcy na
fakturze korygującej zmieniły się w stosunku do danych
na fakturze korygowanej [pole fakultatywne]
Maksymalna ilość znaków: 32
Schemat 40. Struktura elementu DaneIdentyfikacyjne dla Podmiot2K

Tabela 40. Opis struktury elementu DaneIdentyfikacyjne dla Podmiot2K

Nazwa pola Opis pola
NIP Identyfikator podatkowy NIP nabywcy, który został
wskazany na fakturze korygowanej
KodUE Kod (prefiks) nabywcy VAT UE, o którym mowa w art.
106e ust. 1 pkt 24 ustawy oraz w przypadku, o którym
mowa w art. 136 ust. 1 pkt 4 ustawy, który został
wskazany na fakturze korygowanej
NrVatUE Numer identyfikacyjny VAT kontrahenta UE, który został
wskazany na fakturze korygowanej
KodKraju Kod kraju nadania innego identyfikatora podatkowego,
który został wskazany na fakturze korygowanej [pole
fakultatywne]
NrID Identyfikator podatkowy nabywcy inny, który został
wskazany na fakturze korygowanej
BrakID Podmiot nieposiadający identyfikatora podatkowego lub
podmiot, którego identyfikator nie występuje na
fakturze korygowanej
Podaje się „1” w przypadku, gdy na fakturze
korygowanej wskazano, że nabywca nie posiada
identyfikatora podatkowego lub faktura korygowana nie
zawierała identyfikatora nabywcy.
Nazwa
Imię i nazwisko lub nazwa nabywcy, które zostały
wskazane na fakturze korygowanej
Schemat 41. Struktura elementu Adres dla Podmiot2K

Tabela 41. Opis struktury elementu Adres dla Podmiot2K

Nazwa pola Opis pola
KodKraju Kod kraju, który został wskazany na fakturze
korygowanej
AdresL1
Adres nabywcy (linia pierwsza), który został wskazany
na fakturze korygowanej
AdresL2
Adres nabywcy (linia druga), który został wskazany na
fakturze korygowanej [pole fakultatywne]
GLN Globalny Numer Lokalizacyjny, który został wskazany na
fakturze korygowanej [pole fakultatywne]
Przykład 15. Przykład zastosowania pola IDNabywcy

Stan faktyczny:

Podatnik VAT wystawił fakturę pierwotną na trzech nabywców. Następnie, w związku ze
stwierdzeniem błędu w danych pierwszego i trzeciego z nabywców, wystawia fakturę
korygującą.

Wystawiając fakturę korygującą, podatnik uwzględnia w niej już (w elemencie Podmiot2 i
Podmiot3) prawidłowe dane nabywców.

W fakturze korygującej w polu Podmiot2 wskazuje prawidłowe dane pierwszego nabywcy.
Wypełnia także pole IDNabywcy wskazując „NB/ 01 ”:

Nazwa pola Sposób wypełnienia
Podmiot2/Dane
Identyfikacyjne
NIP 3333333333
Nazwa Władysław Kowalski
Podmiot2/Adres KodKraju PL
AdresL1 ul. Biała 5, 22-222 Katowice
Podmiot2 IDNabywcy NB/ 01
W elemencie Podmiot3 wskazuje dane drugiego nabywcy. Wypełnia także pole IDNabywcy
wskazując „NB/ 02 ”:

Nazwa pola Sposób wypełnienia
Podmiot3 IDNabywcy NB/ 02
Podmiot3/Dane
Identyfikacyjne
NIP 5555555555
Nazwa Anna Nowak
Podmiot3/Adres KodKraju PL
AdresL1 ul. Zielona 7, 33-333 Dąbrowa Górnicza
Podmiot3 Rola 4
Prawidłowe dane trzeciego z nabywców podatnik uwzględnia w elemencie Podmiot3.
Wypełnia także pole IDNabywcy wskazując „NB/03”:

Nazwa pola Sposób wypełnienia
Podmiot3 IDNabywcy NB/ 03
Podmiot3/Dane
Identyfikacyjne
NIP 7777777777
Nazwa Adam Kowalczyk
Podmiot3/Adres KodKraju PL
AdresL1 ul. Błękitna 9, 44 - 444 Olkusz
Podmiot3 Rola 4
Pomyłka w fakturze podstawowej dotyczy:

data pierwszego zakupu (błąd w sklepie - był „Jan”, a powinien być
„Władysław”) oraz
dane dotyczące zakupuy (błąd w adresie – była „ul. Niebieska 9, 44-444 Olkusz” a
mogła być „ul. Błękitna 9, 44-444 Olkusz”).
W opisie danych dotyczących posiadania, charakterystycznego jako Podmiot2 lub dodatkowego
nabywcy charakterystycznego jako Podmiot3, w fakturze korygowanej, należy pamiętać, że pełne dane
tego podmiotu są charakterystyczne dla faktury korygowanej (co oznacza główne dane). Zgodnie z
obowiązującym prawem, w fakturze korygującej należy uwzględnić m.in. dane nabywców, gromadzone w
fakturze podatkowej.

W związku z tym, w elemencie Podmiot2K znajduje się dane pierwotne
, które pochodzą z konta końcowego:

Nazwa pola Sposób wypełnienia
Podmiot2K/Dane
Identyfikacyjne
NIP 3333333333
Nazwa Jan Kowalski
Podmiot2K/Adres KodKraju PL
AdresL1 ul. Biała 5, 22-222 Katowice
Podmiot2K IDNabywcy NB/ 01
Nazwa pola Sposób wypełnienia
Podmiot2K/Dane
Identyfikacyjne
NIP 7777777777
Nazwa Adam Kowalczyk
Podmiot2K/Adres KodKraju PL
AdresL1 ul. Niebieska 9, 44-444 Olkusz
Podmiot2K IDNabywcy NB/ 03
Stosowanie klucza powiazania danych osobowych w sposób zwiększający
czytelność faktury korygującej oraz proste podmiotu, które dane są
korygowane, bez szczegółowej analizy, zawartość poszczególnych pól.

Schemat 42. Struktura elementu Fa (pola od Zaliczki Czesciowej do Zamowienia)

Tabela 42. Opis struktury elementu Fa (pola od Zaliczki Czesciowej do Zamowienia)

Nazwa pola Opis pola
ZaliczkaCzesciowa Element opcjonalny zawierający dane dla przypadków
faktur:
Dokumenty otrzymanie więcej niż jednej
płatności, o której mowa w art. 106b ust. 1 pkt 4
ustawy,
o których mowa w art. 106e ust. 1a ustawy (w związku
z art. 106b ust. 1a ustawy).
W przypadku, gdy faktura, wystawiana po wydaniu
towaru lub wykonaniu usługi, dokumentuje
jednocześnie otrzymanie części zapłaty przed
dokonaniem czynności, różnica kwoty w polu P_15 i
sumy poszczególnych pól P_15Z stanowi kwotę
pozostałą ponad płatności otrzymane przed
wykonaniem czynności udokumentowanej fakturą
Maksymalna ilość wystąpień: 31
FP Faktura, o której mowa w art. 109 ust. 3d ustawy [pole
fakultatywne]

Podaje się „1” w celu zawarcia na fakturze informacji, że
jest to faktura, o której mowa w art. 109 ust. 3d ustawy.
TP okresowe powiązania między kupującymi a dokonującymi
dostawy dostawy lub usługodawcą, zgodnie z § 10 ust.
4 pkt 3, z zastrzeżeniem ust. 4b rozporządzenia w
sprawie JPK_VAT z deklaracją [pole fakultatywne]

Podaje się „1” w celu zawarcia na fakturze informacji o
ww. istniejących powiązaniach.
Uwaga!
Oznaczenia „TP” nie stosuje się w przypadku dostaw
towarów oraz świadczenia usług, gdy powiązania między
nabywcą a dokonującym dostawy towarów lub
usługodawcą wynikają wyłącznie z powiązania ze
Skarbem Państwa lub jednostkami samorządu
terytorialnego, lub ich związkami.
Opis Element jest przeznaczony dla
wykazywania dodatkowych danych na fakturze, w tych
wymaganych prawach, dla których nie
działają inne pola/elementy [element
fakultatywny]

Maksymalna ilość wystąpień: 1 0 000
FakturaZaliczkowa
Element kontynuowany m.in. in. numery faktur zaliczkowych
lub ich numery KSeF, jeśli zostały wytworzone z użycia
KSeF [element opcjonalny]

Maksymalna ilość wystąpień: 100
ZwrotAkcyzy Informacja dodatkowa niezbędna dla rolników
ubiegających się o zwrot podatku akcyzowego
zawartego w cenie oleju napędowego [pole
fakultatywne]
Podaje się „1” w celu zawarcia na fakturze informacji
dodatkowej dotyczącej zwrotu akcyzy, niezbędnej dla
rolników ubiegających się o zwrot podatku akcyzowego
zawartego w cenie oleju napędowego.
FaWiersz Element zawierający szczegółowe pozycje faktury w
walucie, w której wystawiono fakturę [element
opcjonalny]
Maksymalna ilość wystąpień: 1 0 000
Rozliczenie Element zawierający dane dotyczące dodatkowych
rozliczeń na fakturze [element fakultatywny]
Płatnosc Element zawierający dane dotyczące warunków
płatności [element fakultatywny]
WarunkiTransakcji Element zawierający dane dotyczące warunków
transakcji, o ile występują [element fakultatywny]
Zamowienie Element zawierający dane dotyczące zamówienia lub
umowy, o których mowa w art. 106f ust. 1 pkt 4 ustawy
(dla faktur zaliczkowych) w walucie, w której
wystawiono fakturę zaliczkową [element opcjonalny]
Schemat 43. Struktura elementu Zaliczka Czesciowa dla Fa

Tabela 43. Opis struktury elementu Zaliczka Czesciowa dla Fa

Nazwa pola Opis pola
P_6Z
Data otrzymania płatności, o której mowa w art. 106b
ust. 1 pkt 4 ustawy
P_15Z
Kwota płatności, o której mowa w art. 106b ust. 1 pkt 4
ustawy, składająca się na kwotę w polu P_15. W
przypadku faktur korygujących - korekta kwoty
wynikającej z faktury korygowanej
KursWalutyZW
Kurs waluty dotyczący płatności, o której mowa w art.
106b ust. 1 pkt 4 ustawy, stosowany do wyliczenia
kwoty podatku, w przypadkach, o których mowa w
dziale VI ustawy [pole fakultatywne]
Przykład 16. Sposób wykonania elementu Zaliczka Czesciowa

Stan faktyczny:

Podatnik VAT otrzymał 3 zaliczki na pocztę zamówień:

w dniu 10 września 202 6 r. – na zastosowanie 500 euro (właściwy kurs euro wykreślony 4. 4512
zł),
w dniu 15 września 202 6 r. – na zastosowanie 2500 euro (właściwy kurs euro wycięty 4. 4724
zł),
w dniu 20 września 202 6 r. – na zastosowanie 1000 euro (właściwy kurs euro wykreślony 4. 5148
zł).
Podatnik zdecydował się udokumentować wszystkie trzy otrzymane zaliczki jedną fakturą
ustrukturyzowaną. W fakturze uwzględnił także właściwe kursy waluty, celem wyliczenia
kwoty podatku należnego, wynikającej z otrzymanych zaliczek. Właściwy kod waluty wskazał
w polu Fa/KodWaluty.

Element ZaliczkaCzesciowa może wypełnić w poniższy sposób:

Nazwa pola Sposób wypełnienia
Fa/ZaliczkaCzesciowa P_6Z 2026 - 09 - 10
P_15Z 500
KursWalutyZW 4. 4512
Fa/ZaliczkaCzesciowa P_6Z 2026 - 09 - 15
P_15Z 2500
KursWalutyZW 4. 4724
Fa/ZaliczkaCzesciowa P_6Z 2026 - 09 - 20
P_15Z 1000
KursWalutyZW 4. 5148
Schemat 44. Struktura elementu DodatkowyOpis dla Fa

Tabela 44. Opis struktury elementu DodatkowyOpis dla Fa

Nazwa pola Opis pola
NrWiersza Numer wiersza podany w polu NrWierszaFa lub
NrWierszaZam, jeśli informacja odnosi się wyłącznie do
danej pozycji faktury [pole fakultatywne]
Klucz Klucz dla pola niezdefiniowanego, stanowiącego
element typu złożonego klucz-wartość
Podaje się nazwę pola przeznaczonego dla wykazywania
dodatkowych danych na fakturze, w tym wymaganych
przepisami prawa, dla których nie przewidziano innych
pól/elementów. Nazwę wskazuje podatnik.
Maksymalna ilość znaków: 256
Wartosc Wartość pola, stanowiącego element typu złożonego
klucz-wartość, dla którego nazwę (klucz) określił
podatnik
Podaje się wartość pola przeznaczonego dla
wykazywania dodatkowych danych na fakturze, w tym
wymaganych przepisami prawa, dla których nie
przewidziano innych pól/elementów.
Maksymalna ilość znaków: 256
Przykład 17. Sposób wypełnienia elementu DodatkowyOpis

Stan faktyczny:

Podatnik VAT wystawia fakturę dokumentującą sprzedaż energii elektrycznej. Na fakturze
podaje m. in. numer licznika (11/20 23 /KTW) oraz adres punku poboru ( 77 - 777 Katowice, ul.
Biała 7).

W celu uwzględnienia powyższych danych na fakturze, podatnik może wykorzystać element
DodatkowyOpis:

Nazwa pola Sposób wypełnienia
Fa/DodatkowyOpis Klucz Numer licznika
Wartosc 11/20 23 /KTW
Fa/DodatkowyOpis Klucz Adres punktu poboru
Wartosc 77 - 777 Katowice, ul. Biała 7
WAŻNE
W przypadku faktur dotyczących czynności o złożonej liczbie danych w zakresie jednostek
miary i ilości (liczby) dostarczanych towarów lub wykonywanych usług lub cen
jednostkowych netto, podatnik może wystawiać i przesyłać do KSeF faktury
ustrukturyzowane lub faktury, o których mowa w art. 106nda ust. 1, art. 106nf ust. 1 i art.
106nh ust. 1 ustawy, z załącznikiem będącym integralną częścią faktury, zawierającym
wyłącznie dane, o których mowa w art. 106e ust. 1 ustawy, lub dane ściśle powiązane z tymi
danymi. Aby wystawiać i przesyłać do KSeF faktury z wypełnionym elementem Zalacznik w
strukturze FA(3), konieczne jest złożenie zgłoszenia o zamiarze wystawiania i przesyłania do
KSeF faktur z załącznikiem za pośrednictwem e-Urzędu Skarbowego.

Przykład 18. Sposób wypełnienia elementu DodatkowyOpis

Stan faktyczny:

Podatnik VAT wystawia fakturę dokumentującą sprzedaż wody w danym okresie
rozliczeniowym. Odczyt wodomierza o numerze 001/ABC/3 odbył się w dniu 01. 05 .202 6 r.

Stan początkowy licznika, w pierwszym dniu okresu rozliczeniowego wyniósł 18 m^3 ,
natomiast stan końcowy licznika na ostatni dzień okresu rozliczeniowego wyniósł 99 m^3.
Zużycie w okresie rozliczeniowym wyniosło więc łącznie 81 m^3 wody.

Wystawiając fakturę podatnik (wystawca) w elemencie Fa/FaWiersz, w polach P_7, P_8A
oraz P_8B wskazał nazwę sprzedawanego towaru (woda), jego miarę (m^3 ) i ilość (81).

Natomiast w celu uwzględnienia dodatkowych danych na fakturze (np. daty odczytu, numeru
i stanu licznika), podatnik może wykorzystać element DodatkowyOpis:

Nazwa pola Sposób wypełnienia
Fa/DodatkowyOpis Klucz Data odczytu
Wartosc 2026 - 05 - 01
Fa/DodatkowyOpis Klucz Numer wodomierza
Wartosc 001/ABC/3
Fa/DodatkowyOpis Klucz Stan początkowy licznika
Wartosc 18 m^3
Fa/DodatkowyOpis Klucz Stan końcowy licznika
Wartosc 99 m^3
Przykład 19. Sposób wypełnienia elementu DodatkowyOpis

Stan faktyczny:

Podatnik VAT wystawia fakturę dokumentującą sprzedaż usług telekomunikacyjnych. Na
fakturze podaje również zbiorczą informację w zakresie zrealizowanych połączeń i wysłanych
wiadomości w danym okresie rozliczeniowym:

liczba wysłanych wiadomości SMS – 84,
liczba wysłanych wiadomości MMS – 16,
liczba wykonanych połączeń krajowych - 76,
łączny czas połączeń krajowych - 08:40:28,
liczba wykonanych połączeń międzynarodowych - 4,
łączny czas połączeń międzynarodowych – 01:12:35.
W celu uwzględnienia powyższych danych na fakturze, podatnik może wykorzystać element
DodatkowyOpis:

Nazwa pola Sposób wypełnienia
Fa/DodatkowyOpis
Klucz Liczba wysłanych wiadomości SMS
Wartosc 84
Fa/DodatkowyOpis
Klucz Liczba wysłanych wiadomości MMS
Wartosc 16
Fa/DodatkowyOpis
Klucz Liczba wykonanych połączeń krajowych
Wartosc 76
Fa/DodatkowyOpis
Klucz Łączny czas połączeń krajowych
Wartosc 08:40:28
Fa/DodatkowyOpis
Klucz Liczba wykonanych połączeń międzynarodowych
Wartosc 4
Fa/DodatkowyOpis
Klucz Łączny czas połączeń międzynarodowych
Wartosc 01:12:35
Przykład 20. Sposób wypełnienia elementu DodatkowyOpis

Stan faktyczny:

Podatnik VAT dokonał sprzedaży następujących produktów:

pralka (marka Abc, pojemność: 9 kg, szybkość wirowania 1 200 obrotów/ minutę);
odkurzacz (marka Xyz, poziom hałasu: 78dB, funkcja prania).
Wystawiając fakturę, podatnik w elemencie FaWiersz wskazał m. in.:

„1” w polu NrWierszaFa, a w polu P_7 „pralka”,
„2” w polu NrWierszaFa, a w polu P_7 „odkurzacz”.
Dodatkowo podatnik chciałby zawrzeć na fakturze dodatkowe informacje charakteryzujące
sprzedawane produkty. Aby zidentyfikować, którego towaru (wymienionego w elemencie
FaWiersz) dotyczy dana informacja dodatkowa, można wskazać w elemencie
DodatkowyOpis, w polu NrWiersza, numer wiersza faktury, do którego odnosi się dana
informacja.

Przykładowo, gdy w elemencie FaWiersz wskazano „2” (w polu NrWierszaFa) oraz w
elemencie DodatkowyOpis (w polu NrWiersza) wskazano „2” – oznacza to, że informacja
dodatkowa, ujęta w elemencie DodatkowyOpis dotyczy drugiej pozycji faktury, czyli
odkurzacza.

W analizowanym stanie faktycznym element DodatkowyOpis można wypełnić następująco:

Nazwa pola Sposób wypełnienia
Fa/DodatkowyOpis NrWiersza 1
Klucz Marka
Wartosc Abc
Fa/DodatkowyOpis NrWiersza 1
Klucz Pojemność
Wartosc 9 kg
Fa/DodatkowyOpis NrWiersza 1
Klucz Szybkość wirowania
Wartosc 1200 obrotów/minutę
Fa/DodatkowyOpis NrWiersza 2
Klucz Marka
Wartosc Xyz
Fa/DodatkowyOpis NrWiersza 2
Klucz Poziom hałasu
Wartosc 78dB
Fa/DodatkowyOpis NrWiersza 2
Klucz Dodatkowe funkcje
Wartosc Funkcja prania
Schemat 45. Struktura elementu FakturaZaliczkowa dla Fa

Tabela 45. Opis struktury elementu FakturaZaliczkowa dla Fa

Nazwa pola Opis pola
NrKSeFZN Znacznik faktury zaliczkowej wystawionej poza KSeF
Podaje się „1” w przypadku, gdy faktura zaliczkowa
została wystawiona poza KSeF.
W przypadku, gdy w polu NrKSeFZN wskazano wartość
„1”, należy wypełnić również pole NrFaZaliczkowej.
NrFaZaliczkowej Numer faktury zaliczkowej wystawionej poza KSeF
Pole obowiązkowe dla faktury wystawianej po wydaniu
towaru lub wykonaniu usługi, o której mowa w art. 106f
ust. 3 ustawy i ostatniej z faktur, o której mowa w art.
106f ust. 4 ustawy.
Pole NrFaZaliczkowej wypełnia się w przypadku, gdy w
polu NrKSeFZN wskazano wartość „1”.
NrKSeFFaZaliczkowej Numer identyfikujący fakturę zaliczkową w KSeF
Pole obowiązkowe w przypadku, gdy faktura zaliczkowa
była wystawiona za pomocą KSeF.
W przypadku, gdy faktura zaliczkowa była wystawiona w
KSeF, pola NrKSeFZN oraz NrFaZaliczkowej pomija się.
Przykład 21. Sposób wypełnienia elementu FakturaZaliczkowa

Stan faktyczny:

Podatnik VAT wystawił:

w dniu 15 lipca 202 5 r. fakturę zaliczkową nr FZ/123/07/202 5 poza KSeF,
w dniu 16 sierpnia 202 5 r. kolejną fakturę zaliczkową, nr FZ/133/08/202 5 poza KSeF.
Następnie 10 września 202 6 r. podatnik wystawia fakturę rozliczającą (w KSeF), w której
uwzględnia m. in. dane wcześniej wystawionych faktur zaliczkowych.

Element FakturaZaliczkowa w powyższej sytuacji zostanie wypełniony dwukrotnie, ponieważ
wskazane zostaną numery dwóch wcześniej wystawionych faktur zaliczkowych:

Nazwa pola Sposób wypełnienia
Fa/FakturaZaliczkowa NrKSeFZN 1
NrFaZaliczkowej FZ/123/07/202 5
Fa/FakturaZaliczkowa NrKSeFZN 1
NrFaZaliczkowej FZ/133/08/202 5
Element FaWiersz dla Fa
Element FaWiersz zawiera szczegółowe pozycje faktury w walucie, w której wystawiono
fakturę.

Jest to element nieobowiązkowy dla faktury zaliczkowej, faktury korygującej fakturę
zaliczkową oraz faktur korygujących dotyczących wszystkich dostaw towarów lub usług
dokonanych lub świadczonych w danym okresie, o których mowa w art. 106j ust. 3 ustawy,
dla których należy podać dane dotyczące opustu lub obniżki w podziale na stawki podatku i
procedury w części Fa.

W przypadku faktur korygujących, o których mowa w art. 106j ust. 3 ustawy, gdy opust lub
niższe ceny odnoszą się do części dostaw lub usług określonych lub specyficznych
w określonym obszarze, w części FaWiersz należy podać nazwę (rodzaje) składnika usług lub analizy
korekty.

W przypadku faktury, o której mowa w art. 106f ust. 3 ustawy, należy uwzględnić pełne
wartości zamówień lub umowy. W przypadku faktur korygujących odnoszących się do faktury (w tym
faktur korygujących faktury, o których mowa w art. 106f ust. 3 ustawy, jeśli korekta dotyczy
wartości zamówień), należy uwzględnić zastosowanie z konkretnymi pozycjami
lub danymi korygowanymi według stanu przed korektą i po korekcie jako wprowadzone wiersze.

W przypadku faktur korygujących, o których mowa w art. 106f ust. 3 ustawy, jeśli
korekta nie dotyczy wartości zamówień i jednocześnie zmienia wysokość podstawy

podlega obowiązkowi podatkowemu, należy wprowadzić zapis według stanu przed korektą i zapisać według
stanu po korekcie w celu uzyskania potwierdzenia braku zmiany wartości pozycji faktury.

Schemat 46. Struktura elementu FaWiersz dla Fa (od pola od NrWierszaFa do pola PKOB)

Tabela 46. Opis struktury elementu FaWiersz dla Fa (od pola NrWierszaFa do pola PKOB)

Nazwa pola Opis pola
NrWierszaFa Kolejny numer wiersza faktury
Podaje się kolejny numer wiersza faktury.
Przykład:
W przypadku faktury dokumentującej sprzedaż dwóch
różnych towarów, w przypadku pierwszej pozycji na
fakturze pole NrWierszaFa równa się „1”, a w przypadku
drugiej pozycji na fakturze, pole NrWierszaFa równa się
„2” (itd.).
UU_ID Uniwersalny unikalny numer wiersza faktury [pole
fakultatywne]
Pole tekstowe zawierające uniwersalny, unikalny
identyfikator danych, umożliwiający jednoznaczne
zidentyfikowanie wiersza faktury. Pożądaną unikalnością
pola UU_ID jest unikalność w skali danego podatnika lub
danego systemu wykorzystywanego przez danego
podatnika.
P_6A Data dokonania lub zakończenia dostawy towarów lub
wykonania usługi lub data otrzymania zapłaty, o której
mowa w art. 106b ust. 1 pkt 4 ustawy, o ile taka data
jest określona i różni się od daty wystawienia faktury
[pole opcjonalne]
Pole wypełnia się w przypadku, gdy dla poszczególnych
pozycji faktury występują różne daty. W przeciwnym
przypadku pole pozostaje puste.
Uwaga!
W przypadku, gdy dla wszystkich wierszy faktury data
jest wspólna – wypełnia się pole P_6 (element Fa).
P_7 Nazwa (rodzaj) towaru lub usługi [pole pomocnicze]

Pole nie jest wymagane wyłącznie dla przypadku
określonego w art 106j ust. 3 pkt 2 ustawy, tj., gdy
podatnik udziela opustu lub obniżki ceny i wystawia
fakturę korygującą, dotyczącą wszystkich dostaw
towarów i świadczenia usług na rzecz jednego odbiorcy
w danym okresie.
Maksymalna ilość znaków: 512
Indeks przeznaczony do wpisania wewnętrznego kodu
towaru lub usług, nadany przez rozszerzenie
dodatkowego opisu towaru lub usług [pole
fakultatywne]

Maksymalna ilość znaków: 50
GTIN Globalny Numer Jednostki Handlowej [pole
fakultatywne]

Podaje się cyfrowy kod GTIN towaru lub usługi, których
sprzedaż jest dokumentowana fakturą.
GTIN to numer pozwalający na identyfikację towarów i
usług na całym świecie, jest to cyfrowy odpowiednik
kodu EAN.
PKWIU
Symbol Polskiej Klasyfikacji Wyrobów i Usług [pole
fakultatywne]

Obecnie na potrzeby podatku od towarów i usług,
stosuje się Polską Klasyfikację Wyrobów i Usług z 2015 r.
Symbol CN Nomenklatury Scalonej [pole fakultatywne]

Podaje się symbol Nomenklatury Scalonej CN.
PKOB
Symbol Polskiej Klasyfikacji Obiektów Budowlanych
[pole fakultatywne]
Podaje się symbol Polskiej Klasyfikacji Obiektów
Budowlanych.
Schemat 47. Struktura elementu FaWiersz dla Fa (od pola P_8A do pola P_12_XII)

Tabela 47. Opis struktury elementu FaWiersz dla Fa (od pola P_8A do pola P_12_XII)

Nazwa pola Opis pola
P_8A Miara dostarczonych towarów lub zakres wykonanych
usług [pole opcjonalne]
Pole nie jest wymagane dla przypadku określonego w
art. 106e ust. 5 pkt 3 ustawy (faktura uproszczona do
450 zł).
P_8B Ilość (liczba) dostarczonych towarów lub zakres
wykonanych usług [pole opcjonalne]
Pole nie jest wymagane dla przypadku określonego w
art. 106e ust. 5 pkt 3 ustawy (faktura uproszczona do
450 zł).
P_9A Cena jednostkowa towaru lub usługi bez kwoty podatku
(cena jednostkowa netto) [pole opcjonalne]
Pole nie jest wymagane dla przypadków określonych w
art. 106e ust. 2 i 3 oraz ust. 5 pkt 3 ustawy (tj.
świadczenie usług turystyki, dla których podstawę
opodatkowania stanowi marża zgodnie z art. 119
ustawy; dostawa towarów używanych, dzieł sztuki,
przedmiotów kolekcjonerskich, antyków, dla których
podstawę opodatkowania stanowi marża zgodnie z art.
120 ust. 4 i ust. 5 ustawy; faktura uproszczona do 450
zł).
Maksymalna liczba miejsc po kropce: 8
P_9B Cena wraz z kwotą podatku (cena jednostkowa brutto)
[pole zwolnienia]

Pole dotyczy przypadku zastosowania art. 106e ust. 7 i 8
ustawy – tj. gdy kwotę podatku w odniesieniu do
dostarczanych towarów lub świadczonych usług
objętych daną stawką podatku podatnik oblicza według
następującego wzoru:
KP = WB x SP/100+SP
gdzie
KP - oznacza kwotę podatku,
WB - oznacza wartość dostarczonych towarów lub
wykonanych usług objętych stawką podatku,
uwzględniającą kwotę podatku (wartość sprzedaży
brutto),
SP - oznacza stawkę podatku.
Jeżeli podatnik oblicza kwotę podatku w powyższy
sposób, zamiast ceny jednostkowej netto podatnik
może wykazywać na fakturze cenę wraz z kwotą
podatku (cenę jednostkową brutto), a zamiast wartości
sprzedaży netto - wartość sprzedaży brutto.
Maksymalna liczba miejsc po kropce: 8
P_10 Kwoty każdego opustów lub obniżek cen, w tym w
formie rabatu z wcześniejszego otrzymania, o ile nie
zostało dostarczone jedno w cenie jednostkowej netto, a
w przypadku zastosowania art. 106e ust. 7 ustawy w cenie
jednostkowej brutto

Pole nie jest wymagane dla przypadków określonych w
art. 106e ust. 2 i 3 oraz ust. 5 pkt 1 ustawy, tj.:
świadczenie usług turystyki, dla których podstawę
opodatkowania stanowi marża zgodnie z art. 119
ustawy; dostawa towarów używanych, dzieł sztuki,
przedmiotów kolekcjonerskich, antyków, dla których
podstawę opodatkowania stanowi marża zgodnie z art.
120 ust. 4 i ust. 5 ustawy; dostawa towarów i
świadczenie usług dokonywanych przez podatnika
posiadającego na terytorium kraju siedzibę działalności
gospodarczej lub stałe miejsce prowadzenia działalności
gospodarczej, z którego dokonywane są te czynności, a
w przypadku braku na terytorium kraju siedziby
działalności gospodarczej oraz stałego miejsca
prowadzenia działalności gospodarczej - posiadającego
na terytorium kraju stałe miejsce zamieszkania albo
zwykłe miejsce pobytu, z którego dokonywane są te
czynności, w przypadku gdy miejscem świadczenia jest
terytorium państwa członkowskiego inne niż terytorium
kraju, a osobą zobowiązaną do zapłaty podatku od
wartości dodanej jest nabywca towaru lub usługobiorca
i faktura dokumentująca te czynności nie jest
wystawiana przez tego nabywcę lub usługobiorcę w
imieniu i na rzecz podatnika.
Maksymalna liczba miejsc po kropce: 8
P_11 Wysokość kwoty pobieranej przez podatnika lub usługi,
która obejmuje transakcję, bez podatku (wartość
sprzedaży netto) [pole podlegające]

Pole nie jest wymagane dla przypadków określonych w
art. 106e ust. 2 i 3 oraz ust. 5 pkt 3 ustawy, tj.
świadczenie usług turystyki, dla których podstawę
opodatkowania stanowi marża zgodnie z art. 119
ustawy; dostawa towarów używanych, dzieł sztuki,
przedmiotów kolekcjonerskich, antyków, dla których
podstawę opodatkowania stanowi marża zgodnie z art.
120 ust. 4 i ust. 5 ustawy; faktura uproszczona do 450 zł.
P_11A
Wartość sprzedaży brutto, w przypadku zastosowania
art. 106e ust. 7 i 8 ustawy [pole opcjonalne]
Pole dotyczy przypadku zastosowania art. 106e ust. 7 i 8
ustawy – tj., gdy kwotę podatku w odniesieniu do
dostarczanych towarów lub świadczonych usług
objętych daną stawką podatku podatnik oblicza według
następującego wzoru:
KP = WB x SP/100+SP
gdzie
KP - oznacza kwotę podatku,
WB - oznacza wartość dostarczonych towarów lub
wykonanych usług objętych stawką podatku,
uwzględniającą kwotę podatku (wartość sprzedaży
brutto),
SP - oznacza stawkę podatku.
Jeżeli podatnik oblicza kwotę podatku w powyższy
sposób, zamiast ceny jednostkowej netto podatnik
może wykazywać na fakturze cenę wraz z kwotą
podatku (cenę jednostkową brutto), a zamiast wartości
sprzedaży netto - wartość sprzedaży brutto.
P_11Vat
Kwota podatku w przypadku, o której mowa w art.
106e ust. 10 ustawy

Zgodnie z art. 106e ust. 10 ustawy podatnik może
określić na fakturze również kwoty podatku dotyczące
wartości poszczególnych dostarczonych towarów i
wykonanych usług wykazanych w tej fakturze; w tym
przypadku łączna kwota podatku może być ustalona w
wyniku podsumowania jednostkowych kwot podatku.
P_12 Stawka podatku [pole wolne]:

„23” - w przypadku stawki 23%
„22” - w przypadku stawki 22%
„ 8 ” - w przypadku stawki 8%
„7” – w przypadku stawki 7%
„ 5 ” - w przypadku stawki 5%
„ 4 ” - w przypadku stawki 4 %
„ 3 ” - w przypadku stawki 3%
„ 0 KR” - w przypadku stawki 0% dla sprzedaży towarów
i świadczenia usług na terytorium kraju (z wyłączeniem
WDT i eksportu)
„0 WDT” - w przypadku stawki 0% dla
wewnątrzwspólnotowej dostawy towarów
„0 EX” - w przypadku stawki 0% dla eksportu towarów
„zw” - w przypadku zwolnienia od podatku
„oo” - w przypadku odwrotnego obciążenia w obrocie
krajowym
„np I” - w przypadku niepodlegających opodatkowaniu
dostaw towarów oraz świadczenia usług poza
terytorium kraju, z wyłączeniem transakcji, o których
mowa w art. 100 ust. 1 pkt 4 ustawy oraz OSS
„np II” – w przypadku niepodlegającego
opodatkowaniu na terytorium kraju, świadczenia usług
o których mowa w art. 100 ust. 1 pkt 4 ustawy.
Pole nie jest wymagane dla przypadków określonych w
art. 106e ust. 2, 3, ust. 4 pkt 3 i ust. 5 pkt 3 ustawy, tj.:
świadczenie usług turystyki, dla których podstawę
opodatkowania stanowi marża zgodnie z art. 119
ustawy; dostawa towarów używanych, dzieł sztuki,
przedmiotów kolekcjonerskich, antyków, dla których
podstawę opodatkowania stanowi marża zgodnie z art.
120 ust. 4 i ust. 5 ustawy; sprzedaż zwolniona, o której
mowa w art. 106b ust. 3 pkt 2 ustawy, faktura
uproszczona do 450 zł.
P_12_XII Stawka podatku od wartości dodanej w przypadku, o
którym mowa w dziale XII w rozdziale 6a ustawy [pole
opcjonalne]
Podaje się stawkę podatku od wartości dodanej w
przypadku wystawienia faktury dokumentującej
czynności realizowane przez podatnika
zidentyfikowanego na terytorium kraju do procedury
unijnej OSS.
Na stronie Komisji Europejskiej dostępna jest Baza
stawek podatkowych w innych krajach UE.
Schemat 48. Struktura elementu FaWiersz dla Fa (od pola P_12_Zal_15 do pola StanPrzed)

Tabela 48. Opis struktury elementu FaWiersz dla Fa (od pola P_12_Zal_15 do pola StanPrzed)

Nazwa pola Opis pola
P_12_Zal_15 Znacznik dla towaru lub usługi wymienionych w
załączniku nr 15 do ustawy [pole fakultatywne]
W przypadku sprzedaży towaru lub usługi wymienionych
w załączniku nr 15 do ustawy (niezależnie czy transakcja
podlega obowiązkowemu mechanizmowi podzielonej
płatności czy nie podlega) podaje się wartość „1".
KwotaAkcyzy Kwota podatku akcyzowego zawarta w cenie towaru
[pole fakultatywne]
Zgodnie z art. 10 ust. 12 ustawy z dnia 6 grudnia 2008 r.
o podatku akcyzowym^4 na żądanie nabywcy podatnik
akcyzy wykazuje w fakturze lub oświadczeniu
załączanym do faktury kwotę akcyzy zawartą w cenie
wyrobów akcyzowych wykazanych w tej fakturze.
GTU Oznaczenie dotyczące dostawy towaru i świadczenia
usług [pole fakultatywne]
Podaje się:
„GTU_01” - w przypadku dostawy towarów, o których
mowa w § 10 ust. 3 pkt 1 lit. a rozporządzenia w sprawie
JPK_VAT z deklaracją.
Symbol „GTU_01” oznacza dostawę napojów
alkoholowych o zawartości alkoholu powyżej 1,2%, piwa
oraz napojów alkoholowych będących mieszaniną piwa i
napojów bezalkoholowych, w których zawartość
alkoholu przekracza 0,5% (CN od 2203 do 2208).
„GTU_02” - w przypadku dostawy towarów, o których
mowa w § 10 ust. 3 pkt 1 lit. b rozporządzenia w sprawie
JPK_VAT z deklaracją.
Symbol „GTU_02” oznacza dostawę towarów, o których
mowa w art. 103 ust. 5aa ustawy.
„GTU_03” - w przypadku dostawy towarów, o których
mowa w § 10 ust. 3 pkt 1 lit. c rozporządzenia w sprawie
JPK_VAT z deklaracją.
Symbol „GTU_03” oznacza dostawę olejów opałowych
nieujętych w § 10 ust. 3 pkt 1 lit. b, olejów smarowych i
pozostałych olejów (CN od 2710 19 71 do 2710 19 83 i
CN od 2710 19 87 do 2710 19 99, z wyłączeniem
smarów plastycznych zaliczonych do kodu CN 2710 19
99), olejów smarowych (CN 2710 20 90) oraz
preparatów smarowych (CN 3403, z wyłączeniem
smarów plastycznych objętych tą pozycją).
(^4) Dz. U. z 202 5 r. poz. 126 ze zm.

„GTU_04” - w przypadku dostawy towarów, o których
mowa w § 10 ust. 3 pkt 1 lit. d rozporządzenia w sprawie
JPK_VAT z deklaracją.
Symbol „GTU_04” oznacza dostawę wyrobów
tytoniowych, suszu tytoniowego, płynu do papierosów
elektronicznych i wyrobów nowatorskich, w rozumieniu
przepisów o podatku akcyzowym.

„GTU_05” - w przypadku dostawy towarów, o których
mowa w § 10 ust. 3 pkt 1 lit. e rozporządzenia w sprawie
JPK_VAT z deklaracją.
Symbol „GTU_05” oznacza dostawę odpadów -
wyłącznie określonych w poz. 79-91 załącznika nr 15 do
ustawy.

„GTU_06” - w przypadku dostawy towarów, o których
mowa w § 10 ust. 3 pkt 1 lit. f rozporządzenia w sprawie
JPK_VAT z deklaracją.
Symbol „GTU_06” oznacza dostawę urządzeń
elektronicznych oraz części i materiałów do nich,
wyłącznie określonych w poz. 7, 8, 59-63, 65, 66, 69 i 94-
96 załącznika nr 15 do ustawy, a także folii typu stretch
określonej w poz. 9 tego załącznika.

„GTU_07” - w przypadku dostawy towarów, o których
mowa w § 10 ust. 3 pkt 1 lit. g rozporządzenia w sprawie
JPK_VAT z deklaracją.
Symbol „GTU_07” oznacza dostawę pojazdów oraz
części (CN od 8701 do 8708).

„GTU_08” - w przypadku” dostawy dostaw, o których
mowa w § 10 ust. 3 pkt 1 lit. h rozporządzenia w sprawie
JPK_VAT z deklaracją.
Symbol „GTU_08” oznacza dostawę metali szlachetnych
oraz nieszlachetnych - wyłącznie podstawowych w poz. 1 i
1a zamordowana nr 12 do ustawy oraz w poz. 12-25, 33-40,
45, 46, 56 i 78 zamordowany nr 15 do ustawy.

„GTU_09” - w przypadku dostawy, o której
mowa w § 10 ust. 3 pkt 1 lit. i rozporządzenia w sprawie
JPK_VAT z deklaracją.
Symbol „GTU_09” oznacza dostawę produktów
leczniczych, środków spożywczych specjalnego
przeznaczenia żywieniowego oraz wyrobów medycznych
będący jedynym obowiązkiem zgłoszenia, o którym
mowa w art. 37av ust. 1 ustawy z dnia 6 września 2001
r. - Prawo farmaceutyczne^5.
„GTU_10” - w przypadku dostawy, o której
mowa w § 10 ust. 3 pkt 1 lit. j rozporządzenia w sprawie
JPK_VAT z deklaracją.
Symbol „GTU_10” oznacza dostawę budynków, budowli
i gruntów oraz ich części i udziałów w prawie własności,
w tym również zbycia praw, o których mowa w art. 7
ust. 1 ustawy.
„GTU_11” - w dodatku do usług, o których
mowa w § 10 ust. 3 pkt 2 lit. a rozporządzenie w sprawie
JPK_VAT z deklaracją.
Symbol „GTU_11” oznacza świadczenie usług w zakresie
przenoszenia uprawnień do emisji gazów
cieplarnianych, o których mowa w ustawie z dnia 12
czerwca 2015 r. o systemie handlu uprawnieniami do
emisji gazów cieplarnianych^6.
„GTU_12” - w dodatku do usług, o których
mowa w § 10 ust. 3 pkt 2 lit. b rozporządzenia w sprawie
JPK_VAT z deklaracją.
Symbol „GTU_12” oznacza świadczenie usług o
charakterze niematerialnym - wyłącznie: doradczych, w
tym doradztwa prawnego i podatkowego oraz
doradztwa związanego z zarządzaniem (PKWiU 62.02.1,
62.02.2, 66.19.91, 69.20.3, 70.22.11, 70.22.12, 70.22.13,
70.22.14, 70.22.15, 70.22.16, 70.22.3, 71.11.24,
71.11.42, 71.12.11, 71.12.31, 74.90.13, 74.90.15,
74.90.19), w zakresie rachunkowości i audytu
finansowego (PKWiU 69.20.1, 69.20.2), prawnych
(PKWiU 69.1), zarządczych (PKWiU 62.03, 63.11.12,
66.11.19, 66.30, 68.32, 69.20.4, 70.22.17, 70.22.2,
90.02.19.1), firm centralnych (PKWiU 70.1),
marketingowych lub reklamowych (PKWiU 73.1),
(^5) Dz. U. z 2024 r. poz. 686
(^6) Dz. U. z 2024 r. poz. 1505 ze zm.

badania rynku i opinii publicznej (PKWiU 73.2), w
zakresie badań naukowych i prac rozwojowych (PKWiU
72) oraz w zakresie pozaszkolnych form edukacji (PKWiU
85.5).
„GTU_13” - w dodatku do usług, o których
mowa w § 10 ust. 3 pkt 2 lit. c rozporządzenia w sprawie
JPK_VAT z deklaracją.
Symbol „GTU_13” oznacza świadczenie usług
transportowych i gospodarki magazynowej (PKWiU 49.4,
52.1).
Procedura oznaczenia procedury dostarczania towaru
lub uwierzytelnienia usług [pole fakultatywne]

Podaje się:
„WSTO_EE” – w przypadku procedury, o której mowa
w § 10 ust. 4 pkt 2a rozporządzenia w sprawie JPK_VAT
z deklaracją.
Symbol „WSTO_EE” oznacza wewnątrzwspólnotową
sprzedaż na odległość towarów, które w momencie
rozpoczęcia ich wysyłki lub transportu znajdują się na
terytorium kraju, oraz świadczenie usług
telekomunikacyjnych, nadawczych i elektronicznych, o
których mowa w art. 28k ustawy, na rzecz podmiotów
niebędących podatnikami, posiadających siedzibę, stałe
miejsce zamieszkania lub miejsce pobytu na terytorium
państwa członkowskiego innym niż terytorium kraju.
„IED” - w przypadku postępowania, o którym mowa w § 10
ust. 4 pkt 2b rozporządzenia w sprawie JPK_VAT z
deklaracją.
Symbol „IED” oznacza dostawę towarów, o której mowa
w art. 7a ust. 1 i 2 ustawy, dokonaną przez podatnika
ułatwiającego tę dostawę, który nie korzysta z
procedury szczególnej, o której mowa w dziale XII w
rozdziale 6a lub 9 ustawy lub w odpowiadających im
regulacjach, dla której miejscem dostawy jest
terytorium kraju.
„TT_D” – w przypadku procedury, o której mowa w §
10 ust. 4 pkt 5 rozporządzenia w sprawie JPK_VAT z
deklaracją.
Symbol „TT_D” oznacza dostawę poza
krajem centralnym, przez drugą w zasięgu połączenia
VAT w ramach transakcji trójstronnej w
procedurze uproszczonej, której mowa w XII
rozdziale.

„I_42” – w przypadku procedury, o której mowa § 10
ust. 4 pkt 8 rozporządzenia w sprawie JPK_VAT z
deklaracją.
Symbol „I_42” oznacza wewnątrzwspólnotową dostawę
następującą po porcie usług w
ramach procedury celnej 42 (import).

„I_63” w przypadku postępowania, o którym mowa § 10 ust.
4 pkt 9 rozporządzenia w sprawie JPK_VAT z deklaracją.
Symbol „I_63” oznacza wewnątrzwspólnotową dostawę
następującą po porcie usług w
ramach procedury celnej 63 (import).

„B_SPV” - w przypadku procedury, o której mowa w §
10 ust. 4 pkt 10 rozporządzenia w sprawie JPK_VAT z
deklaracją.
Symbol „B_SPV” oznacza transfer bonusu jednego
przeznaczenia, który jest udostępniany przez użytkowników
własnych, określonych w art. 8a
ust. 1 ustawy.

„B_SPV_DOSTAWA” - w przypadku postępowania, o którym
mowa w § 10 ust. 4 pkt 11 rozporządzenia w sprawie
JPK_VAT z deklaracją.
Symbol „B_SPV_DOSTAWA” oznacza dostawę usług
oraz świadczenie usług, których dotyczy jedno
przeznaczenie na rzecz, która wyemitowała
bon zgodnie z art. 8a ust. 4 ustawy.

„B_MPV_PROWIZJA” – w przypadku postępowania, o
którym mowa w § 10 ust. 4 pkt 12 rozporządzenia w
sprawie JPK_VAT z deklaracją.
Symbol „B_MPV_PROWIZJA” oznacza świadczenie usług
pośrednictwa oraz inne usługi dotyczące transferu
bonusu przeznaczenia, świadczeń zgodnie
z art. 8b ust. 2 ustawy.

KursWaluty Kurs waluty stosowany do wyliczenia kwoty podatku w
przypadkach, o których mowa w dziale VI ustawy [pole
fakultatywne]
W przypadku, gdy kwoty stosowane do określenia
podstawy opodatkowania są określone w walucie obcej,
podaje się kurs waluty właściwy dla danego wiersza
faktury.
StanPrzed Znacznik stanu przed korektą w przypadku faktury
korygującej lub faktury korygującej fakturę wystawioną
w związku z art. 106f ust. 3 ustawy, w przypadku, gdy
korekta dotyczy danych wykazanych w pozycjach faktury
i jest dokonywana w sposób polegający na wykazaniu
danych przed korektą i po korekcie jako osobnych
wierszy z odrębną numeracją oraz w przypadku
potwierdzania braku zmiany wartości danej pozycji [pole
fakultatywne]
Podaje się „1” w przypadku, gdy dany wiersz faktury
dotyczy stanu przed korektą.
WAŻNE
Oznaczenia dotyczące dostawy i usług usług (GTU_01 - GTU_13) zawierają
fakultatywny element faktury. odpowiedni symbolu GTU na fakturze
wyłącznie od umywalki. Przepis w tym zakresie nie podlega zmianie. Ujęcie na fakturze
ustrukturyzowanej ww. Informacje mogą jednak dotyczyć rozporządzenia JPK_VAT z
deklaracją.

Zasadnicze zastosowanie w odniesieniu do zasad stosowania ww. Oznaczenie w JPK_VAT z deklaracją
polegającą na tym, oznaczenie GTU na fakturze ustrukturyzowanej, zawartej na poziomie
elementu FaWiersz (tzn. podanego wiersza faktury). W JPK_VAT z deklaracją w
ewidencji sprzedaży, symbolami GTU oznaczają z kolei fakturę VAT.

Oznaczenia GTU można zastosować w odniesieniu do rodzaju transakcji dokumentowanej fakturą
(np. sprzedaż krajowa, WDT, eksport czy dostawa lub świadectwo usług
niepodlegających przepisom na terytorium kraju) pod szczegółowym, że wymagane jest przekazanie ich do
określonego symbolu GTU. Oznaczenie GTU może być opisane jako w
wierszu faktury krajowej („VAT”), faktury korygującej („KOR”), faktury rozliczeniowej i
jej krytycznej („ROZ”, „KOR_ROZ”) jak i faktury uproszczonej („UPR”).

W przypadku faktury korygującej oznaczenie GTU można zastosować, jeśli korekta dotyczy
towaru/usługi stosowanej do oznaczenia GTU.

W przypadku faktur zaliczkowych i ich korekt („ZAL”, „KOR_ZAL”), dla których wypełnia się
element Zamowienie, można zidentyfikować oznaczenia usług i usług związanych
z zamówieniami lub potwierdzeniem w tym elemencie (GTUZ).

WAŻNE
Oznaczenia dotyczące procedury (I_42, I_63, B_SPV, itd.) zawierają fakultatywny element
faktury. Oznaczenia procedury na fakturze zależą wyłącznie od woliery.
Przepis w tym zakresie nie podlega zmianie. Ujęcie na fakturze ustrukturyzowanej ww.
Informacje mogą jednak dotyczyć rozporządzenia JPK_VAT z deklaracją.

Zasadnicze zastosowanie w odniesieniu do zasad stosowania ww. Oznaczenie w JPK_VAT z deklaracją
polegającą na tym, oznaczenie procedury na fakturze ustrukturyzowanej, zawartej na
poziomie elementu FaWiersz (tzn. dotyczy otrzymania wiersza faktury). W JPK_VAT z
deklaracją w ewidencji sprzedaży, oznaczenie procedury dotyczy natomiast całego
dokumentu (faktury, uzasadnienie wewnętrzne).

Oznaczenie procedury może być podane w wierszu faktury krajowej („VAT”),
faktury korygującej („KOR”), faktury rozliczeniowej i jej krytycznej („ROZ”, „KOR_ROZ”) jak i
faktury uproszczonej („UPR”).

W przypadku faktury korygującej, którą można zastosować, jeśli korekta dotyczy
towaru/usługi stosowanej w procedurze składania wniosków.

W przypadku faktur zaliczkowych i ich korekt („ZAL”, „KOR_ZAL”), dla których wypełnia się
element Zamowienie, można zidentyfikować oznaczenie procedury, znaczenie w tym
elemencie (ProceduraZ).

Przykład 22. Sposób wypełnienia FaWiersz dla Fa

Stan faktyczny:

Podatnik VAT sprzedaje:

w dniu 12.0 9 .202 6 r. - 3 koce polarowe (cena jednostkowa 90 zł, wartość netto 3
sztuki równa się 270 zł) oraz
w dniu 14.0 9 .202 6 r. - 5 kompletów pościeli pościeli (cena jednostkowa 120 zł,
wartość netto 5 sztuk równa się 600 zł).
Podatnik wystawiający fakturę ustrukturyzowaną, dokumentującą tę sprzedaż i nieobliczającą
podatku VAT na podstawie art. 106e ust. 7 i 8 ustawy.

Element FaWiersz jest producentem sprzedaży z dnia 12. 09 .202 6 r. wypełnić hipotezy:

Nazwa pola Sposób wypełnienia
Fa/FaWiersz NrWierszaFa 1
P_6A 2026 - 09 - 12
P_7 Koc polarowy
P_8A szt.
P_8B 3
P_9A 90
P_11 270
P_12 23
Element FaWiersz jest producentem sprzedaży z dnia 14.0 9 .202 6 r. wypełnić hipotezy:

Nazwa pola Sposób wypełnienia
Fa/FaWiersz NrWierszaFa 2
P_6A 2026 - 09 - 14
P_7 Pościel bawełniana
P_8A szt.
P_8B 5
P_9A 120
P_11 600
P_12 23
Przykład 23. Sposób wypełnienia FaWiersz dla Fa

Stan faktyczny:

Podatnik, o którym mowa w komentarzach, które pochodzą z postaci 1
szt. koca polarowego oraz 2 komplety pościeli. Wystawa w związku z tą fakturą
korygującą.

Istnieje kilka sposobów prezentowania tego typu korekt w elemencie FaWiersz. Pierwszy –
polega na wykazywaniu tzw. różnicowy, drugi – polegający na wykazywaniu stanu „przed”
(korektą) oraz stanu „po” (korekcie).

Metoda pierwsza:

Element FaWiersz w zakresie 1 szt. koca polarowego można wypełnić twierdzenia:

Nazwa pola Sposób wypełnienia
Fa/FaWiersz NrWierszaFa 1
P_6A 2026 - 09 - 12
P_7 Koc polarowy
P_8A szt.
P_8B - 1
P_9A 90
P_11 - 90
P_12 23
Element FaWiersz w zakresie 2 kompletów pościeli można odpowiedzieć na następujące pytania:

Nazwa pola Sposób wypełnienia
Fa/FaWiersz NrWierszaFa 2
P_6A 2026 - 09 - 14
P_7 Pościel bawełniana
P_8A szt.
P_8B - 2
P_9A 120
P_11 - 240
P_12 23
Metoda druga:

Element FaWiersz w zakresie 1 szt. koca polarowego (stan „przed”):

Nazwa pola Sposób wypełnienia
Fa/FaWiersz NrWierszaFa 1
P_6A 2026 - 09 - 12
P_7 Koc polarowy
P_8A szt.
P_8B 3
P_9A 90
P_11 270
P_12 23
StanPrzed 1
Element FaWiersz w zakresie 1 szt. koca polarowego (stan „po”):

Nazwa pola Sposób wypełnienia
Fa/FaWiersz NrWierszaFa 1
P_6A 2026 - 09 - 12
P_7 Koc polarowy
P_8A szt.
P_8B 2
P_9A 90
P_11 180
P_12 23
Element FaWiersz w zakresie 2 kompletów pościeli (stan „przed”):

Nazwa pola Sposób wypełnienia
Fa/FaWiersz NrWierszaFa 2
P_6A 2026 - 09 - 14
P_7 Pościel bawełniana
P_8A szt.
P_8B 5
P_9A 120
P_11 600
P_12 23
StanPrzed 1
Element FaWiersz w zakresie 2 kompletów pościeli (stan „po”):

Nazwa pola Sposób wypełnienia
Fa/FaWiersz NrWierszaFa 2
P_6A 2026 - 09 - 14
P_7 Pościel bawełniana
P_8A szt.
P_8B 3
P_9A 120
P_11 360
P_12 23
Alternatywą, alternatywne rozwiązanie do metod oznaczonego znacznika StanPrzed jest
korygowanie przez storna (różnica polega na tym, że zamiast stosowania znacznika
StanPrzed, wiersz występujący się stanowi przed korektą prezentowany jest ze znakiem
ostrzegawczym).

Element Rozliczenie dla Fa
Element Rozliczania ma charakter fakultatywny. Dostęp do treści faktury
ustrukturyzowanej informacji w zakresie dotyczącym zastosowania lub odliczeń, wpływających
na stan konta, jest możliwy do uiszczenia za pośrednictwem konta lub usługobiorcy.
Dotyczy wyłącznie sytuacji, gdy faktura dokumentuje podlegającą ustawie, a
oprócz tego zawiera ww. dane dodatkowe o kontroli lub odliczeniach.

Może to być przykładowo:

zwroty historyczne, które są dostarczane przez użytkowników
,
rozliczenie salda klienta (np. w związku z wpłatami klienta w zbyt wysokiej wartości),
rozliczenie kwoty (różnicy) określone z wystawionych wcześniej faktur
korygujących in minus/in plus.
Wymagane, że nie są stosowane faktury urzędowe, które nie
podlegają obowiązkowi ustawowemu np. dokumentujące otrzymanie odszkodowania.

Schemat 49. Struktura elementu Rozliczenie dla Fa

Tabela 49. Opis struktury elementu Rozliczenie dla Fa

Nazwa pola Opis pola
Obciazenia Element zawierający informacje w zakresie obciążeń
[element fakultatywny]
W przypadku, gdy podatnik zdecyduje się wypełnić
element fakultatywny Obciazenia, wówczas
obligatoryjne staje się uzupełnienie obu występujących
w nim pól: Kwota oraz Powod.
Maksymalna ilość wystąpień: 100
SumaObciazen Suma obciążeń [pole fakultatywne]
Podaje się sumę kwot wskazanych w polu Kwota w
elementach Obciazenia.
Odliczenia Element zawierający informacje w zakresie odliczeń
[element fakultatywny]
W przypadku, gdy podatnik zdecyduje się wypełnić
element fakultatywny Odliczenia, wówczas
obligatoryjne staje się uzupełnienie obu występujących
w nim pól: Kwota oraz Powod.
Maksymalna ilość wystąpień: 100
SumaOdliczen Suma odliczeń [pole fakultatywne]
Podaje się sumę kwot wskazanych w polu Kwota w
elementach Odliczenia.
DoZaplaty Kwota należności do zapłaty równa polu P_15
powiększonemu o Obciazenia i pomniejszonemu o
Odliczenia
Podaje się kwotę pozostałą do zapłaty stanowiącą wynik
powiększenia kwoty należności ogółem, wynikającej z
faktury (P_15), o sumę obciążeń i pomniejszenia jej o
sumę odliczeń.
Sekwencja składająca się z wyboru pomiędzy dwoma
polami DoZaplaty oraz DoRozliczenia ma charakter
fakultatywny. Jeżeli jednak podatnik zdecyduje się
wypełnić tę sekwencję, wówczas obligatoryjne staje się
wypełnienie jednego z ww. pól (w zależności od sytuacji
pole DoZaplaty lub DoRozliczenia).
DoRozliczenia Kwota nadpłacona do rozliczenia/zwrotu
Podaje się kwotę nadpłaconą do rozliczenia/zwrotu
stanowiącą wynik powiększenia kwoty należności
ogółem, wynikającej z faktury (P_15) o sumę obciążeń i
pomniejszenia jej o sumę odliczeń.
Sekwencja składająca się z wyboru pomiędzy dwoma
polami DoZaplaty oraz DoRozliczenia ma charakter
fakultatywny. Jeżeli jednak podatnik zdecyduje się
wypełnić tę sekwencję, wówczas obligatoryjne staje się
wypełnienie jednego z ww. pól (w zależności od sytuacji
pole DoZaplaty lub DoRozliczenia).
Schemat 50. Struktura elementu Obciazenia dla Rozliczenia

Tabela 50. Opis struktury elementu Obciazenia dla Rozliczenia

Nazwa pola Opis pola
Kwota Kwota doliczona do kwoty wykazanej w polu P_15
Podaje się kwotę obciążenia, doliczoną do kwoty
należności ogółem, wynikającej z faktury.
Powod Powód obciążenia
Podaje się przyczynę obciążenia.
Schemat 51. Struktura elementu Odliczenia dla Rozliczenia

Tabela 51. Opis struktury elementu Odliczenia dla Rozliczenia

Nazwa pola Opis pola
Kwota Kwota odliczona od kwoty wykazanej w polu P_15
Podaje się kwotę odliczenia, o którą pomniejszono
kwotę należności ogółem, wynikającą z faktury.
Powod Powód odliczenia
Podaje się przyczynę odliczenia.
Przykład 24. Sposób wypełniania Rozliczenia dla Fa

Stan faktyczny:

Podatnik VAT obejmuje wyposażenie pomocnicze i biurowe na rzecz innego urządzenia.
Wystawia fakturę dokumentującą tę niezbędną, opiewającą na dostępną dla społeczeństwa 246
zł (pole P_15 równe 246). Dołączone do Twojego odbiorcy płatności płatnicze
skarbowej 17 zł i powiadomienie w tym zakresie w formie fakturze. Powyższa
kwota, szersza art. 29a ust. 7 pkt 3 ustawy nie jest wliczana do podstaw
dotyczących podatków VAT, ponieważ stanowią one otrzymane od usługobiorcy zwroty
danych, które są przekazywane poniesionych przez administratora i na rzecz usługobiorcy i
ujmowanych przejściowo przez akcję w wydawaniu przez niego odprowadzającego
podatek. Potwierdzono przy płatnościach za fakturę z potwierdzeniem usługobiorca, który
pomylił się (wpłacając usługi dostawcy zbyt dużej kwoty), w związku z czym posiada obciążenie
saldo o wartości +300 zł.

Element Rozliczenie można wypełnić w sposób:

Nazwa pola Sposób wypełnienia
Fa/Rozliczenie/Obciazenia Kwota 17
Powod Zwrot kosztów - opłata skarbowa
Fa/Rozliczenie SumaObciazen 17
Fa/Rozliczenie/Odliczenia
Kwota 300
Powod Rozliczenie salda klienta
Fa/Rozliczenie SumaOdliczen 300
Fa/Rozliczenie DoRozliczenia 37
Element Platnosc dla Fa
Element fakultatywny Platnosc zawiera informacje dotyczące warunków płatności za towar
lub usługę, których sprzedaż dokumentowana jest fakturą. Są to m. in.:

dane w zakresie należności otrzymanych do momentu wystawienia faktury (ich
wartości, daty zapłaty),
termin płatności (w postaci daty dziennej lub opisowej),
forma płatności (przyszłej lub już dokonanej),
dane rachunku, na który była lub będzie realizowana płatność należności wynikającej
z faktury (numer rachunku, opis rachunku, nazwa banku),
informacje w zakresie wysokości oraz warunków skonta.
Wskazanie na fakturze ustrukturyzowanej takich danych ma charakter dobrowolny - przepisy
w tym zakresie nie uległy zmianie.

Warto również zaznaczyć, że zawarcie w treści faktury, terminu płatności należności z niej
wynikającej usprawni proces sporządzenia JPK_VAT z deklaracją, w przypadku, gdy podatnik
będzie dokonywał korekty – tzw. ulgi na złe długi. Za okresy począwszy od stycznia 2022 r. w
JPK_VAT z deklaracją występuje obowiązek podawania w ewidencji sprzedaży daty upływu
terminu płatności w przypadku korekty dokonanej zgodnie z art. 89a ust. 1 ustawy.

Dodatkowo biorąc pod uwagę przepisy:

art. 117ba § 3 ustawy z dnia 29 sierpnia 1997 r. Ordynacja Podatkowa^7 ,
art. 22p ust. 4 pkt 2 ustawy z dnia 26 lipca 1991 r. o podatku dochodowym od osób
fizycznych^8 ,
art. 15d ust. 4 pkt 2 ustawy z dnia 15 lutego 1992 r. o podatku dochodowym od osób
prawnych^9 ,
umożliwiono podatnikowi zawarcie w treści faktury ustrukturyzowanej informacji o rodzaju
rachunku banku lub rachunku spółdzielczej kasy oszczędnościowo-kredytowej (znacznik „1”,
„2” lub „3” w polu RachunekWlasnyBanku). Ujęcie na fakturze ww. danych stanowi jedną z
przesłanek do wyłączenia ewentualnej odpowiedzialności solidarnej nabywcy lub wyłączenia
braku możliwości zaliczenia wydatku w kosztach uzyskania przychodu.

(^7) Dz. U. z 2025 r. poz. 1 11 ze zm.
(^8) Dz. U. z 202 5 r. poz. 163 ze zm.
(^9) Dz. U. z 202 5 r. poz. 278 ze zm.

Schemat 52. Struktura elementu Platnosc dla Fa

Tabela 52. Opis struktury elementu Platnosc dla Fa

Nazwa pola Opis pola
Zaplacono Znacznik informujący, że należność wynikająca z faktury
została zapłacona
Podaje się „1” w przypadku, gdy należność wynikająca z
faktury, do momentu jej wystawienia, została zapłacona.
Uwaga!
W przypadku faktur zaliczkowych, wartość „1” w polu
Zaplacono oznacza, że kwota zaliczki wynikająca z faktury
została zapłacona do momentu wystawienia faktury
zaliczkowej.
DataZaplaty Data zapłaty, jeśli do wystawienia faktury płatność została
dokonana
Podaje się datę zapłaty w formacie RRRR-MM-DD (np.
2026 - 06 - 21) w przypadku, gdy pole Zaplacono przyjęło
wartość „1”.
ZnacznikZaplatyCzesciowej Znacznik informujący, że należność wynikająca z faktury
została zapłacona w części lub w całości

Podaje się:
„1” - w przypadku, gdy należność wynikająca z faktury,
została zapłacona w części,
„ 2 ” - w przypadku, gdy należność wynikająca z faktury
została zapłacona w całości - w dwóch lub więcej częściach,
a ostatnia płatność jest płatnością końcową.
ZaplataCzesciowa Element zawierający dane dotyczące zapłat częściowych tj.
daty, kwoty zapłat częściowych oraz formy płatności.

Maksymalna ilość wystąpień: 100
Terminplatnosci Element dotyczący danych końcowych dotyczących płatności
pieniężnej z faktury tj. termin płatności oraz
opis termin płatności [element fakultatywny]

Maksymalna ilość wystąpień: 100
FormaPlatnosci Forma płatności

Podaje się:
„1” - w przypadku płatności gotówkowej,
„2” - w przypadku płatności kartą,
„3” - w przypadku płatności bonem,
„4” - w przypadku płatności czekiem,
„5” – w przypadku kredytu,
„6” - w przypadku płatności przelewem,
„7” - w przypadku płatności mobilnych.
Uwaga!
Pole może dotyczyć płatności już dokonanej lub płatności
przyszłej.
PlatnoscInna Znacznik Inne formy płatności

Podaje się „1” – inna forma płatności, w przypadku
zawarcia na fakturze informacji o płatności w formie innej
niż przewidziana do wyboru w polu FormaPlatnosci (opcje
„1” – „7”).
OpisPlatnosci Uszczegółowienie Inne formy płatności

Podaje się opis innej formy płatności, w przypadku, gdy
pole PlatnoscInna przyjmuje wartość „1”.
RachunekBankowy Element złożony z danych rachunku, który był/będzie
dokonana płatności wychodzącej z faktury (m.in.
numer rachunku, opis rachunku, nazwa banku) [element
fakultatywny]

Maksymalna ilość wystąpień: 100
RachunekBankowyFaktora Element wydany dane rachunku faktycznego, który
był/będzie dokonana płatności wynikającej z
faktury (m.in. numer rachunku, opis rachunku, nazwa
banku) [element fakultatywny]

Maksymalna ilość wystąpień: 20
Skonto Element odprowadzający dane w zakresie skonta (warunki oraz
wysokość skonta) [element fakultatywny]

LinkDoPlatnosci Link do płatności bezgotówkowej [pole fakultatywne]

Podaje się link do płatności bezgotówkowej dla należności
wynikającej z faktury.
Przykład linku:
https://nazwaagenta.xyz/bramka?IPKSeF=001ABC123DEF4
Uwaga!
Link do płatności wygenerowany przez agenta
rozliczeniowego zawiera identyfikator płatności KSeF
jednoznacznie identyfikujący transakcję.
IPKSeF Identyfikator płatności KSeF [pole fakultatywne]

Podaje się identyfikator płatności bezgotówkowej,
wygenerowany przez agenta rozliczeniowego dla
należności wynikającej z faktury. IPKSeF powinien być
być unikalny i odnosić się wyłącznie do jednej płatności.
Uwaga!
Identyfikator płatności KSeF składa się z 13 znaków
alfanumerycznych (dopuszczone znaki: „0-9”, „a-z”, „A-Z”)
z czego:
pierwsze 3 znaki (np. „001”) definiują
identyfikator identyfikatora Agenta Rozliczeniowego (IAR),
pozostałych 10 znaków (np. „ABC123DEF4”) jest losowym,
ciągiem znaków nadanym przez agenta
rozliczeniowego, w celu uzyskania dostępu do płatności za e-
fakturę.
Przykład IP KSeF:
001ABC123DEF4
Uwaga!
Nie należy utożsamiać identyfikatora płatności
bezgotówkowej z identyfikatorem zbiorczym, o którym
mowa w art. 106nd ust. 2 pkt 8a ustawy.
WAŻNE
Pole ZnacznikZaplatyCzesciowej, może zostać zapisane w strukturze faktury ustrukturyzowanej
tylko jeden raz. W zamian element ZaplataCzesciowa, tworzący się z pól
KwotaZaplatyCzesciowej, DataZaplatyCzesciowej oraz informacje o płatnościach,
tworzą poszczególne części płatności, które mogą zostać wysłane na fakturze ustrukturyzowanej maksymalnie
100 razy. otrzymano trzy płatności częściowe po dostawie
lub po wykonaniu usługi, a przed wystawieniem faktury (składającej się na 100%
należności z faktury) głównego przedstawiciela zawrzeć na fakturze informacje w tym
zakresie:

w polu ZnacznikZaplatyCzesciowej wskaże wartość „ 2 ”, otrzymanie częściowego wsparcia, które jest
całkowicie dostępne na koncie z faktury,
element ZaplataCzesciowa tworzący się z pól KwotaZaplatyCzesciowej,
DataZaplatyCzesciowej, FormaPlatnosci/Platnoscinna, OpisPlatnosci elektroniczne trzy kontrolery kontroli
, daty otrzymania poszczególnych płatności częściowych oraz
dane dotyczące formularzy płatności.
Schemat 53. Struktura elementu ZaplataCzesciowa dla Platnosc

Tabela 53. Opis struktury elementu ZaplataCzesciowe dla Platnosc

Nazwa pola Opis pola
KwotaZaplatyCzesciowej Kwota zapłaty częściowej
Podaje się kwotę zapłaty częściowej w przypadku, gdy
pole ZnacznikZaplatyCzesciowej przyjmuje wartość „1”.
DataZaplatyCzesciowej Data zapłaty częściowej, jeśli do wystawienia faktury
płatność częściowa została dokonana
Podaje się datę zapłaty częściowej w formacie RRRR-
MM-DD (np. 202 6 - 05 - 21) w przypadku, gdy pole
ZnacznikZaplatyCzesciowej przyjmuje wartość „1”.
FormaPlatnosci Forma płatności dotycząca zapłaty częściowej
Podaje się:
„1” - w przypadku płatności gotówkowej,
„2” - w przypadku płatności kartą,
„3” - w przypadku płatności bonem,
„4” - w przypadku płatności czekiem,
„5” – w przypadku kredytu,
„6” - w przypadku płatności przelewem,
„7” - w przypadku płatności mobilnych.
Uwaga!
W przypadku, gdy należność z faktury została zapłacona
przy użyciu innej formy płatności niż wskazane wyżej
(„1”-”7”) zamiast pola FormaPlatnosci można wypełnić
pola PlatnoscInna oraz OpisPlatnosci.
Uwaga!
Pola FormaPlatnosci oraz PlatnoscInna, OpisPlatnosci
znajdują się sekwencji fakultatywnej typu choice.
Oznacza to, że podatnik chcąc podać formę płatności
dotyczącą danej zapłaty częściowej wypełnia:
pole FormaPlatnosci lub
pola PlatnoscInna oraz OpisPlatnosci.
PlatnoscInna Znacznik innej formy płatności zapłaty częściowej
Podaje się „1” – inna forma płatności, w przypadku
zawarcia na fakturze informacji o płatności dotyczącej
danej zapłaty częściowej w formie innej niż
przewidziana do wyboru w polu FormaPlatnosci (opcje
„1” – „7”).
Uwaga!
Pola FormaPlatnosci oraz PlatnoscInna, OpisPlatnosci
znajdują się sekwencji fakultatywnej typu choice.
Oznacza to, że podatnik chcąc podać formę płatności
dotyczącą danej zapłaty częściowej wypełnia:
pole FormaPlatnosci lub
pola PlatnoscInna oraz OpisPlatnosci.
OpisPlatnosci Uszczegółowienie innej formy płatności
Podaje się opis innej formy płatności dotyczącej danej
zapłaty częściowej, w przypadku, gdy pole PlatnoscInna
przyjmuje wartość „1”.
Uwaga!
Pola FormaPlatnosci oraz PlatnoscInna, OpisPlatnosci
znajdują się sekwencji fakultatywnej typu choice.
Oznacza to, że podatnik chcąc podać formę płatności
dotyczącą danej zapłaty częściowej wypełnia:
pole FormaPlatnosci lub
pola PlatnoscInna oraz OpisPlatnosci.
Schemat 54. Struktura elementu Terminplatnosci dla Platnosc

Tabela 54. Opis struktury elementu TerminPlatnosci dla Platnosc

Nazwa pola Opis pola
Termin Termin płatności [pole fakultatywne]
Podaje się termin płatności, należności wynikającej z
faktury, w formacie RRRR-MM-DD (np. 202 6 - 05 - 21).
Uwaga!
Pole może dotyczyć płatności już dokonanej lub
płatności przyszłej.
TerminOpis Opis terminu płatności [pole fakultatywne]
Podaje się opis terminu płatności np. 14 dni od dnia
wystawienia faktury.
Uwaga!
Pole może dotyczyć płatności już dokonanej lub
płatności przyszłej.
Schemat 55. Struktura elementu TerminOpis dla Terminplatnosci

Tabela 55. Opis struktury elementu TerminOpis dla Terminplatnosci

Nazwa pola Opis pola
Ilosc Ilość (pierwszy element opisu terminu płatności)
Podaje się ilość np. dni, o którego liczony jest termin
płatności za fakturę (np. „14”).
Jednostka
Jednostka czasu (drugi element opisu terminu płatności)
Podaje się jednostkę czasu, w której liczony jest termin
płatności za fakturę (np. dzień, tydzień itp.).
ZdarzeniePoczatkowe Zdarzenie początkowe (trzeci element opisu terminu
płatności)
Podaje się zdarzenie początkowe, od którego liczony jest
termin płatności za fakturę (np. wystawienie faktury).
Schemat 56. Struktura elementu RachunekBankowy dla Platnosc

Tabela 56. Struktura elementu RachunekBankowy dla Platnosc

Nazwa pola Opis pola
NrRB Pełny numer rachunku
Podaje się pełny numer rachunku (na który była/będzie
dokonana płatność należności wynikająca z faktury).
Minimalna ilość znaków: 10
Maksymalna ilość znaków: 34
SWIFT Kod SWIFT [pole fakultatywne]
Podaje się identyfikator (cyfrowo - literowy) instytucji
finansowej prowadzącej zagraniczny rachunek.
RachunekWlasnyBanku Typy rachunków własnych [pole fakultatywne]
Podaje się:
„1” - w przypadku rachunku banku lub rachunku
spółdzielczej kasy oszczędnościowo-kredytowej
pobierającej do rozliczeń z tytułu
nabywanych przez ten bank lub tę kasę wierzytelności
żydowskich,
„2” - w przypadku rachunku banku lub rachunku
spółdzielczej kasy oszczędnościowo-kredytowej
zapisanego przez ten bank lub tę kasę do
pobrania od kupującego usług lub za
dostawę szczegółową lub świadectwo usług,
fakturę, i przekazuję jej w całości albo część dostawcy
lub usługodawcy,
„3” - w przypadku rachunku banku lub rachunku
spółdzielczego kasy oszczędnościowo-kredytowej
stosowanego przez ten bank lub tę kasę w ramach
własnych własnych, niebędących rachunkówem
rozliczeniowym.
NazwaBanku Nazwa [pole fakultatywne]
Podaje się nazwę podmiotu, w którym prowadzony jest
rachunek, na który była/będzie dokonana płatność
należności wynikająca z faktury.
OpisRachunku Opis rachunku [pole fakultatywne]
Podaje się dodatkowe informacje opisujące rachunek,
na który była/będzie dokonana płatność należności
wynikająca z faktury.
Schemat 57. Struktura elementu RachunekBankowyFaktora dla Platnosc

Tabela 57. Opis struktury elementu RachunekBankowyFaktora dla Platnosc

Nazwa pola Opis pola
NrRB Pełny numer rachunku faktora
Podaje się pełny numer rachunku faktora (na który
była/będzie dokonana płatność należności wynikająca z
faktury).
Minimalna ilość znaków: 10
Maksymalna ilość znaków: 34
SWIFT Kod SWIFT [pole fakultatywne]
Podaje się identyfikator (cyfrowo - literowy) instytucji
finansowej prowadzącej zagraniczny rachunek.
RachunekWlasnyBanku Typy rachunków własnych [pole fakultatywne]
Podaje się:
„1” - w przypadku rachunku banku lub rachunku
spółdzielczej kasy oszczędnościowo-kredytowej
pobierającej do rozliczeń z tytułu
nabywanych przez ten bank lub tę kasę wierzytelności
żydowskich,
„2” - w przypadku rachunku banku lub rachunku
spółdzielczej kasy oszczędnościowo-kredytowej
wykorzystywanego przez ten bank lub tę kasę do
pobrania należności od nabywcy towarów lub usług za
dostawę towarów lub świadczenie usług, potwierdzone
fakturą, i przekazania jej w całości albo części dostawcy
towarów lub usługodawcy,
„3” - w przypadku rachunku banku lub rachunku
spółdzielczego kasy oszczędnościowo-kredytowej
stosowanego przez ten bank lub tę kasę w ramach
własnych własnych, niebędących rachunkówem
rozliczeniowym.
NazwaBanku Nazwa [pole fakultatywne]
Podaje się nazwę podmiotu, w którym prowadzony jest
rachunek faktora, na który była/będzie dokonana
płatność należności wynikająca z faktury.
OpisRachunku Opis rachunku [pole fakultatywne]
Podaje się dodatkowe informacje opisujące rachunek
faktora, na który była/będzie dokonana płatność
należności wynikająca z faktury.
Schemat 58. Struktura elementu Skonto dla Platnosc

Tabela 58. Opis struktury elementu Skonto dla Platnosc

Nazwa pola Opis pola
WarunkiSkonta Warunki, które nabywca powinien spełnić, aby
skorzystać ze skonta
Przykład:
„płatność w ciągu 7 dni od dnia wystawienia faktury”
WysokoscSkonta Wysokość skonta
Przykład:
„3% kwoty należności (brutto) wynikającej z faktury”
Przykład 25. Sposób wypełnienia Platnosc dla Fa

Stan faktyczny:

Podatnik VAT nabył usługę remontową w dniu 15.0 5 .202 6 r. Zapłaty za wyższą opłatę
wstępną w dniu 20.0 5.202 6 r., w formie przelewu. Administrator faktury w dniu
22.0 5.202 6 r., zawiera w niej m. w. informacja w zakresie otrzymanej płatności.

Element Platnosc, który można znaleźć w sytuacji, należy odpowiedzieć na następujące pytania:

Nazwa pola Sposób wypełnienia
Fa/Platnosc Zaplacono 1
DataZaplaty 2026 - 05 - 20
FormaPlatnosci 6
Przykład 26. Sposób wypełnienia Platnosc dla Fa

Stan faktyczny

Podatnik VAT w dniu 20. 06 .202 6 r. Dostęp do dostawy na rzecz drugiego wejścia.
Strony ustalone, że płatność następuje w trzech ratach, z pierwszą płatnością następującą
w gotówce, druga karta, trzecia przelewem na rachunek bankowy sprzedawcy (nr
11 1111 1111 1111 1111 1111 1111), w banku XYZ. Jest to kontroler prowadzony w PLN.
pierwsza rata (300 zł brutto) nabywca zapłacił 2 1 .0 6 .202 6 r., druga rata (400 zł brutto) w
2 4. 06 .202 6 r., a transakcji 28. 06 .202 6 r. (500 zł). Sprzedawca 0 4.07.202 6 r. płatność
fakturą na kwotę 1200 zł brutto. Informacje na temat otrzymywanych płatności częściowych
(wpłacane na konto dostępne) chcą być umieszczone na fakturze.

Element Platnosc, który można znaleźć w sytuacji, należy odpowiedzieć na następujące pytania:

Nazwa pola Sposób wypełnienia
Fa/Platnosc ZnacznikZaplatyCzesciowej 2
Fa/Platnosc/
ZaplataCzesciowa
KwotaZaplatyCzesciowej 300
DataZaplatyCzesciowej 2026 - 06 - 21
FormaPlatnosci 1
Fa/Platnosc/
ZaplataCzesciowa
KwotaZaplatyCzesciowej 400
DataZaplatyCzesciowej 2026 - 06 - 24
FormaPlatnosci 2
Fa/Platnosc/
ZaplataCzesciowa
KwotaZaplatyCzesciowej 2026 - 06 - 28
DataZaplatyCzesciowej 500 zł
FormaPlatnosci 6
Fa/Platnosc/ NrRB 11111111111111111111111111
RachunekBankowy NazwaBanku XYZ
OpisRachunku Rachunek prowadzony w walucie
krajowej (PLN)
Przykład 27. Sposób wypełnienia Platnosc dla Fa

Stan faktyczny:

Podatnik VAT w dniu 20.0 5 .202 6 r. dokonał dostawy towarów na rzecz drugiego podatnika.
Strony ustaliły, że płatność należności nastąpi przelewem, w ciągu 14 dni od dnia
wystawienia faktury, na rachunek bankowy sprzedawcy (nr 11 1111 111 1111 1111 1111
1111), w banku XYZ. Sprzedawca wystawia fakturę, a informację o wyznaczonym terminie
płatności chce umieścić na fakturze.

Element Platnosc można w tej sytuacji wypełnić następująco:

Nazwa pola Sposób wypełnienia
Fa/Platnosc/
TerminPlatnosci/
TerminOpis
Ilosc 14
Jednostka dni
ZdarzeniePoczatkowe od wystawienia faktury
Fa/Platnosc FormaPlatnosci 6
Fa/Platnosc/
RachunekBankowy
NrRB 11111111111111111111111111
NazwaBanku XYZ
Element WarunkiTransakcji dla Fa
Element fakultatywny WarunkiTransakcji zawiera informacje dotyczące warunków transakcji
w oparciu, o które realizowana jest dostawa towarów lub świadczenie usług
dokumentowane fakturą. Są to m. in.:

daty oraz numery zamówień,
daty oraz numery umów,
numery partii towarów,
informacje w zakresie warunków dostawy - tzw. Incoterms,
kurs umowny i waluta umowna,
informacje dotyczące warunków transportu towaru,
oznaczenie, że dostawa jest realizowana przez podmiot pośredniczący, o którym
mowa w art. 22 ust. 2d ustawy.
Wskazanie na fakturze ustrukturyzowanej powyższych danych ma charakter dobrowolny -
przepisy w tym zakresie nie uległy zmianie.

Ponadto biorąc pod uwagę różnorodność sytuacji w obrocie gospodarczym, część pól i
elementów może wystąpić w strukturze faktury ustrukturyzowanej więcej niż jeden raz – jest
to np. element Umowy, element Zamowienia, pole NrPartiiTowaru, element Transport.

Schemat 59. Struktura elementu WarunkiTransakcji dla Fa

Tabela 59. Opis struktury elementu WarunkiTransakcji dla Fa

Nazwa pola Opis pola
Umowy Element zawierający dane dotyczące daty i numeru
umowy, na podstawie której realizowana jest dostawa
towarów lub świadczenie usług [element
fakultatywny]
Maksymalna ilość wystąpień: 100
Zamowienia Element zawierający dane dotyczące daty i numeru
zamówienia, na podstawie którego realizowana jest
dostawa towarów lub świadczenie usług [element
fakultatywny]
Maksymalna ilość wystąpień: 100
NrPartiiTowaru Numery partii towaru [pole fakultatywne]
Podaje się numer partii towarów, z której pochodzą
towary będące przedmiotem dostawy
dokumentowanej fakturą.
Maksymalna ilość wystąpień: 100 0
Uwaga!
Zgodnie z art. 12g ust. 2 pkt 7 lit. d ustawy z dnia 11
września 2015 r. o zdrowiu publicznym^10 , informacja w
postaci elektronicznej, składana przez podmioty
zobowiązane do zapłaty opłaty, o których mowa w art.
12d ustawy, powinna zawierać m.in. numery partii
towaru, jeśli nie są zawarte na fakturze.
WarunkiDostawy Warunki dostawy towarów [pole fakultatywne]
Podaje się warunki dostawy towarów, w przypadku,
gdy pomiędzy stronami transakcji istnieją umowne
warunki dostawy, tzw. Incoterms (opis słowny lub
skrót).
Przykład: „DDP”
KursUmowny Kurs umowny - w przypadkach, gdy na fakturze
znajduje się informacja o kursie, po którym zostały
przeliczone kwoty wykazane na fakturze w złotych.
Pole nie dotyczy przypadków, o których mowa w dziale
VI ustawy.
Uwaga!
Pole KursUmowny dotyczy w szczególności sytuacji,
gdy strony transakcji ustaliły, że cena towaru wyniesie
np. 100 EUR, płatność nastąpi w PLN, a umowny kurs
euro na cele tej transakcji jest równy 4,50 PLN. Finalnie
nabywca płaci więc sprzedawcy 450 PLN i faktura
również jest wystawiona w PLN (z ewentualną
informacją o kursie umownym i walucie umownej).
Sekwencja składająca się z pól KursUmowny oraz
WalutaUmowna ma charakter fakultatywny. Jeżeli
jednak podatnik zdecyduje się ją wypełnić, wówczas
uzupełnia oba ww. pola.
WalutaUmowna Waluta umowna - kod waluty (ISO4217) w
przypadkach gdy na fakturze znajduje się informacja o
kursie, po którym zostały przeliczone kwoty wykazane
na fakturze w złotych. Pole nie dotyczy przypadków, o
których mowa w dziale VI ustawy.
(^10) Dz. U. z 2024 r. poz. 16 70 ze zm.

Uwaga!
Pole WalutaUmowna dotyczy w szczególności sytuacji,
gdy strony transakcji ustaliły, że cena towaru wyniesie
np. 100 EUR, płatność nastąpi w PLN, a umowny kurs
euro na cele tej transakcji jest równy 4,50 PLN. Finalnie
nabywca płaci więc sprzedawcy 450 PLN i faktura
również jest wystawiona w PLN (z ewentualną
informacją o kursie umownym i walucie umownej).
Sekwencja składająca się z pól KursUmowny oraz
WalutaUmowna ma charakter fakultatywny. Jeżeli
jednak podatnik zdecyduje się ją wypełnić, wówczas
uzupełnia oba ww. pola.
Uwaga!
W polu WalutaUmowna nigdy nie powinna wystąpić
waluta polska (PLN).
Transport Element zawierający dane dotyczące warunków
transportu m. in. rodzaj środka transportu, opis
ładunku, dane przewoźnika, adres miejsca wysyłki,
adres punktu pośredniego, adres miejsca docelowego
[element fakultatywny]
Maksymalna ilość wystąpień: 20
PodmiotPosredniczacy Podmiot pośredniczący, o którym mowa w art. 22 ust.
2d ustawy [pole fakultatywne]
Podaje się wartość „1" w przypadku zawarcia na
fakturze informacji, że dostawy dokonuje podmiot, o
którym mowa w art. 22 ust. 2d ustawy. Pole dotyczy
przypadku, w którym, podmiot uczestniczy w transakcji
łańcuchowej, innej niż procedura trójstronna
uproszczona, o której mowa w art. 135 ust. 1 pkt 4
ustawy.
Schemat 60. Struktura elementu Umowy dla WarunkiTransakcji

Tabela 60. Opis struktury elementu Umowy dla WarunkiTransakcji

Nazwa pola Opis pola
DataUmowy Data umowy [pole fakultatywne]
Podaje się datę zawarcia umowy, na podstawie której
realizowana jest dostawa towarów lub świadczenie
usług dokumentowane fakturą.
Uwaga!
Najwcześniejsza data umowy, którą można wskazać w
polu DataUmowy to 1990- 01 - 01. W przypadku umów
zawartych wcześniej można skorzystać z konstrukcji
DodatkowyOpis w celu zawarciu ww. danych na
fakturze.
Uwaga!
Dla faktur zaliczkowych dedykowany jest odrębny,
dodatkowy element Fa/Zamowienie, zawierający dane
wymagane art. 106f ust. 1 pkt 4 ustawy.
NrUmowy Numer umowy [pole fakultatywne]
Podaje się numer umowy, na podstawie której
realizowana jest dostawa towarów lub świadczenie
usług dokumentowane fakturą.
Uwaga!
Dla faktur zaliczkowych dedykowany jest odrębny,
dodatkowy element Fa/Zamowienie, zawierający dane
wymagane art. 106f ust. 1 pkt 4 ustawy.
Schemat 61. Struktura elementu Zamowienia dla WarunkiTransakcji

Tabela 61. Opis struktury elementu Zamowienia dla WarunkiTransakcji

Nazwa pola Opis pola
DataZamowienia Data zamówienia [pole fakultatywne]
Podaje się datę zamówienia, na podstawie którego
realizowana jest dostawa towarów lub świadczenie
usług dokumentowane fakturą.
Uwaga!
Najwcześniejsza data zamówienia, którą można wskazać
w polu DataZamowienia to 1990- 01 - 01. W przypadku
zamówień sprzed tego roku, można skorzystać z
konstrukcji DodatkowyOpis w celu zawarciu ww. danych
na fakturze.
Uwaga!
Dla faktur zaliczkowych dedykowany jest odrębny,
dodatkowy element Fa/Zamowienie, zawierający dane
wymagane art. 106f ust. 1 pkt 4 ustawy.
NrZamowienia Numer zamówienia [pole fakultatywne]
Podaje się numer zamówienia, na podstawie którego
realizowana jest dostawa towarów lub świadczenie
usług dokumentowane fakturą.
Uwaga!
Dla faktur zaliczkowych dedykowany jest odrębny,
dodatkowy element Fa/Zamowienie, zawierający dane
wymagane art. 106f ust. 1 pkt 4 ustawy.
Element Transport dla WarunkiTransakcji
Element fakultatywny Transport zawiera dane dotyczące warunków transportu towaru,
którego sprzedaż dokumentowana jest fakturą. Są to m. in.:

dane dotyczące rodzaju zastosowanego transportu,
dane identyfikujące przewoźnika,
numer zlecenia transportu,
dane dotyczące rodzaju ładunku oraz jednostki opakowania,
dane dotyczące godziny rozpoczęcia i zakończenia transportu,
adres miejsca wysyłki, adres pośredni oraz adres docelowy, do którego realizowany
jest transport.
Wskazanie na fakturze ustrukturyzowanej takich danych ma charakter dobrowolny - przepisy
w tym zakresie nie uległy zmianie.

Jeżeli jednak podatnik zdecyduje się wypełnić element Transport, to minimalny zakres
danych obejmuje wtedy:

pole RodzajTransportu, względnie TransportInny oraz OpisInnegoTransportu,
pole OpisLadunku, względnie LadunekInny oraz OpisInnegoLadunku.
Schemat 62. Struktura elementu Transport dla WarunkiTransakcji

Tabela 62. Opis struktury elementu Transport dla WarunkiTransakcji

Nazwa pola Opis pola
RodzajTransportu Rodzaj zastosowanego transportu w przypadku
dokonanej dostawy towarów
Podaje się:
„1” – w przypadku transportu morskiego,
„2” – w przypadku transportu kolejowego,
„3” – w przypadku transportu drogowego,
„4” – w przypadku transportu lotniczego,
„5” – w przypadku przesyłki pocztowej,
„7” – w przypadku stałych instalacji przesyłowych,
„8” – w przypadku żeglugi śródlądowej.
Obowiązujące kody rodzaju transportu wynikają z treści
Rozporządzenia wykonawczego Komisji (UE) 2015/2447
z dnia 24 listopada 2015 r. ustanawiającego szczegółowe
zasady wykonania niektórych przepisów rozporządzenia
Parlamentu Europejskiego i Rady (UE) nr 952/2013
ustanawiającego unijny kodeks celny (kod „6” został
pominięty celowo).
TransportInny Znacznik innego rodzaju transportu

W przypadku wystąpienia innego rodzaju transportu niż
przewidziane do wyboru w polu RodzajTransportu („1” -
„ 5 ”, „7”, „8”), podaje się „1” - inny rodzaj transportu.
OpisInnegoTransportu Opis innego rodzaju transportu

W przypadku wskazania „1” w polu TransportInny,
podaje się opis innego rodzaju transportu.
Przewoznik Element zawierający dane identyfikacyjne przewoźnika
oraz jego adres [element fakultatywny]

NrZleceniaTransportu Numer zlecenia transportu [pole fakultatywne]

Podaje się numer zlecenia transportu, na podstawie
którego realizowany jest transport towarów.
OpisLadunku Rodzaj ładunku (rodzaj opakowania zbiorczego, w
którym transportowany jest towar)

Podaje się liczbę odpowiadającą danemu rodzajowi
opakowania zbiorczego:
„1” - Bańka,
„2” - Beczka,
„3” - Butla,
„4” - Karton,
„5” - Kanister,
„6” - Klatka,
„7” - Kontener,
„8” - Kosz/koszyk,
„9” - Łubianka,
„10” - Opakowanie zbiorcze,
„11” - Paczka,
„12” - Pakiet,
„13” - Paleta,
„14” - Pojemnik,
„15” - Pojemnik do ładunków masowych stałych,
„16” - Pojemnik do ładunków masowych w postaci
płynnej,
„17” - Pudełko,
„18” - Puszka,
„19” - Skrzynia,
„20” - Worek.
LadunekInny Znacznik innego ładunku, w tym ładunek mieszany

W przypadku wystąpienia innego rodzaju opakowania
zbiorczego (niż przewidziany w polu OpisLadunku), w
którym transportowany jest towar lub ładunku
mieszanego podaje się „1” - inny ładunek.
OpisInnegoLadunku Opis innego ładunku

W przypadku wskazania „1” w polu LadunekInny podaje
się opis innego ładunku lub opis ładunku mieszanego.
JednostkaOpakowania Jednostka opakowania [pole fakultatywne]

Podaje się dodatkowe informacje opisujące ładunek,
dotyczące w szczególności zbiorczego opakowania
ładunku, określonego w polach dotyczących opisu
ładunku (np. ilość jednostek towaru w przeliczeniu na
jedną sztukę opakowania zbiorczego).
Przykład:
1 karton/ 30 sztuk
DataGodzRozpTransportu Data i godzina rozpoczęcia transportu [pole
fakultatywne]

Podaje się datę i godzinę rozpoczęcia transportu w
formacie RRRR-MM-DDTGG:MM:SS (np.: 202 6 - 05 -
24T09:30:47Z; gdzie T oznacza „Time”).
Przykład:
Transport towaru rozpoczyna się 2 1 .0 5 .202 6 r. o godz.
12:45. W polu DataGodzRozpTransportu podaje się:
2026 - 05 - 21T12:45:00Z.
DataGodzZakTransportu Data i godzina zakończenia transportu [pole
fakultatywne]

Podaje się datę i godzinę zakończenia transportu w
formacie RRRR-MM-DDTGG:MM:SS (np.: 202 6 - 05 -
24T09:30:47Z; gdzie T oznacza „Time”).
Przykład:
Transport towaru zakończył się 23.0 5 .202 6 r. o godz.
14:00. W polu DataGodzZakTransportu podaje się: 202 6 -
05 - 23 T14:00:00Z.
WysylkaZ Element zawierający dane dotyczące adresu miejsca
wysyłki towaru (rozpoczęcia transportu) [element
fakultatywny]
WysylkaPrzez Element zawierający dane dotyczące adresu
pośredniego wysyłki towaru [element fakultatywny]
Maksymalna ilość wystąpień: 20
WysylkaDo Element zawierający dane dotyczące adresu miejsca
docelowego, do którego został zlecony transport towaru
[element fakultatywny]
Schemat 63. Struktura elementu Przewoznik dla Transport

Tabela 63. Opis struktury elementu Przewoznik dla Transport

Nazwa pola Opis pola
DaneIdentyfikacyjne Element zawierający dane identyfikacyjne przewoźnika,
m.in. NIP, imię, nazwisko lub nazwę przewoźnika
AdresPrzewoznika Element zawierający dane adresowe przewoźnika
Schemat 64. Struktura elementu DaneIdentyfikacyjne dla Przewoznik

Tabela 64. Opis struktury elementu DaneIdentyfikacyjne dla Przewoznik

Nazwa pola Opis pola
NIP Identyfikator podatkowy NIP przewoźnika
KodUE Dwuliterowy kod (prefiks) poprzedzający NrVatUE
przewoźnika
NrVatUE Numer identyfikacyjny VAT przewoźnika
KodKraju Kod kraju nadania innego identyfikatora przewoźnika
[pole fakultatywne]
NrID Inny identyfikator podatkowy przewoźnika
BrakID Podmiot nieposiadający identyfikatora podatkowego lub
podmiot, którego identyfikator podatkowy nie
występuje na fakturze
Podaje się „1” w przypadku, gdy przewoźnik nie posiada
identyfikatora podatkowego lub gdy identyfikator
podatkowy przewoźnika nie występuje na fakturze.
Nazwa Imię i nazwisko lub nazwa przewoźnika
Schemat 65. Struktura elementu AdresPrzewoznika dla Przewoznik

Tabela 65. Opis struktury elementu AdresPrzewoznika dla Przewoznik

Nazwa pola Opis pola
KodKraju Kod kraju
AdresL1
Adres przewoźnika – linia pierwsza
AdresL2 Adres przewoźnika – linia druga [pole fakultatywne]
GLN Globalny Numer Lokalizacyjny [pole fakultatywne]
GLN jest to numer umożliwiający m.in. zidentyfikowanie
jednostek fizycznych lub funkcjonalnych w obrębie firmy.
Schemat 66. Struktura elementu WysylkaZ dla Transport

Tabela 66. Opis struktury elementu WysylkaZ dla Transport

Nazwa pola Opis pola
KodKraju Kod kraju
AdresL1
Adres miejsca wysyłki towaru (rozpoczęcia transportu) – linia
pierwsza
AdresL2
Adres miejsca wysyłki towaru (rozpoczęcia transportu) – linia
druga [pole fakultatywne]
GLN Globalny Numer Lokalizacyjny [pole fakultatywne]
GLN jest to numer umożliwiający m. in. zidentyfikowanie
jednostek fizycznych lub funkcjonalnych w obrębie firmy.
Schemat 67. Struktura elementu WysylkaPrzez dla Transport

Tabela 67. Opis struktury elementu WysylkaPrzez dla Transport

Nazwa pola Opis pola
KodKraju Kod kraju
AdresL1
Adres pośredni wysyłki – linia pierwsza
AdresL2
Adres pośredni wysyłki – linia druga [pole fakultatywne]
GLN Globalny Numer Lokalizacyjny [pole fakultatywne]
GLN jest to numer umożliwiający m.in. zidentyfikowanie
jednostek fizycznych lub funkcjonalnych w obrębie firmy.
Schemat 68. Struktura elementu WysylkaDo dla Transport

Tabela 68. Opis struktury elementu WysylkaDo dla Transport

Nazwa pola Opis pola
KodKraju Kod kraju
AdresL1
Adres miejsca docelowego, do którego został zlecony
transport towaru – linia pierwsza
AdresL2
Adres miejsca docelowego, do którego został zlecony
transport towaru – linia druga [pole fakultatywne]
GLN Globalny Numer Lokalizacyjny [pole fakultatywne]
GLN jest to numer umożliwiający m.in. zidentyfikowanie
jednostek fizycznych lub funkcjonalnych w obrębie firmy.
Przykład 28. Sposób wypełnienia elementu Warunki Transakcji dla Fa

Stan faktyczny:

Podatnik VAT zamawia towar u innego polskiego podatnika w dniu 15.09.202 6 r. (numer
zamówienia ZAM/182/202 6 ). Przedmiotem transakcji (i jednocześnie transportu) jest 2000
szt. suszarek do włosów, które w celu transportu zostały zapakowane w 50 kartonów (w
każdym po 40 sztuk).

Rozpoczęcie transportu (drogowego) nastąpiło w dniu 25.09.202 6 r. o godz. 07:34 w
Katowicach (11-111, ul. Zielona 5), a zakończenie transportu miało miejsce w dniu
25.09.202 6 r. o godzinie 21:40 w Gdyni (22- 222 , ul. Szara 25). W trakcie transportu nastąpił
przeładunek towaru w Łodzi (55-555, ul. Niebieska 27 – magazyn „B”).

Przewoźnik Jan Nowak (NIP 9999999999, ul. Pomarańczowa 12, 33-333 Gliwice) zadziałał
transport, na podstawie zlecenia transportu nr TR/09/2 6.

W sytuacji, w której występuje sprzedawca, wystawiając fakturę, może wypełnić element
WarunkiTransakcji w powyższy sposób:

Nazwa pola Sposób wypełnienia
Fa/WarunkiTransakcji/Zamowienia
DataZamowienia 2026 - 09 - 15
NrZamowienia ZAM/182/202 6
Fa/WarunkiTransakcji/Transport RodzajTransportu 3
Fa/WarunkiTransakcji/Transport/
Przewoznik/DaneIdentyfikacyjne
NIP 9999999999
Nazwa Jan Nowak
Fa/WarunkiTransakcji/Transport/
Przewoznik/AdresPrzewoznika
KodKraju PL
AdresL1 ul. Pomarańczowa 12
33 - 333 Gliwice
Fa/WarunkiTranskcji/Transport
NrZleceniaTransportu TR/09/2 6
OpisLadunku 4
JednostkaOpakowania 1 karton/40 sztuk
DataGodzRozpTransportu 2026 - 09 - 25T07:34:00Z
DataGodzZakTransportu 2026 - 09 - 25T21:40:00Z
Fa/WarunkiTransakcji/Transport/
WysylkaZ
KodKraju PL
AdresL1 ul. Zielona 5
11 - 111 Katowice
Fa/WarunkiTransakcji/Transport/
WysylkaPrzez
KodKraju PL
AdresL1 ul. Niebieska 27
55 - 555 Łódź
AdresL2 Magazyn „B”
Fa/WarunkiTransakcji/Transport/
WysylkaDo
KodKraju PL
AdresL1 ul. Szara 25
22 - 222 Gdynia
Element Zamowienie dla Fa
Element opcjonalny Zamówienie dotyczy zamówień lub umów, o których mowa w art.
106f ust. 1 pkt 4 ustawy (dla faktur zaliczkowych). Wypełniany jest w walucie, w którym
wystawiono fakturę zaliczkową.

W przypadku faktury korygującej przed fakturą zaliczkową należy zastosować współczynnik z
określonymi pozycjami zamówień lub umowy lub dane korygowane według
stanu korektą i po korekcie jako głównej wierszy, jeśli korekta dotyczy wartości
zamówień lub umowy. W przypadku faktur korygujących faktury zaliczkowe, jeśli korekta
nie dotyczy wartości zamówień lub umowy i jednocześnie zmienia wysokość podstawy
lub podatku, należy wprowadzić zapis według stanu przed korektą i zapisać według
stanu po korekcie w celu sprawdzenia braku zmiany wartości poszczególnych pozycji.

Schemat 69. Struktura elementu Zamowienie dla Fa

Tabela 69. Opis struktury elementu Zamowienie dla Fa

Nazwa pola Opis pola
WartoscZamowienia Wartość zamówienia lub umowy z uwzględnieniem
kwoty podatku
Podaje się łączną wartość pól P_11NettoZ oraz P_11VatZ
(obejmującą wszystkie wiersze zamówienia).
ZamowienieWiersz Element zawierający szczegółowe pozycje zamówienia
lub umowy w walucie, w której wystawiono fakturę
zaliczkową
Maksymalna ilość wystąpień: 1 0 000
Schemat 70. Struktura elementu ZamowienieWiersz dla Zamowienie (od pola NrWierszaZam
do pola PKOBZ)

Tabela 70. Opis struktury elementu ZamowienieWiersz dla Zamowienie (od pola
NrWierszaZam do pola PKOBZ)

Nazwa pola Opis pola
NrWierszaZam Kolejny numer wiersza zamówienia lub umowy
Podaje się kolejny numer wiersza zamówienia lub
umowy
Przykład:
W przypadku faktury dokumentującej otrzymanie
zaliczki na poczet dwóch różnych towarów, w przypadku
pierwszego wiersza zamówienia, pole NrWierszaZam
równa się „1”, a w przypadku drugiego wiersza
zamówienia, pole NrWierszaZam równa się „2” (itd.).
UU_IDZ Uniwersalny unikalny numer wiersza zamówienia lub
umowy [pole fakultatywne]
Pole tekstowe zawierające uniwersalny, unikalny
identyfikator danych, umożliwiający jednoznaczne
zidentyfikowanie wiersza zamówienia lub umowy.
Pożądaną unikalnością pola UU_IDZ jest unikalność w
skali danego podatnika lub danego systemu
wykorzystywanego przez danego podatnika.
P_7Z Nazwa (rodzaj) towaru lub usługi [pole opcjonalne]
Podaje się nazwę (rodzaj) towaru lub usługi będących
przedmiotem zamówienia lub umowy.
Maksymalna ilość znaków: 512
IndeksZ Pole przeznaczone do wpisania wewnętrznego kodu
zamówienia towaru lub usług nadanych przez zastosowanie
albo dodatkowego opisu zamówienia
towaru lub usług [pole fakultatywne]

Maksymalna ilość znaków: 50
GTINZ Globalny Numer Jednostki Handlowej [pole
fakultatywne]

GTIN to numer pozwalający na identyfikację towarów i
usług na całym świecie, jest to cyfrowy odpowiednik
kodu EAN.
Podaje się cyfrowy kod GTIN towaru lub usługi,
będących przedmiotem zamówienia lub umowy.
PKWiUZ Symbol Polskiej Klasyfikacji Wyrobów i Usług [pole
fakultatywne]

Obecnie, na potrzeby podatku od towarów i usług,
stosuje się Polską Klasyfikację Wyrobów i Usług z 2015 r.
CNZ Symbol Nomenklatury Scalonej [pole fakultatywne]

Podaje się symbol Nomenklatury Scalonej CN.
PKOBZ Symbol Polskiej Klasyfikacji Obiektów Budowlanych
[pole fakultatywne]

Podaje się symbol Polskiej Klasyfikacji Obiektów
Budowlanych.
Schemat 71. Struktura elementu ZamowienieWiersz dla Zamowienie (od pola P_8AZ do pola
P_12Z_XII)

Tabela 71. Opis struktury elementu ZamowienieWiersz dla Zamowienie (od pola P_8AZ do
pola P_12Z_XII)

Nazwa pola Opis pola
P_8AZ Miara zamówionego towaru lub zakres usługi [pole
opcjonalne]
P_8BZ Ilość zamówionego towaru lub zakres usługi [pole
opcjonalne]
P_9AZ Cena jednostkowa netto zamówionego towaru lub
usługi [pole fakultatywne]
Maksymalna liczba miejsc po kropce: 8
P_11NettoZ Wartość zamówionego towaru lub usługi bez kwoty
podatku [pole opcjonalne]
P_11VatZ Kwota podatku od zamówionego towaru lub usługi [pole
opcjonalne]
P_12Z Stawka podatku [pole opcjonalne]:
„23” - w przypadku stawki 23%
„22” - w przypadku stawki 22%
„8” - w przypadku stawki 8%
„7” – w przypadku stawki 7%
„5” - w przypadku stawki 5%
„4” - w przypadku stawki 4 %
„3” - w przypadku stawki 3%
„0 KR” - w przypadku stawki 0% dla sprzedaży
i udostępniania usług na terenie kraju (z handlum
WDT i eksportu)
„0 WDT” - w przypadku stawki 0% dla
wewnątrzwspólnotowej dostawy
„0 EX” - w przypadku stawki 0% dla eksportu towarów
„zw” - w przypadku zwolnienia z podatku
„oo” - w przypadku odwrotnego stosowania prawa w obrocie
krajowym
„np I” - w przypadkach niepodlegających opodatkowaniu
dostaw oraz udostępnieniu usług poza
krajem, z dostępem do transakcji, o których
mowa w art. 100 ust. 1 pkt 4 ustawy oraz OSS
„np II” – w przypadku niepodlegającego
opodatkowaniu na terytorium kraju, udostępniania usług
o których mowa w art. 100 ust. 1 pkt 4 ustawy.
Podaje się stawkę podatku właściwą dla zamawianego
towaru lub usługi.
Uwaga!
Oznaczenie „oo” dotyczy transakcji objętych odwrotnym
obciążeniem w obrocie krajowym.
Natomiast w przypadku faktur dokumentujących
transakcje z podmiotem zagranicznym, których
miejscem opodatkowania jest inny kraj niż Polska, a
zobowiązanym do rozliczenia podatku od wartości
dodanej lub podatku o podobnym charakterze w kraju
opodatkowania jest nabywca towaru lub usługi, stosuje
się oznaczenie „np. I” lub „np. II” (a nie „oo”).
Uwaga!
Słowniki stawek w polach P_12 (w elemencie FaWiersz)
oraz P_12Z (w elemencie Zamowienie) są identyczne.
Należy jednak pamiętać, że w przypadku WDT zaliczka
nie jest dokumentowana fakturą i nie powoduje
powstania obowiązku podatkowego. W praktyce więc w
przypadku faktur zaliczkowych stawka „O WDT” nie
będzie wykorzystywana.
P_12Z_XII Stawka podatku od wartości dodanej w przypadku, o
której mowa w dokumencie XII w przepisie 6a ustawy [pole
kluczowe]

Podaje się stawkę podatku od wartości dodanej
właściwą dla przedmiotu zamówienia, w przypadku
wystawienia faktury zaliczkowej przez podatnika
zidentyfikowanego na terytorium kraju do procedury
unijnej OSS.
Na stronie Komisji Europejskiej dostępna jest Baza
stawek podatkowych w innych krajach UE.
Schemat 72. Struktura elementu ZamowienieWiersz dla Zamowienie (od pola P_12Z_Zal_15
do pola StanPrzedZ)

Tabela 72. Opis struktury elementu ZamowienieWiersz dla Zamowienie (od pola
P_12Z_Zal_15 do pola StanPrzedZ)

Nazwa pola Opis pola
P_12Z_Zal_15 Znacznik dla towaru lub usługi wymienionych w
załączniku nr 15 do ustawy [pole fakultatywne]
Podaje się wartość „1” w przypadku, gdy dana pozycja
zamówienia lub umowy dotyczy towaru lub usługi
wymienionej w załączniku nr 15 do ustawy (niezależnie
czy zaliczka podlega obowiązkowemu mechanizmowi
podzielonej płatności).
GTUZ Oznaczenie dotyczące dostawy towarów i świadczenia
usług, będących przedmiotem zamówienia lub umowy
[pole fakultatywne]
Podaje się:
„GTU_01” - w przypadku dostawy, o której
mowa w § 10 ust. 3 pkt 1 lit. a rozporządzenie w sprawie
JPK_VAT z deklaracją.
Symbol „GTU_01” oznacza wiersz zamówienia lub
umowy dotyczący dostawy napojów alkoholowych o
zawartości alkoholu powyżej 1,2%, piwa oraz napojów
alkoholowych będących mieszaniną piwa i napojów
bezalkoholowych, w których zawartość alkoholu
przekracza 0,5% (CN od 2203 do 2208).
„GTU_02” - w przypadku dostawy, o której
mowa w § 10 ust. 3 pkt 1 lit. b rozporządzenia w sprawie
JPK_VAT z deklaracją.
Symbol „GTU_02” oznacza wiersz zamówień lub
umowę dotyczącą dostawy towarów, o których mowa w
art. 103 ust. 5aa ustawy.

„GTU_03” - w przypadku dostawy, o której
mowa w § 10 ust. 3 pkt 1 lit. c rozporządzenia w sprawie
JPK_VAT z deklaracją.
Symbol „GTU_03” oznacza wiersz zamówień lub
umowę o dostawę olejów opałowych nieujętych
w § 10 ust. 3 pkt 1 lit. b, olejów smarowych i
określonych olejów (CN od 2710 19 71 do 2710 19 83 i
CN od 2710 19 87 do 2710 19 99, z zastosowań
smarów plastycznych zaliczonych do kodu CN 2710 19
99), olejów smarowych (CN 2710 20 90) oraz
preparatów smarowych (CN 3403, z powodu
smarów plastycznych, które zagrażają).

„GTU_04” - w przypadku dostawy, o której
mowa w § 10 ust. 3 pkt 1 lit. d rozporządzenia w sprawie
JPK_VAT z deklaracją.
Symbol „GTU_04” oznacza wiersz zamówień lub
umowę dotyczącą dostawy wyrobów tytoniowych, suszu
tytoniowego, rozdział do urządzeń elektronicznych i
wyrobów dostępnych, w których zawarte są przepisy dotyczące
podatku akcyzowego.

„GTU_05” - w przypadku dostawy, o której
mowa w § 10 ust. 3 pkt 1 lit. e rozporządzenia w sprawie
JPK_VAT z deklaracją.
Symbol „GTU_05” oznacza wiersz zamówień lub
umowę dotyczącą dostawy odpadów - wyłącznie
w poz. 79-91 skazana nr 15 do ustawy.

„GTU_06” - w przypadku dostawy, o której
mowa w § 10 ust. 3 pkt 1 lit. f rozporządzenia w sprawie
JPK_VAT z deklaracją.
Symbol „GTU_06” oznacza wiersz zamówień lub
umowę dotyczącą dostawy urządzeń elektronicznych
oraz części i materiałów do nich, wyłącznie podstawowych

w poz. 7, 8, 59-63, 65, 66, 69 i 94-96 załącznika nr 15 do
ustawy, a także folii typu stretch określonej w poz. 9
tego załącznika.
„GTU_07” - w przypadku dostawy, o której
mowa w § 10 ust. 3 pkt 1 lit. g rozporządzenia w sprawie
JPK_VAT z deklaracją.
Symbol „GTU_07” oznacza wiersz zamówienia lub
umowy dotyczący dostawy pojazdów oraz części (CN od
8701 do 8708).
„GTU_08” - w przypadku dostawy, o której
mowa w § 10 ust. 3 pkt 1 lit. h rozporządzenia w sprawie
JPK_VAT z deklaracją.
Symbol „GTU_08” oznacza wiersz zamówienia lub
umowy dotyczący dostawy metali szlachetnych oraz
nieszlachetnych - wyłącznie określonych w poz. 1 i 1a
załącznika nr 12 do ustawy oraz w poz. 12-25, 33-40, 45,
46, 56 i 78 załącznika nr 15 do ustawy.
„GTU_09” - w przypadku dostawy, o której
mowa w § 10 ust. 3 pkt 1 lit. i rozporządzenia w sprawie
JPK_VAT z deklaracją.
Symbol „GTU_09” oznacza wiersz zamówienia lub
umowy dotyczący dostawy produktów leczniczych,
środków spożywczych specjalnego przeznaczenia
żywieniowego oraz wyrobów medycznych - wyłącznie
objętych obowiązkiem zgłoszenia, o którym mowa w art.
37av ust. 1 ustawy z dnia 6 września 2001 r. - Prawo
farmaceutyczne^11.
„GTU_10” - w przypadku dostawy, o której
mowa w § 10 ust. 3 pkt 1 lit. j rozporządzenia w sprawie
JPK_VAT z deklaracją.
Symbol „GTU_10” oznacza wiersz zamówienia lub
umowy dotyczący dostawy budynków, budowli i
gruntów oraz ich części i udziałów w prawie własności,
w tym również zbycia praw, o których mowa w art. 7
ust. 1 ustawy.
(^11) Dz. U. z 2024 r. poz. 686 ze zm.

„GTU_11” - w dodatku do usług, o których
mowa w § 10 ust. 3 pkt 2 lit. a rozporządzenie w sprawie
JPK_VAT z deklaracją.
Symbol „GTU_11” oznacza wiersz zamówienia lub
umowy dotyczący świadczenia usług w zakresie
przenoszenia uprawnień do emisji gazów
cieplarnianych, o których mowa w ustawie z dnia 12
czerwca 2015 r. o systemie handlu uprawnieniami do
emisji gazów cieplarnianych^12.
„GTU_12” - w dodatku do usług, o których
mowa w § 10 ust. 3 pkt 2 lit. b rozporządzenia w sprawie
JPK_VAT z deklaracją.
Symbol „GTU_12” oznacza wiersz zamówienia lub
umowy dotyczący świadczenia usług o charakterze
niematerialnym - wyłącznie: doradczych, w tym
doradztwa prawnego i podatkowego oraz doradztwa
związanego z zarządzaniem (PKWiU 62.02.1, 62.02.2,
66.19.91, 69.20.3, 70.22.11, 70.22.12, 70.22.13,
70.22.14, 70.22.15, 70.22.16, 70.22.3, 71.11.24,
71.11.42, 71.12.11, 71.12.31, 74.90.13, 74.90.15,
74.90.19), w zakresie rachunkowości i audytu
finansowego (PKWiU 69.20.1, 69.20.2), prawnych
(PKWiU 69.1), zarządczych (PKWiU 62.03, 63.11.12,
66.11.19, 66.30, 68.32, 69.20.4, 70.22.17, 70.22.2,
90.02.19.1), firm centralnych (PKWiU 70.1),
marketingowych lub reklamowych (PKWiU 73.1),
badania rynku i opinii publicznej (PKWiU 73.2), w
zakresie badań naukowych i prac rozwojowych (PKWiU
72) oraz w zakresie pozaszkolnych form edukacji (PKWiU
85.5).
„GTU_13” - w dodatku do usług, o których
mowa w § 10 ust. 3 pkt 2 lit. c rozporządzenia w sprawie
JPK_VAT z deklaracją.
Symbol „GTU_13” oznacza wiersz zamówienia lub
umowy dotyczący świadczenia usług transportowych i
gospodarki magazynowej (PKWiU 49.4, 52.1).
ProceduraZ Oznaczenie procedury dotyczącej towaru lub usługi
będących przedmiotem danego zamówienia lub umowy
[pole fakultatywne]
(^12) Dz. U. z 2024 r. poz. 1505 ze zm.

Podaje się:

„WSTO_EE” – w przypadku procedury, o której mowa
w § 10 ust. 4 pkt 2a rozporządzenia w sprawie JPK_VAT
z deklaracją.
Symbol „WSTO_EE” oznacza wiersz zamówień lub
umowę związaną z wewnątrzwspólnotową sprzedażą na
odległość, która rozpoczyna się od ich
dostarczenia lub transportu znajdującego się na terytorium kraju,
oraz zapewnia usługi telekomunikacyjne,
nadawcze i elektroniczne, o których mowa w art.
28k ustawy, na rzecz niebędących
członkami, posiadającymi siedzibę, stałe miejsce
zamieszkania lub miejsce zamieszkania na terenie wyprowadzenia
innego niż kraj.

„IED” - w przypadku postępowania, o którym mowa w § 10
ust. 4 pkt 2b rozporządzenia w sprawie JPK_VAT z
deklaracją.
Symbol „IED” oznacza wiersz zamówienia lub umowę
dotyczącą dostawy, o której mowa w art. 7a
ust. 1 i 2 ustawy, wydanej przez funkcję
ułatwiającą tę dostawę, która nie jest dostępna z
specjalną procedurą, o której mowa w XII
rozdziale 6a lub 9 ustawy lub w określonych
przepisach, dla których miejsce dostawy jest
terytorium kraju.

„TT_D” – w przypadku procedury, o której mowa w §
10 ust. 4 pkt 5 rozporządzenia w sprawie JPK_VAT z
deklaracją.
Symbol „TT_D” oznacza wiersz zamówienia lub umowy
dotyczący dostawy towarów poza terytorium kraju
dokonanej przez drugiego w kolejności podatnika VAT w
ramach transakcji trójstronnej w procedurze
uproszczonej, o której mowa w dziale XII rozdział 8
ustawy.

„B_SPV” - w przypadku procedury, o której mowa w §
10 ust. 4 pkt 10 rozporządzenia w sprawie JPK_VAT z
deklaracją.
Symbol „B_SPV” oznacza wiersz zamówienia lub umowy
dotyczący transferu bonu jednego przeznaczenia

dokonanego przez podatnika działającego we własnym
imieniu, opodatkowanego zgodnie z art. 8a ust. 1
ustawy.
„B_SPV_DOSTAWA” - w przypadku procedury, o której
mowa w § 10 ust. 4 pkt 11 rozporządzenia w sprawie
JPK_VAT z deklaracją.
Symbol „B_SPV_DOSTAWA” oznacza wiersz zamówienia
lub umowy dotyczący dostawy towarów oraz
świadczenia usług, których dotyczy bon jednego
przeznaczenia na rzecz podatnika, który wyemitował
bon zgodnie z art. 8a ust. 4 ustawy.
„B_MPV_PROWIZJA” – w przypadku procedury, o
której mowa w § 10 ust. 4 pkt 12 rozporządzenia w
sprawie JPK_VAT z deklaracją.
Symbol „B_MPV_PROWIZJA” oznacza wiersz
zamówienia lub umowy dotyczący świadczenia usług
pośrednictwa oraz innych usług dotyczących transferu
bonu różnego przeznaczenia, opodatkowanych zgodnie
z art. 8b ust. 2 ustawy.
KwotaAkcyzyZ Kwota podatku akcyzowego zawarta w cenie towaru
[pole fakultatywne]

StanPrzedZ Znacznik stanu przed korektą [pole fakultatywne]

Podaje się „1” w przypadku faktury korygującej fakturę
dokumentującą otrzymanie zapłaty lub jej części przed
dokonaniem czynności oraz fakturę wystawioną w
związku z art. 106f ust. 4 ustawy (faktura korygująca
fakturę zaliczkową), w przypadku, gdy korekta dotyczy
danych wykazanych w pozycjach zamówienia i jest
dokonywana w sposób polegający na wykazaniu danych
przed korektą i po korekcie jako osobnych wierszy z
odrębną numeracją oraz w przypadku potwierdzania
braku zmiany wartości danej pozycji.
Przykład 29. Sposób wypełnienia elementu ZamowienieWiersz dla Zamowienie

Stan faktyczny:

Podatnik VAT otrzymał zaliczkę na poczet:

dostawy domu jednorodzinnego o powierzchni użytkowej 80 m^2 (PKOB 1110),
opodatkowanej 8% stawką podatku (wartość 600 000 zł netto + 48 000 zł VAT) oraz
dostawy wyposażenia: 2 komody (wartość 1 szt.: 1000 zł netto + 230 zł VAT) i 2 sofy
(wartość 1 szt.: 2000 zł netto + 460 zł VAT), opodatkowane 23% stawką podatku,
Łączna wartość zamówienia (brutto) wynosi więc 655 380 zł.

Podatnik wystawiając fakturę zaliczkową, poza danymi, o których mowa w art. 106f ust. 1 pkt
1 - 3 ustawy, wskazuje na fakturze również dane dotyczące zamówienia (art. 106f ust. 1 pkt 4
ustawy):

Wiersz dotyczący zamówienia domu jednorodzinnego można wypełnić następująco:

Nazwa pola Sposób wypełnienia
Fa/Zamowienie/
ZamowienieWiersz
NrWierszaZam 1
P_7Z Dom jednorodzinny
PKOBZ 1110
P_8AZ Szt.
P_8BZ 1
P_9AZ 600000
P_11NettoZ 600000
P_11VatZ 48000
P_12Z 8
GTUZ GTU_10
Warto zwrócić uwagę, że w celu wskazania metrażu dom jednorodzinnego, można
wykorzystać element DodatkowyOpis znajdujące się w elemencie Fa:

Nazwa pola Sposób wypełnienia
Fa/DodatkowyOpis NrWiersza 1
Klucz Powierzchnia użytkowa
Wartosc 8 0 m^2
Wiersz dotyczący zamówienia 2 szt. komód można wypełnić następująco:

Nazwa pola Sposób wypełnienia
Fa/Zamowienie/
ZamowienieWiersz
NrWierszaZam 2
P_7Z Komoda
P_8AZ Szt.
P_8BZ 2
P_9AZ 1000
P_11NettoZ 2000
P_11VatZ 460
P_12Z 23
Wiersz dotyczący zamówienia 2 szt. sof można wypełnić następująco:

Nazwa pola Treść pola
Fa/Zamowienie/
ZamowienieWiersz
NrWierszaZam 3
P_7Z Sofa
P_8AZ Szt.
P_8BZ 2
P_9AZ 2000
P_11NettoZ 4000
P_11VatZ 920
P_12Z 23
Wartość zamówienia (w tym przypadku 655 380 zł) podaje się w polu
Fa/Zamowienie/WartoscZamowienia.

Stopka dla FA(3)
Struktura elementu Stopka dla FA(3)
Schemat 73. Struktura elementu Stopka dla FA( 3 )

Tabela 73. Opis struktury elementu Stopka dla FA( 3 )

Nazwa pola Opis pola
Informacje Element zawierający pozostałe dane na fakturze (stopkę
faktury) [element fakultatywny]
Maksymalna ilość wystąpień: 3
Rejestry Element zawierający numery podmiotu lub grupy
podmiotów w innych rejestrach i bazach danych
[element fakultatywny]
Maksymalna ilość wystąpień: 100
Schemat 74. Struktura elementu Informacje dla Stopka

Tabela 74. Opis struktury elementu Informacje dla Stopka

Nazwa pola Opis pola
StopkaFaktury Pole zawierające pozostałe dane na fakturze [pole
fakultatywne]
W stopce faktury można zawrzeć np. podziękowanie za
zakup, zachętę do dalszej współpracy, kod rabatowy do
wykorzystania przy okazji kolejnych zakupów, godziny
otwarcia punktu sprzedaży, godziny pracy
infolinii/punktu obsługi klienta, link (wyłącznie w formie
tekstowej) do formularza zwrotu towaru, link (wyłącznie
w formie tekstowej) do formularza reklamacyjnego,
informacje marketingowe, klauzulę RODO, wartość
kapitału zakładowego itp.
Maksymalna ilość znaków: 3500
Schemat 75. Struktura elementu Rejestry dla Stopka

Tabela 75. Opis struktury elementu Rejestry dla Stopka

Nazwa pola Opis pola
PelnaNazwa Pełna nazwa podmiotu, dla którego wskazano numer w
polu KRS/REGON/BDO [pole fakultatywne]
KRS Numer KRS [pole fakultatywne]
Numer KRS jest to numer w Krajowym Rejestrze
Sądowym. Krajowy Rejestr Sądowy jest scentralizowaną,
informatyczną bazą danych składającą się z trzech
osobnych rejestrów:
rejestru przedsiębiorców,
rejestru stowarzyszeń, innych organizacji społecznych i
zawodowych, fundacji oraz publicznych zakładów opieki
zdrowotnej,
rejestru dłużników niewypłacalnych.^13
REGON Numer REGON [pole fakultatywne]
Numer REGON jest to niepowtarzalny numer nadawany
podmiotom gospodarki narodowej i jednostkom
lokalnym tych podmiotów w krajowym rejestrze
urzędowym podmiotów gospodarki narodowej REGON,
niemający ukrytego lub jawnego charakteru znaczącego,
określającego cechy podmiotu.
BDO Numer BDO [pole fakultatywne]
Numer BDO jest to numer rejestrowy w Bazie Danych o
Odpadach. Rejestr BDO jest to rejestr podmiotów
wprowadzających na rynek produkty, produkty w
opakowaniach i gospodarujących odpadami.
(^13) Źródło:https://www.gov.pl/web/sprawiedliwosc/ogolne-informacje-o-krajowym-rejestrze-sadowym

Przykład 30. Sposób wykonania StopkaFaktury dla Informacje

Nazwa pola Sposób wypełnienia
Stopka/Informacje StopkaFaktury Serdecznie dziękujemy za zakupy w naszej
firmie.
W dniach 10. 12 .202 6 r. - 17. 12 .202 6 r. z
kodem „ZIMOWE_PROMOCJE” zamawiając
towar w naszym sklepie internetowym,
zapłacisz 30% mniej za wszystkie ozdoby
choinkowe, opakowania prezentowe oraz
zabawki!
Chcesz zwrócić towar, złożyć reklamację,
zgłosić opinię w zakresie jakości naszej obsługi
lub uzyskać dodatkowe informacje dotyczące
obowiązujących promocji? Skontaktuj się z
naszą infolinią (tel. 801 055 055) – konsultanci
pracują 5 dni w tygodniu w godzinach 8:00-
18:00. Zapraszamy!
Przykład 31. Sposób wypełnienia Stopka dla FA(3)

Nazwa pola Sposób wypełnienia
Stopka/Informacje StopkaFaktury Wysokość kapitału zakładowego 50 000 000 zł
Stopka/Rejestry PelnaNazwa XYZ Sp. z o. o.
KRS 0000111111
REGON 011111111
Zalacznik dla FA(3)
Struktura elementu Zalacznik dla FA(3)
Struktura logiczna e-Faktury została rozbudowana o dodatkowy, fakultatywny element
Zalacznik. W związku z 1 lutego 2026 r. Można zastosować i przesłać
do KSeF faktury ustrukturyzowane lub faktury, o których mowa w art. 106 ust. 1, sztuka.
106nf ust. 1 sztuka. 106nh ust. 1 ustawy, z nich stanowiącej integralną część faktury, w
przypadku gdy faktury te dotyczą o złożonych danych w zakresie jednostek
miary i ilości (liczby) dostarczanych lub wykonanych usług lub cen
jednostkowych netto.

Zamiar przesłania i przesłania do KSeF faktury z złożonego wniosku wymaga wcześniejszego
zgłoszenia za pośrednictwem e-Urzędu Skarbowego (https://urzadskarbowy.gov.pl).
Funkcjonalność będzie dostępna od 1 stycznia 2026 r.

WAŻNE
Załącznik do faktury służący do prezentacji danych o charakterze podatkowym. Zawierają
wyłącznie dane, o których mowa w art. 106e ust. 1 ustawy, lub dane poprawne
powiązane z tymi danymi.
Można to, że nie należy umieszczać w nim danych o charakterze typowo handlowym,
marketingowym/reklamowym lub biznesowym tj. np.:

cenniki, warunki, instrukcje obsługi,
zamówienia, umowa, aneksy do umów, protokół odbioru,
informacje o promocjach i wyprzedażach, materiały reklamowe, oferty indywidualne,
newsletter.
W przypadku użycia niezgodnego z przeznaczeniem, prawo do wydania i
otrzymania faktury z KSeF zostanie odebrane.
Schemat 76. Struktura elementu Zalacznik dla FA( 3 )

Tabela 76. Opis struktury elementu Zalacznik dla FA( 3 )

Nazwa pola Opis pola
BlokDanych Szczegółowe dane załącznika do faktury (bloki danych)
Maksymalna ilość wystąpień: 1000
Schemat 77. Struktura elementu BlokDanych dla Zalacznik

Tabela 77. Opis struktury elementu BlokDanych dla Zalacznik

Nazwa pola Opis pola
ZNaglowek Nagłówek bloku danych [pole fakultatywne]
Podaje się nagłówek danego bloku danych.
Maksymalna ilość znaków: 512
MetaDane Dane opisowe bloku danych
Podaje się dane opisowe charakteryzujące dany blok
danych (złożone z typu złożonego ZKlucz oraz
ZWartosc).
Maksymalna ilość wystąpień: 100 0
Tekst Część tekstowa bloku danych [element fakultatywny]
Element Tekst zawiera część tekstową bloku danych
składającą się z akapitów.
Tabela Tabela danych [element fakultatywny]
Element Tabela umożliwia odzwierciedlenie w postaci
pliku xml, uporządkowanych w sposób logiczny danych,
które zwyczajowo są zwykle prezentowane w formie
tabelarycznej (dotyczących np. zużycia energii
elektrycznej w odniesieniu do danego punktu poboru
energii).
Maksymalna ilość tabel w jednym bloku danych: 100 0
Schemat 78. Struktura elementu MetaDane dla BlokDanych

Tabela 78. Opis struktury elementu MetaDane dla BlokDanych

Nazwa pola Opis pola
ZKlucz Klucz dla pola niezdefiniowanego, stanowiącego
element typu złożonego klucz-wartość
Podaje się nazwę pola przeznaczonego dla wykazywania
metadanych bloku danych. Nazwę wskazuje podatnik.
Maksymalna ilość znaków: 256
ZWartosc Wartość pola, stanowiącego element typu złożonego
klucz-wartość.
Podaje się wartość pola przeznaczonego dla
wykazywania metadanych bloku danych. Wartość
określa podatnik.
Maksymalna ilość znaków: 256
Schemat 79. Struktura elementu Tekst dla BlokDanych

Tabela 79. Opis struktury elementu Tekst dla BlokDanych

Nazwa pola Opis pola
Akapit Akapit stanowiący część tekstową bloku danych
Maksymalna ilość znaków: 512
Maksymalna ilość wystąpień: 10
Schemat 80. Struktura elementu Tabela dla BlokDanych

Tabela 80. Opis struktury elementu tabeli dla BlokDanych

Nazwa pola Opis pola
TMetaDane Dane opisowe dotyczące tabeli [element fakultatywny]
Podaje się dane opisowe (metadane) charakteryzujące
daną tabelę danych (złożone z typu złożonego TKlucz i
TWartosc).
Maksymalna ilość wystąpień: 1000
Opis Opis tabeli [pole fakultatywne]
Podaje się opis dotyczący danej tabeli danych.
Maksymalna ilość znaków: 512
TNaglowek Nagłówek tabeli
Element TNaglowek składa się z komórek stanowiących
treść nagłówka tabeli danych (tj. nazwy poszczególnych
kolumn tabeli danych oraz typy danych w nich
zawartych).
Wiersz Wiersze tabeli
Element Wiersz składa się z komórek stanowiących treść
poszczególnych wierszy tabeli danych.
Maksymalna ilość wierszy w jednej tabeli: 1000
Suma Podsumowania tabeli [element fakultatywny]
Element Suma stanowi podsumowanie danych
prezentowanych w tabeli.
Schemat 81. Struktura elementu TMetaDane dlaTabela

Tabela 81. Opis struktury elementu TMetaDane dlaTabela

Nazwa pola Opis pola
TKlucz Klucz dla pola niezdefiniowanego, stanowiącego
element typu złożonego klucz-wartość
Podaje się nazwę pola przeznaczonego dla wykazywania
metadanych tabeli danych. Nazwę wskazuje podatnik.
Maksymalna ilość znaków: 256
TWartosc Wartość pola, stanowiącego element typu złożonego
klucz-wartość.
Podaje się wartość pola przeznaczonego dla
wykazywania metadanych tabeli danych. Wartość
określa podatnik.
Maksymalna ilość znaków: 256
Schemat 82. Struktura elementu TNagłowek dlaTabela

Tabela 82. Opis struktury elementu TNagłowek dlaTabela

Nazwa pola Opis pola
Kol Nagłówki kolumn
Podaje się nagłówki poszczególnych kolumn tabeli
danych oraz typy danych w poszczególnych kolumnach.
Maksymalna ilość wystąpień (tj. kolumn w tabeli): 20
Schemat 83. Struktura elementu Kol dla TNagłowek

Tabela 83. Opis struktury elementu Kol dla TNagłowek

Nazwa pola Opis pola
Typ Typ danych w nagłówku tabeli (poszczególnych
kolumnach tabeli).
Podaje się:
„date” - w przypadku, gdy w kolumnie danych
znajduje się dane typu,
„datetime” - w przypadku, gdy w kolumnie
danych znajduje się dane typu i czas,
„dec” - w przypadku, gdy w kolumnie danych
znajduje się dane typu liczba z miejscami po przecinku,
„int” - w przypadku gdy w kolumnie danych
znajduje się dane typu suma całkowita,
„time” - w przypadku, gdy w kolumnie danych
znajduje się dane typu czas,
„txt” - w przypadku, gdy w kolumnie danych
znajduje się dane typu tekst.
NKom Zawartość komórki
Podaje się zawartość komórki stanowiącej nagłówek
danej kolumny w tabeli danych.
Maksymalna ilość znaków: 256
Schemat 84. Struktura elementu Wiersz dlaTabela

Tabela 84. Opis struktury elementu Wiersz dlaTabela

Nazwa pola Opis pola
WKom Komórki wiersza tabeli
Podaje się treść poszczególnych komórek w ramach
danego wiersza tabeli.
Maksymalna ilość komórek w jednym wierszu: 20
Schemat 85. Struktura elementu Suma dla tabeli

Tabela 85. Opis struktury elementu Suma dla tabeli

Nazwa pola Opis pola
SKom Komórki podsumowania tabeli
Podaje się treść poszczególnych komórek
podsumowania tabeli danych.
Maksymalna ilość wystąpień (komórek w
podsumowaniu): 20
Przykład 32. Sposób wypełnienia elementu Zalacznik dla FA

Stan faktyczny:

Podatnik VAT faktura dokumentująca dostawę gazu. Faktura zawiera dane
w zakresie cen jednostkowej netto, miary oraz ilości. Faktura dotyczy dwóch punktów
poboru, w związku z czym są one uwzględnione poza podstawową częścią faktury, uwzględniają
także szczegółowe dane dotyczące zużycia paliwa w poszczególnych punktach poboru w
załączniku do faktury, stanowią integralną część pliku xml faktury.

Treść zasądzona do faktury przedstawia założenia:

WAŻNE
Przedstawiony poniżej sposób prezentacji danych w ramach FA(3) w elemencie Zalacznik
ma charakter poglądowy. Struktura elementu Zalacznik jest na tyle funkcjonalny, że zastosowanie
może być dostosowane w sposób przypadkowy dla Twoich potrzeb oraz specyfikacje
ujmowane w dodatku danych.

Krok 1

Element Zalacznik jest uniwersalny maks. z 1000 elementów BlokDanych. Wypełniając Zalacznik
należy umieścić w pierwszej kolejności, wydzielić w sposób logiczny moduł bloków danych.
Odnosząc się do treści przykładowego zarzutu, zasadnym jest podział na dwa bloki
danych. Pierwszy BlokDanych będzie dotyczył rozliczeń punktu poboru nr 1, drugi
BlokDanych będzie dotyczył rozliczeń punktu poboru nr 2.

Krok 2

Po wydzieleniu bloków danych, wymagane jest wyznaczenie w ramach określonych bloków
danych:

nagłówka bloku danych: BlokDanych/ZNagłowek [pole fakultatywne]
metadanych blok danych: BlokDanych/MetaDane [pole obowiązkowe]
część tekstowa bloku danych: BlokDanych/Tekst [pole fakultatywne]
tabele wprowadzające w skład określonych bloków danych: BlokDanych/Tabela [pole
fakultatywne] mogą
być odnoszone do bloku danych nr 1:
Krok 3

Po wydzieleniu elementu określonego bloku danych, zastosowanie jest możliwe, że zostanie wydzielone tabela danych
w BlokDanych/Tabela oraz opisów i metadanych dotyczących
poszczególnych tabel.

Odnosząc się do bloku danych nr 1 zasadne jest wydzielenie:

Pierwsza informacja zawierająca szczegółowy opis opłat i opłat eksploatacyjnych dotyczących danego
punktu poboru oraz metadanych dotyczących tej tabeli w postaci numeru
gazomierza, typu odczytu i podatku akcyzowego,
Druga obejmująca podsumowanie sprzedaży dla punktu poboru wraz z
opisem tej tabeli.
Śledzenie kroków, które następuje po wprowadzeniu faktury w
przypadku zablokowania danych nr 1, można wykryć w przypadku FA(3):

Nazwa pola
Sposób wypełnienia
Zalacznik/BlokDanych/ZNaglowek Rozliczenie punktu poboru1
Zalacznik/BlokDanych/
MetaDane
ZKlucz Okres rozliczeniowy:
ZWartosc 10.03.2026 – 09.05.2026
Zalacznik/BlokDanych/
MetaDane
ZKlucz Nr punktu poboru:
ZWartosc PP/001
Zalacznik/BlokDanych/
MetaDane
ZKlucz Adres punktu poboru:
ZWartosc ul. Szara 1a/2, 00-000 Warszawa
Zalacznik/BlokDanych/
Tekst
Akapit Zużycie paliwa gazowego w bieżącym okresie
rozliczeniowym wynosi 100 m3. Zużycie paliwa
gazowego w analogicznym okresie rozliczeniowym
w roku poprzednim wyniosło 98 m3.
W ramach bloku danych nr 1 wydzielono pierwszą tabelę składającą się w nagłówka oraz
cztery wierszy i metadanych:

Nazwa pola Sposób wypełnienia
Zalacznik/BlokDanych/
Tabela/TMetaDane
TKlucz Nr gazomierza:
TWartosc G1 12345678
Zalacznik/BlokDanych/
Tabela/TMetaDane
TKlucz Typ odczytu:
TWartosc R (R - rzeczywisty; O - odbiorcy; S –
szacunkowy)
Zalacznik/BlokDanych/
Tabela/TMetaDane
TKlucz Kwota podatku akcyzowego, zawarta w
wartości za paliwo gazowe określonej w
aktualnym rozliczeniu:
TWartosc 0 [zł]
Zalacznik/BlokDanych/
Tabela/TNaglowek/
Kol Typ txt
NKom Opłaty
Kol Typ txt
NKom Grupa taryfowa
Kol Typ date
NKom Data od
Kol Typ date
NKom Data do
Kol Typ int
NKom Zużycie początkowe [m^3 ]
Kol Typ int
NKom Zużycie końcowe [m^3 ]
Kol Typ int
NKom Zużycie [m^3 ]
Kol Typ dec
NKom Współczynnik konwersji
Kol Typ int
NKom Ilość
Kol Typ txt
NKom J.m.
Kol Typ dec
NKom Cena jedn. netto [zł]
Kol Typ int
NKom VAT [%}
Kol Typ dec
NKom Wartość netto [zł]
Zalacznik/BlokDanych/
Tabela/Wiersz

WKom Opłata abonamentowa
WKom W-3.12T
WKom 2026 - 03 - 10
WKom 2026 - 05 - 09
WKom -
WKom -
WKom -
WKom -
WKom 2
WKom m-c
WKom 9. 75
WKom 23
WKom 19. 50
Zalacznik/BlokDanych/
Tabela/Wiersz

WKom Paliwo gazowe
WKom W-13T
WKom 2026 - 03 - 09
WKom 2026 - 05 - 08
WKom 1300
WKom 1400
WKom 100
WKom 11. 413
WKom 1141
WKom kWh
WKom 0. 200152
WKom 23
WKom 228. 37
Zalacznik/BlokDanych/
Tabela/Wiersz

WKom Dystrybucyjna stała
WKom W-3.6_WR
WKom 2026 - 03 - 10
WKom 2026 - 05 - 09
WKom -
WKom -
WKom -
WKom -
WKom 2
WKom m-c
WKom 32. 64
WKom 23
WKom 65. 28
Zalacznik/BlokDanych/
Tabela/Wiersz
WKom Dystrybucyjna zmienna
WKom W-3.6_WR
WKom 2026 - 03 - 09
WKom 2026 - 05 - 08
WKom 1300
WKom 1400
WKom 100
WKom 11. 413
WKom 1141
WKom kWh
WKom 0. 03411
WKom 23
WKom 38. 92
WAŻNE
W przypadku tabeli, która w niektórych polach nie zawiera żadnych danych, możliwe jest ich
pominięcie lub np. Znak „ -” należy poinformować o braku danych („b. d”).

W ramach bloku danych nr 1 wydzielono także drugą tabelę składającą się z opisu, nagłówka
oraz jednego wiersza:

Nazwa pola Sposób wypełnienia
Zalacznik/BlokDanych/
Tabela
Opis Podsumowanie sprzedaży dla
punktu poboru
Zalacznik/BlokDanych/
Tabela/TNaglowek
Kol Typ txt
NKom Wartość
Kol Typ dec
NKom Netto [zł]
Kol Typ dec
NKom VAT [zł]
Kol Typ dec
NKom Brutto [zł]
Zalacznik/BlokDanych/
Tabela/Wiersz
WKom Razem sprzedaż
WKom 352. 07
WKom 80. 98
WKom 433. 05
WAŻNE
W podsumowaniu podsumowania danych w tabeli, można
wybrać najodpowiedniejszą formę prezentacji danych. Może w tym celu utworzyć źródło
oddzielnej tabeli, która będzie zawierała wyłącznie podsumowanie danych z tabeli
(analogicznie jak dostęp do pierwotnego źródła). Podatnik może
zawierać element BlokDanych/Tabela/Suma/SKom, który umożliwia wykorzystanie
podsumowania danych w tej samej tabeli danych:

W sposób podany wyżej można uzyskać dostęp do danych dotyczących
wydzielonego załącznika do faktury, blok danych nr 2.

Spis punktów
1. Sposób wykonania elementu Podmiot1 dla FA(3) .................................. 15
Przykład 2. Sposób wypełnienia elementu Podmiot2 dla FA(3) ................................................. 23
Przykład 3. Sposób wypełnienia elementu Podmiot2 dla FA(3) .................................. 24
Przykład 4. Sposób przesłania Podmiot2 dla FA(3) ................................................. 24
Przykład 5. sposób wprowadzenia elementu Podmiot2 dla FA(3) .................................................. 25
Przykład 6. sposób wypełnienia elementu Podmiot3 dla FA(3) .................................. 33
Przykład 7. Sposób wypełnienia elementu Podmiot3 dla FA(3) .................................. 34
Przykład 8. sposób wykonania Podmiot2 i Podmiot3 dla FA(3) .................. 34
Przykład 9. Sposób użycia elementu Podmiot1 i Podmiot3 dla FA(3) .................... 35
Przykład 10. Podmiot3 dla Podmiot3 dla FA(3) .................................................. 36
Przykład 11. Sposób wykonania elementu PodmiotUpowazniony dla FA(3) .................... 41
Przykład 12. Sposób wykonania elementu Adnotacje dla Fa................................................. 64
Przykład 13. Sposób wypełnienia elementu Adnotacje dla Fa................................................. 66
Przykład 14. Sposób zastosowania DaneFaKorygowanej ................................... 70
Przykład 15. Przykład zastosowania pola IDNabywcy ................................................................. 75
Przykład 16. sposobu aplikacji Zaliczka Czesciowa .................................................. 80
Przykład 17. Sposób wykorzystania elementuOpis .................................................. 81 Przykład 18. Sposób wypełnienia elementu Opis
................................................. 82 Przykład 19. sposób wypełnienia elementu
Opis .................................................. 83
Przykład 20. Sposób wprowadzenia elementuOpis .................................................. 84
Przykład 21. Sposób wykorzystania FakturyZaliczkowej .................................................. 86
Przykład Przykład 22. Sposób wypełnienia elementu FaWiersz dla Fa .................................. 100
Przykład 23. Sposób wykonania elementu FaWiersz dla Fa .................................. 101
Przykład 24. Sposób wykonania elementu Rozliczenie dla Fa ................................. 107
25. Sposób wykonania elementu Platnosc dla Fa .................................................. 119
Przykład 26. Sposób wykonania elementu Platnosc dla Fa ................................................. 119
Przykład 27. Sposób wykonania elementu Platnosc dla Fa ................................. 120
Przykład 28. sposób wykonania elementu Transakcji dla Fa .................. 133
Przykład 29. Sposób wykonania elementu Zamowienie dla Zamowienia ............. 145
Przykład 30. StopkaFaktury dla Informacje ................. 149
Przykład 31. Sposób wykonania elementu Stopka dla FA(3) ............................................. 149
Przykład 32. Sposób wykonania elementu Zalacznik dla FA ................................................. 156

Spis schematów
Schemat 1. Rodzaje elementu w obrębie FA(3) na istniejący element
Platnosc/RachunekBankowy ............................................................................................. 5
Schemat 2. Struktura schematu głównego dla FA(3) ................................................................. 8
Schemat 3. Struktura elementu Naglowek dla FA(3) ................................................................. 9
Schemat 4. Struktura elementu Podmiot1 dla FA(3) ................................................................. 10
Schemat 5. Struktura elementu DaneIdentyfikacyjne dla Podmiot1 .................................. 12
Schemat 6. Struktura elementu Adres dla Podmiot1 ............................................................. 13 Schemat 7. Struktura elementu AdresKoresp dla Podmiot1
.................................................... 14 Schemat
8. Struktura elementu DaneKontaktowe dla Podmiot1 .................................... 14 Schemat
9. Struktura elementu Podmiot2 dla FA(3) .............................................................. 16
Schemat 10. Struktura elementu DaneIdentyfikacyjne dla Podmiot2 .................................. 18
Schemat 11. Struktura elementu Adres dla Podmiot2 .................................................... 21
Schemat 12. Struktura elementu AdresKoresp dla Podmiot2 ................................................ 22
Schemat 13. Struktura elementu DaneKontaktowe dla Podmiot2 .................................... 22
Schemat 14. Struktura elementu Podmiot3 dla FA(3) ................................................ 26
Schemat 15. Struktura elementu DaneIdentyfikacyjne dla Podmiot3 ................................. 30
Schemat 16. Struktura elementu dla Podmiot3 .................................................... 31
Schemat 17. Struktura elementu AdresKoresp dla Podmiot3
............................................. 32 Schemat 18. Struktura elementu DaneKontaktowe dla Podmiot3................................. 33
Schemat 19. Struktura elementu PodmiotUpowazniony dla FA(3) ................................... 38
Schemat 20. Struktura elementu DaneIdentyfikacyjne dla PodmiotUp Schematowazniony ............. 39
21. Struktura elementu Adres dla PodmiotUpoważniony ................................... 39
Schemat 22. Struktura elementu AdresKoresp dla PodmiotUpowazniony ............................. 40
Schemat 23. Struktura elementu DaneKontaktowe dla PodmiotUpowazniony .................. 41
Schemat 24. Element Struktura Fa (od pola KodWaluty do pola OkresFa) .................... 42
Schemat 25. Struktura elementu OkresFa dla Fa ................................................................... 45
Schemat 26. Struktura elementu Fa (od pola P_13_1 do pola P_14_5) .................................. 46
Schemat 27. Struktura elementu Fa (od pola P_13_6_1 do pola P_15) .................................. 50
Schemat 28. Struktura elementu Fa (pola od KursWalutyZ do pola RodzajFaktury) .............. 52
Schemat 29. Struktura elementu Adnotacje dla Fa .................................................. 54
Schemat 30. Struktura elementu Zwolnienie dla Adnotacje ................................................... 56
Schemat 31. Struktura elementu NoweSrodkiTransportu dla Adnotacje .................................. 58
Schemat 32. Struktura elementu NowySrodekTransportu dla NoweSrodkiTransportu ..... 59
Schemat 33. Struktura elementu PMarzy dla Adnotacje .................................................. 62
Schemat 34. Struktura elementu Fa (od pola PrzyczynaKorekty do pola KursWalutyZK) ....... 66
Schemat 35. Struktura elementu DaneFaKorygowanej dla Fa ................................................. 69 Schemat
36. Struktura elementu Podmiot1K dla Fa ................................................................ 71 Schemat
37. Struktura elementu DaneIdentyfikacyjne dla Podmiot1K .................................. 71
Schemat 38. Struktura elementu Adres dla Podmiot1K ................................................ 72
Schemat 39. Struktura elementu Podmiot2K dla Fa .................................................. 72
Schemat 40. Struktura elementu DaneIdentyfikacyjne dla Podmiot2K .................................. 73
Schemat 41. Struktura elementu Adres dla Podmiot2K ................................................. 74

Schemat 42. Struktura elementu Fa (pola od Zaliczki Czesciowa do Zamowienie) ............. 77
Schemat 43. Struktura elementu Zaliczka Czesciowa dla Fa .................................................... 79
Schemat 44. Struktura elementu Opis dla Fa ................................................... 81
Schemat 45. Struktura elementu FakturaZaliczkowa dla Fa .................................................. 85
Schemat 46. Struktura elementu FaWiersz dla Fa (od pola od NrWierszaFa do pola PKOB) .. 87
Schemat 47. Struktura elementu FaWiersz dla Fa (od pola P_8A do pola P_12_XII) .............. 89
Schemat 48. Struktura elementu FaWiersz dla Fa (od pola P_12_Zal_15 do pola StanPrzed) 93
Schemat 49. Struktura elementu Rozliczenie dla Fa ................................................................ 104
Schemat 50. Struktura elementu Obciazenia Rozliczenie .................................. 106
Schemat 51. Struktura elementu Odliczenia dla Rozliczenia .................................................. 106
Schemat 52. Struktura elementu Platnosc dla Fa .................................................................. 109
Schemat 53. Struktura elementu ZaplataCzesciowa dla Platnosc .................................... 112
Schemat 54. Struktura elementu TerminPlatnosc dla Platnosc .................................. 114
Schemat 55. Struktura elementu TerminOpis dla TerminPlatnosc ................................ 115
Schemat 56. Struktura elementu RachunekBankowy dla Platnosc .................................. 115
Schemat 57. Struktura elementu RachunekBankowyFaktora dla Platnosc ................... 117
Schemat 58. Struktura
elementu Skonto dla Platnosc.................................................. 118 Schemat 59. Struktura elementu WarunkiTransakcji dla Fa .................................................. 121
Schemat 60. Struktura elementu dla WarunkiTransakcji ................................... 123
Schemat 61. Struktura elementu Zamowienia dla Warunki Transakcji .................................. 124
Schemat 62. Struktura elementu Transport dla WarunkiTransakcji .................................. 126
Schemat 63. Struktura elementu Przewoznik dla Transportu .................................. 129
Schemat 64. Struktura elementu DaneIdentyfikacyjne dla Przewoznik ................................. 129
Schemat 65. Struktura elementu AdresPrzewoznika dla Przewoznika ................................ 130
Schemat 66. Struktura elementu WysylkaZ dla Transportu .................................................. 131
Schemat 67. Struktura elementu WysylkaPrzez dla Transportu ................................. 131
Schemat 68. Struktura elementu WysylkaDo dla Transport .................................................. 132
Schemat 69. Struktura elementu Zamowienie dla Fa .................................................... 134
Schemat 70. Struktura elementu ZamowienieWiersz dla Zamowienie (od pola NrWierszaZam
do pola PKOBZ) ................................................................................................ 135
Schemat 71. Struktura elementu ZamowienieWiersz dla Zamowienie (od pola P_8AZ do pola
P_12Z_XII) ............................................................................................................................. 137
Schemat 72. Struktura elementu ZamowienieWiersz dla Zamowienie (od pola P_12Z_Zal_15
do pola StanPrzedZ) ............................................................................................................... 139
Schemat 73. Struktura elementu Stopka dla FA(3) .................................................. 146
Schemat 74. Struktura elementu Informacje dla Stopka .................................................... 147
Schemat 75. Struktura elementu Rejestry dla Stopka ................................................... 148
Schemat 76. Struktura elementu Zalacznik dla FA(3) .................................................... 150
Schemat 77. Struktura elementu BlokDanych dla Zalacznik .................................. 150
Schemat 78. Struktura elementu MetaDane dla BlokDanych .................................. 151
Schemat 79. Struktura elementu Tekst dla BlokDanych ................................................... 152
Schemat 80. Struktura elementu Tabela dla BlokDanych ................................................ 152
Schemat 81. Struktura elementu TMetaDane dlaTabela .................................................... 153
Schemat 82. Struktura elementu TNaglowek dlaTabela .................................................... 154

Schemat 83. Struktura elementu Kol dla TNaglowek .................................................. 154
Schemat 84. Struktura elementu Wiersz dlaTabela .................................................. 155
Schemat 85. Struktura elementu Suma dla tabeli ................................................ 156

Spis tabel
Tabela 1. Wykaz oznaczeń w diagramie XSD .................................................. 7
Tabela 2. Opis struktury schematu podstawowego dla FA(3) .................................................... 8
Tabela 3. Opis struktury elementu Naglowek dla FA(3) .................................................... 9
Tabela 4. Opis struktury elementu Podmiot1 dla FA(3) .................................................. 11
Tabela 5. Opis elementu DaneIdentyfikacyjne dla Podmiot1 .................................. 12
Tabela 6. Opis struktury elementu Adres dla Podmiot1 .................................................... 13
Tabela 7. Opis struktury elementu AdresKoresp dla Podmiot1 ................................................. 14
Tabela 8. Opis struktury elementu DaneKontaktowe dla Podmiot1 ................................... 15
Tabela 9. Opis struktury elementu Podmiot2 dla FA(3) ................................................................ 16
Tabela 10. Opis elementu DaneIdentyfikacyjne dla Podmiot2 ................................ 18
Tabela 11. Opis struktury elementu Adres dla Podmiot2 .................................................... 21
Tabela 12. Opis struktury elementu AdresKoresp dla Podmiot2 .................................. 22
Tabela 13. Opis struktury elementu DaneKontaktowe dla Podmiot2 ................................. 23
Tabela 14. Opis struktury elementu Podmiot3 dla FA(3) ................................................... 27
Tabela 15. Opis elementu DaneIdentyfikacyjne dla Podmiot3 ................................ 30
Tabela 16. Opis elementu Adres elementu dla Podmiot3 .................................................... 31
Tabela 17. Opis struktury elementu AdresKoresp dla Podmiot3 ............................................. 32
Tabela 18. Opis elementu struktury DaneKontaktowe dla Podmiot3 .................................... 33 Tabela
19. Opis struktury elementu PodmiotUpowazniony dla FA(3) .................................... 38
Tabela 20. Opis struktury elementu DaneIdentyfikacyjne dla PodmiotUpowazniony ..... 39
Tabela 21. Opis elementu Adres dla PodmiotUpoważnionego .................................. 40
Tabela 22. Opis struktury elementu AdresKoresp dla PodmiotUpowazniony ............. 40
Tabela 23. Opis struktury elementu DaneKontaktowe dla PodmiotUpowazniony .................. 41
Tabela 24. Opis struktury elementu Fa (od pola KodWaluty do pola OkresFa) ............. 42
Tabela 25. Opis struktury elementu Fa dla Fa .................................................. 45
Tabela 26. Opis struktury elementu Fa (od pola P_13_1 do pola P_14_5) ................................ 46
Tabela 27. Opis struktury elementu Fa (od pola P_13_6_1 do pola P_15) ................................ 51
Tabela 28. Opis struktury elementu Fa (pola od KursWalutyZ do pola RodzajFaktury) .... 53
Tabela 29. Opis struktury elementu Adnotacje dla Fa .................................................. 54
Tabela 30. Opis struktury elementu Zwolnienie dla Adnotacji .................................. 57
Tabela 31. Opis struktury elementu NoweSrodkiTransportu dla Adnotacji .................. 58
Tabela 32. Opis elementu NowySrodekTransportu dla Nowe ŚrodkiTransportu ..... 59
Tabela 33. Struktura elementu PMarzy dla Adnotacje .................................................... 62
Tabela 34. Opis struktury elementu Fa (od pola PrzyczynaKorekty do pola KursWalutyZK) .. 67
Tabela 35. Opis struktury elementu DaneFaKorygowanej dla Fa .................................. 69
Tabela 36. Opis struktury elementu Podmiot1K dla Fa .................................................. 71
Tabela 37. Opis struktury elementu DaneIdentyfikacyjne dla Podmiot1K ................................ 72
Tabela 38. Opis elementu Adres dla Podmiot1K ............................................................... 72
Tabela 39. Opis struktury elementu Podmiot2K dla Fa .................................................. 73
Tabela 40. Opis struktury elementu DaneIdentyfikacyjne dla Podmiot2K ................................. 73
Tabela 41. Opis struktury elementu Adres dla Podmiot2K ................................................ 74
Tabela 42. Opis struktury elementu Fa (pola od Zaliczki Czesciowej do Zamowienia) .. 77

Tabela 43. Opis struktury elementu ZaliczkaCzesciowa dla Fa .................................. 79
Tabela 44. Opis struktury elementu istniejąceOpis dla Fa.................................................... 81
Tabela 45. Opis struktury elementu FakturaZaliczkowa dla Fa .................................. 85
Tabela 46. Opis elementu FaWiersz dla Fa (od pola NrWierszaFa do pola PKOB)... 87
Tabela 47. Opis elementu FaWiersz dla Fa (od pola) P_8A do pola P_12_XII)........... 89
Tabela 48. Opis struktury elementu FaWiersz dla Fa (od pola P_12_Zal_15 do pola StanPrzed)
...................................................................................................................................... 93
Tabela 49. Opis elementu Rozliczenie dla Fa .................................................. 105
Tabela 50. Opis elementu Obciazenia dla Rozliczenia ................................ 106
Tabela 51. Opis elementu elementu Odliczenia dla Rozliczenia ................................................... 107
Tabela 52. Opis struktury elementu Platnosc dla Fa .................................................. 109
Tabela 53. Opis struktury elementu ZaplataCzesciowe dla Platnosc ................................ 113
Tabela 54. Opis struktury elementu TerminPlatnosci dla Platnosc ................................ 114
Tabela 55. Opis elementu TerminOpis dla TerminPlatnosci .................................. 115
Tabela 56. Struktura elementu RachunekBankowy dla Platnosc .................................................. 116
Tabela 57. Opis struktury elementu RachunekBankowyFaktora dla Platnosc ................. 117
Tabela 58. Opis struktury elementu Skonto dla Platnosc .................................................. 118
Tabela 59. Opis elementu struktury WarunkiTransakcji dla Fa .................................. 121
Tabela 60. Opis elementu zasady dla warunkówTransakcji .................................... 124
Tabela 61. Opis elementu systemu Zamowienia dla Transakcji .................. 124
Tabela 62. Opis struktura elementu Transport dla WarunkiTransakcji .................................. 126
Tabela 63. Opis struktury elementu Przewoznik dla Transportu ................................. 129
Tabela 64. Opis struktury elementu DaneIdentyfikacyjne dla Przewoznik .................. 130
Tabela 65. Opis struktury elementu AdresPrzewoznika dla Przewoznik .................................. 130
Tabela 66. Opis struktury elementu WysylkaZ dla Transportu ................................ 131
Tabela 67. Opis struktury elementu WysylkaPrzez dla Transportu .................................. 132
Tabela 68. Opis struktury elementu WysylkaDo dla Transportu .................................. 132
Tabela 69. Opis struktury elementu Zamowienie dla Fa ................................................ 134
Tabela 70. Opis elementu ZamowienieWiersz dla Zamowienia (od pola
NrWierszaZam do pola PKOBZ) .................................................................................................. 135
Tabela 71. Opis struktury elementu ZamowienieWiersz dla Zamowienie (od pola P_8AZ do
pola P_12Z_XII) ...................................................................................................................... 137
Tabela 72. Opis elementu ZamowienieWiersz dla Zamowienie (od pola
P_12Z_Zal_15 do pola StanPrzedZ) ................................................................................ 139
Tabela 73. Opis struktury elementu Stopka dla FA(3) .................................................... 147
Tabela 74. Opis struktury elementu Informacje dla Stopka .................................................. 147
Tabela 75. Opis elementu rejestru dla Stopka ................................................. 148
Tabela 76. Opis elementu Zalacznik dla FA(3) ................................................... 150
Tabela 77. Opis struktury elementu BlokDanych dla Zalacznik ................................. 151
Tabela 78. Opis elementu MetaDane dla BlokDanych .................................. 151
Tabela 79. Opis struktury elementu Tekst dla BlokDanych .................................... 152
Tabela 80. Opis struktury elementu Tabela dla BlokDanych .................................. 153
Tabela 81. Opis struktury TMetaDane dlaTabela .................................................. 154
Tabela 82. Opis struktury elementu TNaglowek dlaTabela .................................................. 154

Tabela 83. Opis struktury elementu Kol dla TNaglowek .................................................... 155
Tabela 84. Opis struktury elementu Wiersz dlaTabela .................................................... 155
Tabela 85. Opis struktury elementu Suma dla Tabeli ................................................. 156

Rejestr zmian
Dane zmiany Nr strony Zakres zmian ^

Wrzesień 2025 r.

9, 82, 149 Dostosowanie zapisów broszury do finalnego
brzmienia art. 106gba ust. 1 ustawy.
43, 69, 82, 149 Usunięcie przypisów informujących o trwającym
procesie legislacyjnym w zakresie ustawy KSeF2:
Projekt ustawy KSeF2 - druk sejmowy nr 1407.
To narzędzie działa w trybie offline, Twoje dane są przechowywane lokalnie i nie są wysyłane do żadnego serwera!
Opinie i raporty o błędach