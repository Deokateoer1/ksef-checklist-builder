Schema schemat.xsd
schema location:
attributeFormDefault: unqualified
elementFormDefault: qualified
targetNamespace: http://crd.gov.pl/wzor/2023/06/29/12648/
Elements Complex types Simple types
Faktura TAdres SWIFT_Type
TKluczWartosc TData
TNaglowek TDataCzas
TPodmiot1 TDataT
TPodmiot2 TFormaPlatnosci
TPodmiot3 TGLN
TRachunekBankowy TGTU
TIlosci
TKodFormularza
TKodWaluty
TKodyKrajowUE
TKwotowy
TKwotowy2
TLadunek
TNaturalny
TNIPIdWew
TNrRB
TNrVatUE
TNumerKSeF
TNumerTelefonu
TOznaczenieProcedury
TOznaczenieProceduryZ
TProcentowy
TRachunekWlasnyBanku
TRodzajFaktury
TRodzajTransportu
TRolaPodmiotu3
TRolaPodmiotuUpowaznionego
TStatusInfoPodatnika
TStawkaPodatku
TTypKorekty
TZnakowy
TZnakowy20
TZnakowy50
TZnakowy512

---

element Faktura
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
content complex
properties
children tns:Naglowek tns:Podmiot1 tns:Podmiot2 tns:Podmiot3 tns:PodmiotUpowazniony tns:Fa tns:Stopka
documentation
annotation
Faktura VAT
source <xsd:element name="Faktura">
<xsd:annotation>
<xsd:documentation>Faktura VAT</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="Naglowek" type="tns:TNaglowek">

---

<xsd:annotation>
<xsd:documentation>Nagłówek</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Podmiot1">
<xsd:annotation>
<xsd:documentation>Dane podatnika. Imię i nazwisko lub nazwa sprzedawcy towarów
lub usług</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="PrefiksPodatnika" type="tns:TKodyKrajowUE" fixed="PL"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kod (prefiks) podatnika VAT UE dla przypadków określonych
w art. 97 ust. 10 pkt 2 i 3 ustawy oraz w przypadku, o którym mowa w art. 136 ust. 1 pkt 3
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="NrEORI" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer EORI podatnika (sprzedawcy)</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DaneIdentyfikacyjne" type="tns:TPodmiot1">
<xsd:annotation>
<xsd:documentation>Dane identyfikujące podatnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Adres" type="tns:TAdres">
<xsd:annotation>
<xsd:documentation>Adres podatnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="AdresKoresp" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres korespondencyjny podatnika</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:complexContent>
<xsd:extension base="tns:TAdres"/>
</xsd:complexContent>
</xsd:complexType>
</xsd:element>
<xsd:element name="DaneKontaktowe" minOccurs="0" maxOccurs="3">
<xsd:annotation>
<xsd:documentation>Dane kontaktowe podatnika</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence minOccurs="0">
<xsd:element name="Email" type="etd:TAdresEmail" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres e-mail podatnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Telefon" type="tns:TNumerTelefonu" minOccurs="0">

---

<xsd:annotation>
<xsd:documentation>Numer telefonu podatnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="StatusInfoPodatnika" type="tns:TStatusInfoPodatnika"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Status podatnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="Podmiot2">
<xsd:annotation>
<xsd:documentation>Dane nabywcy</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="NrEORI" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer EORI nabywcy towarów</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DaneIdentyfikacyjne" type="tns:TPodmiot2">
<xsd:annotation>
<xsd:documentation>Dane identyfikujące nabywcę</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Adres" type="tns:TAdres" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres nabywcy. Pola opcjonalne dla przypadków określonych
w art. 106e ust. 5 pkt 3 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="AdresKoresp" type="tns:TAdres" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres korespondencyjny nabywcy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DaneKontaktowe" minOccurs="0" maxOccurs="3">
<xsd:annotation>
<xsd:documentation>Dane kontaktowe nabywcy</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence minOccurs="0">
<xsd:element name="Email" type="etd:TAdresEmail" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres e-mail nabywcy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Telefon" type="tns:TNumerTelefonu" minOccurs="0">
<xsd:annotation>

---

<xsd:documentation>Numer telefonu nabywcy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="NrKlienta" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer klienta dla przypadków, w których nabywca posługuje
się nim w umowie lub zamówieniu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="IDNabywcy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Unikalny klucz powiązania danych nabywcy na fakturach
korygujących, w przypadku gdy dane nabywcy na fakturze korygującej zmieniły się w stosunku do
danych na fakturze korygowanej</xsd:documentation>
</xsd:annotation>
<xsd:simpleType>
<xsd:restriction base="tns:TZnakowy50">
<xsd:maxLength value="32"/>
</xsd:restriction>
</xsd:simpleType>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="Podmiot3" minOccurs="0" maxOccurs="100">
<xsd:annotation>
<xsd:documentation>Dane podmiotu/-ów trzeciego/-ich (innego/-ych niż sprzedawca i
nabywca wymieniony w części Podmiot2), związanego/-ych z fakturą</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="IDNabywcy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Unikalny klucz powiązania danych nabywcy na fakturach
korygujących, w przypadku gdy dane nabywcy na fakturze korygującej zmieniły się w stosunku do
danych na fakturze korygowanej</xsd:documentation>
</xsd:annotation>
<xsd:simpleType>
<xsd:restriction base="tns:TZnakowy50">
<xsd:maxLength value="32"/>
</xsd:restriction>
</xsd:simpleType>
</xsd:element>
<xsd:element name="NrEORI" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer EORI podmiotu trzeciego</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DaneIdentyfikacyjne" type="tns:TPodmiot3">
<xsd:annotation>
<xsd:documentation>Dane identyfikujące podmiot trzeci</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

<xsd:element name="Adres" type="tns:TAdres">
<xsd:annotation>
<xsd:documentation>Adres podmiotu trzeciego</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="AdresKoresp" type="tns:TAdres" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres korespondencyjny podmiotu
trzeciego</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DaneKontaktowe" minOccurs="0" maxOccurs="3">
<xsd:annotation>
<xsd:documentation>Dane kontaktowe podmiotu trzeciego</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="Email" type="etd:TAdresEmail" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres e-mail podmiotu trzeciego</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Telefon" type="tns:TNumerTelefonu" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer telefonu podmiotu
trzeciego</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:choice>
<xsd:element name="Rola" type="tns:TRolaPodmiotu3">
<xsd:annotation>
<xsd:documentation>Rola podmiotu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:sequence>
<xsd:element name="RolaInna" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik innego podmiotu: 1 - Inny
podmiot</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="OpisRoli" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Opis roli podmiotu - w przypadku wyboru roli jako Inny
podmiot</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:choice>
<xsd:element name="Udzial" type="tns:TProcentowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Udział - procentowy udział dodatkowego nabywcy. Różnica
pomiędzy wartością 100% a sumą udziałów dodatkowych nabywców jest udziałem nabywcy

---

wymienionego w części Podmiot2. W przypadku niewypełnienia pola przyjmuje się, że udziały
występujących na fakturze nabywców są równe</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="NrKlienta" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer klienta dla przypadków, w których podmiot
wymieniony jako podmiot trzeci posługuje się nim w umowie lub zamówieniu</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="PodmiotUpowazniony" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Dane podmiotu upoważnionego, związanego z
fakturą</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="NrEORI" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer EORI podmiotu upoważnionego</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DaneIdentyfikacyjne" type="tns:TPodmiot1">
<xsd:annotation>
<xsd:documentation>Dane identyfikujące podmiotu
upoważnionego</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Adres" type="tns:TAdres">
<xsd:annotation>
<xsd:documentation>Adres podmiotu upoważnionego</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="AdresKoresp" type="tns:TAdres" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres korespondencyjny podmiotu
upoważnionego</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DaneKontaktowe" minOccurs="0" maxOccurs="3">
<xsd:annotation>
<xsd:documentation>Dane kontaktowe podmiotu
upoważnionego</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="EmailPU" type="etd:TAdresEmail" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres e-mail podmiotu
upoważnionego</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="TelefonPU" type="tns:TNumerTelefonu" minOccurs="0">

---

<xsd:annotation>
<xsd:documentation>Numer telefonu podmiotu
upoważnionego</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="RolaPU" type="tns:TRolaPodmiotuUpowaznionego">
<xsd:annotation>
<xsd:documentation>Rola podmiotu upoważnionego</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="Fa">
<xsd:annotation>
<xsd:documentation>Na podstawie art. 106a - 106q ustawy. Pola dotyczące wartości
sprzedaży i podatku wypełnia się w walucie, w której wystawiono fakturę, z wyjątkiem pól
dotyczących podatku przeliczonego zgodnie z przepisami Działu VI w związku z art. 106e ust. 11
ustawy. W przypadku wystawienia faktury korygującej, wypełnia się wszystkie pola wg stanu po
korekcie, a pola dotyczące podstaw opodatkowania, podatku oraz należności ogółem wypełnia się
poprzez różnicę</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="KodWaluty" type="tns:TKodWaluty">
<xsd:annotation>
<xsd:documentation>Trzyliterowy kod waluty (ISO 4217)</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_1" type="tns:TDataT">
<xsd:annotation>
<xsd:documentation>Data wystawienia, z zastrzeżeniem art. 106na ust. 1
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_1M" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Miejsce wystawienia faktury</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_2" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Kolejny numer faktury, nadany w ramach jednej lub więcej
serii, który w sposób jednoznaczny identyfikuje fakturę</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="WZ" type="tns:TZnakowy" minOccurs="0" maxOccurs="1000">
<xsd:annotation>
<xsd:documentation>Numery dokumentów magazynowych WZ (wydanie na
zewnątrz) związane z fakturą</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:choice minOccurs="0">

---

<xsd:element name="P_6" type="tns:TDataT">
<xsd:annotation>
<xsd:documentation>Data dokonania lub zakończenia dostawy towarów lub
wykonania usługi lub data otrzymania zapłaty, o której mowa w art. 106b ust. 1 pkt 4 ustawy, o ile
taka data jest określona i różni się od daty wystawienia faktury. Pole wypełnia się w przypadku, gdy
dla wszystkich pozycji faktury data jest wspólna</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="OkresFa">
<xsd:annotation>
<xsd:documentation>Okres, którego dotyczy faktura w przypadkach, o których
mowa w art. 19a ust. 3 zdanie pierwsze i ust. 4 oraz ust. 5 pkt 4 ustawy</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="P_6_Od" type="tns:TDataT">
<xsd:annotation>
<xsd:documentation>Data początkowa okresu, którego dotyczy
faktura</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_6_Do" type="tns:TDataT">
<xsd:annotation>
<xsd:documentation>Data końcowa okresu, którego dotyczy faktura - data
dokonania lub zakończenia dostawy towarów lub wykonania usługi</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
</xsd:choice>
<xsd:sequence minOccurs="0">
<xsd:annotation>
<xsd:documentation>Pola wypełniane w przypadku wystąpienia na fakturze
sprzedaży objętej stawką podstawową - aktualnie 23% albo 22%, z wyłączeniem procedury
marży</xsd:documentation>
</xsd:annotation>
<xsd:element name="P_13_1" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży netto ze stawką podstawową -
aktualnie 23% albo 22%. W przypadku faktur zaliczkowych, kwota zaliczki netto. W przypadku
faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_14_1" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota podatku od sumy wartości sprzedaży netto objętej
stawką podstawową - aktualnie 23% albo 22%. W przypadku faktur zaliczkowych, kwota podatku
wyliczona według wzoru, o którym mowa w art. 106f ust. 1 pkt 3 ustawy. W przypadku faktur
korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_14_1W" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>W przypadku gdy faktura jest wystawiona w walucie obcej,

---

kwota podatku od sumy wartości sprzedaży netto objętej stawką podstawową, przeliczona zgodnie
z przepisami Działu VI w związku z art. 106e ust. 11 ustawy - aktualnie 23% albo 22%. W
przypadku faktur zaliczkowych, kwota podatku wyliczona według wzoru, o którym mowa w art. 106f
ust. 1 pkt 3 ustawy. W przypadku faktur korygujących, kwota różnicy, o której mowa w art. 106j ust.
2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:sequence minOccurs="0">
<xsd:annotation>
<xsd:documentation>Pola wypełniane w przypadku wystąpienia na fakturze
sprzedaży objętej stawką obniżoną pierwszą - aktualnie 8 % albo 7%, z wyłączeniem procedury
marży</xsd:documentation>
</xsd:annotation>
<xsd:element name="P_13_2" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży netto objętej stawką obniżoną
pierwszą - aktualnie 8 % albo 7%. W przypadku faktur zaliczkowych, kwota zaliczki netto. W
przypadku faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_14_2" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota podatku od sumy wartości sprzedaży netto objętej
stawką obniżoną pierwszą - aktualnie 8% albo 7%. W przypadku faktur zaliczkowych, kwota
podatku wyliczona według wzoru, o którym mowa w art. 106f ust. 1 pkt 3 ustawy. W przypadku
faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_14_2W" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>W przypadku gdy faktura jest wystawiona w walucie obcej,
kwota podatku od sumy wartości sprzedaży netto objętej stawką obniżoną, przeliczona zgodnie z
przepisami Działu VI w związku z art. 106e ust. 11 ustawy - aktualnie 8% albo 7%. W przypadku
faktur zaliczkowych, kwota podatku wyliczona według wzoru, o którym mowa w art. 106f ust. 1 pkt
3 ustawy. W przypadku faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:sequence minOccurs="0">
<xsd:annotation>
<xsd:documentation>Pola wypełniane w przypadku wystąpienia na fakturze
sprzedaży objętej stawką obniżoną drugą - aktualnie 5%, z wyłączeniem procedury
marży</xsd:documentation>
</xsd:annotation>
<xsd:element name="P_13_3" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży netto objętej stawką obniżoną
drugą - aktualnie 5%. W przypadku faktur zaliczkowych, kwota zaliczki netto. W przypadku faktur
korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_14_3" type="tns:TKwotowy">

---

<xsd:annotation>
<xsd:documentation>Kwota podatku od sumy wartości sprzedaży netto objętej
stawką obniżoną drugą - aktualnie 5%. W przypadku faktur zaliczkowych, kwota podatku wyliczona
według wzoru, o którym mowa w art. 106f ust. 1 pkt 3 ustawy. W przypadku faktur korygujących,
kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_14_3W" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>W przypadku gdy faktura jest wystawiona w walucie obcej,
kwota podatku od sumy wartości sprzedaży netto objętej stawką obniżoną drugą, przeliczona
zgodnie z przepisami Działu VI w związku z art. 106e ust. 11 ustawy - aktualnie 5%. W przypadku
faktur zaliczkowych, kwota podatku wyliczona według wzoru, o którym mowa w art. 106f ust. 1 pkt
3 ustawy. W przypadku faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:sequence minOccurs="0">
<xsd:annotation>
<xsd:documentation>Pola wypełniane w przypadku wystąpienia na fakturze
sprzedaży objętej stawką obniżoną trzecią – ryczałtem dla taksówek
osobowych</xsd:documentation>
</xsd:annotation>
<xsd:element name="P_13_4" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży netto objętej ryczałtem dla
taksówek osobowych. W przypadku faktur zaliczkowych, kwota zaliczki netto. W przypadku faktur
korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_14_4" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota podatku od sumy wartości sprzedaży netto w
przypadku ryczałtu dla taksówek osobowych. W przypadku faktur zaliczkowych, kwota podatku
wyliczona według wzoru, o którym mowa w art. 106f ust. 1 pkt 3 ustawy. W przypadku faktur
korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_14_4W" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>W przypadku gdy faktura jest wystawiona w walucie obcej,
kwota podatku ryczałtu dla taksówek osobowych, przeliczona zgodnie z przepisami Działu VI w
związku z art. 106e ust. 11 ustawy. W przypadku faktur zaliczkowych, kwota podatku wyliczona
według wzoru, o którym mowa w art. 106f ust. 1 pkt 3 ustawy. W przypadku faktur korygujących,
kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:sequence minOccurs="0">
<xsd:annotation>
<xsd:documentation>Pola wypełniane w przypadku wystąpienia na fakturze
sprzedaży w procedurze szczególnej, o której mowa w dziale XII w rozdziale 6a
ustawy</xsd:documentation>
</xsd:annotation>
<xsd:element name="P_13_5" type="tns:TKwotowy">

---

<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży netto w przypadku procedury
szczególnej, o której mowa w dziale XII w rozdziale 6a ustawy. W przypadku faktur zaliczkowych,
kwota zaliczki netto. W przypadku faktur korygujących, kwota różnicy, o której mowa w art. 106j
ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_14_5" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kwota podatku od wartości dodanej w przypadku procedury
szczególnej, o której mowa w dziale XII w rozdziale 6a ustawy. W przypadku faktur zaliczkowych,
kwota podatku wyliczona według wzoru, o którym mowa w art. 106f ust. 1 pkt 3 ustawy. W
przypadku faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:element name="P_13_6_1" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży objętej stawką 0% z wyłączeniem
wewnątrzwspólnotowej dostawy towarów i eksportu. W przypadku faktur zaliczkowych, kwota
zaliczki. W przypadku faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_13_6_2" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży objętej stawką 0% w przypadku
wewnątrzwspólnotowej dostawy towarów. W przypadku faktur korygujących, kwota różnicy, o której
mowa w art. 106j ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_13_6_3" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży objętej stawką 0% w przypadku
eksportu. W przypadku faktur zaliczkowych, kwota zaliczki. W przypadku faktur korygujących,
kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_13_7" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży zwolnionej od podatku. W
przypadku faktur zaliczkowych, kwota zaliczki. W przypadku faktur korygujących, kwota różnicy
wartości sprzedaży</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_13_8" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży w przypadku dostawy towarów
oraz świadczenia usług poza terytorium kraju, z wyłączeniem kwot wykazanych w polach P_13_5 i
P_13_9. W przypadku faktur zaliczkowych, kwota zaliczki. W przypadku faktur korygujących, kwota
różnicy wartości sprzedaży</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_13_9" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>

---

<xsd:documentation>Suma wartości świadczenia usług, o których mowa w art. 100
ust. 1 pkt 4 ustawy. W przypadku faktur zaliczkowych, kwota zaliczki. W przypadku faktur
korygujących, kwota różnicy wartości sprzedaży</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_13_10" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży w procedurze odwrotnego
obciążenia, dla której podatnikiem jest nabywca zgodnie z art. 17 ust. 1 pkt 7 i 8 ustawy oraz
innych przypadków odwrotnego obciążenia występujących w obrocie krajowym. W przypadku
faktur zaliczkowych, kwota zaliczki. W przypadku faktur korygujących, kwota różnicy, o której mowa
w art. 106j ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_13_11" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży w procedurze marży, o której
mowa w art. 119 i art. 120 ustawy. W przypadku faktur zaliczkowych, kwota zaliczki. W przypadku
faktur korygujących, kwota różnicy wartości sprzedaży</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_15" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota należności ogółem. W przypadku faktur zaliczkowych
kwota zapłaty dokumentowana fakturą. W przypadku faktur, o których mowa w art. 106f ust. 3
ustawy kwota pozostała do zapłaty. W przypadku faktur korygujących korekta kwoty wynikającej z
faktury korygowanej. W przypadku, o którym mowa w art. 106j ust. 3 ustawy korekta kwot
wynikających z faktur korygowanych</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="KursWalutyZ" type="tns:TIlosci" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kurs waluty stosowany do wyliczenia kwoty podatku w
przypadkach, o których mowa w przepisach Działu VI ustawy na fakturach, o których mowa w art.
106b ust. 1 pkt 4 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Adnotacje">
<xsd:annotation>
<xsd:documentation>Inne adnotacje na fakturze</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="P_16" type="etd:TWybor1_2">
<xsd:annotation>
<xsd:documentation>W przypadku dostawy towarów lub świadczenia usług,
w odniesieniu do których obowiązek podatkowy powstaje zgodnie z art. 19a ust. 5 pkt 1 lub art. 21
ust. 1 ustawy - wyrazy "metoda kasowa", należy podać wartość "1"; w przeciwnym przypadku -
wartość "2"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_17" type="etd:TWybor1_2">
<xsd:annotation>
<xsd:documentation>W przypadku faktur, o których mowa w art. 106d ust. 1
ustawy - wyraz "samofakturowanie", należy podać wartość "1"; w przeciwnym przypadku - wartość
"2"</xsd:documentation>

---

</xsd:annotation>
</xsd:element>
<xsd:element name="P_18" type="etd:TWybor1_2">
<xsd:annotation>
<xsd:documentation>W przypadku dostawy towarów lub wykonania usługi,
dla których obowiązanym do rozliczenia podatku od wartości dodanej lub podatku o podobnym
charakterze jest nabywca towaru lub usługi - wyrazy "odwrotne obciążenie", należy podać wartość
"1", w przeciwnym przypadku - wartość "2"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_18A" type="etd:TWybor1_2">
<xsd:annotation>
<xsd:documentation>W przypadku faktur, w których kwota należności
ogółem przekracza kwotę 15 000 zł lub jej równowartość wyrażoną w walucie obcej, obejmujących
dokonaną na rzecz podatnika dostawę towarów lub świadczenie usług, o których mowa w
załączniku nr 15 do ustawy - wyrazy "mechanizm podzielonej płatności", przy czym do przeliczania
na złote kwot wyrażonych w walucie obcej stosuje się zasady przeliczania kwot stosowane w celu
określenia podstawy opodatkowania; należy podać wartość "1", w przeciwnym przypadku - wartość
"2"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Zwolnienie">
<xsd:complexType>
<xsd:choice>
<xsd:sequence>
<xsd:element name="P_19" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik dostawy towarów lub świadczenia
usług zwolnionych od podatku na podstawie art. 43 ust. 1, art. 113 ust. 1 i 9 albo przepisów
wydanych na podstawie art. 82 ust. 3 ustawy lub na podstawie innych
przepisów</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:choice>
<xsd:element name="P_19A" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli pole P_19 równa się "1" - należy
wskazać przepis ustawy albo aktu wydanego na podstawie ustawy, na podstawie którego podatnik
stosuje zwolnienie od podatku</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_19B" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli pole P_19 równa się "1" - należy
wskazać przepis dyrektywy 2006/112/WE, który zwalnia od podatku taką dostawę towarów lub
takie świadczenie usług</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_19C" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli pole P_19 równa się "1" - należy
wskazać inną podstawę prawną wskazującą na to, że dostawa towarów lub świadczenie usług
korzysta ze zwolnienia od podatku</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>

---

</xsd:sequence>
<xsd:element name="P_19N" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik braku dostawy towarów lub
świadczenia usług zwolnionych od podatku na podstawie art. 43 ust. 1, art. 113 ust. 1 i 9 ustawy
albo przepisów wydanych na podstawie art. 82 ust. 3 ustawy lub na podstawie innych
przepisów</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
</xsd:complexType>
</xsd:element>
<xsd:element name="NoweSrodkiTransportu">
<xsd:complexType>
<xsd:choice>
<xsd:sequence>
<xsd:element name="P_22" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik wewnątrzwspólnotowej dostawy
nowych środków transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_42_5" type="etd:TWybor1_2">
<xsd:annotation>
<xsd:documentation>Jeśli występuje obowiązek, o którym mowa w
art. 42 ust. 5 ustawy, należy podać wartość "1", w przeciwnym przypadku - wartość
"2"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="NowySrodekTransportu" maxOccurs="10000">
<xsd:complexType>
<xsd:sequence>
<xsd:element name="P_22A" type="tns:TDataT">
<xsd:annotation>
<xsd:documentation>Data dopuszczenia nowego środka
transportu do użytku</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_NrWierszaNST" type="tns:TNaturalny">
<xsd:annotation>
<xsd:documentation>Numer wiersza faktury, w którym
wykazano dostawę nowego środka transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22BMK" type="tns:TZnakowy"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Marka nowego środka
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22BMD" type="tns:TZnakowy"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Model nowego środka
transportu</xsd:documentation>

---

</xsd:annotation>
</xsd:element>
<xsd:element name="P_22BK" type="tns:TZnakowy"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kolor nowego środka
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22BNR" type="tns:TZnakowy"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer rejestracyjny nowego środka
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22BRP" type="tns:TZnakowy"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Rok produkcji nowego środka
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:choice>
<xsd:sequence>
<xsd:element name="P_22B" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów
lądowych, o których mowa w art. 2 pkt 10 lit. a ustawy - należy podać przebieg
pojazdu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:choice minOccurs="0">
<xsd:element name="P_22B1" type="tns:TZnakowy"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów
lądowych, o których mowa w art. 2 pkt 10 lit. a ustawy - można podać numer
VIN</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22B2" type="tns:TZnakowy"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów
lądowych, o których mowa w art. 2 pkt 10 lit. a ustawy - można podać numer
nadwozia</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22B3" type="tns:TZnakowy"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów
lądowych, o których mowa w art. 2 pkt 10 lit. a ustawy - można podać numer
podwozia</xsd:documentation>
</xsd:annotation>

---

</xsd:element>
<xsd:element name="P_22B4" type="tns:TZnakowy"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów
lądowych, o których mowa w art. 2 pkt 10 lit. a ustawy - można podać numer
ramy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
<xsd:element name="P_22BT" type="tns:TZnakowy"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów
lądowych, o których mowa w art. 2 pkt 10 lit. a ustawy - można podać typ nowego środka
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:sequence>
<xsd:element name="P_22C" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy jednostek
pływających, o których mowa w art. 2 pkt 10 lit. b ustawy, należy podać liczbę godzin roboczych
używania nowego środka transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22C1" type="tns:TZnakowy"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy jednostek
pływających, o których mowa w art. 2 pkt 10 lit. b ustawy, można podać numer kadłuba nowego
środka transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:sequence>
<xsd:element name="P_22D" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy statków
powietrznych, o których mowa w art. 2 pkt 10 lit. c ustawy, należy podać liczbę godzin roboczych
używania nowego środka transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22D1" type="tns:TZnakowy"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy statków
powietrznych, o których mowa w art. 2 pkt 10 lit. c ustawy, można podać numer fabryczny nowego
środka transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:choice>
</xsd:sequence>
</xsd:complexType>

---

</xsd:element>
</xsd:sequence>
<xsd:element name="P_22N" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik braku wewnątrzwspólnotowej dostawy
nowych środków transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
</xsd:complexType>
</xsd:element>
<xsd:element name="P_23" type="etd:TWybor1_2">
<xsd:annotation>
<xsd:documentation>W przypadku faktur wystawianych w procedurze
uproszczonej przez drugiego w kolejności podatnika, o którym mowa w art. 135 ust. 1 pkt 4 lit. b i c
oraz ust. 2, zawierającej adnotację, o której mowa w art. 136 ust. 1 pkt 1 i stwierdzenie, o którym
mowa w art. 136 ust. 1 pkt 2 ustawy, należy podać wartość "1", w przeciwnym przypadku - wartość
"2"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="PMarzy">
<xsd:complexType>
<xsd:choice>
<xsd:sequence>
<xsd:element name="P_PMarzy" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik wystąpienia procedur marży, o
których mowa w art. 119 lub art. 120 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:choice>
<xsd:element name="P_PMarzy_2" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik świadczenia usług turystyki, dla
których podstawę opodatkowania stanowi marża, zgodnie z art. 119 ust. 1 ustawy, a faktura
dokumentująca świadczenie zawiera wyrazy "procedura marży dla biur
podróży"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_PMarzy_3_1" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik dostawy towarów używanych dla
których podstawę opodatkowania stanowi marża, zgodnie z art. 120 ustawy, a faktura
dokumentująca dostawę zawiera wyrazy "procedura marży - towary
używane"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_PMarzy_3_2" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik dostawy dzieł sztuki dla których
podstawę opodatkowania stanowi marża, zgodnie z art. 120 ustawy, a faktura dokumentująca
dostawę zawiera wyrazy "procedura marży - dzieła sztuki"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_PMarzy_3_3" type="etd:TWybor1">
<xsd:annotation>

---

<xsd:documentation>Znacznik dostawy przedmiotów
kolekcjonerskich i antyków, dla których podstawę opodatkowania stanowi marża, zgodnie z art. 120
ustawy, a faktura dokumentująca dostawę zawiera wyrazy "procedura marży - przedmioty
kolekcjonerskie i antyki"</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
</xsd:sequence>
<xsd:element name="P_PMarzyN" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik braku wystąpienia procedur marży, o
których mowa w art. 119 lub art. 120 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
</xsd:complexType>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="RodzajFaktury" type="tns:TRodzajFaktury">
<xsd:annotation>
<xsd:documentation>Rodzaj faktury</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:sequence minOccurs="0">
<xsd:annotation>
<xsd:documentation>Dane dla przypadków, gdy pole RodzajFaktury przyjmuje
wartości KOR, KOR_ZAL lub KOR_ROZ</xsd:documentation>
</xsd:annotation>
<xsd:element name="PrzyczynaKorekty" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Przyczyna korekty dla faktur
korygujących</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="TypKorekty" type="tns:TTypKorekty" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Typ skutku korekty w ewidencji dla podatku od towarów i
usług</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DaneFaKorygowanej" maxOccurs="unbounded">
<xsd:annotation>
<xsd:documentation>Dane faktury korygowanej</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="DataWystFaKorygowanej" type="tns:TDataT">
<xsd:annotation>
<xsd:documentation>Data wystawienia faktury
korygowanej</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="NrFaKorygowanej" type="tns:TZnakowy">
<xsd:annotation>

---

<xsd:documentation>Numer faktury korygowanej</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:choice>
<xsd:sequence>
<xsd:element name="NrKSeF" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik numeru KSeF faktury
korygowanej</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="NrKSeFFaKorygowanej" type="tns:TNumerKSeF">
<xsd:annotation>
<xsd:documentation>Numer identyfikujący fakturę korygowaną w
KSeF</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:element name="NrKSeFN" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik faktury korygowanej wystawionej poza
KSeF</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="OkresFaKorygowanej" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Dla faktury korygującej, o której mowa w art. 106j ust. 3
ustawy - okres, do którego odnosi się udzielany opust lub udzielana obniżka, w przypadku gdy
podatnik udziela opustu lub obniżki ceny w odniesieniu do dostaw towarów lub usług dokonanych
lub świadczonych na rzecz jednego odbiorcy w danym okresie</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="NrFaKorygowany" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Poprawny numer faktury korygowanej w przypadku, gdy
przyczyną korekty jest błędny numer faktury korygowanej. W takim przypadku błędny numer
faktury należy wskazać w polu NrFaKorygowanej</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Podmiot1K" minOccurs="0">
<xsd:annotation>
<xsd:documentation>W przypadku korekty danych sprzedawcy należy podać
pełne dane sprzedawcy występujące na fakturze korygowanej. Pole nie dotyczy przypadku korekty
błędnego NIP występującego na fakturze pierwotnej - wówczas wymagana jest korekta faktury do
wartości zerowych</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="PrefiksPodatnika" type="tns:TKodyKrajowUE"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kod (prefiks) podatnika VAT UE dla przypadków

---

określonych w art. 97 ust. 10 pkt 2 i 3 ustawy oraz w przypadku, o którym mowa w art. 136 ust. 1
pkt 3 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DaneIdentyfikacyjne" type="tns:TPodmiot1">
<xsd:annotation>
<xsd:documentation>Dane identyfikujące podatnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Adres" type="tns:TAdres">
<xsd:annotation>
<xsd:documentation>Adres podatnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="Podmiot2K" minOccurs="0" maxOccurs="101">
<xsd:annotation>
<xsd:documentation>W przypadku korekty danych nabywcy występującego jako
Podmiot2 lub dodatkowego nabywcy występującego jako Podmiot3 należy podać pełne dane tego
podmiotu występujące na fakturze korygowanej. Korekcie nie podlegają błędne numery
identyfikujące nabywcę oraz dodatkowego nabywcę. W przypadku korygowania pozostałych
danych nabywcy lub dodatkowego nabywcy wskazany numer identyfikacyjny ma być tożsamy z
numerem w części Podmiot2 względnie Podmiot3 faktury korygującej</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="DaneIdentyfikacyjne" type="tns:TPodmiot2">
<xsd:annotation>
<xsd:documentation>Dane identyfikujące nabywcę</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Adres" type="tns:TAdres" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres nabywcy. Pola opcjonalne dla przypadków
określonych w art. 106e ust. 5 pkt 3 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="IDNabywcy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Unikalny klucz powiązania danych nabywcy na
fakturach korygujących, w przypadku gdy dane nabywcy na fakturze korygującej zmieniły się w
stosunku do danych na fakturze korygowanej</xsd:documentation>
</xsd:annotation>
<xsd:simpleType>
<xsd:restriction base="tns:TZnakowy50">
<xsd:maxLength value="32"/>
</xsd:restriction>
</xsd:simpleType>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:sequence minOccurs="0">
<xsd:element name="P_15ZK" type="tns:TKwotowy">

---

<xsd:annotation>
<xsd:documentation>W przypadku korekt faktur zaliczkowych, kwota zapłaty
przed korektą. W przypadku korekt faktur, o których mowa w art. 106f ust. 3 ustawy, kwota
pozostała do zapłaty przed korektą</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="KursWalutyZK" type="tns:TIlosci" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kurs waluty stosowany do wyliczenia kwoty podatku w
przypadkach, o których mowa w Dziale VI ustawy przed korektą</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:sequence>
<xsd:element name="ZaliczkaCzesciowa" minOccurs="0" maxOccurs="31">
<xsd:annotation>
<xsd:documentation>Dane dla przypadków faktur dokumentujących otrzymanie
więcej niż jednej płatności, o której mowa w art. 106b ust. 1 pkt 4 ustawy. W przypadku, gdy
faktura, o której mowa w art. 106f ust. 3 ustawy dokumentuje jednocześnie otrzymanie części
zapłaty przed dokonaniem czynności, różnica kwoty w polu P_15 i sumy poszczególnych pól
P_15Z stanowi kwotę pozostałą ponad płatności otrzymane przed wykonaniem czynności
udokumentowanej fakturą</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="P_6Z" type="tns:TDataT">
<xsd:annotation>
<xsd:documentation>Data otrzymania płatności, o której mowa w art. 106b
ust. 1 pkt 4 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_15Z" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota płatności, o której mowa w art. 106b ust. 1 pkt 4
ustawy, składająca się na kwotę w polu P_15. W przypadku faktur korygujących korekta kwoty
wynikającej z faktury korygowanej</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="KursWalutyZW" type="tns:TIlosci" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kurs waluty stosowany do wyliczenia kwoty podatku w
przypadkach, o których mowa w Dziale VI ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="FP" type="etd:TWybor1" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Faktura, o której mowa w art. 109 ust. 3d
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="TP" type="etd:TWybor1" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Istniejące powiązania między nabywcą a dokonującym

---

dostawy towarów lub usługodawcą, zgodnie z § 10 ust. 4 pkt 3, z zastrzeżeniem ust. 4b
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w deklaracjach podatkowych
i w ewidencji w zakresie podatku od towarów i usług</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DodatkowyOpis" type="tns:TKluczWartosc" minOccurs="0"
maxOccurs="10000">
<xsd:annotation>
<xsd:documentation>Pola przeznaczone dla wykazywania dodatkowych danych na
fakturze, w tym wymaganych przepisami prawa, dla których nie przewidziano innych
pól/elementów</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="FakturaZaliczkowa" minOccurs="0" maxOccurs="100">
<xsd:annotation>
<xsd:documentation>Numery faktur zaliczkowych lub ich numery KSeF, jeśli
zostały wystawione z użyciem KSeF</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:choice>
<xsd:sequence>
<xsd:element name="NrKSeFZN" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik faktury zaliczkowej wystawionej poza
KSeF</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="NrFaZaliczkowej" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Numer faktury zaliczkowej wystawionej poza KSeF.
Pole obowiązkowe dla faktury wystawianej po wydaniu towaru lub wykonaniu usługi, o której mowa
w art. 106f ust. 3 ustawy i ostatniej z faktur, o której mowa w art. 106f ust. 4
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:element name="NrKSeFFaZaliczkowej" type="tns:TNumerKSeF">
<xsd:annotation>
<xsd:documentation>Numer identyfikujący fakturę zaliczkową w KSeF. Pole
obowiązkowe w przypadku, gdy faktura zaliczkowa była wystawiona za pomocą
KSeF</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
</xsd:complexType>
</xsd:element>
<xsd:element name="ZwrotAkcyzy" type="etd:TWybor1" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Informacja dodatkowa niezbędna dla rolników ubiegających
się o zwrot podatku akcyzowego zawartego w cenie oleju napędowego</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="FaWiersz" minOccurs="0" maxOccurs="10000">
<xsd:annotation>
<xsd:documentation>Szczegółowe pozycje faktury w walucie, w której wystawiono
fakturę - węzeł opcjonalny dla faktury zaliczkowej, faktury korygującej fakturę zaliczkową, oraz

---

faktur korygujących dotyczących wszystkich dostaw towarów lub usług dokonanych lub
świadczonych w danym okresie, o których mowa w art. 106j ust. 3 ustawy, dla których należy
podać dane dotyczące opustu lub obniżki w podziale na stawki podatku i procedury w części Fa. W
przypadku faktur korygujących, o których mowa w art. 106j ust. 3 ustawy, gdy opust lub obniżka
ceny odnosi się do części dostaw towarów lub usług dokonanych lub świadczonych w danym
okresie w części FaWiersz należy podać nazwy (rodzaje) towarów lub usług objętych korektą. W
przypadku faktur, o których mowa w art. 106f ust. 3 ustawy, należy wykazać pełne wartości
zamówienia lub umowy. W przypadku faktur korygujących pozycje faktury (w tym faktur
korygujących faktury, o których mowa w art. 106f ust. 3 ustawy, jeśli korekta dotyczy wartości
zamówienia), należy wykazać różnice wynikające z korekty poszczególnych pozycji lub dane
pozycji korygowanych w stanie przed korektą i po korekcie jako osobne wiersze. W przypadku
faktur korygujących faktury, o których mowa w art. 106f ust. 3 ustawy, jeśli korekta nie dotyczy
wartości zamówienia i jednocześnie zmienia wysokość podstawy opodatkowania lub podatku,
należy wprowadzić zapis wg stanu przed korektą i zapis w stanie po korekcie w celu potwierdzenia
braku zmiany wartości danej pozycji faktury</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="NrWierszaFa" type="tns:TNaturalny">
<xsd:annotation>
<xsd:documentation>Kolejny numer wiersza faktury</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="UU_ID" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Uniwersalny unikalny numer wiersza
faktury</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_6A" type="tns:TDataT" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Data dokonania lub zakończenia dostawy towarów lub
wykonania usługi lub data otrzymania zapłaty, o której mowa w art. 106b ust. 1 pkt 4 ustawy, o ile
taka data jest określona i różni się od daty wystawienia faktury. Pole wypełnia się dla przypadku,
gdy dla poszczególnych pozycji faktury występują różne daty</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_7" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Nazwa (rodzaj) towaru lub usługi. Pole opcjonalne
wyłącznie dla przypadku określonego w art 106j ust. 3 pkt 2 ustawy (faktura
korygująca)</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Indeks" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Pole przeznaczone do wpisania wewnętrznego kodu
towaru lub usługi nadanego przez podatnika albo dodatkowego opisu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="GTIN" type="tns:TZnakowy20" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Globalny numer jednostki
handlowej</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

<xsd:element name="PKWiU" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Symbol Polskiej Klasyfikacji Wyrobów i
Usług</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="CN" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Symbol Nomenklatury Scalonej</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="PKOB" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Symbol Polskiej Klasyfikacji Obiektów
Budowlanych</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_8A" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Miara dostarczonych towarów lub zakres wykonanych
usług. Pole opcjonalne dla przypadku określonego w art. 106e ust. 5 pkt 3
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_8B" type="tns:TIlosci" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Ilość (liczba) dostarczonych towarów lub zakres
wykonanych usług. Pole opcjonalne dla przypadku określonego w art. 106e ust. 5 pkt 3
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_9A" type="tns:TKwotowy2" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Cena jednostkowa towaru lub usługi bez kwoty podatku
(cena jednostkowa netto). Pole opcjonalne dla przypadków określonych w art. 106e ust. 2 i 3 oraz
ust. 5 pkt 3 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_9B" type="tns:TKwotowy2" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Cena wraz z kwotą podatku (cena jednostkowa brutto),
w przypadku zastosowania art. 106e ust. 7 i 8 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_10" type="tns:TKwotowy2" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kwoty wszelkich opustów lub obniżek cen, w tym w
formie rabatu z tytułu wcześniejszej zapłaty, o ile nie zostały one uwzględnione w cenie
jednostkowej netto, a w przypadku stosowania art. 106e ust. 7 ustawy w cenie jednostkowej brutto.
Pole opcjonalne dla przypadków określonych w art. 106e ust. 2 i 3 oraz ust. 5 pkt 1
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_11" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Wartość dostarczonych towarów lub wykonanych

---

usług, objętych transakcją, bez kwoty podatku (wartość sprzedaży netto). Pole opcjonalne dla
przypadków określonych w art. 106e ust. 2 i 3 oraz ust. 5 pkt 3 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_11A" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Wartość sprzedaży brutto, w przypadku zastosowania
art. 106e ust. 7 i 8 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_11Vat" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kwota podatku w przypadku, o którym mowa w art.
106e ust. 10 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_12" type="tns:TStawkaPodatku" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Stawka podatku. Pole opcjonalne dla przypadków
określonych w art. 106e ust. 2, 3, ust. 4 pkt 3 i ust. 5 pkt 3 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_12_XII" type="tns:TProcentowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Stawka podatku od wartości dodanej w przypadku, o
którym mowa w dziale XII w rozdziale 6a ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_12_Zal_15" type="etd:TWybor1" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Znacznik dla towaru lub usługi wymienionych w
załączniku nr 15 do ustawy - wartość "1"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="KwotaAkcyzy" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kwota podatku akcyzowego zawarta w cenie
towaru</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="GTU" type="tns:TGTU" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Oznaczenie dotyczące dostawy towarów i świadczenia
usług</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Procedura" type="tns:TOznaczenieProcedury"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Oznaczenie dotyczące procedury</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="KursWaluty" type="tns:TIlosci" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kurs waluty stosowany do wyliczenia kwoty podatku w
przypadkach, o których mowa w Dziale VI ustawy</xsd:documentation>

---

</xsd:annotation>
</xsd:element>
<xsd:element name="StanPrzed" type="etd:TWybor1" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Znacznik stanu przed korektą w przypadku faktury
korygującej lub faktury korygującej fakturę wystawioną w związku z art. 106f ust. 3 ustawy, w
przypadku gdy korekta dotyczy danych wykazanych w pozycjach faktury i jest dokonywana w
sposób polegający na wykazaniu danych przed korektą i po korekcie jako osobnych wierszy z
odrębną numeracją oraz w przypadku potwierdzania braku zmiany wartości danej
pozycji</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="Rozliczenie" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Dodatkowe rozliczenia na fakturze</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="Obciazenia" minOccurs="0" maxOccurs="100">
<xsd:annotation>
<xsd:documentation>Obciążenia</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="Kwota" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota doliczona do kwoty wykazanej w polu
P_15</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Powod" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Powód obciążenia</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="SumaObciazen" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Suma obciążeń</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Odliczenia" minOccurs="0" maxOccurs="100">
<xsd:annotation>
<xsd:documentation>Odliczenia</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="Kwota" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota odliczona od kwoty wykazanej w polu
P_15</xsd:documentation>

---

</xsd:annotation>
</xsd:element>
<xsd:element name="Powod" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Powód odliczenia</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="SumaOdliczen" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Suma odliczeń</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:choice minOccurs="0">
<xsd:element name="DoZaplaty" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota należności do zapłaty równa polu P_15
powiększonemu o Obciazenia i pomniejszonemu o Odliczenia</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DoRozliczenia" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota nadpłacona do
rozliczenia/zwrotu</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="Platnosc" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Warunki płatności</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:choice minOccurs="0">
<xsd:sequence>
<xsd:element name="Zaplacono" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik informujący, że kwota należności
wynikająca z faktury została zapłacona: 1 - zapłacono</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DataZaplaty" type="tns:TData">
<xsd:annotation>
<xsd:documentation>Data zapłaty, jeśli do wystawienia faktury płatność
została dokonana</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:sequence>
<xsd:element name="ZnacznikZaplatyCzesciowej" type="etd:TWybor1">
<xsd:annotation>

---

<xsd:documentation>Znacznik informujący, że kwota należności
wynikająca z faktury została zapłacona w części: 1 - zapłacono w części</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="ZaplataCzesciowa" maxOccurs="100">
<xsd:annotation>
<xsd:documentation>Dane zapłat częściowych</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="KwotaZaplatyCzesciowej" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota zapłaty
częściowej</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DataZaplatyCzesciowej" type="tns:TData">
<xsd:annotation>
<xsd:documentation>Data zapłaty częściowej, jeśli do wystawienia
faktury płatność częściowa została dokonana</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
</xsd:sequence>
</xsd:choice>
<xsd:element name="TerminPlatnosci" minOccurs="0" maxOccurs="100">
<xsd:complexType>
<xsd:sequence>
<xsd:element name="Termin" type="tns:TData">
<xsd:annotation>
<xsd:documentation>Termin płatności</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="TerminOpis" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Opis terminu płatności</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:choice minOccurs="0">
<xsd:element name="FormaPlatnosci" type="tns:TFormaPlatnosci">
<xsd:annotation>
<xsd:documentation>Forma płatności</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:sequence>
<xsd:element name="PlatnoscInna" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik innej formy płatności: 1 - inna forma
płatności</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

<xsd:element name="OpisPlatnosci" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Doprecyzowanie innej formy
płatności</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:choice>
<xsd:element name="RachunekBankowy" type="tns:TRachunekBankowy"
minOccurs="0" maxOccurs="100">
<xsd:annotation>
<xsd:documentation>Numer rachunku</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="RachunekBankowyFaktora"
type="tns:TRachunekBankowy" minOccurs="0" maxOccurs="20">
<xsd:annotation>
<xsd:documentation>Rachunek faktora</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Skonto" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Skonto</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="WarunkiSkonta" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Warunki, które nabywca powinien spełnić aby
skorzystać ze skonta</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="WysokoscSkonta" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Wysokość skonta</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="WarunkiTransakcji" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Warunki transakcji, o ile występują</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="Umowy" minOccurs="0" maxOccurs="100">
<xsd:complexType>
<xsd:sequence minOccurs="0">
<xsd:element name="DataUmowy" type="tns:TData" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Data umowy</xsd:documentation>
</xsd:annotation>

---

</xsd:element>
<xsd:element name="NrUmowy" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer umowy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="Zamowienia" minOccurs="0" maxOccurs="100">
<xsd:complexType>
<xsd:sequence minOccurs="0">
<xsd:element name="DataZamowienia" type="tns:TData" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Data zamówienia</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="NrZamowienia" type="tns:TZnakowy"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer zamówienia</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="NrPartiiTowaru" type="tns:TZnakowy" minOccurs="0"
maxOccurs="1000">
<xsd:annotation>
<xsd:documentation>Numery partii towaru</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="WarunkiDostawy" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Warunki dostawy towarów - w przypadku istnienia
pomiędzy stronami transakcji, umowy określającej warunki dostawy tzw.
Incoterms</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:sequence minOccurs="0">
<xsd:element name="KursUmowny" type="tns:TIlosci">
<xsd:annotation>
<xsd:documentation>Kurs umowny - w przypadkach, gdy na fakturze
znajduje się informacja o kursie, po którym zostały przeliczone kwoty wykazane na fakturze w
złotych. Nie dotyczy przypadków, o których mowa w Dziale VI ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="WalutaUmowna" type="tns:TKodWaluty">
<xsd:annotation>
<xsd:documentation>Waluta umowna - trzyliterowy kod waluty (ISO-4217)
w przypadkach, gdy na fakturze znajduje się informacja o kursie, po którym zostały przeliczone
kwoty wykazane na fakturze w złotych. Nie dotyczy przypadków, o których mowa w Dziale VI
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>

---

<xsd:element name="Transport" minOccurs="0" maxOccurs="20">
<xsd:complexType>
<xsd:sequence>
<xsd:choice>
<xsd:element name="RodzajTransportu" type="tns:TRodzajTransportu">
<xsd:annotation>
<xsd:documentation>Rodzaj zastosowanego transportu w przypadku
dokonanej dostawy towarów</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:sequence>
<xsd:element name="TransportInny" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik innego rodzaju transportu: 1 - inny
rodzaj transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="OpisInnegoTransportu" type="tns:TZnakowy50">
<xsd:annotation>
<xsd:documentation>Opis innego rodzaju
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:choice>
<xsd:element name="Przewoznik" minOccurs="0">
<xsd:complexType>
<xsd:sequence>
<xsd:element name="DaneIdentyfikacyjne" type="tns:TPodmiot2">
<xsd:annotation>
<xsd:documentation>Dane identyfikacyjne
przewoźnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="AdresPrzewoznika" type="tns:TAdres">
<xsd:annotation>
<xsd:documentation>Adres przewoźnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="NrZleceniaTransportu" type="tns:TZnakowy"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer zlecenia transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:sequence>
<xsd:choice>
<xsd:element name="OpisLadunku" type="tns:TLadunek">
<xsd:annotation>
<xsd:documentation>Rodzaj ładunku</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:sequence>

---

<xsd:element name="LadunekInny" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik innego ładunku: 1 - inny
ładunek</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="OpisInnegoLadunku" type="tns:TZnakowy50">
<xsd:annotation>
<xsd:documentation>Opis innego ładunku, w tym ładunek
mieszany</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:choice>
<xsd:element name="JednostkaOpakowania" type="tns:TZnakowy"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jednostka opakowania</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:sequence minOccurs="0">
<xsd:element name="DataGodzRozpTransportu" type="tns:TDataCzas"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Data i godzina rozpoczęcia
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DataGodzZakTransportu" type="tns:TDataCzas"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Data i godzina zakończenia
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="WysylkaZ" type="tns:TAdres" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres miejsca wysyłki</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="WysylkaPrzez" type="tns:TAdres" minOccurs="0"
maxOccurs="20">
<xsd:annotation>
<xsd:documentation>Adres pośredni wysyłki</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="WysylkaDo" type="tns:TAdres" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres miejsca docelowego, do którego został
zlecony transport</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:sequence>
</xsd:complexType>

---

</xsd:element>
<xsd:element name="PodmiotPosredniczacy" type="etd:TWybor1"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Wartość "1" oznacza dostawę dokonaną przez
podmiot, o którym mowa w art. 22 ust. 2d ustawy. Pole dotyczy przypadku, w którym podmiot
uczestniczy w transakcji łańcuchowej innej niż procedura trójstronna uproszczona, o której mowa w
art. 135 ust. 1 pkt 4 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="Zamowienie" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Zamówienie lub umowa, o których mowa w art. 106f ust. 1 pkt
4 ustawy (dla faktur zaliczkowych) w walucie, w której wystawiono fakturę zaliczkową. W
przypadku faktury korygującej fakturę zaliczkową należy wykazać różnice wynikające z korekty
poszczególnych pozycji zamówienia lub umowy lub dane pozycji korygowanych w stanie przed
korektą i po korekcie jako osobne wiersze, jeśli korekta dotyczy wartości zamówienia lub umowy.
W przypadku faktur korygujących faktury zaliczkowe, jeśli korekta nie dotyczy wartości zamówienia
lub umowy i jednocześnie zmienia wysokość podstawy opodatkowania lub podatku, należy
wprowadzić zapis wg stanu przed korektą i zapis w stanie po korekcie w celu potwierdzenia braku
zmiany wartości danej pozycji</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="WartoscZamowienia" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Wartość zamówienia lub umowy z uwzględnieniem
kwoty podatku</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="ZamowienieWiersz" maxOccurs="10000">
<xsd:annotation>
<xsd:documentation>Szczegółowe pozycje zamówienia lub umowy w
walucie, w której wystawiono fakturę zaliczkową</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="NrWierszaZam" type="tns:TNaturalny">
<xsd:annotation>
<xsd:documentation>Kolejny numer wiersza zamówienia lub
umowy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="UU_IDZ" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Uniwersalny unikalny numer wiersza zamówienia
lub umowy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_7Z" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Nazwa (rodzaj) towaru lub
usługi</xsd:documentation>

---

</xsd:annotation>
</xsd:element>
<xsd:element name="IndeksZ" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Pole przeznaczone do wpisania wewnętrznego
kodu towaru lub usługi nadanego przez podatnika albo dodatkowego opisu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="GTINZ" type="tns:TZnakowy20" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Globalny numer jednostki
handlowej</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="PKWiUZ" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Symbol Polskiej Klasyfikacji Wyrobów i
Usług</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="CNZ" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Symbol Nomenklatury
Scalonej</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="PKOBZ" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Symbol Polskiej Klasyfikacji Obiektów
Budowlanych</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_8AZ" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Miara zamówionego towaru lub zakres
usługi</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_8BZ" type="tns:TIlosci" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Ilość zamówionego towaru lub zakres
usługi</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_9AZ" type="tns:TKwotowy2" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Cena jednostkowa netto</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_11NettoZ" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Wartość zamówionego towaru lub usługi bez
kwoty podatku</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_11VatZ" type="tns:TKwotowy" minOccurs="0">

---

<xsd:annotation>
<xsd:documentation>Kwota podatku od zamówionego towaru lub
usługi</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_12Z" type="tns:TStawkaPodatku" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Stawka podatku</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_12Z_XII" type="tns:TProcentowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Stawka podatku od wartości dodanej w
przypadku, o którym mowa w dziale XII w rozdziale 6a ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_12Z_Zal_15" type="etd:TWybor1" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Znacznik dla towaru lub usługi wymienionych w
załączniku nr 15 do ustawy - wartość "1"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="GTUZ" type="tns:TGTU" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Oznaczenie dotyczące dostawy towarów i
świadczenia usług</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="ProceduraZ" type="tns:TOznaczenieProceduryZ"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Oznaczenia dotyczące
procedur</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="KwotaAkcyzyZ" type="tns:TKwotowy"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kwota podatku akcyzowego zawarta w cenie
towaru</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="StanPrzedZ" type="etd:TWybor1" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Znacznik stanu przed korektą w przypadku
faktury korygującej fakturę dokumentującą otrzymanie zapłaty lub jej części przed dokonaniem
czynności oraz fakturę wystawioną w związku z art. 106f ust. 4 ustawy, w przypadku gdy korekta
dotyczy danych wykazanych w pozycjach zamówienia i jest dokonywana w sposób polegający na
wykazaniu danych przed korektą i po korekcie jako osobnych wierszy z odrębną numeracją oraz w
przypadku potwierdzania braku zmiany wartości danej pozycji</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
</xsd:sequence>

---

</xsd:complexType>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="Stopka" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Pozostałe dane na fakturze</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence minOccurs="0">
<xsd:element name="Informacje" minOccurs="0" maxOccurs="3">
<xsd:annotation>
<xsd:documentation>Pozostałe dane</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence minOccurs="0">
<xsd:element name="StopkaFaktury" type="etd:TTekstowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Stopka faktury</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="Rejestry" minOccurs="0" maxOccurs="100">
<xsd:annotation>
<xsd:documentation>Numery podmiotu lub grupy podmiotów w innych rejestrach i
bazach danych</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence minOccurs="0">
<xsd:element name="PelnaNazwa" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Pełna nazwa</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="KRS" type="etd:TNrKRS" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer Krajowego Rejestru
Sądowego</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="REGON" type="etd:TNrREGON" minOccurs="0">
<xsd:annotation>
<xsd:documentation>REGON</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="BDO" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer w Bazie Danych o
Odpadach</xsd:documentation>
</xsd:annotation>
<xsd:simpleType>
<xsd:restriction base="tns:TZnakowy">
<xsd:maxLength value="9"/>

---

</xsd:restriction>
</xsd:simpleType>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
element Faktura/Naglowek
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TNaglowek
content complex
properties
children tns:KodFormularza tns:WariantFormularza tns:DataWytworzeniaFa tns:SystemInfo
documentation
annotation
Nagłówek
source <xsd:element name="Naglowek" type="tns:TNaglowek">
<xsd:annotation>
<xsd:documentation>Nagłówek</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Podmiot1
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
content complex
properties
children tns:PrefiksPodatnika tns:NrEORI tns:DaneIdentyfikacyjne tns:Adres tns:AdresKoresp tns:DaneKontaktowe
tns:StatusInfoPodatnika
documentation
annotation
Dane podatnika. Imię i nazwisko lub nazwa sprzedawcy towarów lub usług
source <xsd:element name="Podmiot1">
<xsd:annotation>
<xsd:documentation>Dane podatnika. Imię i nazwisko lub nazwa sprzedawcy towarów lub
usług</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="PrefiksPodatnika" type="tns:TKodyKrajowUE" fixed="PL"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kod (prefiks) podatnika VAT UE dla przypadków określonych w art.
97 ust. 10 pkt 2 i 3 ustawy oraz w przypadku, o którym mowa w art. 136 ust. 1 pkt 3
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="NrEORI" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer EORI podatnika (sprzedawcy)</xsd:documentation>

---

</xsd:annotation>
</xsd:element>
<xsd:element name="DaneIdentyfikacyjne" type="tns:TPodmiot1">
<xsd:annotation>
<xsd:documentation>Dane identyfikujące podatnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Adres" type="tns:TAdres">
<xsd:annotation>
<xsd:documentation>Adres podatnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="AdresKoresp" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres korespondencyjny podatnika</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:complexContent>
<xsd:extension base="tns:TAdres"/>
</xsd:complexContent>
</xsd:complexType>
</xsd:element>
<xsd:element name="DaneKontaktowe" minOccurs="0" maxOccurs="3">
<xsd:annotation>
<xsd:documentation>Dane kontaktowe podatnika</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence minOccurs="0">
<xsd:element name="Email" type="etd:TAdresEmail" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres e-mail podatnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Telefon" type="tns:TNumerTelefonu" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer telefonu podatnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="StatusInfoPodatnika" type="tns:TStatusInfoPodatnika" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Status podatnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>

---

element Faktura/Podmiot1/PrefiksPodatnika
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKodyKrajowUE
minOcc 0
properties
maxOcc 1
content simple
fixed PL
Kind Value Annotation
facets
enumeration AT documentation
AUSTRIA
enumeration BE documentation
BELGIA
enumeration BG documentation
BUŁGARIA
enumeration CY documentation
CYPR
enumeration CZ documentation
CZECHY
enumeration DK documentation
DANIA
enumeration EE documentation
ESTONIA
enumeration FI documentation
FINLANDIA
enumeration FR documentation
FRANCJA
enumeration DE documentation
NIEMCY
enumeration EL documentation
GRECJA
enumeration HR documentation
CHORWACJA
enumeration HU documentation
WĘGRY
enumeration IE documentation
IRLANDIA
enumeration IT documentation
WŁOCHY
enumeration LV documentation
ŁOTWA
enumeration LT documentation
LITWA
enumeration LU documentation
LUKSEMBURG
enumeration MT documentation
MALTA
enumeration NL documentation
HOLANDIA
enumeration PL documentation
POLSKA
enumeration PT documentation
PORTUGALIA
enumeration RO documentation
RUMUNIA
enumeration SK documentation
SŁOWACJA
enumeration SI documentation
SŁOWENIA
enumeration ES documentation

---

HISZPANIA
enumeration SE documentation
SZWECJA
enumeration XI documentation
IRLANDIA PÓŁNOCNA
documentation
annotation
Kod (prefiks) podatnika VAT UE dla przypadków określonych w art. 97 ust. 10 pkt 2 i 3 ustawy oraz w przypadku, o
którym mowa w art. 136 ust. 1 pkt 3 ustawy
source <xsd:element name="PrefiksPodatnika" type="tns:TKodyKrajowUE" fixed="PL" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kod (prefiks) podatnika VAT UE dla przypadków określonych w art. 97
ust. 10 pkt 2 i 3 ustawy oraz w przypadku, o którym mowa w art. 136 ust. 1 pkt 3
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Podmiot1/NrEORI
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Numer EORI podatnika (sprzedawcy)
source <xsd:element name="NrEORI" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer EORI podatnika (sprzedawcy)</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Podmiot1/DaneIdentyfikacyjne
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TPodmiot1
content complex
properties

---

children tns:NIP tns:Nazwa
documentation
annotation
Dane identyfikujące podatnika
source <xsd:element name="DaneIdentyfikacyjne" type="tns:TPodmiot1">
<xsd:annotation>
<xsd:documentation>Dane identyfikujące podatnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Podmiot1/Adres
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TAdres
content complex
properties
children tns:KodKraju tns:AdresL1 tns:AdresL2 tns:GLN
documentation
annotation
Adres podatnika
source <xsd:element name="Adres" type="tns:TAdres">
<xsd:annotation>
<xsd:documentation>Adres podatnika</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Podmiot1/AdresKoresp
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type extension of tns:TAdres
minOcc 0
properties
maxOcc 1
content complex
children tns:KodKraju tns:AdresL1 tns:AdresL2 tns:GLN
documentation
annotation
Adres korespondencyjny podatnika
source <xsd:element name="AdresKoresp" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres korespondencyjny podatnika</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:complexContent>
<xsd:extension base="tns:TAdres"/>
</xsd:complexContent>
</xsd:complexType>
</xsd:element>
element Faktura/Podmiot1/DaneKontaktowe
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
minOcc 0
properties
maxOcc 3
content complex
children tns:Email tns:Telefon
documentation
annotation
Dane kontaktowe podatnika

---

source <xsd:element name="DaneKontaktowe" minOccurs="0" maxOccurs="3">
<xsd:annotation>
<xsd:documentation>Dane kontaktowe podatnika</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence minOccurs="0">
<xsd:element name="Email" type="etd:TAdresEmail" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres e-mail podatnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Telefon" type="tns:TNumerTelefonu" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer telefonu podatnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
element Faktura/Podmiot1/DaneKontaktowe/Email
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TAdresEmail
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 3
maxLength 255
pattern (.)+@(.)+
documentation
annotation
Adres e-mail podatnika
source <xsd:element name="Email" type="etd:TAdresEmail" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres e-mail podatnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Podmiot1/DaneKontaktowe/Telefon
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TNumerTelefonu
minOcc 0
properties
maxOcc 1

---

content simple
Kind Value Annotation
facets
minLength 1
maxLength 16
documentation
annotation
Numer telefonu podatnika
source <xsd:element name="Telefon" type="tns:TNumerTelefonu" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer telefonu podatnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Podmiot1/StatusInfoPodatnika
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TStatusInfoPodatnika
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
enumeration 1 documentation
Podatnik znajdujący się w stanie likwidacji
enumeration 2 documentation
Podatnik, który jest w trakcie postępowania restrukturyzacyjnego
enumeration 3 documentation
Podatnik znajdujący się w stanie upadłości
enumeration 4 documentation
Przedsiębiorstwo w spadku
documentation
annotation
Status podatnika
source <xsd:element name="StatusInfoPodatnika" type="tns:TStatusInfoPodatnika" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Status podatnika</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Podmiot2
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
content complex
properties
children tns:NrEORI tns:DaneIdentyfikacyjne tns:Adres tns:AdresKoresp tns:DaneKontaktowe tns:NrKlienta tns:IDNabywcy
documentation
annotation
Dane nabywcy
source <xsd:element name="Podmiot2">
<xsd:annotation>
<xsd:documentation>Dane nabywcy</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="NrEORI" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer EORI nabywcy towarów</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DaneIdentyfikacyjne" type="tns:TPodmiot2">
<xsd:annotation>
<xsd:documentation>Dane identyfikujące nabywcę</xsd:documentation>

---

</xsd:annotation>
</xsd:element>
<xsd:element name="Adres" type="tns:TAdres" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres nabywcy. Pola opcjonalne dla przypadków określonych w
art. 106e ust. 5 pkt 3 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="AdresKoresp" type="tns:TAdres" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres korespondencyjny nabywcy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DaneKontaktowe" minOccurs="0" maxOccurs="3">
<xsd:annotation>
<xsd:documentation>Dane kontaktowe nabywcy</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence minOccurs="0">
<xsd:element name="Email" type="etd:TAdresEmail" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres e-mail nabywcy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Telefon" type="tns:TNumerTelefonu" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer telefonu nabywcy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="NrKlienta" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer klienta dla przypadków, w których nabywca posługuje się
nim w umowie lub zamówieniu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="IDNabywcy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Unikalny klucz powiązania danych nabywcy na fakturach
korygujących, w przypadku gdy dane nabywcy na fakturze korygującej zmieniły się w stosunku do
danych na fakturze korygowanej</xsd:documentation>
</xsd:annotation>
<xsd:simpleType>
<xsd:restriction base="tns:TZnakowy50">
<xsd:maxLength value="32"/>
</xsd:restriction>
</xsd:simpleType>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>

---

element Faktura/Podmiot2/NrEORI
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Numer EORI nabywcy towarów
source <xsd:element name="NrEORI" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer EORI nabywcy towarów</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Podmiot2/DaneIdentyfikacyjne
diagram

---

namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TPodmiot2
content complex
properties
children tns:NIP tns:KodUE tns:NrVatUE tns:KodKraju tns:NrID tns:BrakID tns:Nazwa
documentation
annotation
Dane identyfikujące nabywcę
source <xsd:element name="DaneIdentyfikacyjne" type="tns:TPodmiot2">
<xsd:annotation>
<xsd:documentation>Dane identyfikujące nabywcę</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Podmiot2/Adres
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TAdres
minOcc 0
properties
maxOcc 1
content complex
children tns:KodKraju tns:AdresL1 tns:AdresL2 tns:GLN
documentation
annotation
Adres nabywcy. Pola opcjonalne dla przypadków określonych w art. 106e ust. 5 pkt 3 ustawy
source <xsd:element name="Adres" type="tns:TAdres" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres nabywcy. Pola opcjonalne dla przypadków określonych w art. 106e
ust. 5 pkt 3 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Podmiot2/AdresKoresp
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TAdres
minOcc 0
properties
maxOcc 1
content complex
children tns:KodKraju tns:AdresL1 tns:AdresL2 tns:GLN
documentation
annotation
Adres korespondencyjny nabywcy
source <xsd:element name="AdresKoresp" type="tns:TAdres" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres korespondencyjny nabywcy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Podmiot2/DaneKontaktowe
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
minOcc 0
properties
maxOcc 3
content complex
children tns:Email tns:Telefon
documentation
annotation
Dane kontaktowe nabywcy
source <xsd:element name="DaneKontaktowe" minOccurs="0" maxOccurs="3">
<xsd:annotation>
<xsd:documentation>Dane kontaktowe nabywcy</xsd:documentation>
</xsd:annotation>
<xsd:complexType>

---

<xsd:sequence minOccurs="0">
<xsd:element name="Email" type="etd:TAdresEmail" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres e-mail nabywcy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Telefon" type="tns:TNumerTelefonu" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer telefonu nabywcy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
element Faktura/Podmiot2/DaneKontaktowe/Email
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TAdresEmail
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 3
maxLength 255
pattern (.)+@(.)+
documentation
annotation
Adres e-mail nabywcy
source <xsd:element name="Email" type="etd:TAdresEmail" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres e-mail nabywcy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Podmiot2/DaneKontaktowe/Telefon
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TNumerTelefonu
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 16
documentation
annotation

---

Numer telefonu nabywcy
source <xsd:element name="Telefon" type="tns:TNumerTelefonu" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer telefonu nabywcy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Podmiot2/NrKlienta
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Numer klienta dla przypadków, w których nabywca posługuje się nim w umowie lub zamówieniu
source <xsd:element name="NrKlienta" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer klienta dla przypadków, w których nabywca posługuje się nim w
umowie lub zamówieniu</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Podmiot2/IDNabywcy
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of tns:TZnakowy50
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 32
documentation
annotation
Unikalny klucz powiązania danych nabywcy na fakturach korygujących, w przypadku gdy dane nabywcy na fakturze
korygującej zmieniły się w stosunku do danych na fakturze korygowanej

---

source <xsd:element name="IDNabywcy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Unikalny klucz powiązania danych nabywcy na fakturach korygujących, w
przypadku gdy dane nabywcy na fakturze korygującej zmieniły się w stosunku do danych na
fakturze korygowanej</xsd:documentation>
</xsd:annotation>
<xsd:simpleType>
<xsd:restriction base="tns:TZnakowy50">
<xsd:maxLength value="32"/>
</xsd:restriction>
</xsd:simpleType>
</xsd:element>

---

element Faktura/Podmiot3
diagram

---

namespace http://crd.gov.pl/wzor/2023/06/29/12648/
minOcc 0
properties
maxOcc 100
content complex
children tns:IDNabywcy tns:NrEORI tns:DaneIdentyfikacyjne tns:Adres tns:AdresKoresp tns:DaneKontaktowe tns:Rola
tns:RolaInna tns:OpisRoli tns:Udzial tns:NrKlienta
documentation
annotation
Dane podmiotu/-ów trzeciego/-ich (innego/-ych niż sprzedawca i nabywca wymieniony w części Podmiot2),
związanego/-ych z fakturą
source <xsd:element name="Podmiot3" minOccurs="0" maxOccurs="100">
<xsd:annotation>
<xsd:documentation>Dane podmiotu/-ów trzeciego/-ich (innego/-ych niż sprzedawca i nabywca
wymieniony w części Podmiot2), związanego/-ych z fakturą</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="IDNabywcy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Unikalny klucz powiązania danych nabywcy na fakturach
korygujących, w przypadku gdy dane nabywcy na fakturze korygującej zmieniły się w stosunku do
danych na fakturze korygowanej</xsd:documentation>
</xsd:annotation>
<xsd:simpleType>
<xsd:restriction base="tns:TZnakowy50">
<xsd:maxLength value="32"/>
</xsd:restriction>
</xsd:simpleType>
</xsd:element>
<xsd:element name="NrEORI" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer EORI podmiotu trzeciego</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DaneIdentyfikacyjne" type="tns:TPodmiot3">
<xsd:annotation>
<xsd:documentation>Dane identyfikujące podmiot trzeci</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Adres" type="tns:TAdres">
<xsd:annotation>
<xsd:documentation>Adres podmiotu trzeciego</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="AdresKoresp" type="tns:TAdres" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres korespondencyjny podmiotu trzeciego</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DaneKontaktowe" minOccurs="0" maxOccurs="3">
<xsd:annotation>
<xsd:documentation>Dane kontaktowe podmiotu trzeciego</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="Email" type="etd:TAdresEmail" minOccurs="0">
<xsd:annotation>

---

<xsd:documentation>Adres e-mail podmiotu trzeciego</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Telefon" type="tns:TNumerTelefonu" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer telefonu podmiotu trzeciego</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:choice>
<xsd:element name="Rola" type="tns:TRolaPodmiotu3">
<xsd:annotation>
<xsd:documentation>Rola podmiotu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:sequence>
<xsd:element name="RolaInna" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik innego podmiotu: 1 - Inny
podmiot</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="OpisRoli" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Opis roli podmiotu - w przypadku wyboru roli jako Inny
podmiot</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:choice>
<xsd:element name="Udzial" type="tns:TProcentowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Udział - procentowy udział dodatkowego nabywcy. Różnica
pomiędzy wartością 100% a sumą udziałów dodatkowych nabywców jest udziałem nabywcy
wymienionego w części Podmiot2. W przypadku niewypełnienia pola przyjmuje się, że udziały
występujących na fakturze nabywców są równe</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="NrKlienta" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer klienta dla przypadków, w których podmiot wymieniony jako
podmiot trzeci posługuje się nim w umowie lub zamówieniu</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>

---

element Faktura/Podmiot3/IDNabywcy
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of tns:TZnakowy50
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 32
documentation
annotation
Unikalny klucz powiązania danych nabywcy na fakturach korygujących, w przypadku gdy dane nabywcy na fakturze
korygującej zmieniły się w stosunku do danych na fakturze korygowanej
source <xsd:element name="IDNabywcy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Unikalny klucz powiązania danych nabywcy na fakturach korygujących, w
przypadku gdy dane nabywcy na fakturze korygującej zmieniły się w stosunku do danych na
fakturze korygowanej</xsd:documentation>
</xsd:annotation>
<xsd:simpleType>
<xsd:restriction base="tns:TZnakowy50">
<xsd:maxLength value="32"/>
</xsd:restriction>
</xsd:simpleType>
</xsd:element>
element Faktura/Podmiot3/NrEORI
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Numer EORI podmiotu trzeciego
source <xsd:element name="NrEORI" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer EORI podmiotu trzeciego</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Podmiot3/DaneIdentyfikacyjne
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TPodmiot3
content complex
properties
children tns:NIP tns:IDWew tns:KodUE tns:NrVatUE tns:KodKraju tns:NrID tns:BrakID tns:Nazwa
documentation
annotation
Dane identyfikujące podmiot trzeci
source <xsd:element name="DaneIdentyfikacyjne" type="tns:TPodmiot3">
<xsd:annotation>
<xsd:documentation>Dane identyfikujące podmiot trzeci</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Podmiot3/Adres
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TAdres
content complex
properties
children tns:KodKraju tns:AdresL1 tns:AdresL2 tns:GLN
documentation
annotation
Adres podmiotu trzeciego
source <xsd:element name="Adres" type="tns:TAdres">
<xsd:annotation>
<xsd:documentation>Adres podmiotu trzeciego</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Podmiot3/AdresKoresp
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TAdres

---

minOcc 0
properties
maxOcc 1
content complex
children tns:KodKraju tns:AdresL1 tns:AdresL2 tns:GLN
documentation
annotation
Adres korespondencyjny podmiotu trzeciego
source <xsd:element name="AdresKoresp" type="tns:TAdres" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres korespondencyjny podmiotu trzeciego</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Podmiot3/DaneKontaktowe
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
minOcc 0
properties
maxOcc 3
content complex
children tns:Email tns:Telefon
documentation
annotation
Dane kontaktowe podmiotu trzeciego
source <xsd:element name="DaneKontaktowe" minOccurs="0" maxOccurs="3">
<xsd:annotation>
<xsd:documentation>Dane kontaktowe podmiotu trzeciego</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="Email" type="etd:TAdresEmail" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres e-mail podmiotu trzeciego</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Telefon" type="tns:TNumerTelefonu" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer telefonu podmiotu trzeciego</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>

---

element Faktura/Podmiot3/DaneKontaktowe/Email
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TAdresEmail
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 3
maxLength 255
pattern (.)+@(.)+
documentation
annotation
Adres e-mail podmiotu trzeciego
source <xsd:element name="Email" type="etd:TAdresEmail" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres e-mail podmiotu trzeciego</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Podmiot3/DaneKontaktowe/Telefon
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TNumerTelefonu
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 16
documentation
annotation
Numer telefonu podmiotu trzeciego
source <xsd:element name="Telefon" type="tns:TNumerTelefonu" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer telefonu podmiotu trzeciego</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Podmiot3/Rola
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/

---

type tns:TRolaPodmiotu3
content simple
properties
Kind Value Annotation
facets
enumeration 1 documentation
Faktor - w przypadku, gdy na fakturze występują dane faktora
enumeration 2 documentation
Odbiorca - w przypadku, gdy na fakturze występują dane jednostek wewnętrznych,
oddziałów, wyodrębnionych w ramach nabywcy, które same nie stanowią nabywcy w
rozumieniu ustawy
enumeration 3 documentation
Podmiot pierwotny - w przypadku, gdy na fakturze występują dane podmiotu będącego w
stosunku do podatnika podmiotem przejętym lub przekształconym, który świadczył usługę lub
dokonywał dostawy. Z wyłączeniem przypadków, o których mowa w art. 106j ust.2 pkt 3
ustawy, gdy dane te wykazywane są w części Podmiot1K
enumeration 4 documentation
Dodatkowy nabywca - w przypadku, gdy na fakturze występują dane kolejnych (innych niż
wymieniony w części Podmiot2) nabywców
enumeration 5 documentation
Wystawca faktury - w przypadku, gdy na fakturze występują dane podmiotu wystawiającego
fakturę w imieniu podatnika. Nie dotyczy przypadku, gdy wystawcą faktury jest nabywca
enumeration 6 documentation
Dokonujący płatności - w przypadku, gdy na fakturze występują dane podmiotu regulującego
zobowiązanie w miejsce nabywcy
enumeration 7 documentation
Jednostka samorządu terytorialnego - wystawca
enumeration 8 documentation
Jednostka samorządu terytorialnego - odbiorca
enumeration 9 documentation
Członek grupy VAT - wystawca
enumeration 10 documentation
Członek grupy VAT - odbiorca
documentation
annotation
Rola podmiotu
source <xsd:element name="Rola" type="tns:TRolaPodmiotu3">
<xsd:annotation>
<xsd:documentation>Rola podmiotu</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Podmiot3/RolaInna
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1
content simple
properties
Kind Value Annotation
facets
enumeration 1
documentation
annotation
Znacznik innego podmiotu: 1 - Inny podmiot
source <xsd:element name="RolaInna" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik innego podmiotu: 1 - Inny podmiot</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Podmiot3/OpisRoli
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
content simple
properties
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Opis roli podmiotu - w przypadku wyboru roli jako Inny podmiot
source <xsd:element name="OpisRoli" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Opis roli podmiotu - w przypadku wyboru roli jako Inny
podmiot</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Podmiot3/Udzial
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TProcentowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minInclusive 0
maxInclusive 100
totalDigits 9
fractionDigits 6
whiteSpace collapse
documentation
annotation
Udział - procentowy udział dodatkowego nabywcy. Różnica pomiędzy wartością 100% a sumą udziałów dodatkowych
nabywców jest udziałem nabywcy wymienionego w części Podmiot2. W przypadku niewypełnienia pola przyjmuje się, że
udziały występujących na fakturze nabywców są równe
source <xsd:element name="Udzial" type="tns:TProcentowy" minOccurs="0">

---

<xsd:annotation>
<xsd:documentation>Udział - procentowy udział dodatkowego nabywcy. Różnica pomiędzy
wartością 100% a sumą udziałów dodatkowych nabywców jest udziałem nabywcy wymienionego w
części Podmiot2. W przypadku niewypełnienia pola przyjmuje się, że udziały występujących na
fakturze nabywców są równe</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Podmiot3/NrKlienta
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Numer klienta dla przypadków, w których podmiot wymieniony jako podmiot trzeci posługuje się nim w umowie lub
zamówieniu
source <xsd:element name="NrKlienta" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer klienta dla przypadków, w których podmiot wymieniony jako
podmiot trzeci posługuje się nim w umowie lub zamówieniu</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/PodmiotUpowazniony
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
minOcc 0
properties
maxOcc 1
content complex
children tns:NrEORI tns:DaneIdentyfikacyjne tns:Adres tns:AdresKoresp tns:DaneKontaktowe tns:RolaPU
documentation
annotation
Dane podmiotu upoważnionego, związanego z fakturą
source <xsd:element name="PodmiotUpowazniony" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Dane podmiotu upoważnionego, związanego z
fakturą</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="NrEORI" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer EORI podmiotu upoważnionego</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DaneIdentyfikacyjne" type="tns:TPodmiot1">
<xsd:annotation>
<xsd:documentation>Dane identyfikujące podmiotu
upoważnionego</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Adres" type="tns:TAdres">
<xsd:annotation>
<xsd:documentation>Adres podmiotu upoważnionego</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

<xsd:element name="AdresKoresp" type="tns:TAdres" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres korespondencyjny podmiotu
upoważnionego</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DaneKontaktowe" minOccurs="0" maxOccurs="3">
<xsd:annotation>
<xsd:documentation>Dane kontaktowe podmiotu upoważnionego</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="EmailPU" type="etd:TAdresEmail" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres e-mail podmiotu upoważnionego</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="TelefonPU" type="tns:TNumerTelefonu" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer telefonu podmiotu
upoważnionego</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="RolaPU" type="tns:TRolaPodmiotuUpowaznionego">
<xsd:annotation>
<xsd:documentation>Rola podmiotu upoważnionego</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
element Faktura/PodmiotUpowazniony/NrEORI
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Numer EORI podmiotu upoważnionego
source <xsd:element name="NrEORI" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer EORI podmiotu upoważnionego</xsd:documentation>

---

</xsd:annotation>
</xsd:element>
element Faktura/PodmiotUpowazniony/DaneIdentyfikacyjne
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TPodmiot1
content complex
properties
children tns:NIP tns:Nazwa
documentation
annotation
Dane identyfikujące podmiotu upoważnionego
source <xsd:element name="DaneIdentyfikacyjne" type="tns:TPodmiot1">
<xsd:annotation>
<xsd:documentation>Dane identyfikujące podmiotu upoważnionego</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/PodmiotUpowazniony/Adres
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TAdres
content complex
properties
children tns:KodKraju tns:AdresL1 tns:AdresL2 tns:GLN

---

documentation
annotation
Adres podmiotu upoważnionego
source <xsd:element name="Adres" type="tns:TAdres">
<xsd:annotation>
<xsd:documentation>Adres podmiotu upoważnionego</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/PodmiotUpowazniony/AdresKoresp
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TAdres
minOcc 0
properties
maxOcc 1
content complex
children tns:KodKraju tns:AdresL1 tns:AdresL2 tns:GLN
documentation
annotation
Adres korespondencyjny podmiotu upoważnionego
source <xsd:element name="AdresKoresp" type="tns:TAdres" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres korespondencyjny podmiotu upoważnionego</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/PodmiotUpowazniony/DaneKontaktowe
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/

---

minOcc 0
properties
maxOcc 3
content complex
children tns:EmailPU tns:TelefonPU
documentation
annotation
Dane kontaktowe podmiotu upoważnionego
source <xsd:element name="DaneKontaktowe" minOccurs="0" maxOccurs="3">
<xsd:annotation>
<xsd:documentation>Dane kontaktowe podmiotu upoważnionego</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="EmailPU" type="etd:TAdresEmail" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres e-mail podmiotu upoważnionego</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="TelefonPU" type="tns:TNumerTelefonu" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer telefonu podmiotu upoważnionego</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
element Faktura/PodmiotUpowazniony/DaneKontaktowe/EmailPU
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TAdresEmail
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 3
maxLength 255
pattern (.)+@(.)+
documentation
annotation
Adres e-mail podmiotu upoważnionego
source <xsd:element name="EmailPU" type="etd:TAdresEmail" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres e-mail podmiotu upoważnionego</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/PodmiotUpowazniony/DaneKontaktowe/TelefonPU
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TNumerTelefonu
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 16
documentation
annotation
Numer telefonu podmiotu upoważnionego
source <xsd:element name="TelefonPU" type="tns:TNumerTelefonu" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer telefonu podmiotu upoważnionego</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/PodmiotUpowazniony/RolaPU
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TRolaPodmiotuUpowaznionego
content simple
properties
Kind Value Annotation
facets
enumeration 1 documentation
Organ egzekucyjny - w przypadku, o którym mowa w art. 106c pkt 1 ustawy
enumeration 2 documentation
Komornik sądowy - w przypadku, o którym mowa w art. 106c pkt 2 ustawy
enumeration 3 documentation
Przedstawiciel podatkowy - w przypadku, gdy na fakturze występują dane przedstawiciela
podatkowego, o którym mowa w przepisach art. 18a - 18d ustawy
documentation
annotation
Rola podmiotu upoważnionego
source <xsd:element name="RolaPU" type="tns:TRolaPodmiotuUpowaznionego">
<xsd:annotation>
<xsd:documentation>Rola podmiotu upoważnionego</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa
diagram

---

namespace http://crd.gov.pl/wzor/2023/06/29/12648/
content complex
properties
children tns:KodWaluty tns:P_1 tns:P_1M tns:P_2 tns:WZ tns:P_6 tns:OkresFa tns:P_13_1 tns:P_14_1 tns:P_14_1W
tns:P_13_2 tns:P_14_2 tns:P_14_2W tns:P_13_3 tns:P_14_3 tns:P_14_3W tns:P_13_4 tns:P_14_4 tns:P_14_4W
tns:P_13_5 tns:P_14_5 tns:P_13_6_1 tns:P_13_6_2 tns:P_13_6_3 tns:P_13_7 tns:P_13_8 tns:P_13_9 tns:P_13_10
tns:P_13_11 tns:P_15 tns:KursWalutyZ tns:Adnotacje tns:RodzajFaktury tns:PrzyczynaKorekty tns:TypKorekty
tns:DaneFaKorygowanej tns:OkresFaKorygowanej tns:NrFaKorygowany tns:Podmiot1K tns:Podmiot2K
tns:P_15ZK tns:KursWalutyZK tns:ZaliczkaCzesciowa tns:FP tns:TP tns:DodatkowyOpis tns:FakturaZaliczkowa
tns:ZwrotAkcyzy tns:FaWiersz tns:Rozliczenie tns:Platnosc tns:WarunkiTransakcji tns:Zamowienie
documentation
annotation
Na podstawie art. 106a - 106q ustawy. Pola dotyczące wartości sprzedaży i podatku wypełnia się w walucie, w której
wystawiono fakturę, z wyjątkiem pól dotyczących podatku przeliczonego zgodnie z przepisami Działu VI w związku z art.
106e ust. 11 ustawy. W przypadku wystawienia faktury korygującej, wypełnia się wszystkie pola wg stanu po korekcie, a
pola dotyczące podstaw opodatkowania, podatku oraz należności ogółem wypełnia się poprzez różnicę
source <xsd:element name="Fa">
<xsd:annotation>
<xsd:documentation>Na podstawie art. 106a - 106q ustawy. Pola dotyczące wartości
sprzedaży i podatku wypełnia się w walucie, w której wystawiono fakturę, z wyjątkiem pól
dotyczących podatku przeliczonego zgodnie z przepisami Działu VI w związku z art. 106e ust. 11
ustawy. W przypadku wystawienia faktury korygującej, wypełnia się wszystkie pola wg stanu po
korekcie, a pola dotyczące podstaw opodatkowania, podatku oraz należności ogółem wypełnia się
poprzez różnicę</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="KodWaluty" type="tns:TKodWaluty">
<xsd:annotation>
<xsd:documentation>Trzyliterowy kod waluty (ISO 4217)</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_1" type="tns:TDataT">
<xsd:annotation>
<xsd:documentation>Data wystawienia, z zastrzeżeniem art. 106na ust. 1
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_1M" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Miejsce wystawienia faktury</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_2" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Kolejny numer faktury, nadany w ramach jednej lub więcej serii,
który w sposób jednoznaczny identyfikuje fakturę</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="WZ" type="tns:TZnakowy" minOccurs="0" maxOccurs="1000">
<xsd:annotation>
<xsd:documentation>Numery dokumentów magazynowych WZ (wydanie na zewnątrz)
związane z fakturą</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:choice minOccurs="0">
<xsd:element name="P_6" type="tns:TDataT">
<xsd:annotation>

---

<xsd:documentation>Data dokonania lub zakończenia dostawy towarów lub wykonania
usługi lub data otrzymania zapłaty, o której mowa w art. 106b ust. 1 pkt 4 ustawy, o ile taka data
jest określona i różni się od daty wystawienia faktury. Pole wypełnia się w przypadku, gdy dla
wszystkich pozycji faktury data jest wspólna</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="OkresFa">
<xsd:annotation>
<xsd:documentation>Okres, którego dotyczy faktura w przypadkach, o których mowa w
art. 19a ust. 3 zdanie pierwsze i ust. 4 oraz ust. 5 pkt 4 ustawy</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="P_6_Od" type="tns:TDataT">
<xsd:annotation>
<xsd:documentation>Data początkowa okresu, którego dotyczy
faktura</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_6_Do" type="tns:TDataT">
<xsd:annotation>
<xsd:documentation>Data końcowa okresu, którego dotyczy faktura - data
dokonania lub zakończenia dostawy towarów lub wykonania usługi</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
</xsd:choice>
<xsd:sequence minOccurs="0">
<xsd:annotation>
<xsd:documentation>Pola wypełniane w przypadku wystąpienia na fakturze sprzedaży
objętej stawką podstawową - aktualnie 23% albo 22%, z wyłączeniem procedury
marży</xsd:documentation>
</xsd:annotation>
<xsd:element name="P_13_1" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży netto ze stawką podstawową -
aktualnie 23% albo 22%. W przypadku faktur zaliczkowych, kwota zaliczki netto. W przypadku
faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_14_1" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota podatku od sumy wartości sprzedaży netto objętej stawką
podstawową - aktualnie 23% albo 22%. W przypadku faktur zaliczkowych, kwota podatku
wyliczona według wzoru, o którym mowa w art. 106f ust. 1 pkt 3 ustawy. W przypadku faktur
korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_14_1W" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>W przypadku gdy faktura jest wystawiona w walucie obcej, kwota
podatku od sumy wartości sprzedaży netto objętej stawką podstawową, przeliczona zgodnie z
przepisami Działu VI w związku z art. 106e ust. 11 ustawy - aktualnie 23% albo 22%. W przypadku

---

faktur zaliczkowych, kwota podatku wyliczona według wzoru, o którym mowa w art. 106f ust. 1 pkt
3 ustawy. W przypadku faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:sequence minOccurs="0">
<xsd:annotation>
<xsd:documentation>Pola wypełniane w przypadku wystąpienia na fakturze sprzedaży
objętej stawką obniżoną pierwszą - aktualnie 8 % albo 7%, z wyłączeniem procedury
marży</xsd:documentation>
</xsd:annotation>
<xsd:element name="P_13_2" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży netto objętej stawką obniżoną pierwszą
- aktualnie 8 % albo 7%. W przypadku faktur zaliczkowych, kwota zaliczki netto. W przypadku
faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_14_2" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota podatku od sumy wartości sprzedaży netto objętej stawką
obniżoną pierwszą - aktualnie 8% albo 7%. W przypadku faktur zaliczkowych, kwota podatku
wyliczona według wzoru, o którym mowa w art. 106f ust. 1 pkt 3 ustawy. W przypadku faktur
korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_14_2W" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>W przypadku gdy faktura jest wystawiona w walucie obcej, kwota
podatku od sumy wartości sprzedaży netto objętej stawką obniżoną, przeliczona zgodnie z
przepisami Działu VI w związku z art. 106e ust. 11 ustawy - aktualnie 8% albo 7%. W przypadku
faktur zaliczkowych, kwota podatku wyliczona według wzoru, o którym mowa w art. 106f ust. 1 pkt
3 ustawy. W przypadku faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:sequence minOccurs="0">
<xsd:annotation>
<xsd:documentation>Pola wypełniane w przypadku wystąpienia na fakturze sprzedaży
objętej stawką obniżoną drugą - aktualnie 5%, z wyłączeniem procedury
marży</xsd:documentation>
</xsd:annotation>
<xsd:element name="P_13_3" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży netto objętej stawką obniżoną drugą -
aktualnie 5%. W przypadku faktur zaliczkowych, kwota zaliczki netto. W przypadku faktur
korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_14_3" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota podatku od sumy wartości sprzedaży netto objętej stawką
obniżoną drugą - aktualnie 5%. W przypadku faktur zaliczkowych, kwota podatku wyliczona według

---

wzoru, o którym mowa w art. 106f ust. 1 pkt 3 ustawy. W przypadku faktur korygujących, kwota
różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_14_3W" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>W przypadku gdy faktura jest wystawiona w walucie obcej, kwota
podatku od sumy wartości sprzedaży netto objętej stawką obniżoną drugą, przeliczona zgodnie z
przepisami Działu VI w związku z art. 106e ust. 11 ustawy - aktualnie 5%. W przypadku faktur
zaliczkowych, kwota podatku wyliczona według wzoru, o którym mowa w art. 106f ust. 1 pkt 3
ustawy. W przypadku faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:sequence minOccurs="0">
<xsd:annotation>
<xsd:documentation>Pola wypełniane w przypadku wystąpienia na fakturze sprzedaży
objętej stawką obniżoną trzecią – ryczałtem dla taksówek osobowych</xsd:documentation>
</xsd:annotation>
<xsd:element name="P_13_4" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży netto objętej ryczałtem dla taksówek
osobowych. W przypadku faktur zaliczkowych, kwota zaliczki netto. W przypadku faktur
korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_14_4" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota podatku od sumy wartości sprzedaży netto w przypadku
ryczałtu dla taksówek osobowych. W przypadku faktur zaliczkowych, kwota podatku wyliczona
według wzoru, o którym mowa w art. 106f ust. 1 pkt 3 ustawy. W przypadku faktur korygujących,
kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_14_4W" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>W przypadku gdy faktura jest wystawiona w walucie obcej, kwota
podatku ryczałtu dla taksówek osobowych, przeliczona zgodnie z przepisami Działu VI w związku z
art. 106e ust. 11 ustawy. W przypadku faktur zaliczkowych, kwota podatku wyliczona według
wzoru, o którym mowa w art. 106f ust. 1 pkt 3 ustawy. W przypadku faktur korygujących, kwota
różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:sequence minOccurs="0">
<xsd:annotation>
<xsd:documentation>Pola wypełniane w przypadku wystąpienia na fakturze sprzedaży w
procedurze szczególnej, o której mowa w dziale XII w rozdziale 6a ustawy</xsd:documentation>
</xsd:annotation>
<xsd:element name="P_13_5" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży netto w przypadku procedury
szczególnej, o której mowa w dziale XII w rozdziale 6a ustawy. W przypadku faktur zaliczkowych,
kwota zaliczki netto. W przypadku faktur korygujących, kwota różnicy, o której mowa w art. 106j
ust. 2 pkt 5 ustawy</xsd:documentation>

---

</xsd:annotation>
</xsd:element>
<xsd:element name="P_14_5" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kwota podatku od wartości dodanej w przypadku procedury
szczególnej, o której mowa w dziale XII w rozdziale 6a ustawy. W przypadku faktur zaliczkowych,
kwota podatku wyliczona według wzoru, o którym mowa w art. 106f ust. 1 pkt 3 ustawy. W
przypadku faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:element name="P_13_6_1" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży objętej stawką 0% z wyłączeniem
wewnątrzwspólnotowej dostawy towarów i eksportu. W przypadku faktur zaliczkowych, kwota
zaliczki. W przypadku faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_13_6_2" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży objętej stawką 0% w przypadku
wewnątrzwspólnotowej dostawy towarów. W przypadku faktur korygujących, kwota różnicy, o której
mowa w art. 106j ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_13_6_3" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży objętej stawką 0% w przypadku
eksportu. W przypadku faktur zaliczkowych, kwota zaliczki. W przypadku faktur korygujących,
kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_13_7" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży zwolnionej od podatku. W przypadku
faktur zaliczkowych, kwota zaliczki. W przypadku faktur korygujących, kwota różnicy wartości
sprzedaży</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_13_8" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży w przypadku dostawy towarów oraz
świadczenia usług poza terytorium kraju, z wyłączeniem kwot wykazanych w polach P_13_5 i
P_13_9. W przypadku faktur zaliczkowych, kwota zaliczki. W przypadku faktur korygujących, kwota
różnicy wartości sprzedaży</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_13_9" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Suma wartości świadczenia usług, o których mowa w art. 100 ust. 1
pkt 4 ustawy. W przypadku faktur zaliczkowych, kwota zaliczki. W przypadku faktur korygujących,
kwota różnicy wartości sprzedaży</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

<xsd:element name="P_13_10" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży w procedurze odwrotnego obciążenia,
dla której podatnikiem jest nabywca zgodnie z art. 17 ust. 1 pkt 7 i 8 ustawy oraz innych
przypadków odwrotnego obciążenia występujących w obrocie krajowym. W przypadku faktur
zaliczkowych, kwota zaliczki. W przypadku faktur korygujących, kwota różnicy, o której mowa w art.
106j ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_13_11" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży w procedurze marży, o której mowa w
art. 119 i art. 120 ustawy. W przypadku faktur zaliczkowych, kwota zaliczki. W przypadku faktur
korygujących, kwota różnicy wartości sprzedaży</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_15" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota należności ogółem. W przypadku faktur zaliczkowych kwota
zapłaty dokumentowana fakturą. W przypadku faktur, o których mowa w art. 106f ust. 3 ustawy
kwota pozostała do zapłaty. W przypadku faktur korygujących korekta kwoty wynikającej z faktury
korygowanej. W przypadku, o którym mowa w art. 106j ust. 3 ustawy korekta kwot wynikających z
faktur korygowanych</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="KursWalutyZ" type="tns:TIlosci" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kurs waluty stosowany do wyliczenia kwoty podatku w
przypadkach, o których mowa w przepisach Działu VI ustawy na fakturach, o których mowa w art.
106b ust. 1 pkt 4 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Adnotacje">
<xsd:annotation>
<xsd:documentation>Inne adnotacje na fakturze</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="P_16" type="etd:TWybor1_2">
<xsd:annotation>
<xsd:documentation>W przypadku dostawy towarów lub świadczenia usług, w
odniesieniu do których obowiązek podatkowy powstaje zgodnie z art. 19a ust. 5 pkt 1 lub art. 21
ust. 1 ustawy - wyrazy "metoda kasowa", należy podać wartość "1"; w przeciwnym przypadku -
wartość "2"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_17" type="etd:TWybor1_2">
<xsd:annotation>
<xsd:documentation>W przypadku faktur, o których mowa w art. 106d ust. 1
ustawy - wyraz "samofakturowanie", należy podać wartość "1"; w przeciwnym przypadku - wartość
"2"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_18" type="etd:TWybor1_2">
<xsd:annotation>
<xsd:documentation>W przypadku dostawy towarów lub wykonania usługi, dla

---

których obowiązanym do rozliczenia podatku od wartości dodanej lub podatku o podobnym
charakterze jest nabywca towaru lub usługi - wyrazy "odwrotne obciążenie", należy podać wartość
"1", w przeciwnym przypadku - wartość "2"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_18A" type="etd:TWybor1_2">
<xsd:annotation>
<xsd:documentation>W przypadku faktur, w których kwota należności ogółem
przekracza kwotę 15 000 zł lub jej równowartość wyrażoną w walucie obcej, obejmujących
dokonaną na rzecz podatnika dostawę towarów lub świadczenie usług, o których mowa w
załączniku nr 15 do ustawy - wyrazy "mechanizm podzielonej płatności", przy czym do przeliczania
na złote kwot wyrażonych w walucie obcej stosuje się zasady przeliczania kwot stosowane w celu
określenia podstawy opodatkowania; należy podać wartość "1", w przeciwnym przypadku - wartość
"2"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Zwolnienie">
<xsd:complexType>
<xsd:choice>
<xsd:sequence>
<xsd:element name="P_19" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik dostawy towarów lub świadczenia usług
zwolnionych od podatku na podstawie art. 43 ust. 1, art. 113 ust. 1 i 9 albo przepisów wydanych na
podstawie art. 82 ust. 3 ustawy lub na podstawie innych przepisów</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:choice>
<xsd:element name="P_19A" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli pole P_19 równa się "1" - należy wskazać
przepis ustawy albo aktu wydanego na podstawie ustawy, na podstawie którego podatnik stosuje
zwolnienie od podatku</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_19B" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli pole P_19 równa się "1" - należy wskazać
przepis dyrektywy 2006/112/WE, który zwalnia od podatku taką dostawę towarów lub takie
świadczenie usług</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_19C" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli pole P_19 równa się "1" - należy wskazać
inną podstawę prawną wskazującą na to, że dostawa towarów lub świadczenie usług korzysta ze
zwolnienia od podatku</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
</xsd:sequence>
<xsd:element name="P_19N" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik braku dostawy towarów lub świadczenia
usług zwolnionych od podatku na podstawie art. 43 ust. 1, art. 113 ust. 1 i 9 ustawy albo przepisów
wydanych na podstawie art. 82 ust. 3 ustawy lub na podstawie innych

---

przepisów</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
</xsd:complexType>
</xsd:element>
<xsd:element name="NoweSrodkiTransportu">
<xsd:complexType>
<xsd:choice>
<xsd:sequence>
<xsd:element name="P_22" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik wewnątrzwspólnotowej dostawy nowych
środków transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_42_5" type="etd:TWybor1_2">
<xsd:annotation>
<xsd:documentation>Jeśli występuje obowiązek, o którym mowa w art. 42
ust. 5 ustawy, należy podać wartość "1", w przeciwnym przypadku - wartość
"2"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="NowySrodekTransportu" maxOccurs="10000">
<xsd:complexType>
<xsd:sequence>
<xsd:element name="P_22A" type="tns:TDataT">
<xsd:annotation>
<xsd:documentation>Data dopuszczenia nowego środka transportu
do użytku</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_NrWierszaNST" type="tns:TNaturalny">
<xsd:annotation>
<xsd:documentation>Numer wiersza faktury, w którym wykazano
dostawę nowego środka transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22BMK" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Marka nowego środka
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22BMD" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Model nowego środka
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22BK" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kolor nowego środka
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

<xsd:element name="P_22BNR" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer rejestracyjny nowego środka
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22BRP" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Rok produkcji nowego środka
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:choice>
<xsd:sequence>
<xsd:element name="P_22B" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów lądowych,
o których mowa w art. 2 pkt 10 lit. a ustawy - należy podać przebieg pojazdu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:choice minOccurs="0">
<xsd:element name="P_22B1" type="tns:TZnakowy"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów
lądowych, o których mowa w art. 2 pkt 10 lit. a ustawy - można podać numer
VIN</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22B2" type="tns:TZnakowy"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów
lądowych, o których mowa w art. 2 pkt 10 lit. a ustawy - można podać numer
nadwozia</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22B3" type="tns:TZnakowy"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów
lądowych, o których mowa w art. 2 pkt 10 lit. a ustawy - można podać numer
podwozia</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22B4" type="tns:TZnakowy"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów
lądowych, o których mowa w art. 2 pkt 10 lit. a ustawy - można podać numer
ramy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
<xsd:element name="P_22BT" type="tns:TZnakowy"
minOccurs="0">

---

<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów lądowych,
o których mowa w art. 2 pkt 10 lit. a ustawy - można podać typ nowego środka
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:sequence>
<xsd:element name="P_22C" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy jednostek
pływających, o których mowa w art. 2 pkt 10 lit. b ustawy, należy podać liczbę godzin roboczych
używania nowego środka transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22C1" type="tns:TZnakowy"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy jednostek
pływających, o których mowa w art. 2 pkt 10 lit. b ustawy, można podać numer kadłuba nowego
środka transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:sequence>
<xsd:element name="P_22D" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy statków
powietrznych, o których mowa w art. 2 pkt 10 lit. c ustawy, należy podać liczbę godzin roboczych
używania nowego środka transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22D1" type="tns:TZnakowy"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy statków
powietrznych, o których mowa w art. 2 pkt 10 lit. c ustawy, można podać numer fabryczny nowego
środka transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:choice>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
</xsd:sequence>
<xsd:element name="P_22N" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik braku wewnątrzwspólnotowej dostawy
nowych środków transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
</xsd:complexType>
</xsd:element>
<xsd:element name="P_23" type="etd:TWybor1_2">

---

<xsd:annotation>
<xsd:documentation>W przypadku faktur wystawianych w procedurze
uproszczonej przez drugiego w kolejności podatnika, o którym mowa w art. 135 ust. 1 pkt 4 lit. b i c
oraz ust. 2, zawierającej adnotację, o której mowa w art. 136 ust. 1 pkt 1 i stwierdzenie, o którym
mowa w art. 136 ust. 1 pkt 2 ustawy, należy podać wartość "1", w przeciwnym przypadku - wartość
"2"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="PMarzy">
<xsd:complexType>
<xsd:choice>
<xsd:sequence>
<xsd:element name="P_PMarzy" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik wystąpienia procedur marży, o których
mowa w art. 119 lub art. 120 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:choice>
<xsd:element name="P_PMarzy_2" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik świadczenia usług turystyki, dla których
podstawę opodatkowania stanowi marża, zgodnie z art. 119 ust. 1 ustawy, a faktura
dokumentująca świadczenie zawiera wyrazy "procedura marży dla biur
podróży"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_PMarzy_3_1" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik dostawy towarów używanych dla których
podstawę opodatkowania stanowi marża, zgodnie z art. 120 ustawy, a faktura dokumentująca
dostawę zawiera wyrazy "procedura marży - towary używane"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_PMarzy_3_2" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik dostawy dzieł sztuki dla których podstawę
opodatkowania stanowi marża, zgodnie z art. 120 ustawy, a faktura dokumentująca dostawę
zawiera wyrazy "procedura marży - dzieła sztuki"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_PMarzy_3_3" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik dostawy przedmiotów kolekcjonerskich i
antyków, dla których podstawę opodatkowania stanowi marża, zgodnie z art. 120 ustawy, a faktura
dokumentująca dostawę zawiera wyrazy "procedura marży - przedmioty kolekcjonerskie i
antyki"</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
</xsd:sequence>
<xsd:element name="P_PMarzyN" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik braku wystąpienia procedur marży, o których
mowa w art. 119 lub art. 120 ustawy</xsd:documentation>
</xsd:annotation>

---

</xsd:element>
</xsd:choice>
</xsd:complexType>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="RodzajFaktury" type="tns:TRodzajFaktury">
<xsd:annotation>
<xsd:documentation>Rodzaj faktury</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:sequence minOccurs="0">
<xsd:annotation>
<xsd:documentation>Dane dla przypadków, gdy pole RodzajFaktury przyjmuje wartości
KOR, KOR_ZAL lub KOR_ROZ</xsd:documentation>
</xsd:annotation>
<xsd:element name="PrzyczynaKorekty" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Przyczyna korekty dla faktur korygujących</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="TypKorekty" type="tns:TTypKorekty" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Typ skutku korekty w ewidencji dla podatku od towarów i
usług</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DaneFaKorygowanej" maxOccurs="unbounded">
<xsd:annotation>
<xsd:documentation>Dane faktury korygowanej</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="DataWystFaKorygowanej" type="tns:TDataT">
<xsd:annotation>
<xsd:documentation>Data wystawienia faktury
korygowanej</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="NrFaKorygowanej" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Numer faktury korygowanej</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:choice>
<xsd:sequence>
<xsd:element name="NrKSeF" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik numeru KSeF faktury
korygowanej</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="NrKSeFFaKorygowanej" type="tns:TNumerKSeF">
<xsd:annotation>
<xsd:documentation>Numer identyfikujący fakturę korygowaną w

---

KSeF</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:element name="NrKSeFN" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik faktury korygowanej wystawionej poza
KSeF</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="OkresFaKorygowanej" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Dla faktury korygującej, o której mowa w art. 106j ust. 3 ustawy -
okres, do którego odnosi się udzielany opust lub udzielana obniżka, w przypadku gdy podatnik
udziela opustu lub obniżki ceny w odniesieniu do dostaw towarów lub usług dokonanych lub
świadczonych na rzecz jednego odbiorcy w danym okresie</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="NrFaKorygowany" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Poprawny numer faktury korygowanej w przypadku, gdy
przyczyną korekty jest błędny numer faktury korygowanej. W takim przypadku błędny numer
faktury należy wskazać w polu NrFaKorygowanej</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Podmiot1K" minOccurs="0">
<xsd:annotation>
<xsd:documentation>W przypadku korekty danych sprzedawcy należy podać pełne
dane sprzedawcy występujące na fakturze korygowanej. Pole nie dotyczy przypadku korekty
błędnego NIP występującego na fakturze pierwotnej - wówczas wymagana jest korekta faktury do
wartości zerowych</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="PrefiksPodatnika" type="tns:TKodyKrajowUE" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kod (prefiks) podatnika VAT UE dla przypadków
określonych w art. 97 ust. 10 pkt 2 i 3 ustawy oraz w przypadku, o którym mowa w art. 136 ust. 1
pkt 3 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DaneIdentyfikacyjne" type="tns:TPodmiot1">
<xsd:annotation>
<xsd:documentation>Dane identyfikujące podatnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Adres" type="tns:TAdres">
<xsd:annotation>
<xsd:documentation>Adres podatnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>

---

</xsd:complexType>
</xsd:element>
<xsd:element name="Podmiot2K" minOccurs="0" maxOccurs="101">
<xsd:annotation>
<xsd:documentation>W przypadku korekty danych nabywcy występującego jako
Podmiot2 lub dodatkowego nabywcy występującego jako Podmiot3 należy podać pełne dane tego
podmiotu występujące na fakturze korygowanej. Korekcie nie podlegają błędne numery
identyfikujące nabywcę oraz dodatkowego nabywcę. W przypadku korygowania pozostałych
danych nabywcy lub dodatkowego nabywcy wskazany numer identyfikacyjny ma być tożsamy z
numerem w części Podmiot2 względnie Podmiot3 faktury korygującej</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="DaneIdentyfikacyjne" type="tns:TPodmiot2">
<xsd:annotation>
<xsd:documentation>Dane identyfikujące nabywcę</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Adres" type="tns:TAdres" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres nabywcy. Pola opcjonalne dla przypadków
określonych w art. 106e ust. 5 pkt 3 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="IDNabywcy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Unikalny klucz powiązania danych nabywcy na fakturach
korygujących, w przypadku gdy dane nabywcy na fakturze korygującej zmieniły się w stosunku do
danych na fakturze korygowanej</xsd:documentation>
</xsd:annotation>
<xsd:simpleType>
<xsd:restriction base="tns:TZnakowy50">
<xsd:maxLength value="32"/>
</xsd:restriction>
</xsd:simpleType>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:sequence minOccurs="0">
<xsd:element name="P_15ZK" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>W przypadku korekt faktur zaliczkowych, kwota zapłaty przed
korektą. W przypadku korekt faktur, o których mowa w art. 106f ust. 3 ustawy, kwota pozostała do
zapłaty przed korektą</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="KursWalutyZK" type="tns:TIlosci" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kurs waluty stosowany do wyliczenia kwoty podatku w
przypadkach, o których mowa w Dziale VI ustawy przed korektą</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:sequence>
<xsd:element name="ZaliczkaCzesciowa" minOccurs="0" maxOccurs="31">

---

<xsd:annotation>
<xsd:documentation>Dane dla przypadków faktur dokumentujących otrzymanie więcej
niż jednej płatności, o której mowa w art. 106b ust. 1 pkt 4 ustawy. W przypadku, gdy faktura, o
której mowa w art. 106f ust. 3 ustawy dokumentuje jednocześnie otrzymanie części zapłaty przed
dokonaniem czynności, różnica kwoty w polu P_15 i sumy poszczególnych pól P_15Z stanowi
kwotę pozostałą ponad płatności otrzymane przed wykonaniem czynności udokumentowanej
fakturą</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="P_6Z" type="tns:TDataT">
<xsd:annotation>
<xsd:documentation>Data otrzymania płatności, o której mowa w art. 106b ust. 1
pkt 4 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_15Z" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota płatności, o której mowa w art. 106b ust. 1 pkt 4
ustawy, składająca się na kwotę w polu P_15. W przypadku faktur korygujących korekta kwoty
wynikającej z faktury korygowanej</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="KursWalutyZW" type="tns:TIlosci" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kurs waluty stosowany do wyliczenia kwoty podatku w
przypadkach, o których mowa w Dziale VI ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="FP" type="etd:TWybor1" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Faktura, o której mowa w art. 109 ust. 3d
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="TP" type="etd:TWybor1" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Istniejące powiązania między nabywcą a dokonującym dostawy
towarów lub usługodawcą, zgodnie z § 10 ust. 4 pkt 3, z zastrzeżeniem ust. 4b rozporządzenia w
sprawie szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DodatkowyOpis" type="tns:TKluczWartosc" minOccurs="0"
maxOccurs="10000">
<xsd:annotation>
<xsd:documentation>Pola przeznaczone dla wykazywania dodatkowych danych na
fakturze, w tym wymaganych przepisami prawa, dla których nie przewidziano innych
pól/elementów</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="FakturaZaliczkowa" minOccurs="0" maxOccurs="100">
<xsd:annotation>

---

<xsd:documentation>Numery faktur zaliczkowych lub ich numery KSeF, jeśli zostały
wystawione z użyciem KSeF</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:choice>
<xsd:sequence>
<xsd:element name="NrKSeFZN" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik faktury zaliczkowej wystawionej poza
KSeF</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="NrFaZaliczkowej" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Numer faktury zaliczkowej wystawionej poza KSeF. Pole
obowiązkowe dla faktury wystawianej po wydaniu towaru lub wykonaniu usługi, o której mowa w
art. 106f ust. 3 ustawy i ostatniej z faktur, o której mowa w art. 106f ust. 4
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:element name="NrKSeFFaZaliczkowej" type="tns:TNumerKSeF">
<xsd:annotation>
<xsd:documentation>Numer identyfikujący fakturę zaliczkową w KSeF. Pole
obowiązkowe w przypadku, gdy faktura zaliczkowa była wystawiona za pomocą
KSeF</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
</xsd:complexType>
</xsd:element>
<xsd:element name="ZwrotAkcyzy" type="etd:TWybor1" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Informacja dodatkowa niezbędna dla rolników ubiegających się o
zwrot podatku akcyzowego zawartego w cenie oleju napędowego</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="FaWiersz" minOccurs="0" maxOccurs="10000">
<xsd:annotation>
<xsd:documentation>Szczegółowe pozycje faktury w walucie, w której wystawiono
fakturę - węzeł opcjonalny dla faktury zaliczkowej, faktury korygującej fakturę zaliczkową, oraz
faktur korygujących dotyczących wszystkich dostaw towarów lub usług dokonanych lub
świadczonych w danym okresie, o których mowa w art. 106j ust. 3 ustawy, dla których należy
podać dane dotyczące opustu lub obniżki w podziale na stawki podatku i procedury w części Fa. W
przypadku faktur korygujących, o których mowa w art. 106j ust. 3 ustawy, gdy opust lub obniżka
ceny odnosi się do części dostaw towarów lub usług dokonanych lub świadczonych w danym
okresie w części FaWiersz należy podać nazwy (rodzaje) towarów lub usług objętych korektą. W
przypadku faktur, o których mowa w art. 106f ust. 3 ustawy, należy wykazać pełne wartości
zamówienia lub umowy. W przypadku faktur korygujących pozycje faktury (w tym faktur
korygujących faktury, o których mowa w art. 106f ust. 3 ustawy, jeśli korekta dotyczy wartości
zamówienia), należy wykazać różnice wynikające z korekty poszczególnych pozycji lub dane
pozycji korygowanych w stanie przed korektą i po korekcie jako osobne wiersze. W przypadku
faktur korygujących faktury, o których mowa w art. 106f ust. 3 ustawy, jeśli korekta nie dotyczy
wartości zamówienia i jednocześnie zmienia wysokość podstawy opodatkowania lub podatku,
należy wprowadzić zapis wg stanu przed korektą i zapis w stanie po korekcie w celu potwierdzenia
braku zmiany wartości danej pozycji faktury</xsd:documentation>

---

</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="NrWierszaFa" type="tns:TNaturalny">
<xsd:annotation>
<xsd:documentation>Kolejny numer wiersza faktury</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="UU_ID" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Uniwersalny unikalny numer wiersza
faktury</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_6A" type="tns:TDataT" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Data dokonania lub zakończenia dostawy towarów lub
wykonania usługi lub data otrzymania zapłaty, o której mowa w art. 106b ust. 1 pkt 4 ustawy, o ile
taka data jest określona i różni się od daty wystawienia faktury. Pole wypełnia się dla przypadku,
gdy dla poszczególnych pozycji faktury występują różne daty</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_7" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Nazwa (rodzaj) towaru lub usługi. Pole opcjonalne wyłącznie
dla przypadku określonego w art 106j ust. 3 pkt 2 ustawy (faktura
korygująca)</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Indeks" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Pole przeznaczone do wpisania wewnętrznego kodu towaru
lub usługi nadanego przez podatnika albo dodatkowego opisu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="GTIN" type="tns:TZnakowy20" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Globalny numer jednostki handlowej</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="PKWiU" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Symbol Polskiej Klasyfikacji Wyrobów i
Usług</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="CN" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Symbol Nomenklatury Scalonej</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="PKOB" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Symbol Polskiej Klasyfikacji Obiektów
Budowlanych</xsd:documentation>
</xsd:annotation>

---

</xsd:element>
<xsd:element name="P_8A" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Miara dostarczonych towarów lub zakres wykonanych usług.
Pole opcjonalne dla przypadku określonego w art. 106e ust. 5 pkt 3 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_8B" type="tns:TIlosci" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Ilość (liczba) dostarczonych towarów lub zakres wykonanych
usług. Pole opcjonalne dla przypadku określonego w art. 106e ust. 5 pkt 3
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_9A" type="tns:TKwotowy2" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Cena jednostkowa towaru lub usługi bez kwoty podatku
(cena jednostkowa netto). Pole opcjonalne dla przypadków określonych w art. 106e ust. 2 i 3 oraz
ust. 5 pkt 3 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_9B" type="tns:TKwotowy2" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Cena wraz z kwotą podatku (cena jednostkowa brutto), w
przypadku zastosowania art. 106e ust. 7 i 8 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_10" type="tns:TKwotowy2" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kwoty wszelkich opustów lub obniżek cen, w tym w formie
rabatu z tytułu wcześniejszej zapłaty, o ile nie zostały one uwzględnione w cenie jednostkowej
netto, a w przypadku stosowania art. 106e ust. 7 ustawy w cenie jednostkowej brutto. Pole
opcjonalne dla przypadków określonych w art. 106e ust. 2 i 3 oraz ust. 5 pkt 1
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_11" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Wartość dostarczonych towarów lub wykonanych usług,
objętych transakcją, bez kwoty podatku (wartość sprzedaży netto). Pole opcjonalne dla
przypadków określonych w art. 106e ust. 2 i 3 oraz ust. 5 pkt 3 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_11A" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Wartość sprzedaży brutto, w przypadku zastosowania art.
106e ust. 7 i 8 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_11Vat" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kwota podatku w przypadku, o którym mowa w art. 106e ust.
10 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_12" type="tns:TStawkaPodatku" minOccurs="0">

---

<xsd:annotation>
<xsd:documentation>Stawka podatku. Pole opcjonalne dla przypadków
określonych w art. 106e ust. 2, 3, ust. 4 pkt 3 i ust. 5 pkt 3 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_12_XII" type="tns:TProcentowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Stawka podatku od wartości dodanej w przypadku, o którym
mowa w dziale XII w rozdziale 6a ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_12_Zal_15" type="etd:TWybor1" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Znacznik dla towaru lub usługi wymienionych w załączniku nr
15 do ustawy - wartość "1"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="KwotaAkcyzy" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kwota podatku akcyzowego zawarta w cenie
towaru</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="GTU" type="tns:TGTU" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Oznaczenie dotyczące dostawy towarów i świadczenia
usług</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Procedura" type="tns:TOznaczenieProcedury" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Oznaczenie dotyczące procedury</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="KursWaluty" type="tns:TIlosci" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kurs waluty stosowany do wyliczenia kwoty podatku w
przypadkach, o których mowa w Dziale VI ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="StanPrzed" type="etd:TWybor1" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Znacznik stanu przed korektą w przypadku faktury
korygującej lub faktury korygującej fakturę wystawioną w związku z art. 106f ust. 3 ustawy, w
przypadku gdy korekta dotyczy danych wykazanych w pozycjach faktury i jest dokonywana w
sposób polegający na wykazaniu danych przed korektą i po korekcie jako osobnych wierszy z
odrębną numeracją oraz w przypadku potwierdzania braku zmiany wartości danej
pozycji</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="Rozliczenie" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Dodatkowe rozliczenia na fakturze</xsd:documentation>

---

</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="Obciazenia" minOccurs="0" maxOccurs="100">
<xsd:annotation>
<xsd:documentation>Obciążenia</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="Kwota" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota doliczona do kwoty wykazanej w polu
P_15</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Powod" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Powód obciążenia</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="SumaObciazen" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Suma obciążeń</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Odliczenia" minOccurs="0" maxOccurs="100">
<xsd:annotation>
<xsd:documentation>Odliczenia</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="Kwota" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota odliczona od kwoty wykazanej w polu
P_15</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Powod" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Powód odliczenia</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="SumaOdliczen" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Suma odliczeń</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:choice minOccurs="0">
<xsd:element name="DoZaplaty" type="tns:TKwotowy">
<xsd:annotation>

---

<xsd:documentation>Kwota należności do zapłaty równa polu P_15
powiększonemu o Obciazenia i pomniejszonemu o Odliczenia</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DoRozliczenia" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota nadpłacona do
rozliczenia/zwrotu</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="Platnosc" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Warunki płatności</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:choice minOccurs="0">
<xsd:sequence>
<xsd:element name="Zaplacono" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik informujący, że kwota należności wynikająca z
faktury została zapłacona: 1 - zapłacono</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DataZaplaty" type="tns:TData">
<xsd:annotation>
<xsd:documentation>Data zapłaty, jeśli do wystawienia faktury płatność
została dokonana</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:sequence>
<xsd:element name="ZnacznikZaplatyCzesciowej" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik informujący, że kwota należności wynikająca z
faktury została zapłacona w części: 1 - zapłacono w części</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="ZaplataCzesciowa" maxOccurs="100">
<xsd:annotation>
<xsd:documentation>Dane zapłat częściowych</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="KwotaZaplatyCzesciowej" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota zapłaty częściowej</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DataZaplatyCzesciowej" type="tns:TData">
<xsd:annotation>
<xsd:documentation>Data zapłaty częściowej, jeśli do wystawienia

---

faktury płatność częściowa została dokonana</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
</xsd:sequence>
</xsd:choice>
<xsd:element name="TerminPlatnosci" minOccurs="0" maxOccurs="100">
<xsd:complexType>
<xsd:sequence>
<xsd:element name="Termin" type="tns:TData">
<xsd:annotation>
<xsd:documentation>Termin płatności</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="TerminOpis" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Opis terminu płatności</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:choice minOccurs="0">
<xsd:element name="FormaPlatnosci" type="tns:TFormaPlatnosci">
<xsd:annotation>
<xsd:documentation>Forma płatności</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:sequence>
<xsd:element name="PlatnoscInna" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik innej formy płatności: 1 - inna forma
płatności</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="OpisPlatnosci" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Doprecyzowanie innej formy
płatności</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:choice>
<xsd:element name="RachunekBankowy" type="tns:TRachunekBankowy"
minOccurs="0" maxOccurs="100">
<xsd:annotation>
<xsd:documentation>Numer rachunku</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="RachunekBankowyFaktora" type="tns:TRachunekBankowy"
minOccurs="0" maxOccurs="20">
<xsd:annotation>
<xsd:documentation>Rachunek faktora</xsd:documentation>
</xsd:annotation>

---

</xsd:element>
<xsd:element name="Skonto" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Skonto</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="WarunkiSkonta" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Warunki, które nabywca powinien spełnić aby
skorzystać ze skonta</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="WysokoscSkonta" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Wysokość skonta</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="WarunkiTransakcji" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Warunki transakcji, o ile występują</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="Umowy" minOccurs="0" maxOccurs="100">
<xsd:complexType>
<xsd:sequence minOccurs="0">
<xsd:element name="DataUmowy" type="tns:TData" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Data umowy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="NrUmowy" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer umowy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="Zamowienia" minOccurs="0" maxOccurs="100">
<xsd:complexType>
<xsd:sequence minOccurs="0">
<xsd:element name="DataZamowienia" type="tns:TData" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Data zamówienia</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="NrZamowienia" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>

---

<xsd:documentation>Numer zamówienia</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="NrPartiiTowaru" type="tns:TZnakowy" minOccurs="0"
maxOccurs="1000">
<xsd:annotation>
<xsd:documentation>Numery partii towaru</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="WarunkiDostawy" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Warunki dostawy towarów - w przypadku istnienia pomiędzy
stronami transakcji, umowy określającej warunki dostawy tzw. Incoterms</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:sequence minOccurs="0">
<xsd:element name="KursUmowny" type="tns:TIlosci">
<xsd:annotation>
<xsd:documentation>Kurs umowny - w przypadkach, gdy na fakturze znajduje
się informacja o kursie, po którym zostały przeliczone kwoty wykazane na fakturze w złotych. Nie
dotyczy przypadków, o których mowa w Dziale VI ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="WalutaUmowna" type="tns:TKodWaluty">
<xsd:annotation>
<xsd:documentation>Waluta umowna - trzyliterowy kod waluty (ISO-4217) w
przypadkach, gdy na fakturze znajduje się informacja o kursie, po którym zostały przeliczone kwoty
wykazane na fakturze w złotych. Nie dotyczy przypadków, o których mowa w Dziale VI
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:element name="Transport" minOccurs="0" maxOccurs="20">
<xsd:complexType>
<xsd:sequence>
<xsd:choice>
<xsd:element name="RodzajTransportu" type="tns:TRodzajTransportu">
<xsd:annotation>
<xsd:documentation>Rodzaj zastosowanego transportu w przypadku
dokonanej dostawy towarów</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:sequence>
<xsd:element name="TransportInny" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik innego rodzaju transportu: 1 - inny rodzaj
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="OpisInnegoTransportu" type="tns:TZnakowy50">
<xsd:annotation>
<xsd:documentation>Opis innego rodzaju
transportu</xsd:documentation>

---

</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:choice>
<xsd:element name="Przewoznik" minOccurs="0">
<xsd:complexType>
<xsd:sequence>
<xsd:element name="DaneIdentyfikacyjne" type="tns:TPodmiot2">
<xsd:annotation>
<xsd:documentation>Dane identyfikacyjne
przewoźnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="AdresPrzewoznika" type="tns:TAdres">
<xsd:annotation>
<xsd:documentation>Adres przewoźnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="NrZleceniaTransportu" type="tns:TZnakowy"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer zlecenia transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:sequence>
<xsd:choice>
<xsd:element name="OpisLadunku" type="tns:TLadunek">
<xsd:annotation>
<xsd:documentation>Rodzaj ładunku</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:sequence>
<xsd:element name="LadunekInny" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik innego ładunku: 1 - inny
ładunek</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="OpisInnegoLadunku" type="tns:TZnakowy50">
<xsd:annotation>
<xsd:documentation>Opis innego ładunku, w tym ładunek
mieszany</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:choice>
<xsd:element name="JednostkaOpakowania" type="tns:TZnakowy"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jednostka opakowania</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>

---

<xsd:sequence minOccurs="0">
<xsd:element name="DataGodzRozpTransportu" type="tns:TDataCzas"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Data i godzina rozpoczęcia
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DataGodzZakTransportu" type="tns:TDataCzas"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Data i godzina zakończenia
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="WysylkaZ" type="tns:TAdres" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres miejsca wysyłki</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="WysylkaPrzez" type="tns:TAdres" minOccurs="0"
maxOccurs="20">
<xsd:annotation>
<xsd:documentation>Adres pośredni wysyłki</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="WysylkaDo" type="tns:TAdres" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres miejsca docelowego, do którego został zlecony
transport</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="PodmiotPosredniczacy" type="etd:TWybor1" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Wartość "1" oznacza dostawę dokonaną przez podmiot, o
którym mowa w art. 22 ust. 2d ustawy. Pole dotyczy przypadku, w którym podmiot uczestniczy w
transakcji łańcuchowej innej niż procedura trójstronna uproszczona, o której mowa w art. 135 ust. 1
pkt 4 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="Zamowienie" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Zamówienie lub umowa, o których mowa w art. 106f ust. 1 pkt 4
ustawy (dla faktur zaliczkowych) w walucie, w której wystawiono fakturę zaliczkową. W przypadku
faktury korygującej fakturę zaliczkową należy wykazać różnice wynikające z korekty
poszczególnych pozycji zamówienia lub umowy lub dane pozycji korygowanych w stanie przed
korektą i po korekcie jako osobne wiersze, jeśli korekta dotyczy wartości zamówienia lub umowy.
W przypadku faktur korygujących faktury zaliczkowe, jeśli korekta nie dotyczy wartości zamówienia
lub umowy i jednocześnie zmienia wysokość podstawy opodatkowania lub podatku, należy

---

wprowadzić zapis wg stanu przed korektą i zapis w stanie po korekcie w celu potwierdzenia braku
zmiany wartości danej pozycji</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="WartoscZamowienia" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Wartość zamówienia lub umowy z uwzględnieniem kwoty
podatku</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="ZamowienieWiersz" maxOccurs="10000">
<xsd:annotation>
<xsd:documentation>Szczegółowe pozycje zamówienia lub umowy w walucie, w
której wystawiono fakturę zaliczkową</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="NrWierszaZam" type="tns:TNaturalny">
<xsd:annotation>
<xsd:documentation>Kolejny numer wiersza zamówienia lub
umowy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="UU_IDZ" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Uniwersalny unikalny numer wiersza zamówienia lub
umowy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_7Z" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Nazwa (rodzaj) towaru lub usługi</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="IndeksZ" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Pole przeznaczone do wpisania wewnętrznego kodu
towaru lub usługi nadanego przez podatnika albo dodatkowego opisu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="GTINZ" type="tns:TZnakowy20" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Globalny numer jednostki
handlowej</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="PKWiUZ" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Symbol Polskiej Klasyfikacji Wyrobów i
Usług</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="CNZ" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Symbol Nomenklatury Scalonej</xsd:documentation>

---

</xsd:annotation>
</xsd:element>
<xsd:element name="PKOBZ" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Symbol Polskiej Klasyfikacji Obiektów
Budowlanych</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_8AZ" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Miara zamówionego towaru lub zakres
usługi</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_8BZ" type="tns:TIlosci" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Ilość zamówionego towaru lub zakres
usługi</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_9AZ" type="tns:TKwotowy2" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Cena jednostkowa netto</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_11NettoZ" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Wartość zamówionego towaru lub usługi bez kwoty
podatku</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_11VatZ" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kwota podatku od zamówionego towaru lub
usługi</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_12Z" type="tns:TStawkaPodatku" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Stawka podatku</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_12Z_XII" type="tns:TProcentowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Stawka podatku od wartości dodanej w przypadku, o
którym mowa w dziale XII w rozdziale 6a ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_12Z_Zal_15" type="etd:TWybor1" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Znacznik dla towaru lub usługi wymienionych w
załączniku nr 15 do ustawy - wartość "1"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="GTUZ" type="tns:TGTU" minOccurs="0">
<xsd:annotation>

---

<xsd:documentation>Oznaczenie dotyczące dostawy towarów i świadczenia
usług</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="ProceduraZ" type="tns:TOznaczenieProceduryZ"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Oznaczenia dotyczące procedur</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="KwotaAkcyzyZ" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kwota podatku akcyzowego zawarta w cenie
towaru</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="StanPrzedZ" type="etd:TWybor1" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Znacznik stanu przed korektą w przypadku faktury
korygującej fakturę dokumentującą otrzymanie zapłaty lub jej części przed dokonaniem czynności
oraz fakturę wystawioną w związku z art. 106f ust. 4 ustawy, w przypadku gdy korekta dotyczy
danych wykazanych w pozycjach zamówienia i jest dokonywana w sposób polegający na
wykazaniu danych przed korektą i po korekcie jako osobnych wierszy z odrębną numeracją oraz w
przypadku potwierdzania braku zmiany wartości danej pozycji</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
element Faktura/Fa/KodWaluty
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKodWaluty
content simple
properties
Kind Value Annotation
facets
enumeration AED documentation
DIRHAM ZEA
enumeration AFN documentation
AFGANI
enumeration ALL documentation
LEK
enumeration AMD documentation
DRAM
enumeration ANG documentation

---

GULDEN ANTYLI HOLENDERSKICH
enumeration AOA documentation
KWANZA
enumeration ARS documentation
PESO ARGENTYŃSKIE
enumeration AUD documentation
DOLAR AUSTRALIJSKI
enumeration AWG documentation
GULDEN ARUBAŃSKI
enumeration AZN documentation
MANAT AZERBEJDŻAŃSKI
enumeration BAM documentation
MARKA ZAMIENNA
enumeration BBD documentation
DOLAR BARBADOSKI
enumeration BDT documentation
TAKA
enumeration BGN documentation
LEW
enumeration BHD documentation
DINAR BAHRAJSKI
enumeration BIF documentation
FRANK BURUNDYJSKI
enumeration BMD documentation
DOLAR BERMUDZKI
enumeration BND documentation
DOLAR BRUNEJSKI
enumeration BOB documentation
BOLIWIANO
enumeration BOV documentation
BOLIWIANO MVDOL
enumeration BRL documentation
REAL
enumeration BSD documentation
DOLAR BAHAMSKI
enumeration BTN documentation
NGULTRUM
enumeration BWP documentation
PULA
enumeration BYN documentation
RUBEL BIAŁORUSKI
enumeration BZD documentation
DOLAR BELIZEŃSKI
enumeration CAD documentation
DOLAR KANADYJSKI
enumeration CDF documentation
FRANK KONGIJSKI
enumeration CHE documentation
FRANK SZWAJCARSKI VIR EURO
enumeration CHF documentation
FRANK SZWAJCARSKI
enumeration CHW documentation
FRANK SZWAJCARSKI VIR FRANK
enumeration CLF documentation
JEDNOSTKA ROZLICZENIOWA CHILIJSKA
enumeration CLP documentation
PESO CHILIJSKIE
enumeration CNY documentation
YUAN RENMINBI
enumeration COP documentation
PESO KOLUMBIJSKIE
enumeration COU documentation
UNIDAD DE VALOR REAL KOLUMBILSKIE
enumeration CRC documentation
COLON KOSTARYKAŃSKI
enumeration CUC documentation
PESO WYMIENIALNE
enumeration CUP documentation
PESO KUBAŃSKIE
enumeration CVE documentation

---

ESCUDO REPUBLIKI ZIELONEGO PRZYLĄDKA
enumeration CZK documentation
KORONA CZESKA
enumeration DJF documentation
FRANK DŻIBUTI
enumeration DKK documentation
KORONA DUŃSKA
enumeration DOP documentation
PESO DOMINIKAŃSKIE
enumeration DZD documentation
DINAR ALGIERSKI
enumeration EGP documentation
FUNT EGIPSKI
enumeration ERN documentation
NAKFA
enumeration ETB documentation
BIRR
enumeration EUR documentation
EURO
enumeration FJD documentation
DOLAR FIDŻI
enumeration FKP documentation
FUNT FALKLANDZKI
enumeration GBP documentation
FUNT SZTERLING
enumeration GEL documentation
LARI
enumeration GGP documentation
FUNT GUERNSEY
enumeration GHS documentation
GHANA CEDI
enumeration GIP documentation
FUNT GIBRALTARSKI
enumeration GMD documentation
DALASI
enumeration GNF documentation
FRANK GWINEJSKI
enumeration GTQ documentation
QUETZAL
enumeration GYD documentation
DOLAR GUJAŃSKI
enumeration HKD documentation
DOLAR HONGKONGU
enumeration HNL documentation
LEMPIRA
enumeration HRK documentation
KUNA
enumeration HTG documentation
GOURDE
enumeration HUF documentation
FORINT
enumeration IDR documentation
RUPIA INDONEZYJSKA
enumeration ILS documentation
SZEKEL
enumeration IMP documentation
FUNT MANX
enumeration INR documentation
RUPIA INDYJSKA
enumeration IQD documentation
DINAR IRACKI
enumeration IRR documentation
RIAL IRAŃSKI
enumeration ISK documentation
KORONA ISLANDZKA
enumeration JEP documentation
FUNT JERSEY
enumeration JMD documentation
DOLAR JAMAJSKI
enumeration JOD documentation

---

DINAR JORDAŃSKI
enumeration JPY documentation
JEN
enumeration KES documentation
SZYLING KENIJSKI
enumeration KGS documentation
SOM
enumeration KHR documentation
RIEL
enumeration KMF documentation
FRANK KOMORÓW
enumeration KPW documentation
WON PÓŁNOCNO­KOREAŃSKI
enumeration KRW documentation
WON POŁUDNIOWO­KOREAŃSKI
enumeration KWD documentation
DINAR KUWEJCKI
enumeration KYD documentation
DOLAR KAJMAŃSKI
enumeration KZT documentation
TENGE
enumeration LAK documentation
KIP
enumeration LBP documentation
FUNT LIBAŃSKI
enumeration LKR documentation
RUPIA LANKIJSKA
enumeration LRD documentation
DOLAR LIBERYJSKI
enumeration LSL documentation
LOTI
enumeration LYD documentation
DINAR LIBIJSKI
enumeration MAD documentation
DIRHAM MAROKAŃSKI
enumeration MDL documentation
LEJ MOŁDAWII
enumeration MGA documentation
ARIARY
enumeration MKD documentation
DENAR
enumeration MMK documentation
KYAT
enumeration MNT documentation
TUGRIK
enumeration MOP documentation
PATACA
enumeration MRU documentation
OUGUIYA
enumeration MUR documentation
RUPIA MAURITIUSU
enumeration MVR documentation
RUPIA MALEDIWSKA
enumeration MWK documentation
KWACHA MALAWIJSKA
enumeration MXN documentation
PESO MEKSYKAŃSKIE
enumeration MXV documentation
UNIDAD DE INVERSION (UDI) MEKSYKAŃSKIE
enumeration MYR documentation
RINGGIT
enumeration MZN documentation
METICAL
enumeration NAD documentation
DOLAR NAMIBIJSKI
enumeration NGN documentation
NAIRA
enumeration NIO documentation
CORDOBA ORO
enumeration NOK documentation

---

KORONA NORWESKA
enumeration NPR documentation
RUPIA NEPALSKA
enumeration NZD documentation
DOLAR NOWOZELANDZKI
enumeration OMR documentation
RIAL OMAŃSKI
enumeration PAB documentation
BALBOA
enumeration PEN documentation
SOL
enumeration PGK documentation
KINA
enumeration PHP documentation
PESO FILIPIŃSKIE
enumeration PKR documentation
RUPIA PAKISTAŃSKA
enumeration PLN documentation
ZŁOTY
enumeration PYG documentation
GUARANI
enumeration QAR documentation
RIAL KATARSKI
enumeration RON documentation
LEJ RUMUŃSKI
enumeration RSD documentation
DINAR SERBSKI
enumeration RUB documentation
RUBEL ROSYJSKI
enumeration RWF documentation
FRANK RWANDYJSKI
enumeration SAR documentation
RIAL SAUDYJSKI
enumeration SBD documentation
DOLAR WYSP SALOMONA
enumeration SCR documentation
RUPIA SESZELSKA
enumeration SDG documentation
FUNT SUDAŃSKI
enumeration SEK documentation
KORONA SZWEDZKA
enumeration SGD documentation
DOLAR SINGAPURSKI
enumeration SHP documentation
FUNT ŚWIĘTEJ HELENY (ŚWIĘTA HELENA I WYSPA WNIEBOWSTĄPIENIA)
enumeration SLL documentation
LEONE
enumeration SOS documentation
SZYLING SOMALIJSKI
enumeration SRD documentation
DOLAR SURINAMSKI
enumeration SSP documentation
FUNT POŁUDNIOWOSUDAŃSKI
enumeration STN documentation
DOBRA
enumeration SVC documentation
COLON SALWADORSKI (SV1)
enumeration SYP documentation
FUNT SYRYJSKI
enumeration SZL documentation
LILANGENI
enumeration THB documentation
BAT
enumeration TJS documentation
SOMONI
enumeration TMT documentation
MANAT TURKMEŃSKI
enumeration TND documentation
DINAR TUNEZYJSKI
enumeration TOP documentation

---

PAANGA
enumeration TRY documentation
LIRA TURECKA
enumeration TTD documentation
DOLAR TRYNIDADU I TOBAGO
enumeration TWD documentation
NOWY DOLAR TAJWAŃSKI
enumeration TZS documentation
SZYLING TANZAŃSKI
enumeration UAH documentation
HRYWNA
enumeration UGX documentation
SZYLING UGANDYJSKI
enumeration USD documentation
DOLAR AMERYKAŃSKI
enumeration USN documentation
DOLAR AMERYKAŃSKI (NEXT DAY)
enumeration UYI documentation
PESO EN UNIDADES INDEXADAS URUGWAJSKIE
enumeration UYU documentation
PESO URUGWAJSKIE
enumeration UYW documentation
PESO EN UNIDADES INDEXADAS URUGWAJSKIE
enumeration UZS documentation
SUM
enumeration VES documentation
BOLIWAR SOBERANO
enumeration VND documentation
DONG
enumeration VUV documentation
VATU
enumeration WST documentation
TALA
enumeration XAF documentation
FRANK CFA (BEAC)
enumeration XAG documentation
SREBRO
enumeration XAU documentation
ZŁOTO
enumeration XBA documentation
BOND MARKETS UNIT EUROPEAN COMPOSITE UNIT (EURCO)
enumeration XBB documentation
BOND MARKETS UNIT EUROPEAN MONETARY UNIT (E.M.U.-6)
enumeration XBC documentation
BOND MARKETS UNIT EUROPEAN UNIT OF ACCOUNT 9 (E.U.A.-9)
enumeration XBD documentation
BOND MARKETS UNIT EUROPEAN UNIT OF ACCOUNT 17 (E.U.A.-17)
enumeration XCD documentation
DOLAR WSCHODNIO­KARAIBSKI
enumeration XDR documentation
SDR MIĘDZYNARODOWY FUNDUSZ WALUTOWY
enumeration XOF documentation
FRANK CFA (BCEAO)
enumeration XPD documentation
PALLAD
enumeration XPF documentation
FRANK CFP
enumeration XPT documentation
PLATYNA
enumeration XSU documentation
SUCRE SISTEMA UNITARIO DE COMPENSACION REGIONAL DE PAGOS SUCRE
enumeration XUA documentation
ADB UNIT OF ACCOUNT MEMBER COUNTRIES OF THE AFRICAN DEVELOPMENT
BANK GROUP
enumeration XXX documentation
BRAK WALUTY
enumeration YER documentation
RIAL JEMEŃSKI
enumeration ZAR documentation
RAND

---

enumeration ZMW documentation
KWACHA ZAMBIJSKA
enumeration ZWL documentation
DOLAR ZIMBABWE
documentation
annotation
Trzyliterowy kod waluty (ISO 4217)
source <xsd:element name="KodWaluty" type="tns:TKodWaluty">
<xsd:annotation>
<xsd:documentation>Trzyliterowy kod waluty (ISO 4217)</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/P_1
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TDataT
content simple
properties
Kind Value Annotation
facets
minInclusive 2006-01-01
maxInclusive 2050-01-01
pattern ((\d{4})-(\d{2})-(\d{2}))
documentation
annotation
Data wystawienia, z zastrzeżeniem art. 106na ust. 1 ustawy
source <xsd:element name="P_1" type="tns:TDataT">
<xsd:annotation>
<xsd:documentation>Data wystawienia, z zastrzeżeniem art. 106na ust. 1
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/P_1M
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Miejsce wystawienia faktury
source <xsd:element name="P_1M" type="tns:TZnakowy" minOccurs="0">

---

<xsd:annotation>
<xsd:documentation>Miejsce wystawienia faktury</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/P_2
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
content simple
properties
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Kolejny numer faktury, nadany w ramach jednej lub więcej serii, który w sposób jednoznaczny identyfikuje fakturę
source <xsd:element name="P_2" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Kolejny numer faktury, nadany w ramach jednej lub więcej serii, który w
sposób jednoznaczny identyfikuje fakturę</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/WZ
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1000
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Numery dokumentów magazynowych WZ (wydanie na zewnątrz) związane z fakturą
source <xsd:element name="WZ" type="tns:TZnakowy" minOccurs="0" maxOccurs="1000">
<xsd:annotation>
<xsd:documentation>Numery dokumentów magazynowych WZ (wydanie na zewnątrz)
związane z fakturą</xsd:documentation>
</xsd:annotation>

---

</xsd:element>
element Faktura/Fa/P_6
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TDataT
content simple
properties
Kind Value Annotation
facets
minInclusive 2006-01-01
maxInclusive 2050-01-01
pattern ((\d{4})-(\d{2})-(\d{2}))
documentation
annotation
Data dokonania lub zakończenia dostawy towarów lub wykonania usługi lub data otrzymania zapłaty, o której mowa w
art. 106b ust. 1 pkt 4 ustawy, o ile taka data jest określona i różni się od daty wystawienia faktury. Pole wypełnia się w
przypadku, gdy dla wszystkich pozycji faktury data jest wspólna
source <xsd:element name="P_6" type="tns:TDataT">
<xsd:annotation>
<xsd:documentation>Data dokonania lub zakończenia dostawy towarów lub wykonania usługi
lub data otrzymania zapłaty, o której mowa w art. 106b ust. 1 pkt 4 ustawy, o ile taka data jest
określona i różni się od daty wystawienia faktury. Pole wypełnia się w przypadku, gdy dla
wszystkich pozycji faktury data jest wspólna</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/OkresFa
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
content complex
properties
children tns:P_6_Od tns:P_6_Do

---

documentation
annotation
Okres, którego dotyczy faktura w przypadkach, o których mowa w art. 19a ust. 3 zdanie pierwsze i ust. 4 oraz ust. 5 pkt 4
ustawy
source <xsd:element name="OkresFa">
<xsd:annotation>
<xsd:documentation>Okres, którego dotyczy faktura w przypadkach, o których mowa w art.
19a ust. 3 zdanie pierwsze i ust. 4 oraz ust. 5 pkt 4 ustawy</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="P_6_Od" type="tns:TDataT">
<xsd:annotation>
<xsd:documentation>Data początkowa okresu, którego dotyczy
faktura</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_6_Do" type="tns:TDataT">
<xsd:annotation>
<xsd:documentation>Data końcowa okresu, którego dotyczy faktura - data dokonania lub
zakończenia dostawy towarów lub wykonania usługi</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
element Faktura/Fa/OkresFa/P_6_Od
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TDataT
content simple
properties
Kind Value Annotation
facets
minInclusive 2006-01-01
maxInclusive 2050-01-01
pattern ((\d{4})-(\d{2})-(\d{2}))
documentation
annotation
Data początkowa okresu, którego dotyczy faktura
source <xsd:element name="P_6_Od" type="tns:TDataT">
<xsd:annotation>
<xsd:documentation>Data początkowa okresu, którego dotyczy faktura</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/OkresFa/P_6_Do
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TDataT
content simple
properties
Kind Value Annotation
facets
minInclusive 2006-01-01
maxInclusive 2050-01-01
pattern ((\d{4})-(\d{2})-(\d{2}))
documentation
annotation
Data końcowa okresu, którego dotyczy faktura - data dokonania lub zakończenia dostawy towarów lub wykonania usługi
source <xsd:element name="P_6_Do" type="tns:TDataT">
<xsd:annotation>
<xsd:documentation>Data końcowa okresu, którego dotyczy faktura - data dokonania lub
zakończenia dostawy towarów lub wykonania usługi</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/P_13_1
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
content simple
properties
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Suma wartości sprzedaży netto ze stawką podstawową - aktualnie 23% albo 22%. W przypadku faktur zaliczkowych,
kwota zaliczki netto. W przypadku faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy
source <xsd:element name="P_13_1" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży netto ze stawką podstawową - aktualnie 23%
albo 22%. W przypadku faktur zaliczkowych, kwota zaliczki netto. W przypadku faktur
korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>

---

</xsd:element>
element Faktura/Fa/P_14_1
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
content simple
properties
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Kwota podatku od sumy wartości sprzedaży netto objętej stawką podstawową - aktualnie 23% albo 22%. W przypadku
faktur zaliczkowych, kwota podatku wyliczona według wzoru, o którym mowa w art. 106f ust. 1 pkt 3 ustawy. W
przypadku faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy
source <xsd:element name="P_14_1" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota podatku od sumy wartości sprzedaży netto objętej stawką
podstawową - aktualnie 23% albo 22%. W przypadku faktur zaliczkowych, kwota podatku
wyliczona według wzoru, o którym mowa w art. 106f ust. 1 pkt 3 ustawy. W przypadku faktur
korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/P_14_1W
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/

---

type tns:TKwotowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
W przypadku gdy faktura jest wystawiona w walucie obcej, kwota podatku od sumy wartości sprzedaży netto objętej
stawką podstawową, przeliczona zgodnie z przepisami Działu VI w związku z art. 106e ust. 11 ustawy - aktualnie 23%
albo 22%. W przypadku faktur zaliczkowych, kwota podatku wyliczona według wzoru, o którym mowa w art. 106f ust. 1
pkt 3 ustawy. W przypadku faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy
source <xsd:element name="P_14_1W" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>W przypadku gdy faktura jest wystawiona w walucie obcej, kwota podatku
od sumy wartości sprzedaży netto objętej stawką podstawową, przeliczona zgodnie z przepisami
Działu VI w związku z art. 106e ust. 11 ustawy - aktualnie 23% albo 22%. W przypadku faktur
zaliczkowych, kwota podatku wyliczona według wzoru, o którym mowa w art. 106f ust. 1 pkt 3
ustawy. W przypadku faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/P_13_2
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
content simple
properties
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Suma wartości sprzedaży netto objętej stawką obniżoną pierwszą - aktualnie 8 % albo 7%. W przypadku faktur
zaliczkowych, kwota zaliczki netto. W przypadku faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt
5 ustawy
source <xsd:element name="P_13_2" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży netto objętej stawką obniżoną pierwszą -
aktualnie 8 % albo 7%. W przypadku faktur zaliczkowych, kwota zaliczki netto. W przypadku faktur
korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/P_14_2
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
content simple
properties
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Kwota podatku od sumy wartości sprzedaży netto objętej stawką obniżoną pierwszą - aktualnie 8% albo 7%. W
przypadku faktur zaliczkowych, kwota podatku wyliczona według wzoru, o którym mowa w art. 106f ust. 1 pkt 3 ustawy.
W przypadku faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy
source <xsd:element name="P_14_2" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota podatku od sumy wartości sprzedaży netto objętej stawką
obniżoną pierwszą - aktualnie 8% albo 7%. W przypadku faktur zaliczkowych, kwota podatku
wyliczona według wzoru, o którym mowa w art. 106f ust. 1 pkt 3 ustawy. W przypadku faktur
korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/P_14_2W
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/

---

type tns:TKwotowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
W przypadku gdy faktura jest wystawiona w walucie obcej, kwota podatku od sumy wartości sprzedaży netto objętej
stawką obniżoną, przeliczona zgodnie z przepisami Działu VI w związku z art. 106e ust. 11 ustawy - aktualnie 8% albo
7%. W przypadku faktur zaliczkowych, kwota podatku wyliczona według wzoru, o którym mowa w art. 106f ust. 1 pkt 3
ustawy. W przypadku faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy
source <xsd:element name="P_14_2W" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>W przypadku gdy faktura jest wystawiona w walucie obcej, kwota podatku
od sumy wartości sprzedaży netto objętej stawką obniżoną, przeliczona zgodnie z przepisami
Działu VI w związku z art. 106e ust. 11 ustawy - aktualnie 8% albo 7%. W przypadku faktur
zaliczkowych, kwota podatku wyliczona według wzoru, o którym mowa w art. 106f ust. 1 pkt 3
ustawy. W przypadku faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/P_13_3
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
content simple
properties
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Suma wartości sprzedaży netto objętej stawką obniżoną drugą - aktualnie 5%. W przypadku faktur zaliczkowych, kwota
zaliczki netto. W przypadku faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy
source <xsd:element name="P_13_3" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży netto objętej stawką obniżoną drugą - aktualnie
5%. W przypadku faktur zaliczkowych, kwota zaliczki netto. W przypadku faktur korygujących,
kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/P_14_3
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
content simple
properties
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Kwota podatku od sumy wartości sprzedaży netto objętej stawką obniżoną drugą - aktualnie 5%. W przypadku faktur
zaliczkowych, kwota podatku wyliczona według wzoru, o którym mowa w art. 106f ust. 1 pkt 3 ustawy. W przypadku
faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy
source <xsd:element name="P_14_3" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota podatku od sumy wartości sprzedaży netto objętej stawką
obniżoną drugą - aktualnie 5%. W przypadku faktur zaliczkowych, kwota podatku wyliczona według
wzoru, o którym mowa w art. 106f ust. 1 pkt 3 ustawy. W przypadku faktur korygujących, kwota
różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/P_14_3W
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy

---

minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
W przypadku gdy faktura jest wystawiona w walucie obcej, kwota podatku od sumy wartości sprzedaży netto objętej
stawką obniżoną drugą, przeliczona zgodnie z przepisami Działu VI w związku z art. 106e ust. 11 ustawy - aktualnie 5%.
W przypadku faktur zaliczkowych, kwota podatku wyliczona według wzoru, o którym mowa w art. 106f ust. 1 pkt 3
ustawy. W przypadku faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy
source <xsd:element name="P_14_3W" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>W przypadku gdy faktura jest wystawiona w walucie obcej, kwota podatku
od sumy wartości sprzedaży netto objętej stawką obniżoną drugą, przeliczona zgodnie z
przepisami Działu VI w związku z art. 106e ust. 11 ustawy - aktualnie 5%. W przypadku faktur
zaliczkowych, kwota podatku wyliczona według wzoru, o którym mowa w art. 106f ust. 1 pkt 3
ustawy. W przypadku faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/P_13_4
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
content simple
properties
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Suma wartości sprzedaży netto objętej ryczałtem dla taksówek osobowych. W przypadku faktur zaliczkowych, kwota
zaliczki netto. W przypadku faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy
source <xsd:element name="P_13_4" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży netto objętej ryczałtem dla taksówek
osobowych. W przypadku faktur zaliczkowych, kwota zaliczki netto. W przypadku faktur
korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/P_14_4
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
content simple
properties
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Kwota podatku od sumy wartości sprzedaży netto w przypadku ryczałtu dla taksówek osobowych. W przypadku faktur
zaliczkowych, kwota podatku wyliczona według wzoru, o którym mowa w art. 106f ust. 1 pkt 3 ustawy. W przypadku
faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy
source <xsd:element name="P_14_4" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota podatku od sumy wartości sprzedaży netto w przypadku ryczałtu
dla taksówek osobowych. W przypadku faktur zaliczkowych, kwota podatku wyliczona według
wzoru, o którym mowa w art. 106f ust. 1 pkt 3 ustawy. W przypadku faktur korygujących, kwota
różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/P_14_4W
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
minOcc 0
properties
maxOcc 1
content simple

---

Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
W przypadku gdy faktura jest wystawiona w walucie obcej, kwota podatku ryczałtu dla taksówek osobowych, przeliczona
zgodnie z przepisami Działu VI w związku z art. 106e ust. 11 ustawy. W przypadku faktur zaliczkowych, kwota podatku
wyliczona według wzoru, o którym mowa w art. 106f ust. 1 pkt 3 ustawy. W przypadku faktur korygujących, kwota
różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy
source <xsd:element name="P_14_4W" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>W przypadku gdy faktura jest wystawiona w walucie obcej, kwota podatku
ryczałtu dla taksówek osobowych, przeliczona zgodnie z przepisami Działu VI w związku z art.
106e ust. 11 ustawy. W przypadku faktur zaliczkowych, kwota podatku wyliczona według wzoru, o
którym mowa w art. 106f ust. 1 pkt 3 ustawy. W przypadku faktur korygujących, kwota różnicy, o
której mowa w art. 106j ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/P_13_5
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
content simple
properties
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Suma wartości sprzedaży netto w przypadku procedury szczególnej, o której mowa w dziale XII w rozdziale 6a ustawy.
W przypadku faktur zaliczkowych, kwota zaliczki netto. W przypadku faktur korygujących, kwota różnicy, o której mowa w
art. 106j ust. 2 pkt 5 ustawy
source <xsd:element name="P_13_5" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży netto w przypadku procedury szczególnej, o
której mowa w dziale XII w rozdziale 6a ustawy. W przypadku faktur zaliczkowych, kwota zaliczki
netto. W przypadku faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/P_14_5
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Kwota podatku od wartości dodanej w przypadku procedury szczególnej, o której mowa w dziale XII w rozdziale 6a
ustawy. W przypadku faktur zaliczkowych, kwota podatku wyliczona według wzoru, o którym mowa w art. 106f ust. 1 pkt
3 ustawy. W przypadku faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy
source <xsd:element name="P_14_5" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kwota podatku od wartości dodanej w przypadku procedury szczególnej,
o której mowa w dziale XII w rozdziale 6a ustawy. W przypadku faktur zaliczkowych, kwota podatku
wyliczona według wzoru, o którym mowa w art. 106f ust. 1 pkt 3 ustawy. W przypadku faktur
korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/P_13_6_1
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
totalDigits 18

---

fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Suma wartości sprzedaży objętej stawką 0% z wyłączeniem wewnątrzwspólnotowej dostawy towarów i eksportu. W
przypadku faktur zaliczkowych, kwota zaliczki. W przypadku faktur korygujących, kwota różnicy, o której mowa w art.
106j ust. 2 pkt 5 ustawy
source <xsd:element name="P_13_6_1" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży objętej stawką 0% z wyłączeniem
wewnątrzwspólnotowej dostawy towarów i eksportu. W przypadku faktur zaliczkowych, kwota
zaliczki. W przypadku faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/P_13_6_2
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Suma wartości sprzedaży objętej stawką 0% w przypadku wewnątrzwspólnotowej dostawy towarów. W przypadku faktur
korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy
source <xsd:element name="P_13_6_2" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży objętej stawką 0% w przypadku
wewnątrzwspólnotowej dostawy towarów. W przypadku faktur korygujących, kwota różnicy, o której
mowa w art. 106j ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/P_13_6_3
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Suma wartości sprzedaży objętej stawką 0% w przypadku eksportu. W przypadku faktur zaliczkowych, kwota zaliczki. W
przypadku faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt 5 ustawy
source <xsd:element name="P_13_6_3" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży objętej stawką 0% w przypadku eksportu. W
przypadku faktur zaliczkowych, kwota zaliczki. W przypadku faktur korygujących, kwota różnicy, o
której mowa w art. 106j ust. 2 pkt 5 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/P_13_7
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Suma wartości sprzedaży zwolnionej od podatku. W przypadku faktur zaliczkowych, kwota zaliczki. W przypadku faktur
korygujących, kwota różnicy wartości sprzedaży
source <xsd:element name="P_13_7" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>

---

<xsd:documentation>Suma wartości sprzedaży zwolnionej od podatku. W przypadku faktur
zaliczkowych, kwota zaliczki. W przypadku faktur korygujących, kwota różnicy wartości
sprzedaży</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/P_13_8
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Suma wartości sprzedaży w przypadku dostawy towarów oraz świadczenia usług poza terytorium kraju, z wyłączeniem
kwot wykazanych w polach P_13_5 i P_13_9. W przypadku faktur zaliczkowych, kwota zaliczki. W przypadku faktur
korygujących, kwota różnicy wartości sprzedaży
source <xsd:element name="P_13_8" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży w przypadku dostawy towarów oraz
świadczenia usług poza terytorium kraju, z wyłączeniem kwot wykazanych w polach P_13_5 i
P_13_9. W przypadku faktur zaliczkowych, kwota zaliczki. W przypadku faktur korygujących, kwota
różnicy wartości sprzedaży</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/P_13_9
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy

---

minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Suma wartości świadczenia usług, o których mowa w art. 100 ust. 1 pkt 4 ustawy. W przypadku faktur zaliczkowych,
kwota zaliczki. W przypadku faktur korygujących, kwota różnicy wartości sprzedaży
source <xsd:element name="P_13_9" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Suma wartości świadczenia usług, o których mowa w art. 100 ust. 1 pkt 4
ustawy. W przypadku faktur zaliczkowych, kwota zaliczki. W przypadku faktur korygujących, kwota
różnicy wartości sprzedaży</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/P_13_10
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Suma wartości sprzedaży w procedurze odwrotnego obciążenia, dla której podatnikiem jest nabywca zgodnie z art. 17
ust. 1 pkt 7 i 8 ustawy oraz innych przypadków odwrotnego obciążenia występujących w obrocie krajowym. W przypadku
faktur zaliczkowych, kwota zaliczki. W przypadku faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2 pkt
5 ustawy
source <xsd:element name="P_13_10" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży w procedurze odwrotnego obciążenia, dla
której podatnikiem jest nabywca zgodnie z art. 17 ust. 1 pkt 7 i 8 ustawy oraz innych przypadków
odwrotnego obciążenia występujących w obrocie krajowym. W przypadku faktur zaliczkowych,
kwota zaliczki. W przypadku faktur korygujących, kwota różnicy, o której mowa w art. 106j ust. 2
pkt 5 ustawy</xsd:documentation>
</xsd:annotation>

---

</xsd:element>
element Faktura/Fa/P_13_11
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Suma wartości sprzedaży w procedurze marży, o której mowa w art. 119 i art. 120 ustawy. W przypadku faktur
zaliczkowych, kwota zaliczki. W przypadku faktur korygujących, kwota różnicy wartości sprzedaży
source <xsd:element name="P_13_11" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Suma wartości sprzedaży w procedurze marży, o której mowa w art. 119 i
art. 120 ustawy. W przypadku faktur zaliczkowych, kwota zaliczki. W przypadku faktur
korygujących, kwota różnicy wartości sprzedaży</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/P_15
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
content simple
properties
Kind Value Annotation
facets

---

totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Kwota należności ogółem. W przypadku faktur zaliczkowych kwota zapłaty dokumentowana fakturą. W przypadku faktur,
o których mowa w art. 106f ust. 3 ustawy kwota pozostała do zapłaty. W przypadku faktur korygujących korekta kwoty
wynikającej z faktury korygowanej. W przypadku, o którym mowa w art. 106j ust. 3 ustawy korekta kwot wynikających z
faktur korygowanych
source <xsd:element name="P_15" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota należności ogółem. W przypadku faktur zaliczkowych kwota
zapłaty dokumentowana fakturą. W przypadku faktur, o których mowa w art. 106f ust. 3 ustawy
kwota pozostała do zapłaty. W przypadku faktur korygujących korekta kwoty wynikającej z faktury
korygowanej. W przypadku, o którym mowa w art. 106j ust. 3 ustawy korekta kwot wynikających z
faktur korygowanych</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/KursWalutyZ
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TIlosci
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
totalDigits 22
fractionDigits 6
pattern -?([1-9]\d{0,15}|0)(\.\d{1,6})?
documentation
annotation
Kurs waluty stosowany do wyliczenia kwoty podatku w przypadkach, o których mowa w przepisach Działu VI ustawy na
fakturach, o których mowa w art. 106b ust. 1 pkt 4 ustawy
source <xsd:element name="KursWalutyZ" type="tns:TIlosci" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kurs waluty stosowany do wyliczenia kwoty podatku w przypadkach, o
których mowa w przepisach Działu VI ustawy na fakturach, o których mowa w art. 106b ust. 1 pkt 4
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/Adnotacje
diagram

---

namespace http://crd.gov.pl/wzor/2023/06/29/12648/
content complex
properties
children tns:P_16 tns:P_17 tns:P_18 tns:P_18A tns:Zwolnienie tns:NoweSrodkiTransportu tns:P_23 tns:PMarzy
documentation
annotation
Inne adnotacje na fakturze
source <xsd:element name="Adnotacje">
<xsd:annotation>
<xsd:documentation>Inne adnotacje na fakturze</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="P_16" type="etd:TWybor1_2">
<xsd:annotation>
<xsd:documentation>W przypadku dostawy towarów lub świadczenia usług, w
odniesieniu do których obowiązek podatkowy powstaje zgodnie z art. 19a ust. 5 pkt 1 lub art. 21
ust. 1 ustawy - wyrazy "metoda kasowa", należy podać wartość "1"; w przeciwnym przypadku -
wartość "2"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_17" type="etd:TWybor1_2">
<xsd:annotation>
<xsd:documentation>W przypadku faktur, o których mowa w art. 106d ust. 1 ustawy -
wyraz "samofakturowanie", należy podać wartość "1"; w przeciwnym przypadku - wartość
"2"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_18" type="etd:TWybor1_2">
<xsd:annotation>
<xsd:documentation>W przypadku dostawy towarów lub wykonania usługi, dla których
obowiązanym do rozliczenia podatku od wartości dodanej lub podatku o podobnym charakterze
jest nabywca towaru lub usługi - wyrazy "odwrotne obciążenie", należy podać wartość "1", w
przeciwnym przypadku - wartość "2"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_18A" type="etd:TWybor1_2">
<xsd:annotation>
<xsd:documentation>W przypadku faktur, w których kwota należności ogółem
przekracza kwotę 15 000 zł lub jej równowartość wyrażoną w walucie obcej, obejmujących
dokonaną na rzecz podatnika dostawę towarów lub świadczenie usług, o których mowa w
załączniku nr 15 do ustawy - wyrazy "mechanizm podzielonej płatności", przy czym do przeliczania
na złote kwot wyrażonych w walucie obcej stosuje się zasady przeliczania kwot stosowane w celu
określenia podstawy opodatkowania; należy podać wartość "1", w przeciwnym przypadku - wartość
"2"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Zwolnienie">
<xsd:complexType>
<xsd:choice>
<xsd:sequence>
<xsd:element name="P_19" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik dostawy towarów lub świadczenia usług
zwolnionych od podatku na podstawie art. 43 ust. 1, art. 113 ust. 1 i 9 albo przepisów wydanych na
podstawie art. 82 ust. 3 ustawy lub na podstawie innych przepisów</xsd:documentation>

---

</xsd:annotation>
</xsd:element>
<xsd:choice>
<xsd:element name="P_19A" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli pole P_19 równa się "1" - należy wskazać przepis
ustawy albo aktu wydanego na podstawie ustawy, na podstawie którego podatnik stosuje
zwolnienie od podatku</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_19B" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli pole P_19 równa się "1" - należy wskazać przepis
dyrektywy 2006/112/WE, który zwalnia od podatku taką dostawę towarów lub takie świadczenie
usług</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_19C" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli pole P_19 równa się "1" - należy wskazać inną
podstawę prawną wskazującą na to, że dostawa towarów lub świadczenie usług korzysta ze
zwolnienia od podatku</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
</xsd:sequence>
<xsd:element name="P_19N" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik braku dostawy towarów lub świadczenia usług
zwolnionych od podatku na podstawie art. 43 ust. 1, art. 113 ust. 1 i 9 ustawy albo przepisów
wydanych na podstawie art. 82 ust. 3 ustawy lub na podstawie innych
przepisów</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
</xsd:complexType>
</xsd:element>
<xsd:element name="NoweSrodkiTransportu">
<xsd:complexType>
<xsd:choice>
<xsd:sequence>
<xsd:element name="P_22" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik wewnątrzwspólnotowej dostawy nowych środków
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_42_5" type="etd:TWybor1_2">
<xsd:annotation>
<xsd:documentation>Jeśli występuje obowiązek, o którym mowa w art. 42 ust. 5
ustawy, należy podać wartość "1", w przeciwnym przypadku - wartość "2"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="NowySrodekTransportu" maxOccurs="10000">
<xsd:complexType>
<xsd:sequence>

---

<xsd:element name="P_22A" type="tns:TDataT">
<xsd:annotation>
<xsd:documentation>Data dopuszczenia nowego środka transportu do
użytku</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_NrWierszaNST" type="tns:TNaturalny">
<xsd:annotation>
<xsd:documentation>Numer wiersza faktury, w którym wykazano dostawę
nowego środka transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22BMK" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Marka nowego środka
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22BMD" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Model nowego środka
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22BK" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kolor nowego środka
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22BNR" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer rejestracyjny nowego środka
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22BRP" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Rok produkcji nowego środka
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:choice>
<xsd:sequence>
<xsd:element name="P_22B" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów lądowych, o
których mowa w art. 2 pkt 10 lit. a ustawy - należy podać przebieg pojazdu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:choice minOccurs="0">
<xsd:element name="P_22B1" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów lądowych, o
których mowa w art. 2 pkt 10 lit. a ustawy - można podać numer VIN</xsd:documentation>
</xsd:annotation>

---

</xsd:element>
<xsd:element name="P_22B2" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów lądowych, o
których mowa w art. 2 pkt 10 lit. a ustawy - można podać numer nadwozia</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22B3" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów lądowych, o
których mowa w art. 2 pkt 10 lit. a ustawy - można podać numer podwozia</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22B4" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów lądowych, o
których mowa w art. 2 pkt 10 lit. a ustawy - można podać numer ramy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
<xsd:element name="P_22BT" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów lądowych, o
których mowa w art. 2 pkt 10 lit. a ustawy - można podać typ nowego środka
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:sequence>
<xsd:element name="P_22C" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy jednostek pływających, o
których mowa w art. 2 pkt 10 lit. b ustawy, należy podać liczbę godzin roboczych używania nowego
środka transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22C1" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy jednostek pływających, o
których mowa w art. 2 pkt 10 lit. b ustawy, można podać numer kadłuba nowego środka
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:sequence>
<xsd:element name="P_22D" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy statków powietrznych, o
których mowa w art. 2 pkt 10 lit. c ustawy, należy podać liczbę godzin roboczych używania nowego
środka transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22D1" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy statków powietrznych, o
których mowa w art. 2 pkt 10 lit. c ustawy, można podać numer fabryczny nowego środka

---

transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:choice>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
</xsd:sequence>
<xsd:element name="P_22N" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik braku wewnątrzwspólnotowej dostawy nowych
środków transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
</xsd:complexType>
</xsd:element>
<xsd:element name="P_23" type="etd:TWybor1_2">
<xsd:annotation>
<xsd:documentation>W przypadku faktur wystawianych w procedurze uproszczonej
przez drugiego w kolejności podatnika, o którym mowa w art. 135 ust. 1 pkt 4 lit. b i c oraz ust. 2,
zawierającej adnotację, o której mowa w art. 136 ust. 1 pkt 1 i stwierdzenie, o którym mowa w art.
136 ust. 1 pkt 2 ustawy, należy podać wartość "1", w przeciwnym przypadku - wartość
"2"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="PMarzy">
<xsd:complexType>
<xsd:choice>
<xsd:sequence>
<xsd:element name="P_PMarzy" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik wystąpienia procedur marży, o których mowa w
art. 119 lub art. 120 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:choice>
<xsd:element name="P_PMarzy_2" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik świadczenia usług turystyki, dla których
podstawę opodatkowania stanowi marża, zgodnie z art. 119 ust. 1 ustawy, a faktura
dokumentująca świadczenie zawiera wyrazy "procedura marży dla biur
podróży"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_PMarzy_3_1" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik dostawy towarów używanych dla których
podstawę opodatkowania stanowi marża, zgodnie z art. 120 ustawy, a faktura dokumentująca
dostawę zawiera wyrazy "procedura marży - towary używane"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_PMarzy_3_2" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik dostawy dzieł sztuki dla których podstawę

---

opodatkowania stanowi marża, zgodnie z art. 120 ustawy, a faktura dokumentująca dostawę
zawiera wyrazy "procedura marży - dzieła sztuki"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_PMarzy_3_3" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik dostawy przedmiotów kolekcjonerskich i
antyków, dla których podstawę opodatkowania stanowi marża, zgodnie z art. 120 ustawy, a faktura
dokumentująca dostawę zawiera wyrazy "procedura marży - przedmioty kolekcjonerskie i
antyki"</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
</xsd:sequence>
<xsd:element name="P_PMarzyN" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik braku wystąpienia procedur marży, o których mowa
w art. 119 lub art. 120 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
</xsd:complexType>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
element Faktura/Fa/Adnotacje/P_16
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1_2
content simple
properties
Kind Value Annotation
facets
enumeration 1
enumeration 2
documentation
annotation
W przypadku dostawy towarów lub świadczenia usług, w odniesieniu do których obowiązek podatkowy powstaje zgodnie
z art. 19a ust. 5 pkt 1 lub art. 21 ust. 1 ustawy - wyrazy "metoda kasowa", należy podać wartość "1"; w przeciwnym
przypadku - wartość "2"
source <xsd:element name="P_16" type="etd:TWybor1_2">
<xsd:annotation>
<xsd:documentation>W przypadku dostawy towarów lub świadczenia usług, w odniesieniu do
których obowiązek podatkowy powstaje zgodnie z art. 19a ust. 5 pkt 1 lub art. 21 ust. 1 ustawy -

---

wyrazy "metoda kasowa", należy podać wartość "1"; w przeciwnym przypadku - wartość
"2"</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Adnotacje/P_17
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1_2
content simple
properties
Kind Value Annotation
facets
enumeration 1
enumeration 2
documentation
annotation
W przypadku faktur, o których mowa w art. 106d ust. 1 ustawy - wyraz "samofakturowanie", należy podać wartość "1"; w
przeciwnym przypadku - wartość "2"
source <xsd:element name="P_17" type="etd:TWybor1_2">
<xsd:annotation>
<xsd:documentation>W przypadku faktur, o których mowa w art. 106d ust. 1 ustawy - wyraz
"samofakturowanie", należy podać wartość "1"; w przeciwnym przypadku - wartość
"2"</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Adnotacje/P_18
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1_2
content simple
properties
Kind Value Annotation
facets
enumeration 1
enumeration 2

---

documentation
annotation
W przypadku dostawy towarów lub wykonania usługi, dla których obowiązanym do rozliczenia podatku od wartości
dodanej lub podatku o podobnym charakterze jest nabywca towaru lub usługi - wyrazy "odwrotne obciążenie", należy
podać wartość "1", w przeciwnym przypadku - wartość "2"
source <xsd:element name="P_18" type="etd:TWybor1_2">
<xsd:annotation>
<xsd:documentation>W przypadku dostawy towarów lub wykonania usługi, dla których
obowiązanym do rozliczenia podatku od wartości dodanej lub podatku o podobnym charakterze
jest nabywca towaru lub usługi - wyrazy "odwrotne obciążenie", należy podać wartość "1", w
przeciwnym przypadku - wartość "2"</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Adnotacje/P_18A
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1_2
content simple
properties
Kind Value Annotation
facets
enumeration 1
enumeration 2
documentation
annotation
W przypadku faktur, w których kwota należności ogółem przekracza kwotę 15 000 zł lub jej równowartość wyrażoną w
walucie obcej, obejmujących
dokonaną na rzecz podatnika dostawę towarów lub świadczenie usług, o których mowa w załączniku nr 15 do ustawy -
wyrazy "mechanizm podzielonej płatności", przy czym do przeliczania na złote kwot wyrażonych w walucie obcej stosuje
się zasady przeliczania kwot stosowane w celu określenia podstawy opodatkowania; należy podać wartość "1", w
przeciwnym przypadku - wartość "2"
source <xsd:element name="P_18A" type="etd:TWybor1_2">
<xsd:annotation>
<xsd:documentation>W przypadku faktur, w których kwota należności ogółem przekracza
kwotę 15 000 zł lub jej równowartość wyrażoną w walucie obcej, obejmujących
dokonaną na rzecz podatnika dostawę towarów lub świadczenie usług, o których mowa w
załączniku nr 15 do ustawy - wyrazy "mechanizm podzielonej płatności", przy czym do przeliczania
na złote kwot wyrażonych w walucie obcej stosuje się zasady przeliczania kwot stosowane w celu
określenia podstawy opodatkowania; należy podać wartość "1", w przeciwnym przypadku - wartość
"2"</xsd:documentation>
</xsd:annotation>

---

</xsd:element>
element Faktura/Fa/Adnotacje/Zwolnienie
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
content complex
properties
children tns:P_19 tns:P_19A tns:P_19B tns:P_19C tns:P_19N
source <xsd:element name="Zwolnienie">
<xsd:complexType>
<xsd:choice>
<xsd:sequence>
<xsd:element name="P_19" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik dostawy towarów lub świadczenia usług zwolnionych od
podatku na podstawie art. 43 ust. 1, art. 113 ust. 1 i 9 albo przepisów wydanych na podstawie art.

---

82 ust. 3 ustawy lub na podstawie innych przepisów</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:choice>
<xsd:element name="P_19A" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli pole P_19 równa się "1" - należy wskazać przepis ustawy
albo aktu wydanego na podstawie ustawy, na podstawie którego podatnik stosuje zwolnienie od
podatku</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_19B" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli pole P_19 równa się "1" - należy wskazać przepis
dyrektywy 2006/112/WE, który zwalnia od podatku taką dostawę towarów lub takie świadczenie
usług</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_19C" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli pole P_19 równa się "1" - należy wskazać inną podstawę
prawną wskazującą na to, że dostawa towarów lub świadczenie usług korzysta ze zwolnienia od
podatku</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
</xsd:sequence>
<xsd:element name="P_19N" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik braku dostawy towarów lub świadczenia usług
zwolnionych od podatku na podstawie art. 43 ust. 1, art. 113 ust. 1 i 9 ustawy albo przepisów
wydanych na podstawie art. 82 ust. 3 ustawy lub na podstawie innych
przepisów</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
</xsd:complexType>
</xsd:element>
element Faktura/Fa/Adnotacje/Zwolnienie/P_19
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1
content simple
properties

---

Kind Value Annotation
facets
enumeration 1
documentation
annotation
Znacznik dostawy towarów lub świadczenia usług zwolnionych od podatku na podstawie art. 43 ust. 1, art. 113 ust. 1 i 9
albo przepisów wydanych na podstawie art. 82 ust. 3 ustawy lub na podstawie innych przepisów
source <xsd:element name="P_19" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik dostawy towarów lub świadczenia usług zwolnionych od
podatku na podstawie art. 43 ust. 1, art. 113 ust. 1 i 9 albo przepisów wydanych na podstawie art.
82 ust. 3 ustawy lub na podstawie innych przepisów</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Adnotacje/Zwolnienie/P_19A
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
content simple
properties
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Jeśli pole P_19 równa się "1" - należy wskazać przepis ustawy albo aktu wydanego na podstawie ustawy, na podstawie
którego podatnik stosuje zwolnienie od podatku
source <xsd:element name="P_19A" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli pole P_19 równa się "1" - należy wskazać przepis ustawy albo aktu
wydanego na podstawie ustawy, na podstawie którego podatnik stosuje zwolnienie od
podatku</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Adnotacje/Zwolnienie/P_19B
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
content simple
properties

---

Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Jeśli pole P_19 równa się "1" - należy wskazać przepis dyrektywy 2006/112/WE, który zwalnia od podatku taką dostawę
towarów lub takie świadczenie usług
source <xsd:element name="P_19B" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli pole P_19 równa się "1" - należy wskazać przepis dyrektywy
2006/112/WE, który zwalnia od podatku taką dostawę towarów lub takie świadczenie
usług</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Adnotacje/Zwolnienie/P_19C
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
content simple
properties
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Jeśli pole P_19 równa się "1" - należy wskazać inną podstawę prawną wskazującą na to, że dostawa towarów lub
świadczenie usług korzysta ze zwolnienia od podatku
source <xsd:element name="P_19C" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli pole P_19 równa się "1" - należy wskazać inną podstawę prawną
wskazującą na to, że dostawa towarów lub świadczenie usług korzysta ze zwolnienia od
podatku</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Adnotacje/Zwolnienie/P_19N
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/

---

type etd:TWybor1
content simple
properties
Kind Value Annotation
facets
enumeration 1
documentation
annotation
Znacznik braku dostawy towarów lub świadczenia usług zwolnionych od podatku na podstawie art. 43 ust. 1, art. 113 ust.
1 i 9 ustawy albo przepisów wydanych na podstawie art. 82 ust. 3 ustawy lub na podstawie innych przepisów
source <xsd:element name="P_19N" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik braku dostawy towarów lub świadczenia usług zwolnionych od
podatku na podstawie art. 43 ust. 1, art. 113 ust. 1 i 9 ustawy albo przepisów wydanych na
podstawie art. 82 ust. 3 ustawy lub na podstawie innych przepisów</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Adnotacje/NoweSrodkiTransportu
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
content complex
properties
children tns:P_22 tns:P_42_5 tns:NowySrodekTransportu tns:P_22N
source <xsd:element name="NoweSrodkiTransportu">
<xsd:complexType>
<xsd:choice>
<xsd:sequence>
<xsd:element name="P_22" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik wewnątrzwspólnotowej dostawy nowych środków
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_42_5" type="etd:TWybor1_2">

---

<xsd:annotation>
<xsd:documentation>Jeśli występuje obowiązek, o którym mowa w art. 42 ust. 5
ustawy, należy podać wartość "1", w przeciwnym przypadku - wartość "2"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="NowySrodekTransportu" maxOccurs="10000">
<xsd:complexType>
<xsd:sequence>
<xsd:element name="P_22A" type="tns:TDataT">
<xsd:annotation>
<xsd:documentation>Data dopuszczenia nowego środka transportu do
użytku</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_NrWierszaNST" type="tns:TNaturalny">
<xsd:annotation>
<xsd:documentation>Numer wiersza faktury, w którym wykazano dostawę
nowego środka transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22BMK" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Marka nowego środka transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22BMD" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Model nowego środka transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22BK" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kolor nowego środka transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22BNR" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer rejestracyjny nowego środka
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22BRP" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Rok produkcji nowego środka
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:choice>
<xsd:sequence>
<xsd:element name="P_22B" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów lądowych, o których
mowa w art. 2 pkt 10 lit. a ustawy - należy podać przebieg pojazdu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:choice minOccurs="0">

---

<xsd:element name="P_22B1" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów lądowych, o których
mowa w art. 2 pkt 10 lit. a ustawy - można podać numer VIN</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22B2" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów lądowych, o których
mowa w art. 2 pkt 10 lit. a ustawy - można podać numer nadwozia</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22B3" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów lądowych, o których
mowa w art. 2 pkt 10 lit. a ustawy - można podać numer podwozia</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22B4" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów lądowych, o których
mowa w art. 2 pkt 10 lit. a ustawy - można podać numer ramy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
<xsd:element name="P_22BT" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów lądowych, o których
mowa w art. 2 pkt 10 lit. a ustawy - można podać typ nowego środka
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:sequence>
<xsd:element name="P_22C" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy jednostek pływających, o których
mowa w art. 2 pkt 10 lit. b ustawy, należy podać liczbę godzin roboczych używania nowego środka
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22C1" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy jednostek pływających, o których
mowa w art. 2 pkt 10 lit. b ustawy, można podać numer kadłuba nowego środka
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:sequence>
<xsd:element name="P_22D" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy statków powietrznych, o których
mowa w art. 2 pkt 10 lit. c ustawy, należy podać liczbę godzin roboczych używania nowego środka
transportu</xsd:documentation>
</xsd:annotation>

---

</xsd:element>
<xsd:element name="P_22D1" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy statków powietrznych, o których
mowa w art. 2 pkt 10 lit. c ustawy, można podać numer fabryczny nowego środka
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:choice>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
</xsd:sequence>
<xsd:element name="P_22N" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik braku wewnątrzwspólnotowej dostawy nowych środków
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
</xsd:complexType>
</xsd:element>
element Faktura/Fa/Adnotacje/NoweSrodkiTransportu/P_22
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1
content simple
properties
Kind Value Annotation
facets
enumeration 1
documentation
annotation
Znacznik wewnątrzwspólnotowej dostawy nowych środków transportu
source <xsd:element name="P_22" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik wewnątrzwspólnotowej dostawy nowych środków
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/Adnotacje/NoweSrodkiTransportu/P_42_5
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1_2
content simple
properties
Kind Value Annotation
facets
enumeration 1
enumeration 2
documentation
annotation
Jeśli występuje obowiązek, o którym mowa w art. 42 ust. 5 ustawy, należy podać wartość "1", w przeciwnym przypadku -
wartość "2"
source <xsd:element name="P_42_5" type="etd:TWybor1_2">
<xsd:annotation>
<xsd:documentation>Jeśli występuje obowiązek, o którym mowa w art. 42 ust. 5 ustawy,
należy podać wartość "1", w przeciwnym przypadku - wartość "2"</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu

---

diagram

---

namespace http://crd.gov.pl/wzor/2023/06/29/12648/
minOcc 1
properties
maxOcc 10000
content complex
children tns:P_22A tns:P_NrWierszaNST tns:P_22BMK tns:P_22BMD tns:P_22BK tns:P_22BNR tns:P_22BRP tns:P_22B
tns:P_22B1 tns:P_22B2 tns:P_22B3 tns:P_22B4 tns:P_22BT tns:P_22C tns:P_22C1 tns:P_22D tns:P_22D1
source <xsd:element name="NowySrodekTransportu" maxOccurs="10000">
<xsd:complexType>
<xsd:sequence>
<xsd:element name="P_22A" type="tns:TDataT">
<xsd:annotation>
<xsd:documentation>Data dopuszczenia nowego środka transportu do
użytku</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_NrWierszaNST" type="tns:TNaturalny">
<xsd:annotation>
<xsd:documentation>Numer wiersza faktury, w którym wykazano dostawę nowego
środka transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22BMK" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Marka nowego środka transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22BMD" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Model nowego środka transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22BK" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kolor nowego środka transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22BNR" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer rejestracyjny nowego środka
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22BRP" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Rok produkcji nowego środka transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:choice>
<xsd:sequence>
<xsd:element name="P_22B" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów lądowych, o których mowa w
art. 2 pkt 10 lit. a ustawy - należy podać przebieg pojazdu</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

<xsd:choice minOccurs="0">
<xsd:element name="P_22B1" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów lądowych, o których mowa w
art. 2 pkt 10 lit. a ustawy - można podać numer VIN</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22B2" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów lądowych, o których mowa w
art. 2 pkt 10 lit. a ustawy - można podać numer nadwozia</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22B3" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów lądowych, o których mowa w
art. 2 pkt 10 lit. a ustawy - można podać numer podwozia</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22B4" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów lądowych, o których mowa w
art. 2 pkt 10 lit. a ustawy - można podać numer ramy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
<xsd:element name="P_22BT" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów lądowych, o których mowa w
art. 2 pkt 10 lit. a ustawy - można podać typ nowego środka transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:sequence>
<xsd:element name="P_22C" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy jednostek pływających, o których mowa
w art. 2 pkt 10 lit. b ustawy, należy podać liczbę godzin roboczych używania nowego środka
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_22C1" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy jednostek pływających, o których mowa
w art. 2 pkt 10 lit. b ustawy, można podać numer kadłuba nowego środka
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:sequence>
<xsd:element name="P_22D" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy statków powietrznych, o których mowa w
art. 2 pkt 10 lit. c ustawy, należy podać liczbę godzin roboczych używania nowego środka
transportu</xsd:documentation>
</xsd:annotation>

---

</xsd:element>
<xsd:element name="P_22D1" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy statków powietrznych, o których mowa w
art. 2 pkt 10 lit. c ustawy, można podać numer fabryczny nowego środka
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:choice>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
element Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22A
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TDataT
content simple
properties
Kind Value Annotation
facets
minInclusive 2006-01-01
maxInclusive 2050-01-01
pattern ((\d{4})-(\d{2})-(\d{2}))
documentation
annotation
Data dopuszczenia nowego środka transportu do użytku
source <xsd:element name="P_22A" type="tns:TDataT">
<xsd:annotation>
<xsd:documentation>Data dopuszczenia nowego środka transportu do
użytku</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_NrWierszaNST
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TNaturalny
content simple
properties
Kind Value Annotation
facets
minExclusive 0
totalDigits 14
whiteSpace collapse

---

documentation
annotation
Numer wiersza faktury, w którym wykazano dostawę nowego środka transportu
source <xsd:element name="P_NrWierszaNST" type="tns:TNaturalny">
<xsd:annotation>
<xsd:documentation>Numer wiersza faktury, w którym wykazano dostawę nowego środka
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22BMK
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Marka nowego środka transportu
source <xsd:element name="P_22BMK" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Marka nowego środka transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22BMD
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Model nowego środka transportu
source <xsd:element name="P_22BMD" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Model nowego środka transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22BK
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Kolor nowego środka transportu
source <xsd:element name="P_22BK" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kolor nowego środka transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22BNR
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Numer rejestracyjny nowego środka transportu
source <xsd:element name="P_22BNR" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer rejestracyjny nowego środka transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22BRP
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/

---

type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Rok produkcji nowego środka transportu
source <xsd:element name="P_22BRP" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Rok produkcji nowego środka transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22B
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
content simple
properties
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Jeśli dostawa dotyczy pojazdów lądowych, o których mowa w art. 2 pkt 10 lit. a ustawy - należy podać przebieg pojazdu
source <xsd:element name="P_22B" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów lądowych, o których mowa w art. 2 pkt
10 lit. a ustawy - należy podać przebieg pojazdu</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22B1
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple

---

Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Jeśli dostawa dotyczy pojazdów lądowych, o których mowa w art. 2 pkt 10 lit. a ustawy - można podać numer VIN
source <xsd:element name="P_22B1" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów lądowych, o których mowa w art. 2 pkt
10 lit. a ustawy - można podać numer VIN</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22B2
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Jeśli dostawa dotyczy pojazdów lądowych, o których mowa w art. 2 pkt 10 lit. a ustawy - można podać numer nadwozia
source <xsd:element name="P_22B2" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów lądowych, o których mowa w art. 2 pkt
10 lit. a ustawy - można podać numer nadwozia</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22B3
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256

---

documentation
annotation
Jeśli dostawa dotyczy pojazdów lądowych, o których mowa w art. 2 pkt 10 lit. a ustawy - można podać numer podwozia
source <xsd:element name="P_22B3" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów lądowych, o których mowa w art. 2 pkt
10 lit. a ustawy - można podać numer podwozia</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22B4
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Jeśli dostawa dotyczy pojazdów lądowych, o których mowa w art. 2 pkt 10 lit. a ustawy - można podać numer ramy
source <xsd:element name="P_22B4" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów lądowych, o których mowa w art. 2 pkt
10 lit. a ustawy - można podać numer ramy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22BT
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Jeśli dostawa dotyczy pojazdów lądowych, o których mowa w art. 2 pkt 10 lit. a ustawy - można podać typ nowego
środka transportu

---

source <xsd:element name="P_22BT" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy pojazdów lądowych, o których mowa w art. 2 pkt
10 lit. a ustawy - można podać typ nowego środka transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22C
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
content simple
properties
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Jeśli dostawa dotyczy jednostek pływających, o których mowa w art. 2 pkt 10 lit. b ustawy, należy podać liczbę godzin
roboczych używania nowego środka transportu
source <xsd:element name="P_22C" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy jednostek pływających, o których mowa w art. 2 pkt
10 lit. b ustawy, należy podać liczbę godzin roboczych używania nowego środka
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22C1
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Jeśli dostawa dotyczy jednostek pływających, o których mowa w art. 2 pkt 10 lit. b ustawy, można podać numer kadłuba

---

nowego środka transportu
source <xsd:element name="P_22C1" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy jednostek pływających, o których mowa w art. 2 pkt
10 lit. b ustawy, można podać numer kadłuba nowego środka transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22D
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
content simple
properties
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Jeśli dostawa dotyczy statków powietrznych, o których mowa w art. 2 pkt 10 lit. c ustawy, należy podać liczbę godzin
roboczych używania nowego środka transportu
source <xsd:element name="P_22D" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy statków powietrznych, o których mowa w art. 2 pkt
10 lit. c ustawy, należy podać liczbę godzin roboczych używania nowego środka
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22D1
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256

---

documentation
annotation
Jeśli dostawa dotyczy statków powietrznych, o których mowa w art. 2 pkt 10 lit. c ustawy, można podać numer fabryczny
nowego środka transportu
source <xsd:element name="P_22D1" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jeśli dostawa dotyczy statków powietrznych, o których mowa w art. 2 pkt
10 lit. c ustawy, można podać numer fabryczny nowego środka transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Adnotacje/NoweSrodkiTransportu/P_22N
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1
content simple
properties
Kind Value Annotation
facets
enumeration 1
documentation
annotation
Znacznik braku wewnątrzwspólnotowej dostawy nowych środków transportu
source <xsd:element name="P_22N" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik braku wewnątrzwspólnotowej dostawy nowych środków
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Adnotacje/P_23
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1_2
content simple
properties
Kind Value Annotation
facets
enumeration 1

---

enumeration 2
documentation
annotation
W przypadku faktur wystawianych w procedurze uproszczonej przez drugiego w kolejności podatnika, o którym mowa w
art. 135 ust. 1 pkt 4 lit. b i c oraz ust. 2, zawierającej adnotację, o której mowa w art. 136 ust. 1 pkt 1 i stwierdzenie, o
którym mowa w art. 136 ust. 1 pkt 2 ustawy, należy podać wartość "1", w przeciwnym przypadku - wartość "2"
source <xsd:element name="P_23" type="etd:TWybor1_2">
<xsd:annotation>
<xsd:documentation>W przypadku faktur wystawianych w procedurze uproszczonej przez
drugiego w kolejności podatnika, o którym mowa w art. 135 ust. 1 pkt 4 lit. b i c oraz ust. 2,
zawierającej adnotację, o której mowa w art. 136 ust. 1 pkt 1 i stwierdzenie, o którym mowa w art.
136 ust. 1 pkt 2 ustawy, należy podać wartość "1", w przeciwnym przypadku - wartość
"2"</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/Adnotacje/PMarzy
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
content complex
properties
children tns:P_PMarzy tns:P_PMarzy_2 tns:P_PMarzy_3_1 tns:P_PMarzy_3_2 tns:P_PMarzy_3_3 tns:P_PMarzyN
source <xsd:element name="PMarzy">
<xsd:complexType>
<xsd:choice>
<xsd:sequence>
<xsd:element name="P_PMarzy" type="etd:TWybor1">
<xsd:annotation>

---

<xsd:documentation>Znacznik wystąpienia procedur marży, o których mowa w art. 119
lub art. 120 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:choice>
<xsd:element name="P_PMarzy_2" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik świadczenia usług turystyki, dla których podstawę
opodatkowania stanowi marża, zgodnie z art. 119 ust. 1 ustawy, a faktura dokumentująca
świadczenie zawiera wyrazy "procedura marży dla biur podróży"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_PMarzy_3_1" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik dostawy towarów używanych dla których podstawę
opodatkowania stanowi marża, zgodnie z art. 120 ustawy, a faktura dokumentująca dostawę
zawiera wyrazy "procedura marży - towary używane"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_PMarzy_3_2" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik dostawy dzieł sztuki dla których podstawę
opodatkowania stanowi marża, zgodnie z art. 120 ustawy, a faktura dokumentująca dostawę
zawiera wyrazy "procedura marży - dzieła sztuki"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_PMarzy_3_3" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik dostawy przedmiotów kolekcjonerskich i antyków, dla
których podstawę opodatkowania stanowi marża, zgodnie z art. 120 ustawy, a faktura
dokumentująca dostawę zawiera wyrazy "procedura marży - przedmioty kolekcjonerskie i
antyki"</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
</xsd:sequence>
<xsd:element name="P_PMarzyN" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik braku wystąpienia procedur marży, o których mowa w art.
119 lub art. 120 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
</xsd:complexType>
</xsd:element>
element Faktura/Fa/Adnotacje/PMarzy/P_PMarzy
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/

---

type etd:TWybor1
content simple
properties
Kind Value Annotation
facets
enumeration 1
documentation
annotation
Znacznik wystąpienia procedur marży, o których mowa w art. 119 lub art. 120 ustawy
source <xsd:element name="P_PMarzy" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik wystąpienia procedur marży, o których mowa w art. 119 lub art.
120 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Adnotacje/PMarzy/P_PMarzy_2
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1
content simple
properties
Kind Value Annotation
facets
enumeration 1
documentation
annotation
Znacznik świadczenia usług turystyki, dla których podstawę opodatkowania stanowi marża, zgodnie z art. 119 ust. 1
ustawy, a faktura dokumentująca świadczenie zawiera wyrazy "procedura marży dla biur podróży"
source <xsd:element name="P_PMarzy_2" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik świadczenia usług turystyki, dla których podstawę
opodatkowania stanowi marża, zgodnie z art. 119 ust. 1 ustawy, a faktura dokumentująca
świadczenie zawiera wyrazy "procedura marży dla biur podróży"</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Adnotacje/PMarzy/P_PMarzy_3_1
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/

---

type etd:TWybor1
content simple
properties
Kind Value Annotation
facets
enumeration 1
documentation
annotation
Znacznik dostawy towarów używanych dla których podstawę opodatkowania stanowi marża, zgodnie z art. 120 ustawy, a
faktura dokumentująca dostawę zawiera wyrazy "procedura marży - towary używane"
source <xsd:element name="P_PMarzy_3_1" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik dostawy towarów używanych dla których podstawę
opodatkowania stanowi marża, zgodnie z art. 120 ustawy, a faktura dokumentująca dostawę
zawiera wyrazy "procedura marży - towary używane"</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Adnotacje/PMarzy/P_PMarzy_3_2
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1
content simple
properties
Kind Value Annotation
facets
enumeration 1
documentation
annotation
Znacznik dostawy dzieł sztuki dla których podstawę opodatkowania stanowi marża, zgodnie z art. 120 ustawy, a faktura
dokumentująca dostawę zawiera wyrazy "procedura marży - dzieła sztuki"
source <xsd:element name="P_PMarzy_3_2" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik dostawy dzieł sztuki dla których podstawę opodatkowania
stanowi marża, zgodnie z art. 120 ustawy, a faktura dokumentująca dostawę zawiera wyrazy
"procedura marży - dzieła sztuki"</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/Adnotacje/PMarzy/P_PMarzy_3_3
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1
content simple
properties
Kind Value Annotation
facets
enumeration 1
documentation
annotation
Znacznik dostawy przedmiotów kolekcjonerskich i antyków, dla których podstawę opodatkowania stanowi marża,
zgodnie z art. 120 ustawy, a faktura dokumentująca dostawę zawiera wyrazy "procedura marży - przedmioty
kolekcjonerskie i antyki"
source <xsd:element name="P_PMarzy_3_3" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik dostawy przedmiotów kolekcjonerskich i antyków, dla których
podstawę opodatkowania stanowi marża, zgodnie z art. 120 ustawy, a faktura dokumentująca
dostawę zawiera wyrazy "procedura marży - przedmioty kolekcjonerskie i
antyki"</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Adnotacje/PMarzy/P_PMarzyN
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1
content simple
properties
Kind Value Annotation
facets
enumeration 1
documentation
annotation
Znacznik braku wystąpienia procedur marży, o których mowa w art. 119 lub art. 120 ustawy
source <xsd:element name="P_PMarzyN" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik braku wystąpienia procedur marży, o których mowa w art. 119
lub art. 120 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/RodzajFaktury
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TRodzajFaktury
content simple
properties
Kind Value Annotation
facets
minLength 1
maxLength 256
enumeration VAT documentation
Faktura podstawowa
enumeration KOR documentation
Faktura korygująca
enumeration ZAL documentation
Faktura dokumentująca otrzymanie zapłaty lub jej części przed dokonaniem czynności
oraz faktura wystawiona w związku z art. 106f ust. 4 ustawy
enumeration ROZ documentation
Faktura wystawiona w związku z art. 106f ust. 3 ustawy
enumeration UPR documentation
Faktura, o której mowa w art. 106e ust. 5 pkt 3 ustawy
enumeration KOR_ZAL documentation
Faktura korygująca fakturę dokumentującą otrzymanie zapłaty lub jej części przed
dokonaniem czynności oraz fakturę wystawioną w związku z art. 106f ust. 4 ustawy
enumeration KOR_ROZ documentation
Faktura korygująca fakturę wystawioną w związku z art. 106f ust. 3 ustawy
documentation
annotation
Rodzaj faktury
source <xsd:element name="RodzajFaktury" type="tns:TRodzajFaktury">
<xsd:annotation>
<xsd:documentation>Rodzaj faktury</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/PrzyczynaKorekty
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Przyczyna korekty dla faktur korygujących
source <xsd:element name="PrzyczynaKorekty" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Przyczyna korekty dla faktur korygujących</xsd:documentation>
</xsd:annotation>

---

</xsd:element>
element Faktura/Fa/TypKorekty
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TTypKorekty
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
enumeration 1 documentation
Korekta skutkująca w dacie ujęcia faktury pierwotnej
enumeration 2 documentation
Korekta skutkująca w dacie wystawienia faktury korygującej
enumeration 3 documentation
Korekta skutkująca w dacie innej, w tym gdy dla różnych pozycji faktury korygującej daty te
są różne
documentation
annotation
Typ skutku korekty w ewidencji dla podatku od towarów i usług
source <xsd:element name="TypKorekty" type="tns:TTypKorekty" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Typ skutku korekty w ewidencji dla podatku od towarów i
usług</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/DaneFaKorygowanej
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
minOcc 1
properties
maxOcc unbounded

---

content complex
children tns:DataWystFaKorygowanej tns:NrFaKorygowanej tns:NrKSeF tns:NrKSeFFaKorygowanej tns:NrKSeFN
documentation
annotation
Dane faktury korygowanej
source <xsd:element name="DaneFaKorygowanej" maxOccurs="unbounded">
<xsd:annotation>
<xsd:documentation>Dane faktury korygowanej</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="DataWystFaKorygowanej" type="tns:TDataT">
<xsd:annotation>
<xsd:documentation>Data wystawienia faktury korygowanej</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="NrFaKorygowanej" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Numer faktury korygowanej</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:choice>
<xsd:sequence>
<xsd:element name="NrKSeF" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik numeru KSeF faktury
korygowanej</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="NrKSeFFaKorygowanej" type="tns:TNumerKSeF">
<xsd:annotation>
<xsd:documentation>Numer identyfikujący fakturę korygowaną w
KSeF</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:element name="NrKSeFN" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik faktury korygowanej wystawionej poza
KSeF</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
element Faktura/Fa/DaneFaKorygowanej/DataWystFaKorygowanej
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/

---

type tns:TDataT
content simple
properties
Kind Value Annotation
facets
minInclusive 2006-01-01
maxInclusive 2050-01-01
pattern ((\d{4})-(\d{2})-(\d{2}))
documentation
annotation
Data wystawienia faktury korygowanej
source <xsd:element name="DataWystFaKorygowanej" type="tns:TDataT">
<xsd:annotation>
<xsd:documentation>Data wystawienia faktury korygowanej</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/DaneFaKorygowanej/NrFaKorygowanej
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
content simple
properties
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Numer faktury korygowanej
source <xsd:element name="NrFaKorygowanej" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Numer faktury korygowanej</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/DaneFaKorygowanej/NrKSeF
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1
content simple
properties
Kind Value Annotation
facets
enumeration 1
documentation
annotation
Znacznik numeru KSeF faktury korygowanej
source <xsd:element name="NrKSeF" type="etd:TWybor1">
<xsd:annotation>

---

<xsd:documentation>Znacznik numeru KSeF faktury korygowanej</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/DaneFaKorygowanej/NrKSeFFaKorygowanej
diagra
m
names http://crd.gov.pl/wzor/2023/06/29/12648/
pace
type tns:TNumerKSeF
content simple
properti
es
Kind Value Annot
facets
ation
patt ([1-9]((\d[1-9])|([1-9]\d))\d{7}|M\d{9}|[A-Z]{3}\d{7})-(20[2-9][0-9]|2[1-9][0-9]{2}|[3-9][0-9]{3})(0[1-9]|1[0-2])(0[1-9]
ern |[1-2][0-9]|3[0-1])-([0-9A-F]{6})-?([0-9A-F]{6})-([0-9A-F]{2})
documentation
annotat
Numer identyfikujący fakturę korygowaną w KSeF
ion
source <xsd:element name="NrKSeFFaKorygowanej" type="tns:TNumerKSeF">
<xsd:annotation>
<xsd:documentation>Numer identyfikujący fakturę korygowaną w KSeF</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/DaneFaKorygowanej/NrKSeFN
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1
content simple
properties
Kind Value Annotation
facets
enumeration 1
documentation
annotation
Znacznik faktury korygowanej wystawionej poza KSeF
source <xsd:element name="NrKSeFN" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik faktury korygowanej wystawionej poza
KSeF</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/OkresFaKorygowanej
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Dla faktury korygującej, o której mowa w art. 106j ust. 3 ustawy - okres, do którego odnosi się udzielany opust lub
udzielana obniżka, w przypadku gdy podatnik udziela opustu lub obniżki ceny w odniesieniu do dostaw towarów lub
usług dokonanych lub świadczonych na rzecz jednego odbiorcy w danym okresie
source <xsd:element name="OkresFaKorygowanej" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Dla faktury korygującej, o której mowa w art. 106j ust. 3 ustawy - okres,
do którego odnosi się udzielany opust lub udzielana obniżka, w przypadku gdy podatnik udziela
opustu lub obniżki ceny w odniesieniu do dostaw towarów lub usług dokonanych lub świadczonych
na rzecz jednego odbiorcy w danym okresie</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/NrFaKorygowany
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Poprawny numer faktury korygowanej w przypadku, gdy przyczyną korekty jest błędny numer faktury korygowanej. W
takim przypadku błędny numer faktury należy wskazać w polu NrFaKorygowanej
source <xsd:element name="NrFaKorygowany" type="tns:TZnakowy" minOccurs="0">

---

<xsd:annotation>
<xsd:documentation>Poprawny numer faktury korygowanej w przypadku, gdy przyczyną
korekty jest błędny numer faktury korygowanej. W takim przypadku błędny numer faktury należy
wskazać w polu NrFaKorygowanej</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Podmiot1K
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
minOcc 0
properties
maxOcc 1
content complex
children tns:PrefiksPodatnika tns:DaneIdentyfikacyjne tns:Adres
documentation
annotation
W przypadku korekty danych sprzedawcy należy podać pełne dane sprzedawcy występujące na fakturze korygowanej.
Pole nie dotyczy przypadku korekty błędnego NIP występującego na fakturze pierwotnej - wówczas wymagana jest
korekta faktury do wartości zerowych
source <xsd:element name="Podmiot1K" minOccurs="0">
<xsd:annotation>
<xsd:documentation>W przypadku korekty danych sprzedawcy należy podać pełne dane
sprzedawcy występujące na fakturze korygowanej. Pole nie dotyczy przypadku korekty błędnego
NIP występującego na fakturze pierwotnej - wówczas wymagana jest korekta faktury do wartości
zerowych</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="PrefiksPodatnika" type="tns:TKodyKrajowUE" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kod (prefiks) podatnika VAT UE dla przypadków określonych w art.
97 ust. 10 pkt 2 i 3 ustawy oraz w przypadku, o którym mowa w art. 136 ust. 1 pkt 3
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DaneIdentyfikacyjne" type="tns:TPodmiot1">
<xsd:annotation>
<xsd:documentation>Dane identyfikujące podatnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Adres" type="tns:TAdres">

---

<xsd:annotation>
<xsd:documentation>Adres podatnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
element Faktura/Fa/Podmiot1K/PrefiksPodatnika
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKodyKrajowUE
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
enumeration AT documentation
AUSTRIA
enumeration BE documentation
BELGIA
enumeration BG documentation
BUŁGARIA
enumeration CY documentation
CYPR
enumeration CZ documentation
CZECHY
enumeration DK documentation
DANIA
enumeration EE documentation
ESTONIA
enumeration FI documentation
FINLANDIA
enumeration FR documentation
FRANCJA
enumeration DE documentation
NIEMCY
enumeration EL documentation
GRECJA
enumeration HR documentation
CHORWACJA
enumeration HU documentation
WĘGRY
enumeration IE documentation
IRLANDIA
enumeration IT documentation
WŁOCHY
enumeration LV documentation
ŁOTWA
enumeration LT documentation
LITWA
enumeration LU documentation
LUKSEMBURG
enumeration MT documentation
MALTA
enumeration NL documentation

---

HOLANDIA
enumeration PL documentation
POLSKA
enumeration PT documentation
PORTUGALIA
enumeration RO documentation
RUMUNIA
enumeration SK documentation
SŁOWACJA
enumeration SI documentation
SŁOWENIA
enumeration ES documentation
HISZPANIA
enumeration SE documentation
SZWECJA
enumeration XI documentation
IRLANDIA PÓŁNOCNA
documentation
annotation
Kod (prefiks) podatnika VAT UE dla przypadków określonych w art. 97 ust. 10 pkt 2 i 3 ustawy oraz w przypadku, o
którym mowa w art. 136 ust. 1 pkt 3 ustawy
source <xsd:element name="PrefiksPodatnika" type="tns:TKodyKrajowUE" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kod (prefiks) podatnika VAT UE dla przypadków określonych w art. 97
ust. 10 pkt 2 i 3 ustawy oraz w przypadku, o którym mowa w art. 136 ust. 1 pkt 3
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Podmiot1K/DaneIdentyfikacyjne
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TPodmiot1
content complex
properties
children tns:NIP tns:Nazwa
documentation
annotation
Dane identyfikujące podatnika
source <xsd:element name="DaneIdentyfikacyjne" type="tns:TPodmiot1">
<xsd:annotation>
<xsd:documentation>Dane identyfikujące podatnika</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/Podmiot1K/Adres
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TAdres
content complex
properties
children tns:KodKraju tns:AdresL1 tns:AdresL2 tns:GLN
documentation
annotation
Adres podatnika
source <xsd:element name="Adres" type="tns:TAdres">
<xsd:annotation>
<xsd:documentation>Adres podatnika</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/Podmiot2K
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
minOcc 0
properties
maxOcc 101
content complex
children tns:DaneIdentyfikacyjne tns:Adres tns:IDNabywcy
documentation
annotation
W przypadku korekty danych nabywcy występującego jako Podmiot2 lub dodatkowego nabywcy występującego jako
Podmiot3 należy podać pełne dane tego podmiotu występujące na fakturze korygowanej. Korekcie nie podlegają błędne
numery identyfikujące nabywcę oraz dodatkowego nabywcę. W przypadku korygowania pozostałych danych nabywcy
lub dodatkowego nabywcy wskazany numer identyfikacyjny ma być tożsamy z numerem w części Podmiot2 względnie
Podmiot3 faktury korygującej
source <xsd:element name="Podmiot2K" minOccurs="0" maxOccurs="101">
<xsd:annotation>
<xsd:documentation>W przypadku korekty danych nabywcy występującego jako Podmiot2 lub
dodatkowego nabywcy występującego jako Podmiot3 należy podać pełne dane tego podmiotu
występujące na fakturze korygowanej. Korekcie nie podlegają błędne numery identyfikujące
nabywcę oraz dodatkowego nabywcę. W przypadku korygowania pozostałych danych nabywcy lub
dodatkowego nabywcy wskazany numer identyfikacyjny ma być tożsamy z numerem w części
Podmiot2 względnie Podmiot3 faktury korygującej</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="DaneIdentyfikacyjne" type="tns:TPodmiot2">
<xsd:annotation>
<xsd:documentation>Dane identyfikujące nabywcę</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Adres" type="tns:TAdres" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres nabywcy. Pola opcjonalne dla przypadków określonych w
art. 106e ust. 5 pkt 3 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

<xsd:element name="IDNabywcy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Unikalny klucz powiązania danych nabywcy na fakturach
korygujących, w przypadku gdy dane nabywcy na fakturze korygującej zmieniły się w stosunku do
danych na fakturze korygowanej</xsd:documentation>
</xsd:annotation>
<xsd:simpleType>
<xsd:restriction base="tns:TZnakowy50">
<xsd:maxLength value="32"/>
</xsd:restriction>
</xsd:simpleType>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
element Faktura/Fa/Podmiot2K/DaneIdentyfikacyjne
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TPodmiot2
content complex
properties
children tns:NIP tns:KodUE tns:NrVatUE tns:KodKraju tns:NrID tns:BrakID tns:Nazwa

---

documentation
annotation
Dane identyfikujące nabywcę
source <xsd:element name="DaneIdentyfikacyjne" type="tns:TPodmiot2">
<xsd:annotation>
<xsd:documentation>Dane identyfikujące nabywcę</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Podmiot2K/Adres
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TAdres
minOcc 0
properties
maxOcc 1
content complex
children tns:KodKraju tns:AdresL1 tns:AdresL2 tns:GLN
documentation
annotation
Adres nabywcy. Pola opcjonalne dla przypadków określonych w art. 106e ust. 5 pkt 3 ustawy
source <xsd:element name="Adres" type="tns:TAdres" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres nabywcy. Pola opcjonalne dla przypadków określonych w art. 106e
ust. 5 pkt 3 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Podmiot2K/IDNabywcy
diagram

---

namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of tns:TZnakowy50
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 32
documentation
annotation
Unikalny klucz powiązania danych nabywcy na fakturach korygujących, w przypadku gdy dane nabywcy na fakturze
korygującej zmieniły się w stosunku do danych na fakturze korygowanej
source <xsd:element name="IDNabywcy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Unikalny klucz powiązania danych nabywcy na fakturach korygujących, w
przypadku gdy dane nabywcy na fakturze korygującej zmieniły się w stosunku do danych na
fakturze korygowanej</xsd:documentation>
</xsd:annotation>
<xsd:simpleType>
<xsd:restriction base="tns:TZnakowy50">
<xsd:maxLength value="32"/>
</xsd:restriction>
</xsd:simpleType>
</xsd:element>
element Faktura/Fa/P_15ZK
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
content simple
properties
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
W przypadku korekt faktur zaliczkowych, kwota zapłaty przed korektą. W przypadku korekt faktur, o których mowa w art.
106f ust. 3 ustawy, kwota pozostała do zapłaty przed korektą
source <xsd:element name="P_15ZK" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>W przypadku korekt faktur zaliczkowych, kwota zapłaty przed korektą. W
przypadku korekt faktur, o których mowa w art. 106f ust. 3 ustawy, kwota pozostała do zapłaty
przed korektą</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/KursWalutyZK
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TIlosci
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
totalDigits 22
fractionDigits 6
pattern -?([1-9]\d{0,15}|0)(\.\d{1,6})?
documentation
annotation
Kurs waluty stosowany do wyliczenia kwoty podatku w przypadkach, o których mowa w Dziale VI ustawy przed korektą
source <xsd:element name="KursWalutyZK" type="tns:TIlosci" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kurs waluty stosowany do wyliczenia kwoty podatku w przypadkach, o
których mowa w Dziale VI ustawy przed korektą</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/ZaliczkaCzesciowa
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
minOcc 0
properties
maxOcc 31
content complex

---

children tns:P_6Z tns:P_15Z tns:KursWalutyZW
documentation
annotation
Dane dla przypadków faktur dokumentujących otrzymanie więcej niż jednej płatności, o której mowa w art. 106b ust. 1
pkt 4 ustawy. W przypadku, gdy faktura, o której mowa w art. 106f ust. 3 ustawy dokumentuje jednocześnie otrzymanie
części zapłaty przed dokonaniem czynności, różnica kwoty w polu P_15 i sumy poszczególnych pól P_15Z stanowi
kwotę pozostałą ponad płatności otrzymane przed wykonaniem czynności udokumentowanej fakturą
source <xsd:element name="ZaliczkaCzesciowa" minOccurs="0" maxOccurs="31">
<xsd:annotation>
<xsd:documentation>Dane dla przypadków faktur dokumentujących otrzymanie więcej niż
jednej płatności, o której mowa w art. 106b ust. 1 pkt 4 ustawy. W przypadku, gdy faktura, o której
mowa w art. 106f ust. 3 ustawy dokumentuje jednocześnie otrzymanie części zapłaty przed
dokonaniem czynności, różnica kwoty w polu P_15 i sumy poszczególnych pól P_15Z stanowi
kwotę pozostałą ponad płatności otrzymane przed wykonaniem czynności udokumentowanej
fakturą</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="P_6Z" type="tns:TDataT">
<xsd:annotation>
<xsd:documentation>Data otrzymania płatności, o której mowa w art. 106b ust. 1 pkt 4
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_15Z" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota płatności, o której mowa w art. 106b ust. 1 pkt 4 ustawy,
składająca się na kwotę w polu P_15. W przypadku faktur korygujących korekta kwoty wynikającej
z faktury korygowanej</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="KursWalutyZW" type="tns:TIlosci" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kurs waluty stosowany do wyliczenia kwoty podatku w
przypadkach, o których mowa w Dziale VI ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
element Faktura/Fa/ZaliczkaCzesciowa/P_6Z
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TDataT
content simple
properties
Kind Value Annotation
facets
minInclusive 2006-01-01
maxInclusive 2050-01-01

---

pattern ((\d{4})-(\d{2})-(\d{2}))
documentation
annotation
Data otrzymania płatności, o której mowa w art. 106b ust. 1 pkt 4 ustawy
source <xsd:element name="P_6Z" type="tns:TDataT">
<xsd:annotation>
<xsd:documentation>Data otrzymania płatności, o której mowa w art. 106b ust. 1 pkt 4
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/ZaliczkaCzesciowa/P_15Z
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
content simple
properties
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Kwota płatności, o której mowa w art. 106b ust. 1 pkt 4 ustawy, składająca się na kwotę w polu P_15. W przypadku
faktur korygujących korekta kwoty wynikającej z faktury korygowanej
source <xsd:element name="P_15Z" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota płatności, o której mowa w art. 106b ust. 1 pkt 4 ustawy,
składająca się na kwotę w polu P_15. W przypadku faktur korygujących korekta kwoty wynikającej
z faktury korygowanej</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/ZaliczkaCzesciowa/KursWalutyZW
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TIlosci
minOcc 0
properties
maxOcc 1
content simple

---

Kind Value Annotation
facets
totalDigits 22
fractionDigits 6
pattern -?([1-9]\d{0,15}|0)(\.\d{1,6})?
documentation
annotation
Kurs waluty stosowany do wyliczenia kwoty podatku w przypadkach, o których mowa w Dziale VI ustawy
source <xsd:element name="KursWalutyZW" type="tns:TIlosci" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kurs waluty stosowany do wyliczenia kwoty podatku w przypadkach, o
których mowa w Dziale VI ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/FP
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
enumeration 1
documentation
annotation
Faktura, o której mowa w art. 109 ust. 3d ustawy
source <xsd:element name="FP" type="etd:TWybor1" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Faktura, o której mowa w art. 109 ust. 3d ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/TP
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1
minOcc 0
properties
maxOcc 1
content simple

---

Kind Value Annotation
facets
enumeration 1
documentation
annotation
Istniejące powiązania między nabywcą a dokonującym dostawy towarów lub usługodawcą, zgodnie z § 10 ust. 4 pkt 3, z
zastrzeżeniem ust. 4b rozporządzenia w sprawie szczegółowego zakresu danych zawartych w deklaracjach
podatkowych i w ewidencji w zakresie podatku od towarów i usług
source <xsd:element name="TP" type="etd:TWybor1" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Istniejące powiązania między nabywcą a dokonującym dostawy towarów
lub usługodawcą, zgodnie z § 10 ust. 4 pkt 3, z zastrzeżeniem ust. 4b rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w zakresie
podatku od towarów i usług</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/DodatkowyOpis
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKluczWartosc
minOcc 0
properties
maxOcc 10000
content complex
children tns:NrWiersza tns:Klucz tns:Wartosc
documentation
annotation
Pola przeznaczone dla wykazywania dodatkowych danych na fakturze, w tym wymaganych przepisami prawa, dla
których nie przewidziano innych pól/elementów
source <xsd:element name="DodatkowyOpis" type="tns:TKluczWartosc" minOccurs="0"
maxOccurs="10000">
<xsd:annotation>
<xsd:documentation>Pola przeznaczone dla wykazywania dodatkowych danych na fakturze, w
tym wymaganych przepisami prawa, dla których nie przewidziano innych
pól/elementów</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/FakturaZaliczkowa
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
minOcc 0
properties
maxOcc 100
content complex
children tns:NrKSeFZN tns:NrFaZaliczkowej tns:NrKSeFFaZaliczkowej
documentation
annotation
Numery faktur zaliczkowych lub ich numery KSeF, jeśli zostały wystawione z użyciem KSeF
source <xsd:element name="FakturaZaliczkowa" minOccurs="0" maxOccurs="100">
<xsd:annotation>
<xsd:documentation>Numery faktur zaliczkowych lub ich numery KSeF, jeśli zostały
wystawione z użyciem KSeF</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:choice>
<xsd:sequence>
<xsd:element name="NrKSeFZN" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik faktury zaliczkowej wystawionej poza
KSeF</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="NrFaZaliczkowej" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Numer faktury zaliczkowej wystawionej poza KSeF. Pole
obowiązkowe dla faktury wystawianej po wydaniu towaru lub wykonaniu usługi, o której mowa w
art. 106f ust. 3 ustawy i ostatniej z faktur, o której mowa w art. 106f ust. 4
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:element name="NrKSeFFaZaliczkowej" type="tns:TNumerKSeF">
<xsd:annotation>
<xsd:documentation>Numer identyfikujący fakturę zaliczkową w KSeF. Pole
obowiązkowe w przypadku, gdy faktura zaliczkowa była wystawiona za pomocą
KSeF</xsd:documentation>

---

</xsd:annotation>
</xsd:element>
</xsd:choice>
</xsd:complexType>
</xsd:element>
element Faktura/Fa/FakturaZaliczkowa/NrKSeFZN
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1
content simple
properties
Kind Value Annotation
facets
enumeration 1
documentation
annotation
Znacznik faktury zaliczkowej wystawionej poza KSeF
source <xsd:element name="NrKSeFZN" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik faktury zaliczkowej wystawionej poza
KSeF</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/FakturaZaliczkowa/NrFaZaliczkowej
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
content simple
properties
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Numer faktury zaliczkowej wystawionej poza KSeF. Pole obowiązkowe dla faktury wystawianej po wydaniu towaru lub
wykonaniu usługi, o której mowa w art. 106f ust. 3 ustawy i ostatniej z faktur, o której mowa w art. 106f ust. 4 ustawy
source <xsd:element name="NrFaZaliczkowej" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Numer faktury zaliczkowej wystawionej poza KSeF. Pole obowiązkowe
dla faktury wystawianej po wydaniu towaru lub wykonaniu usługi, o której mowa w art. 106f ust. 3

---

ustawy i ostatniej z faktur, o której mowa w art. 106f ust. 4 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/FakturaZaliczkowa/NrKSeFFaZaliczkowej
diagra
m
names http://crd.gov.pl/wzor/2023/06/29/12648/
pace
type tns:TNumerKSeF
content simple
properti
es
Kind Value Annot
facets
ation
patt ([1-9]((\d[1-9])|([1-9]\d))\d{7}|M\d{9}|[A-Z]{3}\d{7})-(20[2-9][0-9]|2[1-9][0-9]{2}|[3-9][0-9]{3})(0[1-9]|1[0-2])(0[1-9]
ern |[1-2][0-9]|3[0-1])-([0-9A-F]{6})-?([0-9A-F]{6})-([0-9A-F]{2})
documentation
annotat
Numer identyfikujący fakturę zaliczkową w KSeF. Pole obowiązkowe w przypadku, gdy faktura zaliczkowa była wystawiona za
ion
pomocą KSeF
source <xsd:element name="NrKSeFFaZaliczkowej" type="tns:TNumerKSeF">
<xsd:annotation>
<xsd:documentation>Numer identyfikujący fakturę zaliczkową w KSeF. Pole obowiązkowe w
przypadku, gdy faktura zaliczkowa była wystawiona za pomocą KSeF</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/ZwrotAkcyzy
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
enumeration 1
documentation
annotation
Informacja dodatkowa niezbędna dla rolników ubiegających się o zwrot podatku akcyzowego zawartego w cenie oleju
napędowego
source <xsd:element name="ZwrotAkcyzy" type="etd:TWybor1" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Informacja dodatkowa niezbędna dla rolników ubiegających się o zwrot

---

podatku akcyzowego zawartego w cenie oleju napędowego</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/FaWiersz
diagram

---

namespace http://crd.gov.pl/wzor/2023/06/29/12648/
minOcc 0
properties
maxOcc 10000
content complex
children tns:NrWierszaFa tns:UU_ID tns:P_6A tns:P_7 tns:Indeks tns:GTIN tns:PKWiU tns:CN tns:PKOB tns:P_8A tns:P_8B
tns:P_9A tns:P_9B tns:P_10 tns:P_11 tns:P_11A tns:P_11Vat tns:P_12 tns:P_12_XII tns:P_12_Zal_15
tns:KwotaAkcyzy tns:GTU tns:Procedura tns:KursWaluty tns:StanPrzed
documentation
annotation
Szczegółowe pozycje faktury w walucie, w której wystawiono fakturę - węzeł opcjonalny dla faktury zaliczkowej, faktury
korygującej fakturę zaliczkową, oraz faktur korygujących dotyczących wszystkich dostaw towarów lub usług dokonanych
lub świadczonych w danym okresie, o których mowa w art. 106j ust. 3 ustawy, dla których należy podać dane dotyczące
opustu lub obniżki w podziale na stawki podatku i procedury w części Fa. W przypadku faktur korygujących, o których
mowa w art. 106j ust. 3 ustawy, gdy opust lub obniżka ceny odnosi się do części dostaw towarów lub usług dokonanych
lub świadczonych w danym okresie w części FaWiersz należy podać nazwy (rodzaje) towarów lub usług objętych
korektą. W przypadku faktur, o których mowa w art. 106f ust. 3 ustawy, należy wykazać pełne wartości zamówienia lub
umowy. W przypadku faktur korygujących pozycje faktury (w tym faktur korygujących faktury, o których mowa w art. 106f
ust. 3 ustawy, jeśli korekta dotyczy wartości zamówienia), należy wykazać różnice wynikające z korekty poszczególnych
pozycji lub dane pozycji korygowanych w stanie przed korektą i po korekcie jako osobne wiersze. W przypadku faktur
korygujących faktury, o których mowa w art. 106f ust. 3 ustawy, jeśli korekta nie dotyczy wartości zamówienia i
jednocześnie zmienia wysokość podstawy opodatkowania lub podatku, należy wprowadzić zapis wg stanu przed korektą
i zapis w stanie po korekcie w celu potwierdzenia braku zmiany wartości danej pozycji faktury
source <xsd:element name="FaWiersz" minOccurs="0" maxOccurs="10000">
<xsd:annotation>
<xsd:documentation>Szczegółowe pozycje faktury w walucie, w której wystawiono fakturę -
węzeł opcjonalny dla faktury zaliczkowej, faktury korygującej fakturę zaliczkową, oraz faktur
korygujących dotyczących wszystkich dostaw towarów lub usług dokonanych lub świadczonych w
danym okresie, o których mowa w art. 106j ust. 3 ustawy, dla których należy podać dane dotyczące
opustu lub obniżki w podziale na stawki podatku i procedury w części Fa. W przypadku faktur
korygujących, o których mowa w art. 106j ust. 3 ustawy, gdy opust lub obniżka ceny odnosi się do
części dostaw towarów lub usług dokonanych lub świadczonych w danym okresie w części
FaWiersz należy podać nazwy (rodzaje) towarów lub usług objętych korektą. W przypadku faktur, o
których mowa w art. 106f ust. 3 ustawy, należy wykazać pełne wartości zamówienia lub umowy. W
przypadku faktur korygujących pozycje faktury (w tym faktur korygujących faktury, o których mowa
w art. 106f ust. 3 ustawy, jeśli korekta dotyczy wartości zamówienia), należy wykazać różnice
wynikające z korekty poszczególnych pozycji lub dane pozycji korygowanych w stanie przed
korektą i po korekcie jako osobne wiersze. W przypadku faktur korygujących faktury, o których
mowa w art. 106f ust. 3 ustawy, jeśli korekta nie dotyczy wartości zamówienia i jednocześnie
zmienia wysokość podstawy opodatkowania lub podatku, należy wprowadzić zapis wg stanu przed
korektą i zapis w stanie po korekcie w celu potwierdzenia braku zmiany wartości danej pozycji
faktury</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="NrWierszaFa" type="tns:TNaturalny">
<xsd:annotation>
<xsd:documentation>Kolejny numer wiersza faktury</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="UU_ID" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Uniwersalny unikalny numer wiersza faktury</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_6A" type="tns:TDataT" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Data dokonania lub zakończenia dostawy towarów lub wykonania
usługi lub data otrzymania zapłaty, o której mowa w art. 106b ust. 1 pkt 4 ustawy, o ile taka data
jest określona i różni się od daty wystawienia faktury. Pole wypełnia się dla przypadku, gdy dla

---

poszczególnych pozycji faktury występują różne daty</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_7" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Nazwa (rodzaj) towaru lub usługi. Pole opcjonalne wyłącznie dla
przypadku określonego w art 106j ust. 3 pkt 2 ustawy (faktura korygująca)</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Indeks" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Pole przeznaczone do wpisania wewnętrznego kodu towaru lub
usługi nadanego przez podatnika albo dodatkowego opisu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="GTIN" type="tns:TZnakowy20" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Globalny numer jednostki handlowej</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="PKWiU" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Symbol Polskiej Klasyfikacji Wyrobów i Usług</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="CN" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Symbol Nomenklatury Scalonej</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="PKOB" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Symbol Polskiej Klasyfikacji Obiektów
Budowlanych</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_8A" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Miara dostarczonych towarów lub zakres wykonanych usług. Pole
opcjonalne dla przypadku określonego w art. 106e ust. 5 pkt 3 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_8B" type="tns:TIlosci" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Ilość (liczba) dostarczonych towarów lub zakres wykonanych usług.
Pole opcjonalne dla przypadku określonego w art. 106e ust. 5 pkt 3 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_9A" type="tns:TKwotowy2" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Cena jednostkowa towaru lub usługi bez kwoty podatku (cena
jednostkowa netto). Pole opcjonalne dla przypadków określonych w art. 106e ust. 2 i 3 oraz ust. 5
pkt 3 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_9B" type="tns:TKwotowy2" minOccurs="0">

---

<xsd:annotation>
<xsd:documentation>Cena wraz z kwotą podatku (cena jednostkowa brutto), w
przypadku zastosowania art. 106e ust. 7 i 8 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_10" type="tns:TKwotowy2" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kwoty wszelkich opustów lub obniżek cen, w tym w formie rabatu z
tytułu wcześniejszej zapłaty, o ile nie zostały one uwzględnione w cenie jednostkowej netto, a w
przypadku stosowania art. 106e ust. 7 ustawy w cenie jednostkowej brutto. Pole opcjonalne dla
przypadków określonych w art. 106e ust. 2 i 3 oraz ust. 5 pkt 1 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_11" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Wartość dostarczonych towarów lub wykonanych usług, objętych
transakcją, bez kwoty podatku (wartość sprzedaży netto). Pole opcjonalne dla przypadków
określonych w art. 106e ust. 2 i 3 oraz ust. 5 pkt 3 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_11A" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Wartość sprzedaży brutto, w przypadku zastosowania art. 106e ust.
7 i 8 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_11Vat" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kwota podatku w przypadku, o którym mowa w art. 106e ust. 10
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_12" type="tns:TStawkaPodatku" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Stawka podatku. Pole opcjonalne dla przypadków określonych w
art. 106e ust. 2, 3, ust. 4 pkt 3 i ust. 5 pkt 3 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_12_XII" type="tns:TProcentowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Stawka podatku od wartości dodanej w przypadku, o którym mowa
w dziale XII w rozdziale 6a ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_12_Zal_15" type="etd:TWybor1" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Znacznik dla towaru lub usługi wymienionych w załączniku nr 15 do
ustawy - wartość "1"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="KwotaAkcyzy" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kwota podatku akcyzowego zawarta w cenie
towaru</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

<xsd:element name="GTU" type="tns:TGTU" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Oznaczenie dotyczące dostawy towarów i świadczenia
usług</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Procedura" type="tns:TOznaczenieProcedury" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Oznaczenie dotyczące procedury</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="KursWaluty" type="tns:TIlosci" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kurs waluty stosowany do wyliczenia kwoty podatku w
przypadkach, o których mowa w Dziale VI ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="StanPrzed" type="etd:TWybor1" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Znacznik stanu przed korektą w przypadku faktury korygującej lub
faktury korygującej fakturę wystawioną w związku z art. 106f ust. 3 ustawy, w przypadku gdy
korekta dotyczy danych wykazanych w pozycjach faktury i jest dokonywana w sposób polegający
na wykazaniu danych przed korektą i po korekcie jako osobnych wierszy z odrębną numeracją oraz
w przypadku potwierdzania braku zmiany wartości danej pozycji</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
element Faktura/Fa/FaWiersz/NrWierszaFa
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TNaturalny
content simple
properties
Kind Value Annotation
facets
minExclusive 0
totalDigits 14
whiteSpace collapse
documentation
annotation
Kolejny numer wiersza faktury
source <xsd:element name="NrWierszaFa" type="tns:TNaturalny">
<xsd:annotation>
<xsd:documentation>Kolejny numer wiersza faktury</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/FaWiersz/UU_ID
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy50
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 50
documentation
annotation
Uniwersalny unikalny numer wiersza faktury
source <xsd:element name="UU_ID" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Uniwersalny unikalny numer wiersza faktury</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/FaWiersz/P_6A
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TDataT
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minInclusive 2006-01-01
maxInclusive 2050-01-01
pattern ((\d{4})-(\d{2})-(\d{2}))
documentation
annotation
Data dokonania lub zakończenia dostawy towarów lub wykonania usługi lub data otrzymania zapłaty, o której mowa w
art. 106b ust. 1 pkt 4 ustawy, o ile taka data jest określona i różni się od daty wystawienia faktury. Pole wypełnia się dla
przypadku, gdy dla poszczególnych pozycji faktury występują różne daty
source <xsd:element name="P_6A" type="tns:TDataT" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Data dokonania lub zakończenia dostawy towarów lub wykonania usługi
lub data otrzymania zapłaty, o której mowa w art. 106b ust. 1 pkt 4 ustawy, o ile taka data jest
określona i różni się od daty wystawienia faktury. Pole wypełnia się dla przypadku, gdy dla
poszczególnych pozycji faktury występują różne daty</xsd:documentation>

---

</xsd:annotation>
</xsd:element>
element Faktura/Fa/FaWiersz/P_7
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Nazwa (rodzaj) towaru lub usługi. Pole opcjonalne wyłącznie dla przypadku określonego w art 106j ust. 3 pkt 2 ustawy
(faktura korygująca)
source <xsd:element name="P_7" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Nazwa (rodzaj) towaru lub usługi. Pole opcjonalne wyłącznie dla
przypadku określonego w art 106j ust. 3 pkt 2 ustawy (faktura korygująca)</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/FaWiersz/Indeks
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy50
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 50
documentation
annotation
Pole przeznaczone do wpisania wewnętrznego kodu towaru lub usługi nadanego przez podatnika albo dodatkowego
opisu
source <xsd:element name="Indeks" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Pole przeznaczone do wpisania wewnętrznego kodu towaru lub usługi
nadanego przez podatnika albo dodatkowego opisu</xsd:documentation>

---

</xsd:annotation>
</xsd:element>
element Faktura/Fa/FaWiersz/GTIN
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy20
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 20
documentation
annotation
Globalny numer jednostki handlowej
source <xsd:element name="GTIN" type="tns:TZnakowy20" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Globalny numer jednostki handlowej</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/FaWiersz/PKWiU
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy50
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 50
documentation
annotation
Symbol Polskiej Klasyfikacji Wyrobów i Usług
source <xsd:element name="PKWiU" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Symbol Polskiej Klasyfikacji Wyrobów i Usług</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/FaWiersz/CN
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy50
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 50
documentation
annotation
Symbol Nomenklatury Scalonej
source <xsd:element name="CN" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Symbol Nomenklatury Scalonej</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/FaWiersz/PKOB
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy50
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 50
documentation
annotation
Symbol Polskiej Klasyfikacji Obiektów Budowlanych
source <xsd:element name="PKOB" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Symbol Polskiej Klasyfikacji Obiektów
Budowlanych</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/FaWiersz/P_8A
diagram

---

namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Miara dostarczonych towarów lub zakres wykonanych usług. Pole opcjonalne dla przypadku określonego w art. 106e ust.
5 pkt 3 ustawy
source <xsd:element name="P_8A" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Miara dostarczonych towarów lub zakres wykonanych usług. Pole
opcjonalne dla przypadku określonego w art. 106e ust. 5 pkt 3 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/FaWiersz/P_8B
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TIlosci
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
totalDigits 22
fractionDigits 6
pattern -?([1-9]\d{0,15}|0)(\.\d{1,6})?
documentation
annotation
Ilość (liczba) dostarczonych towarów lub zakres wykonanych usług. Pole opcjonalne dla przypadku określonego w art.
106e ust. 5 pkt 3 ustawy
source <xsd:element name="P_8B" type="tns:TIlosci" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Ilość (liczba) dostarczonych towarów lub zakres wykonanych usług. Pole
opcjonalne dla przypadku określonego w art. 106e ust. 5 pkt 3 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/FaWiersz/P_9A
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy2
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
totalDigits 22
fractionDigits 8
pattern -?([1-9]\d{0,13}|0)(\.\d{1,8})?
documentation
annotation
Cena jednostkowa towaru lub usługi bez kwoty podatku (cena jednostkowa netto). Pole opcjonalne dla przypadków
określonych w art. 106e ust. 2 i 3 oraz ust. 5 pkt 3 ustawy
source <xsd:element name="P_9A" type="tns:TKwotowy2" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Cena jednostkowa towaru lub usługi bez kwoty podatku (cena
jednostkowa netto). Pole opcjonalne dla przypadków określonych w art. 106e ust. 2 i 3 oraz ust. 5
pkt 3 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/FaWiersz/P_9B
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy2
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
totalDigits 22
fractionDigits 8
pattern -?([1-9]\d{0,13}|0)(\.\d{1,8})?
documentation
annotation
Cena wraz z kwotą podatku (cena jednostkowa brutto), w przypadku zastosowania art. 106e ust. 7 i 8 ustawy
source <xsd:element name="P_9B" type="tns:TKwotowy2" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Cena wraz z kwotą podatku (cena jednostkowa brutto), w przypadku
zastosowania art. 106e ust. 7 i 8 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/FaWiersz/P_10
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy2
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
totalDigits 22
fractionDigits 8
pattern -?([1-9]\d{0,13}|0)(\.\d{1,8})?
documentation
annotation
Kwoty wszelkich opustów lub obniżek cen, w tym w formie rabatu z tytułu wcześniejszej zapłaty, o ile nie zostały one
uwzględnione w cenie jednostkowej netto, a w przypadku stosowania art. 106e ust. 7 ustawy w cenie jednostkowej
brutto. Pole opcjonalne dla przypadków określonych w art. 106e ust. 2 i 3 oraz ust. 5 pkt 1 ustawy
source <xsd:element name="P_10" type="tns:TKwotowy2" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kwoty wszelkich opustów lub obniżek cen, w tym w formie rabatu z tytułu
wcześniejszej zapłaty, o ile nie zostały one uwzględnione w cenie jednostkowej netto, a w
przypadku stosowania art. 106e ust. 7 ustawy w cenie jednostkowej brutto. Pole opcjonalne dla
przypadków określonych w art. 106e ust. 2 i 3 oraz ust. 5 pkt 1 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/FaWiersz/P_11
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
totalDigits 18

---

fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Wartość dostarczonych towarów lub wykonanych usług, objętych transakcją, bez kwoty podatku (wartość sprzedaży
netto). Pole opcjonalne dla przypadków określonych w art. 106e ust. 2 i 3 oraz ust. 5 pkt 3 ustawy
source <xsd:element name="P_11" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Wartość dostarczonych towarów lub wykonanych usług, objętych
transakcją, bez kwoty podatku (wartość sprzedaży netto). Pole opcjonalne dla przypadków
określonych w art. 106e ust. 2 i 3 oraz ust. 5 pkt 3 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/FaWiersz/P_11A
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Wartość sprzedaży brutto, w przypadku zastosowania art. 106e ust. 7 i 8 ustawy
source <xsd:element name="P_11A" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Wartość sprzedaży brutto, w przypadku zastosowania art. 106e ust. 7 i 8
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/FaWiersz/P_11Vat
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
totalDigits 18

---

fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Kwota podatku w przypadku, o którym mowa w art. 106e ust. 10 ustawy
source <xsd:element name="P_11Vat" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kwota podatku w przypadku, o którym mowa w art. 106e ust. 10
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/FaWiersz/P_12
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TStawkaPodatku
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
enumeration 23
enumeration 22
enumeration 8
enumeration 7
enumeration 5
enumeration 4
enumeration 3
enumeration 0
enumeration zw documentation
zwolnione od podatku
enumeration oo documentation
odwrotne obciążenie
enumeration np documentation
niepodlegające opodatkowaniu- dostawy towarów oraz świadczenia usług poza terytorium
kraju
documentation
annotation
Stawka podatku. Pole opcjonalne dla przypadków określonych w art. 106e ust. 2, 3, ust. 4 pkt 3 i ust. 5 pkt 3 ustawy
source <xsd:element name="P_12" type="tns:TStawkaPodatku" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Stawka podatku. Pole opcjonalne dla przypadków określonych w art.
106e ust. 2, 3, ust. 4 pkt 3 i ust. 5 pkt 3 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/FaWiersz/P_12_XII
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TProcentowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minInclusive 0
maxInclusive 100
totalDigits 9
fractionDigits 6
whiteSpace collapse
documentation
annotation
Stawka podatku od wartości dodanej w przypadku, o którym mowa w dziale XII w rozdziale 6a ustawy
source <xsd:element name="P_12_XII" type="tns:TProcentowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Stawka podatku od wartości dodanej w przypadku, o którym mowa w
dziale XII w rozdziale 6a ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/FaWiersz/P_12_Zal_15
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
enumeration 1
documentation
annotation
Znacznik dla towaru lub usługi wymienionych w załączniku nr 15 do ustawy - wartość "1"
source <xsd:element name="P_12_Zal_15" type="etd:TWybor1" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Znacznik dla towaru lub usługi wymienionych w załączniku nr 15 do
ustawy - wartość "1"</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/FaWiersz/KwotaAkcyzy
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Kwota podatku akcyzowego zawarta w cenie towaru
source <xsd:element name="KwotaAkcyzy" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kwota podatku akcyzowego zawarta w cenie
towaru</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/FaWiersz/GTU
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TGTU
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
enumeration GTU_01 documentation
Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. a rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_02 documentation
Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. b rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_03 documentation
Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. c rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_04 documentation
Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. d rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_05 documentation
Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. e rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w

---

zakresie podatku od towarów i usług
enumeration GTU_06 documentation
Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. f rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_07 documentation
Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. g rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_08 documentation
Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. h rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_09 documentation
Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. i rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_10 documentation
Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. j rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_11 documentation
Świadczenie usług, o których mowa w § 10 ust. 3 pkt 2 lit. a rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_12 documentation
Świadczenie usług, o których mowa w § 10 ust. 3 pkt 2 lit. b rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_13 documentation
Świadczenie usług, o których mowa w § 10 ust. 3 pkt 2 lit. c rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
documentation
annotation
Oznaczenie dotyczące dostawy towarów i świadczenia usług
source <xsd:element name="GTU" type="tns:TGTU" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Oznaczenie dotyczące dostawy towarów i świadczenia
usług</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/FaWiersz/Procedura
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TOznaczenieProcedury
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
enumeration WSTO_EE documentation
Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 2a
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w
deklaracjach podatkowych i w ewidencji w zakresie podatku od towarów i
usług
enumeration IED documentation

---

Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 2b
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w
deklaracjach podatkowych i w ewidencji w zakresie podatku od towarów i
usług
enumeration TT_D documentation
Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 5
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w
deklaracjach podatkowych i w ewidencji w zakresie podatku od towarów i
usług
enumeration I_42 documentation
Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 8
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w
deklaracjach podatkowych i w ewidencji w zakresie podatku od towarów i
usług
enumeration I_63 documentation
Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 9
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w
deklaracjach podatkowych i w ewidencji w zakresie podatku od towarów i
usług
enumeration B_SPV documentation
Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 10
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w
deklaracjach podatkowych i w ewidencji w zakresie podatku od towarów i
usług
enumeration B_SPV_DOSTAWA documentation
Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 11
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w
deklaracjach podatkowych i w ewidencji w zakresie podatku od towarów i
usług
enumeration B_MPV_PROWIZJA documentation
Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 12
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w
deklaracjach podatkowych i w ewidencji w zakresie podatku od towarów i
usług
documentation
annotation
Oznaczenie dotyczące procedury
source <xsd:element name="Procedura" type="tns:TOznaczenieProcedury" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Oznaczenie dotyczące procedury</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/FaWiersz/KursWaluty
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TIlosci
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
totalDigits 22
fractionDigits 6
pattern -?([1-9]\d{0,15}|0)(\.\d{1,6})?
documentation
annotation
Kurs waluty stosowany do wyliczenia kwoty podatku w przypadkach, o których mowa w Dziale VI ustawy

---

source <xsd:element name="KursWaluty" type="tns:TIlosci" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kurs waluty stosowany do wyliczenia kwoty podatku w przypadkach, o
których mowa w Dziale VI ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/FaWiersz/StanPrzed
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
enumeration 1
documentation
annotation
Znacznik stanu przed korektą w przypadku faktury korygującej lub faktury korygującej fakturę wystawioną w związku z
art. 106f ust. 3 ustawy, w przypadku gdy korekta dotyczy danych wykazanych w pozycjach faktury i jest dokonywana w
sposób polegający na wykazaniu danych przed korektą i po korekcie jako osobnych wierszy z odrębną numeracją oraz w
przypadku potwierdzania braku zmiany wartości danej pozycji
source <xsd:element name="StanPrzed" type="etd:TWybor1" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Znacznik stanu przed korektą w przypadku faktury korygującej lub faktury
korygującej fakturę wystawioną w związku z art. 106f ust. 3 ustawy, w przypadku gdy korekta
dotyczy danych wykazanych w pozycjach faktury i jest dokonywana w sposób polegający na
wykazaniu danych przed korektą i po korekcie jako osobnych wierszy z odrębną numeracją oraz w
przypadku potwierdzania braku zmiany wartości danej pozycji</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/Rozliczenie
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
minOcc 0
properties
maxOcc 1
content complex
children tns:Obciazenia tns:SumaObciazen tns:Odliczenia tns:SumaOdliczen tns:DoZaplaty tns:DoRozliczenia
documentation
annotation
Dodatkowe rozliczenia na fakturze
source <xsd:element name="Rozliczenie" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Dodatkowe rozliczenia na fakturze</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="Obciazenia" minOccurs="0" maxOccurs="100">
<xsd:annotation>
<xsd:documentation>Obciążenia</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="Kwota" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota doliczona do kwoty wykazanej w polu
P_15</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Powod" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Powód obciążenia</xsd:documentation>
</xsd:annotation>

---

</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="SumaObciazen" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Suma obciążeń</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Odliczenia" minOccurs="0" maxOccurs="100">
<xsd:annotation>
<xsd:documentation>Odliczenia</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="Kwota" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota odliczona od kwoty wykazanej w polu
P_15</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Powod" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Powód odliczenia</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="SumaOdliczen" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Suma odliczeń</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:choice minOccurs="0">
<xsd:element name="DoZaplaty" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota należności do zapłaty równa polu P_15 powiększonemu o
Obciazenia i pomniejszonemu o Odliczenia</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DoRozliczenia" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota nadpłacona do rozliczenia/zwrotu</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
</xsd:sequence>
</xsd:complexType>
</xsd:element>

---

element Faktura/Fa/Rozliczenie/Obciazenia
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
minOcc 0
properties
maxOcc 100
content complex
children tns:Kwota tns:Powod
documentation
annotation
Obciążenia
source <xsd:element name="Obciazenia" minOccurs="0" maxOccurs="100">
<xsd:annotation>
<xsd:documentation>Obciążenia</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="Kwota" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota doliczona do kwoty wykazanej w polu
P_15</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Powod" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Powód obciążenia</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
element Faktura/Fa/Rozliczenie/Obciazenia/Kwota
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
content simple
properties
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Kwota doliczona do kwoty wykazanej w polu P_15

---

source <xsd:element name="Kwota" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota doliczona do kwoty wykazanej w polu P_15</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Rozliczenie/Obciazenia/Powod
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
content simple
properties
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Powód obciążenia
source <xsd:element name="Powod" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Powód obciążenia</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Rozliczenie/SumaObciazen
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Suma obciążeń
source <xsd:element name="SumaObciazen" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Suma obciążeń</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/Rozliczenie/Odliczenia
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
minOcc 0
properties
maxOcc 100
content complex
children tns:Kwota tns:Powod
documentation
annotation
Odliczenia
source <xsd:element name="Odliczenia" minOccurs="0" maxOccurs="100">
<xsd:annotation>
<xsd:documentation>Odliczenia</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="Kwota" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota odliczona od kwoty wykazanej w polu
P_15</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Powod" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Powód odliczenia</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
element Faktura/Fa/Rozliczenie/Odliczenia/Kwota
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
content simple
properties
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Kwota odliczona od kwoty wykazanej w polu P_15

---

source <xsd:element name="Kwota" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota odliczona od kwoty wykazanej w polu P_15</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Rozliczenie/Odliczenia/Powod
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
content simple
properties
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Powód odliczenia
source <xsd:element name="Powod" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Powód odliczenia</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Rozliczenie/SumaOdliczen
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Suma odliczeń
source <xsd:element name="SumaOdliczen" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Suma odliczeń</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/Rozliczenie/DoZaplaty
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
content simple
properties
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Kwota należności do zapłaty równa polu P_15 powiększonemu o Obciazenia i pomniejszonemu o Odliczenia
source <xsd:element name="DoZaplaty" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota należności do zapłaty równa polu P_15 powiększonemu o
Obciazenia i pomniejszonemu o Odliczenia</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Rozliczenie/DoRozliczenia
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
content simple
properties
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Kwota nadpłacona do rozliczenia/zwrotu
source <xsd:element name="DoRozliczenia" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota nadpłacona do rozliczenia/zwrotu</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/Platnosc
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
minOcc 0
properties
maxOcc 1
content complex
children tns:Zaplacono tns:DataZaplaty tns:ZnacznikZaplatyCzesciowej tns:ZaplataCzesciowa tns:TerminPlatnosci
tns:FormaPlatnosci tns:PlatnoscInna tns:OpisPlatnosci tns:RachunekBankowy tns:RachunekBankowyFaktora
tns:Skonto
documentation
annotation
Warunki płatności

---

source <xsd:element name="Platnosc" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Warunki płatności</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:choice minOccurs="0">
<xsd:sequence>
<xsd:element name="Zaplacono" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik informujący, że kwota należności wynikająca z faktury
została zapłacona: 1 - zapłacono</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DataZaplaty" type="tns:TData">
<xsd:annotation>
<xsd:documentation>Data zapłaty, jeśli do wystawienia faktury płatność została
dokonana</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:sequence>
<xsd:element name="ZnacznikZaplatyCzesciowej" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik informujący, że kwota należności wynikająca z faktury
została zapłacona w części: 1 - zapłacono w części</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="ZaplataCzesciowa" maxOccurs="100">
<xsd:annotation>
<xsd:documentation>Dane zapłat częściowych</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="KwotaZaplatyCzesciowej" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota zapłaty częściowej</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DataZaplatyCzesciowej" type="tns:TData">
<xsd:annotation>
<xsd:documentation>Data zapłaty częściowej, jeśli do wystawienia faktury
płatność częściowa została dokonana</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
</xsd:sequence>
</xsd:choice>
<xsd:element name="TerminPlatnosci" minOccurs="0" maxOccurs="100">
<xsd:complexType>
<xsd:sequence>
<xsd:element name="Termin" type="tns:TData">
<xsd:annotation>

---

<xsd:documentation>Termin płatności</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="TerminOpis" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Opis terminu płatności</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:choice minOccurs="0">
<xsd:element name="FormaPlatnosci" type="tns:TFormaPlatnosci">
<xsd:annotation>
<xsd:documentation>Forma płatności</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:sequence>
<xsd:element name="PlatnoscInna" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik innej formy płatności: 1 - inna forma
płatności</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="OpisPlatnosci" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Doprecyzowanie innej formy płatności</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:choice>
<xsd:element name="RachunekBankowy" type="tns:TRachunekBankowy" minOccurs="0"
maxOccurs="100">
<xsd:annotation>
<xsd:documentation>Numer rachunku</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="RachunekBankowyFaktora" type="tns:TRachunekBankowy"
minOccurs="0" maxOccurs="20">
<xsd:annotation>
<xsd:documentation>Rachunek faktora</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Skonto" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Skonto</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="WarunkiSkonta" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Warunki, które nabywca powinien spełnić aby skorzystać ze
skonta</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="WysokoscSkonta" type="tns:TZnakowy">

---

<xsd:annotation>
<xsd:documentation>Wysokość skonta</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
element Faktura/Fa/Platnosc/Zaplacono
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1
content simple
properties
Kind Value Annotation
facets
enumeration 1
documentation
annotation
Znacznik informujący, że kwota należności wynikająca z faktury została zapłacona: 1 - zapłacono
source <xsd:element name="Zaplacono" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik informujący, że kwota należności wynikająca z faktury została
zapłacona: 1 - zapłacono</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Platnosc/DataZaplaty
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TData
content simple
properties
Kind Value Annotation
facets
minInclusive 2016-07-01
maxInclusive 2050-01-01
pattern ((\d{4})-(\d{2})-(\d{2}))
documentation
annotation
Data zapłaty, jeśli do wystawienia faktury płatność została dokonana
source <xsd:element name="DataZaplaty" type="tns:TData">
<xsd:annotation>

---

<xsd:documentation>Data zapłaty, jeśli do wystawienia faktury płatność została
dokonana</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Platnosc/ZnacznikZaplatyCzesciowej
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1
content simple
properties
Kind Value Annotation
facets
enumeration 1
documentation
annotation
Znacznik informujący, że kwota należności wynikająca z faktury została zapłacona w części: 1 - zapłacono w części
source <xsd:element name="ZnacznikZaplatyCzesciowej" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik informujący, że kwota należności wynikająca z faktury została
zapłacona w części: 1 - zapłacono w części</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Platnosc/ZaplataCzesciowa
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
minOcc 1
properties
maxOcc 100
content complex
children tns:KwotaZaplatyCzesciowej tns:DataZaplatyCzesciowej
documentation
annotation
Dane zapłat częściowych
source <xsd:element name="ZaplataCzesciowa" maxOccurs="100">
<xsd:annotation>
<xsd:documentation>Dane zapłat częściowych</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="KwotaZaplatyCzesciowej" type="tns:TKwotowy">
<xsd:annotation>

---

<xsd:documentation>Kwota zapłaty częściowej</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DataZaplatyCzesciowej" type="tns:TData">
<xsd:annotation>
<xsd:documentation>Data zapłaty częściowej, jeśli do wystawienia faktury płatność
częściowa została dokonana</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
element Faktura/Fa/Platnosc/ZaplataCzesciowa/KwotaZaplatyCzesciowej
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
content simple
properties
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Kwota zapłaty częściowej
source <xsd:element name="KwotaZaplatyCzesciowej" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Kwota zapłaty częściowej</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Platnosc/ZaplataCzesciowa/DataZaplatyCzesciowej
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TData
content simple
properties
Kind Value Annotation
facets
minInclusive 2016-07-01
maxInclusive 2050-01-01
pattern ((\d{4})-(\d{2})-(\d{2}))
documentation
annotation
Data zapłaty częściowej, jeśli do wystawienia faktury płatność częściowa została dokonana

---

source <xsd:element name="DataZaplatyCzesciowej" type="tns:TData">
<xsd:annotation>
<xsd:documentation>Data zapłaty częściowej, jeśli do wystawienia faktury płatność częściowa
została dokonana</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Platnosc/TerminPlatnosci
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
minOcc 0
properties
maxOcc 100
content complex
children tns:Termin tns:TerminOpis
source <xsd:element name="TerminPlatnosci" minOccurs="0" maxOccurs="100">
<xsd:complexType>
<xsd:sequence>
<xsd:element name="Termin" type="tns:TData">
<xsd:annotation>
<xsd:documentation>Termin płatności</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="TerminOpis" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Opis terminu płatności</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
element Faktura/Fa/Platnosc/TerminPlatnosci/Termin
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TData
content simple
properties
Kind Value Annotation
facets
minInclusive 2016-07-01
maxInclusive 2050-01-01
pattern ((\d{4})-(\d{2})-(\d{2}))

---

documentation
annotation
Termin płatności
source <xsd:element name="Termin" type="tns:TData">
<xsd:annotation>
<xsd:documentation>Termin płatności</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Platnosc/TerminPlatnosci/TerminOpis
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Opis terminu płatności
source <xsd:element name="TerminOpis" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Opis terminu płatności</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Platnosc/FormaPlatnosci
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TFormaPlatnosci
content simple
properties
Kind Value Annotation
facets
enumeration 1 documentation
Gotówka
enumeration 2 documentation
Karta
enumeration 3 documentation
Bon
enumeration 4 documentation
Czek
enumeration 5 documentation
Kredyt
enumeration 6 documentation
Przelew
enumeration 7 documentation
Mobilna
documentation
annotation
Forma płatności

---

source <xsd:element name="FormaPlatnosci" type="tns:TFormaPlatnosci">
<xsd:annotation>
<xsd:documentation>Forma płatności</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Platnosc/PlatnoscInna
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1
content simple
properties
Kind Value Annotation
facets
enumeration 1
documentation
annotation
Znacznik innej formy płatności: 1 - inna forma płatności
source <xsd:element name="PlatnoscInna" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik innej formy płatności: 1 - inna forma
płatności</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Platnosc/OpisPlatnosci
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
content simple
properties
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Doprecyzowanie innej formy płatności
source <xsd:element name="OpisPlatnosci" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Doprecyzowanie innej formy płatności</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/Platnosc/RachunekBankowy
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TRachunekBankowy
minOcc 0
properties
maxOcc 100
content complex
children tns:NrRB tns:SWIFT tns:RachunekWlasnyBanku tns:NazwaBanku tns:OpisRachunku
documentation
annotation
Numer rachunku
source <xsd:element name="RachunekBankowy" type="tns:TRachunekBankowy" minOccurs="0"
maxOccurs="100">
<xsd:annotation>
<xsd:documentation>Numer rachunku</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/Platnosc/RachunekBankowyFaktora
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TRachunekBankowy
minOcc 0
properties
maxOcc 20
content complex
children tns:NrRB tns:SWIFT tns:RachunekWlasnyBanku tns:NazwaBanku tns:OpisRachunku
documentation
annotation
Rachunek faktora
source <xsd:element name="RachunekBankowyFaktora" type="tns:TRachunekBankowy" minOccurs="0"
maxOccurs="20">
<xsd:annotation>
<xsd:documentation>Rachunek faktora</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Platnosc/Skonto
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
minOcc 0
properties
maxOcc 1
content complex
children tns:WarunkiSkonta tns:WysokoscSkonta
documentation
annotation
Skonto

---

source <xsd:element name="Skonto" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Skonto</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="WarunkiSkonta" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Warunki, które nabywca powinien spełnić aby skorzystać ze
skonta</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="WysokoscSkonta" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Wysokość skonta</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
element Faktura/Fa/Platnosc/Skonto/WarunkiSkonta
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
content simple
properties
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Warunki, które nabywca powinien spełnić aby skorzystać ze skonta
source <xsd:element name="WarunkiSkonta" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Warunki, które nabywca powinien spełnić aby skorzystać ze
skonta</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Platnosc/Skonto/WysokoscSkonta
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy

---

content simple
properties
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Wysokość skonta
source <xsd:element name="WysokoscSkonta" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Wysokość skonta</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/WarunkiTransakcji
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
minOcc 0
properties
maxOcc 1
content complex
children tns:Umowy tns:Zamowienia tns:NrPartiiTowaru tns:WarunkiDostawy tns:KursUmowny tns:WalutaUmowna
tns:Transport tns:PodmiotPosredniczacy
documentation
annotation
Warunki transakcji, o ile występują

---

source <xsd:element name="WarunkiTransakcji" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Warunki transakcji, o ile występują</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="Umowy" minOccurs="0" maxOccurs="100">
<xsd:complexType>
<xsd:sequence minOccurs="0">
<xsd:element name="DataUmowy" type="tns:TData" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Data umowy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="NrUmowy" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer umowy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="Zamowienia" minOccurs="0" maxOccurs="100">
<xsd:complexType>
<xsd:sequence minOccurs="0">
<xsd:element name="DataZamowienia" type="tns:TData" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Data zamówienia</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="NrZamowienia" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer zamówienia</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="NrPartiiTowaru" type="tns:TZnakowy" minOccurs="0"
maxOccurs="1000">
<xsd:annotation>
<xsd:documentation>Numery partii towaru</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="WarunkiDostawy" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Warunki dostawy towarów - w przypadku istnienia pomiędzy
stronami transakcji, umowy określającej warunki dostawy tzw. Incoterms</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:sequence minOccurs="0">
<xsd:element name="KursUmowny" type="tns:TIlosci">
<xsd:annotation>
<xsd:documentation>Kurs umowny - w przypadkach, gdy na fakturze znajduje się
informacja o kursie, po którym zostały przeliczone kwoty wykazane na fakturze w złotych. Nie

---

dotyczy przypadków, o których mowa w Dziale VI ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="WalutaUmowna" type="tns:TKodWaluty">
<xsd:annotation>
<xsd:documentation>Waluta umowna - trzyliterowy kod waluty (ISO-4217) w
przypadkach, gdy na fakturze znajduje się informacja o kursie, po którym zostały przeliczone kwoty
wykazane na fakturze w złotych. Nie dotyczy przypadków, o których mowa w Dziale VI
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:element name="Transport" minOccurs="0" maxOccurs="20">
<xsd:complexType>
<xsd:sequence>
<xsd:choice>
<xsd:element name="RodzajTransportu" type="tns:TRodzajTransportu">
<xsd:annotation>
<xsd:documentation>Rodzaj zastosowanego transportu w przypadku dokonanej
dostawy towarów</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:sequence>
<xsd:element name="TransportInny" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik innego rodzaju transportu: 1 - inny rodzaj
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="OpisInnegoTransportu" type="tns:TZnakowy50">
<xsd:annotation>
<xsd:documentation>Opis innego rodzaju transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:choice>
<xsd:element name="Przewoznik" minOccurs="0">
<xsd:complexType>
<xsd:sequence>
<xsd:element name="DaneIdentyfikacyjne" type="tns:TPodmiot2">
<xsd:annotation>
<xsd:documentation>Dane identyfikacyjne
przewoźnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="AdresPrzewoznika" type="tns:TAdres">
<xsd:annotation>
<xsd:documentation>Adres przewoźnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="NrZleceniaTransportu" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer zlecenia transportu</xsd:documentation>

---

</xsd:annotation>
</xsd:element>
<xsd:sequence>
<xsd:choice>
<xsd:element name="OpisLadunku" type="tns:TLadunek">
<xsd:annotation>
<xsd:documentation>Rodzaj ładunku</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:sequence>
<xsd:element name="LadunekInny" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik innego ładunku: 1 - inny
ładunek</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="OpisInnegoLadunku" type="tns:TZnakowy50">
<xsd:annotation>
<xsd:documentation>Opis innego ładunku, w tym ładunek
mieszany</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:choice>
<xsd:element name="JednostkaOpakowania" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jednostka opakowania</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:sequence minOccurs="0">
<xsd:element name="DataGodzRozpTransportu" type="tns:TDataCzas"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Data i godzina rozpoczęcia
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DataGodzZakTransportu" type="tns:TDataCzas"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Data i godzina zakończenia
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="WysylkaZ" type="tns:TAdres" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres miejsca wysyłki</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="WysylkaPrzez" type="tns:TAdres" minOccurs="0"
maxOccurs="20">
<xsd:annotation>
<xsd:documentation>Adres pośredni wysyłki</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

<xsd:element name="WysylkaDo" type="tns:TAdres" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres miejsca docelowego, do którego został zlecony
transport</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="PodmiotPosredniczacy" type="etd:TWybor1" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Wartość "1" oznacza dostawę dokonaną przez podmiot, o którym
mowa w art. 22 ust. 2d ustawy. Pole dotyczy przypadku, w którym podmiot uczestniczy w transakcji
łańcuchowej innej niż procedura trójstronna uproszczona, o której mowa w art. 135 ust. 1 pkt 4
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
element Faktura/Fa/WarunkiTransakcji/Umowy
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
minOcc 0
properties
maxOcc 100
content complex
children tns:DataUmowy tns:NrUmowy
source <xsd:element name="Umowy" minOccurs="0" maxOccurs="100">
<xsd:complexType>
<xsd:sequence minOccurs="0">
<xsd:element name="DataUmowy" type="tns:TData" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Data umowy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="NrUmowy" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer umowy</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>

---

element Faktura/Fa/WarunkiTransakcji/Umowy/DataUmowy
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TData
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minInclusive 2016-07-01
maxInclusive 2050-01-01
pattern ((\d{4})-(\d{2})-(\d{2}))
documentation
annotation
Data umowy
source <xsd:element name="DataUmowy" type="tns:TData" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Data umowy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/WarunkiTransakcji/Umowy/NrUmowy
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Numer umowy
source <xsd:element name="NrUmowy" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer umowy</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/WarunkiTransakcji/Zamowienia
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
minOcc 0
properties
maxOcc 100
content complex
children tns:DataZamowienia tns:NrZamowienia
source <xsd:element name="Zamowienia" minOccurs="0" maxOccurs="100">
<xsd:complexType>
<xsd:sequence minOccurs="0">
<xsd:element name="DataZamowienia" type="tns:TData" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Data zamówienia</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="NrZamowienia" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer zamówienia</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
element Faktura/Fa/WarunkiTransakcji/Zamowienia/DataZamowienia
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TData
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minInclusive 2016-07-01
maxInclusive 2050-01-01
pattern ((\d{4})-(\d{2})-(\d{2}))
documentation
annotation
Data zamówienia
source <xsd:element name="DataZamowienia" type="tns:TData" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Data zamówienia</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/WarunkiTransakcji/Zamowienia/NrZamowienia
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Numer zamówienia
source <xsd:element name="NrZamowienia" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer zamówienia</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/WarunkiTransakcji/NrPartiiTowaru
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1000
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Numery partii towaru
source <xsd:element name="NrPartiiTowaru" type="tns:TZnakowy" minOccurs="0" maxOccurs="1000">
<xsd:annotation>
<xsd:documentation>Numery partii towaru</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/WarunkiTransakcji/WarunkiDostawy
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Warunki dostawy towarów - w przypadku istnienia pomiędzy stronami transakcji, umowy określającej warunki dostawy
tzw. Incoterms
source <xsd:element name="WarunkiDostawy" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Warunki dostawy towarów - w przypadku istnienia pomiędzy stronami
transakcji, umowy określającej warunki dostawy tzw. Incoterms</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/WarunkiTransakcji/KursUmowny
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TIlosci
content simple
properties
Kind Value Annotation
facets
totalDigits 22
fractionDigits 6
pattern -?([1-9]\d{0,15}|0)(\.\d{1,6})?
documentation
annotation
Kurs umowny - w przypadkach, gdy na fakturze znajduje się informacja o kursie, po którym zostały przeliczone kwoty
wykazane na fakturze w złotych. Nie dotyczy przypadków, o których mowa w Dziale VI ustawy
source <xsd:element name="KursUmowny" type="tns:TIlosci">
<xsd:annotation>
<xsd:documentation>Kurs umowny - w przypadkach, gdy na fakturze znajduje się informacja o
kursie, po którym zostały przeliczone kwoty wykazane na fakturze w złotych. Nie dotyczy
przypadków, o których mowa w Dziale VI ustawy</xsd:documentation>
</xsd:annotation>

---

</xsd:element>
element Faktura/Fa/WarunkiTransakcji/WalutaUmowna
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKodWaluty
content simple
properties
Kind Value Annotation
facets
enumeration AED documentation
DIRHAM ZEA
enumeration AFN documentation
AFGANI
enumeration ALL documentation
LEK
enumeration AMD documentation
DRAM
enumeration ANG documentation
GULDEN ANTYLI HOLENDERSKICH
enumeration AOA documentation
KWANZA
enumeration ARS documentation
PESO ARGENTYŃSKIE
enumeration AUD documentation
DOLAR AUSTRALIJSKI
enumeration AWG documentation
GULDEN ARUBAŃSKI
enumeration AZN documentation
MANAT AZERBEJDŻAŃSKI
enumeration BAM documentation
MARKA ZAMIENNA
enumeration BBD documentation
DOLAR BARBADOSKI
enumeration BDT documentation
TAKA
enumeration BGN documentation
LEW
enumeration BHD documentation
DINAR BAHRAJSKI
enumeration BIF documentation
FRANK BURUNDYJSKI
enumeration BMD documentation
DOLAR BERMUDZKI
enumeration BND documentation
DOLAR BRUNEJSKI
enumeration BOB documentation
BOLIWIANO
enumeration BOV documentation
BOLIWIANO MVDOL
enumeration BRL documentation
REAL
enumeration BSD documentation
DOLAR BAHAMSKI
enumeration BTN documentation

---

NGULTRUM
enumeration BWP documentation
PULA
enumeration BYN documentation
RUBEL BIAŁORUSKI
enumeration BZD documentation
DOLAR BELIZEŃSKI
enumeration CAD documentation
DOLAR KANADYJSKI
enumeration CDF documentation
FRANK KONGIJSKI
enumeration CHE documentation
FRANK SZWAJCARSKI VIR EURO
enumeration CHF documentation
FRANK SZWAJCARSKI
enumeration CHW documentation
FRANK SZWAJCARSKI VIR FRANK
enumeration CLF documentation
JEDNOSTKA ROZLICZENIOWA CHILIJSKA
enumeration CLP documentation
PESO CHILIJSKIE
enumeration CNY documentation
YUAN RENMINBI
enumeration COP documentation
PESO KOLUMBIJSKIE
enumeration COU documentation
UNIDAD DE VALOR REAL KOLUMBILSKIE
enumeration CRC documentation
COLON KOSTARYKAŃSKI
enumeration CUC documentation
PESO WYMIENIALNE
enumeration CUP documentation
PESO KUBAŃSKIE
enumeration CVE documentation
ESCUDO REPUBLIKI ZIELONEGO PRZYLĄDKA
enumeration CZK documentation
KORONA CZESKA
enumeration DJF documentation
FRANK DŻIBUTI
enumeration DKK documentation
KORONA DUŃSKA
enumeration DOP documentation
PESO DOMINIKAŃSKIE
enumeration DZD documentation
DINAR ALGIERSKI
enumeration EGP documentation
FUNT EGIPSKI
enumeration ERN documentation
NAKFA
enumeration ETB documentation
BIRR
enumeration EUR documentation
EURO
enumeration FJD documentation
DOLAR FIDŻI
enumeration FKP documentation
FUNT FALKLANDZKI
enumeration GBP documentation
FUNT SZTERLING
enumeration GEL documentation
LARI
enumeration GGP documentation
FUNT GUERNSEY
enumeration GHS documentation
GHANA CEDI
enumeration GIP documentation
FUNT GIBRALTARSKI
enumeration GMD documentation
DALASI
enumeration GNF documentation

---

FRANK GWINEJSKI
enumeration GTQ documentation
QUETZAL
enumeration GYD documentation
DOLAR GUJAŃSKI
enumeration HKD documentation
DOLAR HONGKONGU
enumeration HNL documentation
LEMPIRA
enumeration HRK documentation
KUNA
enumeration HTG documentation
GOURDE
enumeration HUF documentation
FORINT
enumeration IDR documentation
RUPIA INDONEZYJSKA
enumeration ILS documentation
SZEKEL
enumeration IMP documentation
FUNT MANX
enumeration INR documentation
RUPIA INDYJSKA
enumeration IQD documentation
DINAR IRACKI
enumeration IRR documentation
RIAL IRAŃSKI
enumeration ISK documentation
KORONA ISLANDZKA
enumeration JEP documentation
FUNT JERSEY
enumeration JMD documentation
DOLAR JAMAJSKI
enumeration JOD documentation
DINAR JORDAŃSKI
enumeration JPY documentation
JEN
enumeration KES documentation
SZYLING KENIJSKI
enumeration KGS documentation
SOM
enumeration KHR documentation
RIEL
enumeration KMF documentation
FRANK KOMORÓW
enumeration KPW documentation
WON PÓŁNOCNO­KOREAŃSKI
enumeration KRW documentation
WON POŁUDNIOWO­KOREAŃSKI
enumeration KWD documentation
DINAR KUWEJCKI
enumeration KYD documentation
DOLAR KAJMAŃSKI
enumeration KZT documentation
TENGE
enumeration LAK documentation
KIP
enumeration LBP documentation
FUNT LIBAŃSKI
enumeration LKR documentation
RUPIA LANKIJSKA
enumeration LRD documentation
DOLAR LIBERYJSKI
enumeration LSL documentation
LOTI
enumeration LYD documentation
DINAR LIBIJSKI
enumeration MAD documentation
DIRHAM MAROKAŃSKI
enumeration MDL documentation

---

LEJ MOŁDAWII
enumeration MGA documentation
ARIARY
enumeration MKD documentation
DENAR
enumeration MMK documentation
KYAT
enumeration MNT documentation
TUGRIK
enumeration MOP documentation
PATACA
enumeration MRU documentation
OUGUIYA
enumeration MUR documentation
RUPIA MAURITIUSU
enumeration MVR documentation
RUPIA MALEDIWSKA
enumeration MWK documentation
KWACHA MALAWIJSKA
enumeration MXN documentation
PESO MEKSYKAŃSKIE
enumeration MXV documentation
UNIDAD DE INVERSION (UDI) MEKSYKAŃSKIE
enumeration MYR documentation
RINGGIT
enumeration MZN documentation
METICAL
enumeration NAD documentation
DOLAR NAMIBIJSKI
enumeration NGN documentation
NAIRA
enumeration NIO documentation
CORDOBA ORO
enumeration NOK documentation
KORONA NORWESKA
enumeration NPR documentation
RUPIA NEPALSKA
enumeration NZD documentation
DOLAR NOWOZELANDZKI
enumeration OMR documentation
RIAL OMAŃSKI
enumeration PAB documentation
BALBOA
enumeration PEN documentation
SOL
enumeration PGK documentation
KINA
enumeration PHP documentation
PESO FILIPIŃSKIE
enumeration PKR documentation
RUPIA PAKISTAŃSKA
enumeration PLN documentation
ZŁOTY
enumeration PYG documentation
GUARANI
enumeration QAR documentation
RIAL KATARSKI
enumeration RON documentation
LEJ RUMUŃSKI
enumeration RSD documentation
DINAR SERBSKI
enumeration RUB documentation
RUBEL ROSYJSKI
enumeration RWF documentation
FRANK RWANDYJSKI
enumeration SAR documentation
RIAL SAUDYJSKI
enumeration SBD documentation
DOLAR WYSP SALOMONA
enumeration SCR documentation

---

RUPIA SESZELSKA
enumeration SDG documentation
FUNT SUDAŃSKI
enumeration SEK documentation
KORONA SZWEDZKA
enumeration SGD documentation
DOLAR SINGAPURSKI
enumeration SHP documentation
FUNT ŚWIĘTEJ HELENY (ŚWIĘTA HELENA I WYSPA WNIEBOWSTĄPIENIA)
enumeration SLL documentation
LEONE
enumeration SOS documentation
SZYLING SOMALIJSKI
enumeration SRD documentation
DOLAR SURINAMSKI
enumeration SSP documentation
FUNT POŁUDNIOWOSUDAŃSKI
enumeration STN documentation
DOBRA
enumeration SVC documentation
COLON SALWADORSKI (SV1)
enumeration SYP documentation
FUNT SYRYJSKI
enumeration SZL documentation
LILANGENI
enumeration THB documentation
BAT
enumeration TJS documentation
SOMONI
enumeration TMT documentation
MANAT TURKMEŃSKI
enumeration TND documentation
DINAR TUNEZYJSKI
enumeration TOP documentation
PAANGA
enumeration TRY documentation
LIRA TURECKA
enumeration TTD documentation
DOLAR TRYNIDADU I TOBAGO
enumeration TWD documentation
NOWY DOLAR TAJWAŃSKI
enumeration TZS documentation
SZYLING TANZAŃSKI
enumeration UAH documentation
HRYWNA
enumeration UGX documentation
SZYLING UGANDYJSKI
enumeration USD documentation
DOLAR AMERYKAŃSKI
enumeration USN documentation
DOLAR AMERYKAŃSKI (NEXT DAY)
enumeration UYI documentation
PESO EN UNIDADES INDEXADAS URUGWAJSKIE
enumeration UYU documentation
PESO URUGWAJSKIE
enumeration UYW documentation
PESO EN UNIDADES INDEXADAS URUGWAJSKIE
enumeration UZS documentation
SUM
enumeration VES documentation
BOLIWAR SOBERANO
enumeration VND documentation
DONG
enumeration VUV documentation
VATU
enumeration WST documentation
TALA
enumeration XAF documentation
FRANK CFA (BEAC)
enumeration XAG documentation

---

SREBRO
enumeration XAU documentation
ZŁOTO
enumeration XBA documentation
BOND MARKETS UNIT EUROPEAN COMPOSITE UNIT (EURCO)
enumeration XBB documentation
BOND MARKETS UNIT EUROPEAN MONETARY UNIT (E.M.U.-6)
enumeration XBC documentation
BOND MARKETS UNIT EUROPEAN UNIT OF ACCOUNT 9 (E.U.A.-9)
enumeration XBD documentation
BOND MARKETS UNIT EUROPEAN UNIT OF ACCOUNT 17 (E.U.A.-17)
enumeration XCD documentation
DOLAR WSCHODNIO­KARAIBSKI
enumeration XDR documentation
SDR MIĘDZYNARODOWY FUNDUSZ WALUTOWY
enumeration XOF documentation
FRANK CFA (BCEAO)
enumeration XPD documentation
PALLAD
enumeration XPF documentation
FRANK CFP
enumeration XPT documentation
PLATYNA
enumeration XSU documentation
SUCRE SISTEMA UNITARIO DE COMPENSACION REGIONAL DE PAGOS SUCRE
enumeration XUA documentation
ADB UNIT OF ACCOUNT MEMBER COUNTRIES OF THE AFRICAN DEVELOPMENT
BANK GROUP
enumeration XXX documentation
BRAK WALUTY
enumeration YER documentation
RIAL JEMEŃSKI
enumeration ZAR documentation
RAND
enumeration ZMW documentation
KWACHA ZAMBIJSKA
enumeration ZWL documentation
DOLAR ZIMBABWE
documentation
annotation
Waluta umowna - trzyliterowy kod waluty (ISO-4217) w przypadkach, gdy na fakturze znajduje się informacja o kursie, po
którym zostały przeliczone kwoty wykazane na fakturze w złotych. Nie dotyczy przypadków, o których mowa w Dziale VI
ustawy
source <xsd:element name="WalutaUmowna" type="tns:TKodWaluty">
<xsd:annotation>
<xsd:documentation>Waluta umowna - trzyliterowy kod waluty (ISO-4217) w przypadkach, gdy
na fakturze znajduje się informacja o kursie, po którym zostały przeliczone kwoty wykazane na
fakturze w złotych. Nie dotyczy przypadków, o których mowa w Dziale VI
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/WarunkiTransakcji/Transport
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
minOcc 0
properties
maxOcc 20
content complex

---

children tns:RodzajTransportu tns:TransportInny tns:OpisInnegoTransportu tns:Przewoznik tns:NrZleceniaTransportu
tns:OpisLadunku tns:LadunekInny tns:OpisInnegoLadunku tns:JednostkaOpakowania
tns:DataGodzRozpTransportu tns:DataGodzZakTransportu tns:WysylkaZ tns:WysylkaPrzez tns:WysylkaDo
source <xsd:element name="Transport" minOccurs="0" maxOccurs="20">
<xsd:complexType>
<xsd:sequence>
<xsd:choice>
<xsd:element name="RodzajTransportu" type="tns:TRodzajTransportu">
<xsd:annotation>
<xsd:documentation>Rodzaj zastosowanego transportu w przypadku dokonanej
dostawy towarów</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:sequence>
<xsd:element name="TransportInny" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik innego rodzaju transportu: 1 - inny rodzaj
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="OpisInnegoTransportu" type="tns:TZnakowy50">
<xsd:annotation>
<xsd:documentation>Opis innego rodzaju transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:choice>
<xsd:element name="Przewoznik" minOccurs="0">
<xsd:complexType>
<xsd:sequence>
<xsd:element name="DaneIdentyfikacyjne" type="tns:TPodmiot2">
<xsd:annotation>
<xsd:documentation>Dane identyfikacyjne przewoźnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="AdresPrzewoznika" type="tns:TAdres">
<xsd:annotation>
<xsd:documentation>Adres przewoźnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="NrZleceniaTransportu" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer zlecenia transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:sequence>
<xsd:choice>
<xsd:element name="OpisLadunku" type="tns:TLadunek">
<xsd:annotation>
<xsd:documentation>Rodzaj ładunku</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

<xsd:sequence>
<xsd:element name="LadunekInny" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik innego ładunku: 1 - inny
ładunek</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="OpisInnegoLadunku" type="tns:TZnakowy50">
<xsd:annotation>
<xsd:documentation>Opis innego ładunku, w tym ładunek
mieszany</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:choice>
<xsd:element name="JednostkaOpakowania" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jednostka opakowania</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:sequence minOccurs="0">
<xsd:element name="DataGodzRozpTransportu" type="tns:TDataCzas" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Data i godzina rozpoczęcia transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="DataGodzZakTransportu" type="tns:TDataCzas" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Data i godzina zakończenia transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="WysylkaZ" type="tns:TAdres" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres miejsca wysyłki</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="WysylkaPrzez" type="tns:TAdres" minOccurs="0" maxOccurs="20">
<xsd:annotation>
<xsd:documentation>Adres pośredni wysyłki</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="WysylkaDo" type="tns:TAdres" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres miejsca docelowego, do którego został zlecony
transport</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:sequence>
</xsd:complexType>
</xsd:element>

---

element Faktura/Fa/WarunkiTransakcji/Transport/RodzajTransportu
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TRodzajTransportu
content simple
properties
Kind Value Annotation
facets
enumeration 1 documentation
Transport morski
enumeration 2 documentation
Transport kolejowy
enumeration 3 documentation
Transport drogowy
enumeration 4 documentation
Transport lotniczy
enumeration 5 documentation
Przesyłka pocztowa
enumeration 7 documentation
Stałe instalacje przesyłowe
enumeration 8 documentation
Żegluga śródlądowa
documentation
annotation
Rodzaj zastosowanego transportu w przypadku dokonanej dostawy towarów
source <xsd:element name="RodzajTransportu" type="tns:TRodzajTransportu">
<xsd:annotation>
<xsd:documentation>Rodzaj zastosowanego transportu w przypadku dokonanej dostawy
towarów</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/WarunkiTransakcji/Transport/TransportInny
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1
content simple
properties
Kind Value Annotation
facets
enumeration 1
documentation
annotation
Znacznik innego rodzaju transportu: 1 - inny rodzaj transportu
source <xsd:element name="TransportInny" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik innego rodzaju transportu: 1 - inny rodzaj
transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/WarunkiTransakcji/Transport/OpisInnegoTransportu
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy50
content simple
properties
Kind Value Annotation
facets
minLength 1
maxLength 50
documentation
annotation
Opis innego rodzaju transportu
source <xsd:element name="OpisInnegoTransportu" type="tns:TZnakowy50">
<xsd:annotation>
<xsd:documentation>Opis innego rodzaju transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/WarunkiTransakcji/Transport/Przewoznik
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
minOcc 0
properties
maxOcc 1
content complex
children tns:DaneIdentyfikacyjne tns:AdresPrzewoznika
source <xsd:element name="Przewoznik" minOccurs="0">
<xsd:complexType>
<xsd:sequence>
<xsd:element name="DaneIdentyfikacyjne" type="tns:TPodmiot2">
<xsd:annotation>
<xsd:documentation>Dane identyfikacyjne przewoźnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="AdresPrzewoznika" type="tns:TAdres">
<xsd:annotation>
<xsd:documentation>Adres przewoźnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>

---

element Faktura/Fa/WarunkiTransakcji/Transport/Przewoznik/DaneIdentyfikacyjne
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TPodmiot2
content complex
properties
children tns:NIP tns:KodUE tns:NrVatUE tns:KodKraju tns:NrID tns:BrakID tns:Nazwa
documentation
annotation
Dane identyfikacyjne przewoźnika
source <xsd:element name="DaneIdentyfikacyjne" type="tns:TPodmiot2">
<xsd:annotation>
<xsd:documentation>Dane identyfikacyjne przewoźnika</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/WarunkiTransakcji/Transport/Przewoznik/AdresPrzewoznika
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TAdres
content complex
properties
children tns:KodKraju tns:AdresL1 tns:AdresL2 tns:GLN
documentation
annotation
Adres przewoźnika
source <xsd:element name="AdresPrzewoznika" type="tns:TAdres">
<xsd:annotation>
<xsd:documentation>Adres przewoźnika</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/WarunkiTransakcji/Transport/NrZleceniaTransportu
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Numer zlecenia transportu
source <xsd:element name="NrZleceniaTransportu" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer zlecenia transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/WarunkiTransakcji/Transport/OpisLadunku
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TLadunek
content simple
properties
Kind Value Annotation
facets
enumeration 1 documentation
Bańka
enumeration 2 documentation
Beczka
enumeration 3 documentation
Butla
enumeration 4 documentation
Karton
enumeration 5 documentation
Kanister
enumeration 6 documentation
Klatka
enumeration 7 documentation
Kontener
enumeration 8 documentation
Kosz/koszyk
enumeration 9 documentation
Łubianka
enumeration 10 documentation
Opakowanie zbiorcze
enumeration 11 documentation
Paczka
enumeration 12 documentation
Pakiet
enumeration 13 documentation
Paleta
enumeration 14 documentation
Pojemnik
enumeration 15 documentation
Pojemnik do ładunków masowych stałych
enumeration 16 documentation
Pojemnik do ładunków masowych w postaci płynnej
enumeration 17 documentation
Pudełko
enumeration 18 documentation
Puszka
enumeration 19 documentation
Skrzynia
enumeration 20 documentation
Worek
documentation
annotation
Rodzaj ładunku
source <xsd:element name="OpisLadunku" type="tns:TLadunek">
<xsd:annotation>
<xsd:documentation>Rodzaj ładunku</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/WarunkiTransakcji/Transport/LadunekInny
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1
content simple
properties
Kind Value Annotation
facets
enumeration 1
documentation
annotation
Znacznik innego ładunku: 1 - inny ładunek
source <xsd:element name="LadunekInny" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Znacznik innego ładunku: 1 - inny ładunek</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/WarunkiTransakcji/Transport/OpisInnegoLadunku
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy50
content simple
properties
Kind Value Annotation
facets
minLength 1
maxLength 50
documentation
annotation
Opis innego ładunku, w tym ładunek mieszany
source <xsd:element name="OpisInnegoLadunku" type="tns:TZnakowy50">
<xsd:annotation>
<xsd:documentation>Opis innego ładunku, w tym ładunek mieszany</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/WarunkiTransakcji/Transport/JednostkaOpakowania
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple

---

Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Jednostka opakowania
source <xsd:element name="JednostkaOpakowania" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Jednostka opakowania</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/WarunkiTransakcji/Transport/DataGodzRozpTransportu
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TDataCzas
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minInclusive 2021-10-01T00:00:00Z
maxInclusive 2050-01-01T23:59:59Z
whiteSpace collapse
documentation
annotation
Data i godzina rozpoczęcia transportu
source <xsd:element name="DataGodzRozpTransportu" type="tns:TDataCzas" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Data i godzina rozpoczęcia transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/WarunkiTransakcji/Transport/DataGodzZakTransportu
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TDataCzas
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minInclusive 2021-10-01T00:00:00Z
maxInclusive 2050-01-01T23:59:59Z
whiteSpace collapse
documentation
annotation
Data i godzina zakończenia transportu
source <xsd:element name="DataGodzZakTransportu" type="tns:TDataCzas" minOccurs="0">
<xsd:annotation>

---

<xsd:documentation>Data i godzina zakończenia transportu</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/WarunkiTransakcji/Transport/WysylkaZ
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TAdres
minOcc 0
properties
maxOcc 1
content complex
children tns:KodKraju tns:AdresL1 tns:AdresL2 tns:GLN
documentation
annotation
Adres miejsca wysyłki
source <xsd:element name="WysylkaZ" type="tns:TAdres" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres miejsca wysyłki</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/WarunkiTransakcji/Transport/WysylkaPrzez
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TAdres
minOcc 0
properties
maxOcc 20
content complex
children tns:KodKraju tns:AdresL1 tns:AdresL2 tns:GLN
documentation
annotation
Adres pośredni wysyłki
source <xsd:element name="WysylkaPrzez" type="tns:TAdres" minOccurs="0" maxOccurs="20">
<xsd:annotation>
<xsd:documentation>Adres pośredni wysyłki</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/WarunkiTransakcji/Transport/WysylkaDo
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TAdres

---

minOcc 0
properties
maxOcc 1
content complex
children tns:KodKraju tns:AdresL1 tns:AdresL2 tns:GLN
documentation
annotation
Adres miejsca docelowego, do którego został zlecony transport
source <xsd:element name="WysylkaDo" type="tns:TAdres" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres miejsca docelowego, do którego został zlecony
transport</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/WarunkiTransakcji/PodmiotPosredniczacy
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
enumeration 1
documentation
annotation
Wartość "1" oznacza dostawę dokonaną przez podmiot, o którym mowa w art. 22 ust. 2d ustawy. Pole dotyczy
przypadku, w którym podmiot uczestniczy w transakcji łańcuchowej innej niż procedura trójstronna uproszczona, o której
mowa w art. 135 ust. 1 pkt 4 ustawy
source <xsd:element name="PodmiotPosredniczacy" type="etd:TWybor1" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Wartość "1" oznacza dostawę dokonaną przez podmiot, o którym mowa
w art. 22 ust. 2d ustawy. Pole dotyczy przypadku, w którym podmiot uczestniczy w transakcji
łańcuchowej innej niż procedura trójstronna uproszczona, o której mowa w art. 135 ust. 1 pkt 4
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/Zamowienie
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
minOcc 0
properties
maxOcc 1
content complex
children tns:WartoscZamowienia tns:ZamowienieWiersz
documentation
annotation
Zamówienie lub umowa, o których mowa w art. 106f ust. 1 pkt 4 ustawy (dla faktur zaliczkowych) w walucie, w której
wystawiono fakturę zaliczkową. W przypadku faktury korygującej fakturę zaliczkową należy wykazać różnice wynikające
z korekty poszczególnych pozycji zamówienia lub umowy lub dane pozycji korygowanych w stanie przed korektą i po
korekcie jako osobne wiersze, jeśli korekta dotyczy wartości zamówienia lub umowy. W przypadku faktur korygujących
faktury zaliczkowe, jeśli korekta nie dotyczy wartości zamówienia lub umowy i jednocześnie zmienia wysokość podstawy
opodatkowania lub podatku, należy wprowadzić zapis wg stanu przed korektą i zapis w stanie po korekcie w celu
potwierdzenia braku zmiany wartości danej pozycji
source <xsd:element name="Zamowienie" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Zamówienie lub umowa, o których mowa w art. 106f ust. 1 pkt 4 ustawy
(dla faktur zaliczkowych) w walucie, w której wystawiono fakturę zaliczkową. W przypadku faktury
korygującej fakturę zaliczkową należy wykazać różnice wynikające z korekty poszczególnych
pozycji zamówienia lub umowy lub dane pozycji korygowanych w stanie przed korektą i po korekcie
jako osobne wiersze, jeśli korekta dotyczy wartości zamówienia lub umowy. W przypadku faktur
korygujących faktury zaliczkowe, jeśli korekta nie dotyczy wartości zamówienia lub umowy i
jednocześnie zmienia wysokość podstawy opodatkowania lub podatku, należy wprowadzić zapis
wg stanu przed korektą i zapis w stanie po korekcie w celu potwierdzenia braku zmiany wartości
danej pozycji</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="WartoscZamowienia" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Wartość zamówienia lub umowy z uwzględnieniem kwoty
podatku</xsd:documentation>

---

</xsd:annotation>
</xsd:element>
<xsd:element name="ZamowienieWiersz" maxOccurs="10000">
<xsd:annotation>
<xsd:documentation>Szczegółowe pozycje zamówienia lub umowy w walucie, w której
wystawiono fakturę zaliczkową</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="NrWierszaZam" type="tns:TNaturalny">
<xsd:annotation>
<xsd:documentation>Kolejny numer wiersza zamówienia lub
umowy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="UU_IDZ" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Uniwersalny unikalny numer wiersza zamówienia lub
umowy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_7Z" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Nazwa (rodzaj) towaru lub usługi</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="IndeksZ" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Pole przeznaczone do wpisania wewnętrznego kodu towaru
lub usługi nadanego przez podatnika albo dodatkowego opisu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="GTINZ" type="tns:TZnakowy20" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Globalny numer jednostki handlowej</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="PKWiUZ" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Symbol Polskiej Klasyfikacji Wyrobów i
Usług</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="CNZ" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Symbol Nomenklatury Scalonej</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="PKOBZ" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Symbol Polskiej Klasyfikacji Obiektów
Budowlanych</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_8AZ" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>

---

<xsd:documentation>Miara zamówionego towaru lub zakres
usługi</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_8BZ" type="tns:TIlosci" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Ilość zamówionego towaru lub zakres
usługi</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_9AZ" type="tns:TKwotowy2" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Cena jednostkowa netto</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_11NettoZ" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Wartość zamówionego towaru lub usługi bez kwoty
podatku</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_11VatZ" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kwota podatku od zamówionego towaru lub
usługi</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_12Z" type="tns:TStawkaPodatku" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Stawka podatku</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_12Z_XII" type="tns:TProcentowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Stawka podatku od wartości dodanej w przypadku, o którym
mowa w dziale XII w rozdziale 6a ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_12Z_Zal_15" type="etd:TWybor1" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Znacznik dla towaru lub usługi wymienionych w załączniku nr
15 do ustawy - wartość "1"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="GTUZ" type="tns:TGTU" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Oznaczenie dotyczące dostawy towarów i świadczenia
usług</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="ProceduraZ" type="tns:TOznaczenieProceduryZ"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Oznaczenia dotyczące procedur</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

<xsd:element name="KwotaAkcyzyZ" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kwota podatku akcyzowego zawarta w cenie
towaru</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="StanPrzedZ" type="etd:TWybor1" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Znacznik stanu przed korektą w przypadku faktury
korygującej fakturę dokumentującą otrzymanie zapłaty lub jej części przed dokonaniem czynności
oraz fakturę wystawioną w związku z art. 106f ust. 4 ustawy, w przypadku gdy korekta dotyczy
danych wykazanych w pozycjach zamówienia i jest dokonywana w sposób polegający na
wykazaniu danych przed korektą i po korekcie jako osobnych wierszy z odrębną numeracją oraz w
przypadku potwierdzania braku zmiany wartości danej pozycji</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
element Faktura/Fa/Zamowienie/WartoscZamowienia
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
content simple
properties
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Wartość zamówienia lub umowy z uwzględnieniem kwoty podatku
source <xsd:element name="WartoscZamowienia" type="tns:TKwotowy">
<xsd:annotation>
<xsd:documentation>Wartość zamówienia lub umowy z uwzględnieniem kwoty
podatku</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/Zamowienie/ZamowienieWiersz
diagram

---

namespace http://crd.gov.pl/wzor/2023/06/29/12648/
minOcc 1
properties
maxOcc 10000
content complex
children tns:NrWierszaZam tns:UU_IDZ tns:P_7Z tns:IndeksZ tns:GTINZ tns:PKWiUZ tns:CNZ tns:PKOBZ tns:P_8AZ
tns:P_8BZ tns:P_9AZ tns:P_11NettoZ tns:P_11VatZ tns:P_12Z tns:P_12Z_XII tns:P_12Z_Zal_15 tns:GTUZ
tns:ProceduraZ tns:KwotaAkcyzyZ tns:StanPrzedZ
documentation
annotation
Szczegółowe pozycje zamówienia lub umowy w walucie, w której wystawiono fakturę zaliczkową
source <xsd:element name="ZamowienieWiersz" maxOccurs="10000">
<xsd:annotation>
<xsd:documentation>Szczegółowe pozycje zamówienia lub umowy w walucie, w której
wystawiono fakturę zaliczkową</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence>
<xsd:element name="NrWierszaZam" type="tns:TNaturalny">
<xsd:annotation>
<xsd:documentation>Kolejny numer wiersza zamówienia lub
umowy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="UU_IDZ" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Uniwersalny unikalny numer wiersza zamówienia lub
umowy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_7Z" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Nazwa (rodzaj) towaru lub usługi</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="IndeksZ" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Pole przeznaczone do wpisania wewnętrznego kodu towaru lub
usługi nadanego przez podatnika albo dodatkowego opisu</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="GTINZ" type="tns:TZnakowy20" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Globalny numer jednostki handlowej</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="PKWiUZ" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Symbol Polskiej Klasyfikacji Wyrobów i Usług</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="CNZ" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Symbol Nomenklatury Scalonej</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="PKOBZ" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>

---

<xsd:documentation>Symbol Polskiej Klasyfikacji Obiektów
Budowlanych</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_8AZ" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Miara zamówionego towaru lub zakres usługi</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_8BZ" type="tns:TIlosci" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Ilość zamówionego towaru lub zakres usługi</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_9AZ" type="tns:TKwotowy2" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Cena jednostkowa netto</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_11NettoZ" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Wartość zamówionego towaru lub usługi bez kwoty
podatku</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_11VatZ" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kwota podatku od zamówionego towaru lub
usługi</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_12Z" type="tns:TStawkaPodatku" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Stawka podatku</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_12Z_XII" type="tns:TProcentowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Stawka podatku od wartości dodanej w przypadku, o którym mowa
w dziale XII w rozdziale 6a ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="P_12Z_Zal_15" type="etd:TWybor1" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Znacznik dla towaru lub usługi wymienionych w załączniku nr 15 do
ustawy - wartość "1"</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="GTUZ" type="tns:TGTU" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Oznaczenie dotyczące dostawy towarów i świadczenia
usług</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="ProceduraZ" type="tns:TOznaczenieProceduryZ" minOccurs="0">
<xsd:annotation>

---

<xsd:documentation>Oznaczenia dotyczące procedur</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="KwotaAkcyzyZ" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kwota podatku akcyzowego zawarta w cenie
towaru</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="StanPrzedZ" type="etd:TWybor1" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Znacznik stanu przed korektą w przypadku faktury korygującej
fakturę dokumentującą otrzymanie zapłaty lub jej części przed dokonaniem czynności oraz fakturę
wystawioną w związku z art. 106f ust. 4 ustawy, w przypadku gdy korekta dotyczy danych
wykazanych w pozycjach zamówienia i jest dokonywana w sposób polegający na wykazaniu
danych przed korektą i po korekcie jako osobnych wierszy z odrębną numeracją oraz w przypadku
potwierdzania braku zmiany wartości danej pozycji</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
element Faktura/Fa/Zamowienie/ZamowienieWiersz/NrWierszaZam
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TNaturalny
content simple
properties
Kind Value Annotation
facets
minExclusive 0
totalDigits 14
whiteSpace collapse
documentation
annotation
Kolejny numer wiersza zamówienia lub umowy
source <xsd:element name="NrWierszaZam" type="tns:TNaturalny">
<xsd:annotation>
<xsd:documentation>Kolejny numer wiersza zamówienia lub umowy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Zamowienie/ZamowienieWiersz/UU_IDZ
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/

---

type tns:TZnakowy50
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 50
documentation
annotation
Uniwersalny unikalny numer wiersza zamówienia lub umowy
source <xsd:element name="UU_IDZ" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Uniwersalny unikalny numer wiersza zamówienia lub
umowy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Zamowienie/ZamowienieWiersz/P_7Z
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Nazwa (rodzaj) towaru lub usługi
source <xsd:element name="P_7Z" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Nazwa (rodzaj) towaru lub usługi</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Zamowienie/ZamowienieWiersz/IndeksZ
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy50
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1

---

maxLength 50
documentation
annotation
Pole przeznaczone do wpisania wewnętrznego kodu towaru lub usługi nadanego przez podatnika albo dodatkowego
opisu
source <xsd:element name="IndeksZ" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Pole przeznaczone do wpisania wewnętrznego kodu towaru lub usługi
nadanego przez podatnika albo dodatkowego opisu</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Zamowienie/ZamowienieWiersz/GTINZ
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy20
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 20
documentation
annotation
Globalny numer jednostki handlowej
source <xsd:element name="GTINZ" type="tns:TZnakowy20" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Globalny numer jednostki handlowej</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Zamowienie/ZamowienieWiersz/PKWiUZ
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy50
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 50
documentation
annotation
Symbol Polskiej Klasyfikacji Wyrobów i Usług
source <xsd:element name="PKWiUZ" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Symbol Polskiej Klasyfikacji Wyrobów i Usług</xsd:documentation>

---

</xsd:annotation>
</xsd:element>
element Faktura/Fa/Zamowienie/ZamowienieWiersz/CNZ
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy50
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 50
documentation
annotation
Symbol Nomenklatury Scalonej
source <xsd:element name="CNZ" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Symbol Nomenklatury Scalonej</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Zamowienie/ZamowienieWiersz/PKOBZ
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy50
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 50
documentation
annotation
Symbol Polskiej Klasyfikacji Obiektów Budowlanych
source <xsd:element name="PKOBZ" type="tns:TZnakowy50" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Symbol Polskiej Klasyfikacji Obiektów
Budowlanych</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/Zamowienie/ZamowienieWiersz/P_8AZ
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Miara zamówionego towaru lub zakres usługi
source <xsd:element name="P_8AZ" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Miara zamówionego towaru lub zakres usługi</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Zamowienie/ZamowienieWiersz/P_8BZ
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TIlosci
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
totalDigits 22
fractionDigits 6
pattern -?([1-9]\d{0,15}|0)(\.\d{1,6})?
documentation
annotation
Ilość zamówionego towaru lub zakres usługi
source <xsd:element name="P_8BZ" type="tns:TIlosci" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Ilość zamówionego towaru lub zakres usługi</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Zamowienie/ZamowienieWiersz/P_9AZ
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/

---

type tns:TKwotowy2
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
totalDigits 22
fractionDigits 8
pattern -?([1-9]\d{0,13}|0)(\.\d{1,8})?
documentation
annotation
Cena jednostkowa netto
source <xsd:element name="P_9AZ" type="tns:TKwotowy2" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Cena jednostkowa netto</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Zamowienie/ZamowienieWiersz/P_11NettoZ
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Wartość zamówionego towaru lub usługi bez kwoty podatku
source <xsd:element name="P_11NettoZ" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Wartość zamówionego towaru lub usługi bez kwoty
podatku</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Zamowienie/ZamowienieWiersz/P_11VatZ
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
minOcc 0
properties
maxOcc 1
content simple

---

Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Kwota podatku od zamówionego towaru lub usługi
source <xsd:element name="P_11VatZ" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kwota podatku od zamówionego towaru lub usługi</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Zamowienie/ZamowienieWiersz/P_12Z
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TStawkaPodatku
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
enumeration 23
enumeration 22
enumeration 8
enumeration 7
enumeration 5
enumeration 4
enumeration 3
enumeration 0
enumeration zw documentation
zwolnione od podatku
enumeration oo documentation
odwrotne obciążenie
enumeration np documentation
niepodlegające opodatkowaniu- dostawy towarów oraz świadczenia usług poza terytorium
kraju
documentation
annotation
Stawka podatku
source <xsd:element name="P_12Z" type="tns:TStawkaPodatku" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Stawka podatku</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/Zamowienie/ZamowienieWiersz/P_12Z_XII
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TProcentowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minInclusive 0
maxInclusive 100
totalDigits 9
fractionDigits 6
whiteSpace collapse
documentation
annotation
Stawka podatku od wartości dodanej w przypadku, o którym mowa w dziale XII w rozdziale 6a ustawy
source <xsd:element name="P_12Z_XII" type="tns:TProcentowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Stawka podatku od wartości dodanej w przypadku, o którym mowa w
dziale XII w rozdziale 6a ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Zamowienie/ZamowienieWiersz/P_12Z_Zal_15
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
enumeration 1
documentation
annotation
Znacznik dla towaru lub usługi wymienionych w załączniku nr 15 do ustawy - wartość "1"
source <xsd:element name="P_12Z_Zal_15" type="etd:TWybor1" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Znacznik dla towaru lub usługi wymienionych w załączniku nr 15 do
ustawy - wartość "1"</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/Zamowienie/ZamowienieWiersz/GTUZ
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TGTU
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
enumeration GTU_01 documentation
Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. a rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_02 documentation
Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. b rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_03 documentation
Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. c rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_04 documentation
Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. d rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_05 documentation
Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. e rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_06 documentation
Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. f rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_07 documentation
Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. g rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_08 documentation
Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. h rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_09 documentation
Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. i rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_10 documentation
Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. j rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_11 documentation
Świadczenie usług, o których mowa w § 10 ust. 3 pkt 2 lit. a rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_12 documentation
Świadczenie usług, o których mowa w § 10 ust. 3 pkt 2 lit. b rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_13 documentation
Świadczenie usług, o których mowa w § 10 ust. 3 pkt 2 lit. c rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług

---

documentation
annotation
Oznaczenie dotyczące dostawy towarów i świadczenia usług
source <xsd:element name="GTUZ" type="tns:TGTU" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Oznaczenie dotyczące dostawy towarów i świadczenia
usług</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Zamowienie/ZamowienieWiersz/ProceduraZ
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TOznaczenieProceduryZ
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
enumeration WSTO_EE documentation
Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 2a
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w
deklaracjach podatkowych i w ewidencji w zakresie podatku od towarów i
usług
enumeration IED documentation
Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 2b
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w
deklaracjach podatkowych i w ewidencji w zakresie podatku od towarów i
usług
enumeration TT_D documentation
Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 5
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w
deklaracjach podatkowych i w ewidencji w zakresie podatku od towarów i
usług
enumeration B_SPV documentation
Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 10
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w
deklaracjach podatkowych i w ewidencji w zakresie podatku od towarów i
usług
enumeration B_SPV_DOSTAWA documentation
Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 11
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w
deklaracjach podatkowych i w ewidencji w zakresie podatku od towarów i
usług
enumeration B_MPV_PROWIZJA documentation
Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 12
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w
deklaracjach podatkowych i w ewidencji w zakresie podatku od towarów i
usług
documentation
annotation
Oznaczenia dotyczące procedur
source <xsd:element name="ProceduraZ" type="tns:TOznaczenieProceduryZ" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Oznaczenia dotyczące procedur</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Fa/Zamowienie/ZamowienieWiersz/KwotaAkcyzyZ
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKwotowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Kwota podatku akcyzowego zawarta w cenie towaru
source <xsd:element name="KwotaAkcyzyZ" type="tns:TKwotowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kwota podatku akcyzowego zawarta w cenie
towaru</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Fa/Zamowienie/ZamowienieWiersz/StanPrzedZ
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
enumeration 1
documentation
annotation
Znacznik stanu przed korektą w przypadku faktury korygującej fakturę dokumentującą otrzymanie zapłaty lub jej części
przed dokonaniem czynności oraz fakturę wystawioną w związku z art. 106f ust. 4 ustawy, w przypadku gdy korekta

---

dotyczy danych wykazanych w pozycjach zamówienia i jest dokonywana w sposób polegający na wykazaniu danych
przed korektą i po korekcie jako osobnych wierszy z odrębną numeracją oraz w przypadku potwierdzania braku zmiany
wartości danej pozycji
source <xsd:element name="StanPrzedZ" type="etd:TWybor1" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Znacznik stanu przed korektą w przypadku faktury korygującej fakturę
dokumentującą otrzymanie zapłaty lub jej części przed dokonaniem czynności oraz fakturę
wystawioną w związku z art. 106f ust. 4 ustawy, w przypadku gdy korekta dotyczy danych
wykazanych w pozycjach zamówienia i jest dokonywana w sposób polegający na wykazaniu
danych przed korektą i po korekcie jako osobnych wierszy z odrębną numeracją oraz w przypadku
potwierdzania braku zmiany wartości danej pozycji</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Stopka
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
minOcc 0
properties
maxOcc 1
content complex
children tns:Informacje tns:Rejestry
documentation
annotation
Pozostałe dane na fakturze
source <xsd:element name="Stopka" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Pozostałe dane na fakturze</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence minOccurs="0">
<xsd:element name="Informacje" minOccurs="0" maxOccurs="3">
<xsd:annotation>
<xsd:documentation>Pozostałe dane</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence minOccurs="0">
<xsd:element name="StopkaFaktury" type="etd:TTekstowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Stopka faktury</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
<xsd:element name="Rejestry" minOccurs="0" maxOccurs="100">

---

<xsd:annotation>
<xsd:documentation>Numery podmiotu lub grupy podmiotów w innych rejestrach i
bazach danych</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence minOccurs="0">
<xsd:element name="PelnaNazwa" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Pełna nazwa</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="KRS" type="etd:TNrKRS" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer Krajowego Rejestru Sądowego</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="REGON" type="etd:TNrREGON" minOccurs="0">
<xsd:annotation>
<xsd:documentation>REGON</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="BDO" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer w Bazie Danych o Odpadach</xsd:documentation>
</xsd:annotation>
<xsd:simpleType>
<xsd:restriction base="tns:TZnakowy">
<xsd:maxLength value="9"/>
</xsd:restriction>
</xsd:simpleType>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
element Faktura/Stopka/Informacje
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
minOcc 0
properties
maxOcc 3
content complex
children tns:StopkaFaktury
documentation
annotation
Pozostałe dane
source <xsd:element name="Informacje" minOccurs="0" maxOccurs="3">
<xsd:annotation>
<xsd:documentation>Pozostałe dane</xsd:documentation>

---

</xsd:annotation>
<xsd:complexType>
<xsd:sequence minOccurs="0">
<xsd:element name="StopkaFaktury" type="etd:TTekstowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Stopka faktury</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
element Faktura/Stopka/Informacje/StopkaFaktury
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TTekstowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 3500
documentation
annotation
Stopka faktury
source <xsd:element name="StopkaFaktury" type="etd:TTekstowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Stopka faktury</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Stopka/Rejestry
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
minOcc 0
properties
maxOcc 100

---

content complex
children tns:PelnaNazwa tns:KRS tns:REGON tns:BDO
documentation
annotation
Numery podmiotu lub grupy podmiotów w innych rejestrach i bazach danych
source <xsd:element name="Rejestry" minOccurs="0" maxOccurs="100">
<xsd:annotation>
<xsd:documentation>Numery podmiotu lub grupy podmiotów w innych rejestrach i bazach
danych</xsd:documentation>
</xsd:annotation>
<xsd:complexType>
<xsd:sequence minOccurs="0">
<xsd:element name="PelnaNazwa" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Pełna nazwa</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="KRS" type="etd:TNrKRS" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer Krajowego Rejestru Sądowego</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="REGON" type="etd:TNrREGON" minOccurs="0">
<xsd:annotation>
<xsd:documentation>REGON</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="BDO" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer w Bazie Danych o Odpadach</xsd:documentation>
</xsd:annotation>
<xsd:simpleType>
<xsd:restriction base="tns:TZnakowy">
<xsd:maxLength value="9"/>
</xsd:restriction>
</xsd:simpleType>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
</xsd:element>
element Faktura/Stopka/Rejestry/PelnaNazwa
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256

---

documentation
annotation
Pełna nazwa
source <xsd:element name="PelnaNazwa" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Pełna nazwa</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Stopka/Rejestry/KRS
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TNrKRS
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
pattern \d{10}
documentation
annotation
Numer Krajowego Rejestru Sądowego
source <xsd:element name="KRS" type="etd:TNrKRS" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer Krajowego Rejestru Sądowego</xsd:documentation>
</xsd:annotation>
</xsd:element>
element Faktura/Stopka/Rejestry/REGON
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TNrREGON
minOcc 0
properties
maxOcc 1
content simple
documentation
annotation
REGON
source <xsd:element name="REGON" type="etd:TNrREGON" minOccurs="0">
<xsd:annotation>
<xsd:documentation>REGON</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element Faktura/Stopka/Rejestry/BDO
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 9
documentation
annotation
Numer w Bazie Danych o Odpadach
source <xsd:element name="BDO" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer w Bazie Danych o Odpadach</xsd:documentation>
</xsd:annotation>
<xsd:simpleType>
<xsd:restriction base="tns:TZnakowy">
<xsd:maxLength value="9"/>
</xsd:restriction>
</xsd:simpleType>
</xsd:element>
complexType TAdres
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
children tns:KodKraju tns:AdresL1 tns:AdresL2 tns:GLN
elements Faktura/Podmiot1/Adres Faktura/Podmiot2/Adres Faktura/Podmiot3/Adres
used by
Faktura/PodmiotUpowazniony/Adres Faktura/Fa/Podmiot1K/Adres Faktura/Fa/Podmiot2K/Adres
Faktura/Podmiot1/AdresKoresp Faktura/Podmiot2/AdresKoresp Faktura/Podmiot3/AdresKoresp
Faktura/PodmiotUpowazniony/AdresKoresp
Faktura/Fa/WarunkiTransakcji/Transport/Przewoznik/AdresPrzewoznika
Faktura/Fa/WarunkiTransakcji/Transport/WysylkaDo
Faktura/Fa/WarunkiTransakcji/Transport/WysylkaPrzez
Faktura/Fa/WarunkiTransakcji/Transport/WysylkaZ
documentation
annotation
Informacje opisujące adres

---

source <xsd:complexType name="TAdres">
<xsd:annotation>
<xsd:documentation>Informacje opisujące adres</xsd:documentation>
</xsd:annotation>
<xsd:sequence>
<xsd:element name="KodKraju" type="etd:TKodKraju">
<xsd:annotation>
<xsd:documentation>Kod Kraju [Country Code]</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="AdresL1" type="tns:TZnakowy512">
<xsd:annotation>
<xsd:documentation>Adres [Address]</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="AdresL2" type="tns:TZnakowy512" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres [Address]</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="GLN" type="tns:TGLN" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Globalny Numer Lokalizacyjny [Global Location
Number]</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
element TAdres/KodKraju
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TKodKraju
content simple
properties
Kind Value Annotation
facets
enumeration AF documentation
AFGANISTAN
enumeration AX documentation
ALAND ISLANDS
enumeration AL documentation
ALBANIA
enumeration DZ documentation
ALGIERIA
enumeration AD documentation
ANDORA
enumeration AO documentation
ANGOLA
enumeration AI documentation
ANGUILLA
enumeration AQ documentation
ANTARKTYDA
enumeration AG documentation
ANTIGUA I BARBUDA

---

enumeration AN documentation
ANTYLE HOLENDERSKIE
enumeration SA documentation
ARABIA SAUDYJSKA
enumeration AR documentation
ARGENTYNA
enumeration AM documentation
ARMENIA
enumeration AW documentation
ARUBA
enumeration AU documentation
AUSTRALIA
enumeration AT documentation
AUSTRIA
enumeration AZ documentation
AZERBEJDŻAN
enumeration BS documentation
BAHAMY
enumeration BH documentation
BAHRAJN
enumeration BD documentation
BANGLADESZ
enumeration BB documentation
BARBADOS
enumeration BE documentation
BELGIA
enumeration BZ documentation
BELIZE
enumeration BJ documentation
BENIN
enumeration BM documentation
BERMUDY
enumeration BT documentation
BHUTAN
enumeration BY documentation
BIAŁORUŚ
enumeration BO documentation
BOLIWIA
enumeration BQ documentation
BONAIRE, SINT EUSTATIUS I SABA
enumeration BA documentation
BOŚNIA I HERCEGOWINA
enumeration BW documentation
BOTSWANA
enumeration BR documentation
BRAZYLIA
enumeration BN documentation
BRUNEI DARUSSALAM
enumeration IO documentation
BRYTYJSKIE TERYTORIUM OCEANU INDYJSKIEGO
enumeration BG documentation
BUŁGARIA
enumeration BF documentation
BURKINA FASO
enumeration BI documentation
BURUNDI
enumeration XC documentation
CEUTA
enumeration CL documentation
CHILE
enumeration CN documentation
CHINY
enumeration HR documentation
CHORWACJA
enumeration CW documentation
CURAÇAO
enumeration CY documentation
CYPR
enumeration TD documentation
CZAD

---

enumeration ME documentation
CZARNOGÓRA
enumeration DK documentation
DANIA
enumeration DM documentation
DOMINIKA
enumeration DO documentation
DOMINIKANA
enumeration DJ documentation
DŻIBUTI
enumeration EG documentation
EGIPT
enumeration EC documentation
EKWADOR
enumeration ER documentation
ERYTREA
enumeration EE documentation
ESTONIA
enumeration ET documentation
ETIOPIA
enumeration FK documentation
FALKLANDY
enumeration FJ documentation
FIDŻI REPUBLIKA
enumeration PH documentation
FILIPINY
enumeration FI documentation
FINLANDIA
enumeration FR documentation
FRANCJA
enumeration TF documentation
FRANCUSKIE TERYTORIUM POŁUDNIOWE
enumeration GA documentation
GABON
enumeration GM documentation
GAMBIA
enumeration GH documentation
GHANA
enumeration GI documentation
GIBRALTAR
enumeration GR documentation
GRECJA
enumeration GD documentation
GRENADA
enumeration GL documentation
GRENLANDIA
enumeration GE documentation
GRUZJA
enumeration GU documentation
GUAM
enumeration GG documentation
GUERNSEY
enumeration GY documentation
GUJANA
enumeration GF documentation
GUJANA FRANCUSKA
enumeration GP documentation
GWADELUPA
enumeration GT documentation
GWATEMALA
enumeration GN documentation
GWINEA
enumeration GQ documentation
GWINEA RÓWNIKOWA
enumeration GW documentation
GWINEA-BISSAU
enumeration HT documentation
HAITI
enumeration ES documentation
HISZPANIA

---

enumeration HN documentation
HONDURAS
enumeration HK documentation
HONGKONG
enumeration IN documentation
INDIE
enumeration ID documentation
INDONEZJA
enumeration IQ documentation
IRAK
enumeration IR documentation
IRAN
enumeration IE documentation
IRLANDIA
enumeration IS documentation
ISLANDIA
enumeration IL documentation
IZRAEL
enumeration JM documentation
JAMAJKA
enumeration JP documentation
JAPONIA
enumeration YE documentation
JEMEN
enumeration JE documentation
JERSEY
enumeration JO documentation
JORDANIA
enumeration KY documentation
KAJMANY
enumeration KH documentation
KAMBODŻA
enumeration CM documentation
KAMERUN
enumeration CA documentation
KANADA
enumeration QA documentation
KATAR
enumeration KZ documentation
KAZACHSTAN
enumeration KE documentation
KENIA
enumeration KG documentation
KIRGISTAN
enumeration KI documentation
KIRIBATI
enumeration CO documentation
KOLUMBIA
enumeration KM documentation
KOMORY
enumeration CG documentation
KONGO
enumeration CD documentation
KONGO, REPUBLIKA DEMOKRATYCZNA
enumeration KP documentation
KOREAŃSKA REPUBLIKA LUDOWO-DEMOKRATYCZNA
enumeration XK documentation
KOSOWO
enumeration CR documentation
KOSTARYKA
enumeration CU documentation
KUBA
enumeration KW documentation
KUWEJT
enumeration LA documentation
LAOS
enumeration LS documentation
LESOTHO
enumeration LB documentation
LIBAN

---

enumeration LR documentation
LIBERIA
enumeration LY documentation
LIBIA
enumeration LI documentation
LIECHTENSTEIN
enumeration LT documentation
LITWA
enumeration LV documentation
ŁOTWA
enumeration LU documentation
LUKSEMBURG
enumeration MK documentation
MACEDONIA
enumeration MG documentation
MADAGASKAR
enumeration YT documentation
MAJOTTA
enumeration MO documentation
MAKAU
enumeration MW documentation
MALAWI
enumeration MV documentation
MALEDIWY
enumeration MY documentation
MALEZJA
enumeration ML documentation
MALI
enumeration MT documentation
MALTA
enumeration MP documentation
MARIANY PÓŁNOCNE
enumeration MA documentation
MAROKO
enumeration MQ documentation
MARTYNIKA
enumeration MR documentation
MAURETANIA
enumeration MU documentation
MAURITIUS
enumeration MX documentation
MEKSYK
enumeration XL documentation
MELILLA
enumeration FM documentation
MIKRONEZJA
enumeration UM documentation
MINOR
enumeration MD documentation
MOŁDOWA
enumeration MC documentation
MONAKO
enumeration MN documentation
MONGOLIA
enumeration MS documentation
MONTSERRAT
enumeration MZ documentation
MOZAMBIK
enumeration MM documentation
MYANMAR (BURMA)
enumeration NA documentation
NAMIBIA
enumeration NR documentation
NAURU
enumeration NP documentation
NEPAL
enumeration NL documentation
NIDERLANDY (HOLANDIA)
enumeration DE documentation
NIEMCY

---

enumeration NE documentation
NIGER
enumeration NG documentation
NIGERIA
enumeration NI documentation
NIKARAGUA
enumeration NU documentation
NIUE
enumeration NF documentation
NORFOLK
enumeration NO documentation
NORWEGIA
enumeration NC documentation
NOWA KALEDONIA
enumeration NZ documentation
NOWA ZELANDIA
enumeration PS documentation
OKUPOWANE TERYTORIUM PALESTYNY
enumeration OM documentation
OMAN
enumeration PK documentation
PAKISTAN
enumeration PW documentation
PALAU
enumeration PA documentation
PANAMA
enumeration PG documentation
PAPUA NOWA GWINEA
enumeration PY documentation
PARAGWAJ
enumeration PE documentation
PERU
enumeration PN documentation
PITCAIRN
enumeration PF documentation
POLINEZJA FRANCUSKA
enumeration PL documentation
POLSKA
enumeration GS documentation
POŁUDNIOWA GEORGIA I POŁUD.WYSPY SANDWICH
enumeration PT documentation
PORTUGALIA
enumeration PR documentation
PORTORYKO
enumeration CF documentation
REP.ŚRODKOWOAFRYKAŃSKA
enumeration CZ documentation
REPUBLIKA CZESKA
enumeration KR documentation
REPUBLIKA KOREI
enumeration ZA documentation
REPUBLIKA POŁUDNIOWEJ AFRYKI
enumeration RE documentation
REUNION
enumeration RU documentation
ROSJA
enumeration RO documentation
RUMUNIA
enumeration RW documentation
RWANDA
enumeration EH documentation
SAHARA ZACHODNIA
enumeration BL documentation
SAINT BARTHELEMY
enumeration KN documentation
SAINT KITTS I NEVIS
enumeration LC documentation
SAINT LUCIA
enumeration MF documentation
SAINT MARTIN

---

enumeration VC documentation
SAINT VINCENT I GRENADYNY
enumeration SV documentation
SALWADOR
enumeration WS documentation
SAMOA
enumeration AS documentation
SAMOA AMERYKAŃSKIE
enumeration SM documentation
SAN MARINO
enumeration SN documentation
SENEGAL
enumeration RS documentation
SERBIA
enumeration SC documentation
SESZELE
enumeration SL documentation
SIERRA LEONE
enumeration SG documentation
SINGAPUR
enumeration SK documentation
SŁOWACJA
enumeration SI documentation
SŁOWENIA
enumeration SO documentation
SOMALIA
enumeration LK documentation
SRI LANKA
enumeration PM documentation
SAINT PIERRE I MIQUELON
enumeration US documentation
STANY ZJEDNOCZONE AMERYKI
enumeration SZ documentation
SUAZI
enumeration SD documentation
SUDAN
enumeration SS documentation
SUDAN POŁUDNIOWY
enumeration SR documentation
SURINAM
enumeration SJ documentation
SVALBARD I JAN MAYEN
enumeration SH documentation
ŚWIĘTA HELENA
enumeration SY documentation
SYRIA
enumeration CH documentation
SZWAJCARIA
enumeration SE documentation
SZWECJA
enumeration TJ documentation
TADŻYKISTAN
enumeration TH documentation
TAJLANDIA
enumeration TW documentation
TAJWAN
enumeration TZ documentation
TANZANIA
enumeration TG documentation
TOGO
enumeration TK documentation
TOKELAU
enumeration TO documentation
TONGA
enumeration TT documentation
TRYNIDAD I TOBAGO
enumeration TN documentation
TUNEZJA
enumeration TR documentation
TURCJA

---

enumeration TM documentation
TURKMENISTAN
enumeration TV documentation
TUVALU
enumeration UG documentation
UGANDA
enumeration UA documentation
UKRAINA
enumeration UY documentation
URUGWAJ
enumeration UZ documentation
UZBEKISTAN
enumeration VU documentation
VANUATU
enumeration WF documentation
WALLIS I FUTUNA
enumeration VA documentation
WATYKAN
enumeration HU documentation
WĘGRY
enumeration VE documentation
WENEZUELA
enumeration GB documentation
WIELKA BRYTANIA
enumeration VN documentation
WIETNAM
enumeration IT documentation
WŁOCHY
enumeration TL documentation
WSCHODNI TIMOR
enumeration CI documentation
WYBRZEŻE KOŚCI SŁONIOWEJ
enumeration BV documentation
WYSPA BOUVETA
enumeration CX documentation
WYSPA BOŻEGO NARODZENIA
enumeration IM documentation
WYSPA MAN
enumeration SX documentation
WYSPA SINT MAARTEN (CZĘŚĆ HOLENDERSKA WYSPY)
enumeration CK documentation
WYSPY COOKA
enumeration VI documentation
WYSPY DZIEWICZE-USA
enumeration VG documentation
WYSPY DZIEWICZE-W.B.
enumeration HM documentation
WYSPY HEARD I MCDONALD
enumeration CC documentation
WYSPY KOKOSOWE (KEELINGA)
enumeration MH documentation
WYSPY MARSHALLA
enumeration FO documentation
WYSPY OWCZE
enumeration SB documentation
WYSPY SALOMONA
enumeration ST documentation
WYSPY ŚWIĘTEGO TOMASZA I KSIĄŻĘCA
enumeration TC documentation
WYSPY TURKS I CAICOS
enumeration ZM documentation
ZAMBIA
enumeration CV documentation
ZIELONY PRZYLĄDEK
enumeration ZW documentation
ZIMBABWE
enumeration AE documentation
ZJEDNOCZONE EMIRATY ARABSKIE
enumeration XI documentation
ZJEDNOCZONE KRÓLESTWO (IRLANDIA PÓŁNOCNA)

---

documentation
annotation
Kod Kraju [Country Code]
source <xsd:element name="KodKraju" type="etd:TKodKraju">
<xsd:annotation>
<xsd:documentation>Kod Kraju [Country Code]</xsd:documentation>
</xsd:annotation>
</xsd:element>
element TAdres/AdresL1
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy512
content simple
properties
Kind Value Annotation
facets
minLength 1
maxLength 512
documentation
annotation
Adres [Address]
source <xsd:element name="AdresL1" type="tns:TZnakowy512">
<xsd:annotation>
<xsd:documentation>Adres [Address]</xsd:documentation>
</xsd:annotation>
</xsd:element>
element TAdres/AdresL2
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy512
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 512
documentation
annotation
Adres [Address]
source <xsd:element name="AdresL2" type="tns:TZnakowy512" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Adres [Address]</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element TAdres/GLN
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TGLN
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 13
documentation
annotation
Globalny Numer Lokalizacyjny [Global Location Number]
source <xsd:element name="GLN" type="tns:TGLN" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Globalny Numer Lokalizacyjny [Global Location
Number]</xsd:documentation>
</xsd:annotation>
</xsd:element>
complexType TKluczWartosc
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
children tns:NrWiersza tns:Klucz tns:Wartosc
element Faktura/Fa/DodatkowyOpis
used by
documentation
annotation
Typ złożony, klucz-wartość
source <xsd:complexType name="TKluczWartosc">
<xsd:annotation>
<xsd:documentation>Typ złożony, klucz-wartość</xsd:documentation>
</xsd:annotation>
<xsd:sequence>
<xsd:element name="NrWiersza" type="tns:TNaturalny" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer wiersza podany w polu NrWierszaFa lub NrWierszaZam, jeśli
informacja odnosi się wyłącznie do danej pozycji faktury</xsd:documentation>
</xsd:annotation>

---

</xsd:element>
<xsd:element name="Klucz" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Klucz</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Wartosc" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Wartość</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
element TKluczWartosc/NrWiersza
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TNaturalny
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minExclusive 0
totalDigits 14
whiteSpace collapse
documentation
annotation
Numer wiersza podany w polu NrWierszaFa lub NrWierszaZam, jeśli informacja odnosi się wyłącznie do danej pozycji
faktury
source <xsd:element name="NrWiersza" type="tns:TNaturalny" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Numer wiersza podany w polu NrWierszaFa lub NrWierszaZam, jeśli
informacja odnosi się wyłącznie do danej pozycji faktury</xsd:documentation>
</xsd:annotation>
</xsd:element>
element TKluczWartosc/Klucz
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
content simple
properties
Kind Value Annotation
facets

---

minLength 1
maxLength 256
documentation
annotation
Klucz
source <xsd:element name="Klucz" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Klucz</xsd:documentation>
</xsd:annotation>
</xsd:element>
element TKluczWartosc/Wartosc
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
content simple
properties
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Wartość
source <xsd:element name="Wartosc" type="tns:TZnakowy">
<xsd:annotation>
<xsd:documentation>Wartość</xsd:documentation>
</xsd:annotation>
</xsd:element>
complexType TNaglowek
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
children tns:KodFormularza tns:WariantFormularza tns:DataWytworzeniaFa tns:SystemInfo
element Faktura/Naglowek
used by
documentation
annotation
Nagłówek
source <xsd:complexType name="TNaglowek">

---

<xsd:annotation>
<xsd:documentation>Nagłówek</xsd:documentation>
</xsd:annotation>
<xsd:sequence>
<xsd:element name="KodFormularza">
<xsd:complexType>
<xsd:simpleContent>
<xsd:extension base="tns:TKodFormularza">
<xsd:attribute name="kodSystemowy" type="xsd:string" use="required" fixed="FA
(2)"/>
<xsd:attribute name="wersjaSchemy" type="xsd:string" use="required" fixed="1-0E"/>
</xsd:extension>
</xsd:simpleContent>
</xsd:complexType>
</xsd:element>
<xsd:element name="WariantFormularza">
<xsd:simpleType>
<xsd:restriction base="xsd:byte">
<xsd:enumeration value="2"/>
</xsd:restriction>
</xsd:simpleType>
</xsd:element>
<xsd:element name="DataWytworzeniaFa">
<xsd:annotation>
<xsd:documentation>Data i czas wytworzenia faktury</xsd:documentation>
</xsd:annotation>
<xsd:simpleType>
<xsd:restriction base="etd:TDataCzas">
<xsd:minInclusive value="2022-01-01T00:00:00Z"/>
<xsd:maxInclusive value="2050-01-01T23:59:59Z"/>
</xsd:restriction>
</xsd:simpleType>
</xsd:element>
<xsd:element name="SystemInfo" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Nazwa systemu teleinformatycznego, z którego korzysta
podatnik</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
element TNaglowek/KodFormularza
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type extension of tns:TKodFormularza

---

content complex
properties
Kind Value Annotation
facets
enumeration FA
Name Type Use Default Fixed Annotation
attributes
kodSystemowy xsd:string required FA (2)
wersjaSchemy xsd:string required 1-0E
source <xsd:element name="KodFormularza">
<xsd:complexType>
<xsd:simpleContent>
<xsd:extension base="tns:TKodFormularza">
<xsd:attribute name="kodSystemowy" type="xsd:string" use="required" fixed="FA (2)"/>
<xsd:attribute name="wersjaSchemy" type="xsd:string" use="required" fixed="1-0E"/>
</xsd:extension>
</xsd:simpleContent>
</xsd:complexType>
</xsd:element>
attribute TNaglowek/KodFormularza/@kodSystemowy
type xsd:string
use required
properties
fixed FA (2)
source <xsd:attribute name="kodSystemowy" type="xsd:string" use="required" fixed="FA (2)"/>
attribute TNaglowek/KodFormularza/@wersjaSchemy
type xsd:string
use required
properties
fixed 1-0E
source <xsd:attribute name="wersjaSchemy" type="xsd:string" use="required" fixed="1-0E"/>
element TNaglowek/WariantFormularza
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of xsd:byte
content simple
properties
Kind Value Annotation
facets
enumeration 2
source <xsd:element name="WariantFormularza">
<xsd:simpleType>
<xsd:restriction base="xsd:byte">
<xsd:enumeration value="2"/>
</xsd:restriction>
</xsd:simpleType>
</xsd:element>

---

element TNaglowek/DataWytworzeniaFa
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of etd:TDataCzas
content simple
properties
Kind Value Annotation
facets
minInclusive 2022-01-01T00:00:00Z
maxInclusive 2050-01-01T23:59:59Z
whiteSpace collapse
documentation
annotation
Data i czas wytworzenia faktury
source <xsd:element name="DataWytworzeniaFa">
<xsd:annotation>
<xsd:documentation>Data i czas wytworzenia faktury</xsd:documentation>
</xsd:annotation>
<xsd:simpleType>
<xsd:restriction base="etd:TDataCzas">
<xsd:minInclusive value="2022-01-01T00:00:00Z"/>
<xsd:maxInclusive value="2050-01-01T23:59:59Z"/>
</xsd:restriction>
</xsd:simpleType>
</xsd:element>
element TNaglowek/SystemInfo
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Nazwa systemu teleinformatycznego, z którego korzysta podatnik
source <xsd:element name="SystemInfo" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Nazwa systemu teleinformatycznego, z którego korzysta
podatnik</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

complexType TPodmiot1
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
children tns:NIP tns:Nazwa
elements Faktura/Podmiot1/DaneIdentyfikacyjne Faktura/PodmiotUpowazniony/DaneIdentyfikacyjne
used by
Faktura/Fa/Podmiot1K/DaneIdentyfikacyjne
documentation
annotation
Zestaw danych identyfikacyjnych oraz danych adresowych podatnika
source <xsd:complexType name="TPodmiot1">
<xsd:annotation>
<xsd:documentation>Zestaw danych identyfikacyjnych oraz danych adresowych
podatnika</xsd:documentation>
</xsd:annotation>
<xsd:sequence>
<xsd:element name="NIP" type="etd:TNrNIP">
<xsd:annotation>
<xsd:documentation>Identyfikator podatkowy NIP</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="Nazwa" type="tns:TZnakowy512">
<xsd:annotation>
<xsd:documentation>Imię i nazwisko lub nazwa</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
element TPodmiot1/NIP
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TNrNIP
content simple
properties
Kind Value Annotation
facets
pattern [1-9]((\d[1-9])|([1-9]\d))\d{7}
documentation
annotation
Identyfikator podatkowy NIP
source <xsd:element name="NIP" type="etd:TNrNIP">
<xsd:annotation>
<xsd:documentation>Identyfikator podatkowy NIP</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element TPodmiot1/Nazwa
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy512
content simple
properties
Kind Value Annotation
facets
minLength 1
maxLength 512
documentation
annotation
Imię i nazwisko lub nazwa
source <xsd:element name="Nazwa" type="tns:TZnakowy512">
<xsd:annotation>
<xsd:documentation>Imię i nazwisko lub nazwa</xsd:documentation>
</xsd:annotation>
</xsd:element>
complexType TPodmiot2
diagram

---

namespace http://crd.gov.pl/wzor/2023/06/29/12648/
children tns:NIP tns:KodUE tns:NrVatUE tns:KodKraju tns:NrID tns:BrakID tns:Nazwa
elements Faktura/Podmiot2/DaneIdentyfikacyjne Faktura/Fa/Podmiot2K/DaneIdentyfikacyjne
used by
Faktura/Fa/WarunkiTransakcji/Transport/Przewoznik/DaneIdentyfikacyjne
documentation
annotation
Zestaw danych identyfikacyjnych oraz danych adresowych nabywcy
source <xsd:complexType name="TPodmiot2">
<xsd:annotation>
<xsd:documentation>Zestaw danych identyfikacyjnych oraz danych adresowych
nabywcy</xsd:documentation>
</xsd:annotation>
<xsd:sequence>
<xsd:choice>
<xsd:annotation>
<xsd:documentation>Numer, za pomocą którego nabywca towarów lub usług jest
identyfikowany dla podatku lub podatku od wartości dodanej, pod którym otrzymał on towary lub
usługi, z zastrzeżeniem art. 106e ust. 1 pkt 24 lit. b ustawy. Pole opcjonalne dla przypadku
określonego w art. 106e ust. 5 pkt 2 ustawy. W przypadku faktur wystawianych w procedurze
uproszczonej przez drugiego w kolejności podatnika, o którym mowa w art. 135 ust. 1 pkt 4 lit. b i c
oraz ust. 2 ustawy, numer, o którym mowa w art. 136 ust. 1 pkt 4 ustawy</xsd:documentation>
</xsd:annotation>
<xsd:element name="NIP" type="etd:TNrNIP">
<xsd:annotation>
<xsd:documentation>Identyfikator podatkowy NIP</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:sequence>
<xsd:element name="KodUE" type="tns:TKodyKrajowUE">
<xsd:annotation>
<xsd:documentation>Kod (prefiks) nabywcy VAT UE, o którym mowa w art. 106e ust. 1
pkt 24 ustawy oraz w przypadku, o którym mowa w art. 136 ust. 1 pkt 4
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="NrVatUE" type="tns:TNrVatUE">
<xsd:annotation>
<xsd:documentation>Numer Identyfikacyjny VAT kontrahenta
UE</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:sequence>
<xsd:element name="KodKraju" type="etd:TKodKraju" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kod kraju nadania identyfikatora
podatkowego</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="NrID">
<xsd:annotation>
<xsd:documentation>Identyfikator podatkowy inny</xsd:documentation>
</xsd:annotation>
<xsd:simpleType>
<xsd:restriction base="etd:TNrIdentyfikacjiPodatkowej">
<xsd:pattern value="[a-zA-Z0-9]{1,50}"/>

---

</xsd:restriction>
</xsd:simpleType>
</xsd:element>
</xsd:sequence>
<xsd:element name="BrakID" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Podmiot nie posiada identyfikatora podatkowego lub identyfikator
nie występuje na fakturze: 1- tak</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
<xsd:sequence minOccurs="0">
<xsd:annotation>
<xsd:documentation>Dane opcjonalne dla przypadków, o których mowa w art. 106e ust. 5
pkt 3 ustawy</xsd:documentation>
</xsd:annotation>
<xsd:element name="Nazwa" type="tns:TZnakowy512">
<xsd:annotation>
<xsd:documentation>Imię i nazwisko lub nazwa</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:sequence>
</xsd:complexType>
element TPodmiot2/NIP
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TNrNIP
content simple
properties
Kind Value Annotation
facets
pattern [1-9]((\d[1-9])|([1-9]\d))\d{7}
documentation
annotation
Identyfikator podatkowy NIP
source <xsd:element name="NIP" type="etd:TNrNIP">
<xsd:annotation>
<xsd:documentation>Identyfikator podatkowy NIP</xsd:documentation>
</xsd:annotation>
</xsd:element>
element TPodmiot2/KodUE
diagram

---

namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKodyKrajowUE
content simple
properties
Kind Value Annotation
facets
enumeration AT documentation
AUSTRIA
enumeration BE documentation
BELGIA
enumeration BG documentation
BUŁGARIA
enumeration CY documentation
CYPR
enumeration CZ documentation
CZECHY
enumeration DK documentation
DANIA
enumeration EE documentation
ESTONIA
enumeration FI documentation
FINLANDIA
enumeration FR documentation
FRANCJA
enumeration DE documentation
NIEMCY
enumeration EL documentation
GRECJA
enumeration HR documentation
CHORWACJA
enumeration HU documentation
WĘGRY
enumeration IE documentation
IRLANDIA
enumeration IT documentation
WŁOCHY
enumeration LV documentation
ŁOTWA
enumeration LT documentation
LITWA
enumeration LU documentation
LUKSEMBURG
enumeration MT documentation
MALTA
enumeration NL documentation
HOLANDIA
enumeration PL documentation
POLSKA
enumeration PT documentation
PORTUGALIA
enumeration RO documentation
RUMUNIA
enumeration SK documentation
SŁOWACJA
enumeration SI documentation
SŁOWENIA
enumeration ES documentation
HISZPANIA
enumeration SE documentation
SZWECJA
enumeration XI documentation
IRLANDIA PÓŁNOCNA
documentation
annotation
Kod (prefiks) nabywcy VAT UE, o którym mowa w art. 106e ust. 1 pkt 24 ustawy oraz w przypadku, o którym mowa w art.
136 ust. 1 pkt 4 ustawy
source <xsd:element name="KodUE" type="tns:TKodyKrajowUE">
<xsd:annotation>
<xsd:documentation>Kod (prefiks) nabywcy VAT UE, o którym mowa w art. 106e ust. 1 pkt 24

---

ustawy oraz w przypadku, o którym mowa w art. 136 ust. 1 pkt 4 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element TPodmiot2/NrVatUE
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TNrVatUE
content simple
properties
Kind Value Annotation
facets
pattern (\d|[A-Z]|\+|\*){1,12}
documentation
annotation
Numer Identyfikacyjny VAT kontrahenta UE
source <xsd:element name="NrVatUE" type="tns:TNrVatUE">
<xsd:annotation>
<xsd:documentation>Numer Identyfikacyjny VAT kontrahenta UE</xsd:documentation>
</xsd:annotation>
</xsd:element>
element TPodmiot2/KodKraju
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TKodKraju
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
enumeration AF documentation
AFGANISTAN
enumeration AX documentation
ALAND ISLANDS
enumeration AL documentation
ALBANIA
enumeration DZ documentation
ALGIERIA
enumeration AD documentation
ANDORA
enumeration AO documentation
ANGOLA
enumeration AI documentation
ANGUILLA
enumeration AQ documentation
ANTARKTYDA
enumeration AG documentation
ANTIGUA I BARBUDA
enumeration AN documentation
ANTYLE HOLENDERSKIE
enumeration SA documentation

---

ARABIA SAUDYJSKA
enumeration AR documentation
ARGENTYNA
enumeration AM documentation
ARMENIA
enumeration AW documentation
ARUBA
enumeration AU documentation
AUSTRALIA
enumeration AT documentation
AUSTRIA
enumeration AZ documentation
AZERBEJDŻAN
enumeration BS documentation
BAHAMY
enumeration BH documentation
BAHRAJN
enumeration BD documentation
BANGLADESZ
enumeration BB documentation
BARBADOS
enumeration BE documentation
BELGIA
enumeration BZ documentation
BELIZE
enumeration BJ documentation
BENIN
enumeration BM documentation
BERMUDY
enumeration BT documentation
BHUTAN
enumeration BY documentation
BIAŁORUŚ
enumeration BO documentation
BOLIWIA
enumeration BQ documentation
BONAIRE, SINT EUSTATIUS I SABA
enumeration BA documentation
BOŚNIA I HERCEGOWINA
enumeration BW documentation
BOTSWANA
enumeration BR documentation
BRAZYLIA
enumeration BN documentation
BRUNEI DARUSSALAM
enumeration IO documentation
BRYTYJSKIE TERYTORIUM OCEANU INDYJSKIEGO
enumeration BG documentation
BUŁGARIA
enumeration BF documentation
BURKINA FASO
enumeration BI documentation
BURUNDI
enumeration XC documentation
CEUTA
enumeration CL documentation
CHILE
enumeration CN documentation
CHINY
enumeration HR documentation
CHORWACJA
enumeration CW documentation
CURAÇAO
enumeration CY documentation
CYPR
enumeration TD documentation
CZAD
enumeration ME documentation
CZARNOGÓRA
enumeration DK documentation

---

DANIA
enumeration DM documentation
DOMINIKA
enumeration DO documentation
DOMINIKANA
enumeration DJ documentation
DŻIBUTI
enumeration EG documentation
EGIPT
enumeration EC documentation
EKWADOR
enumeration ER documentation
ERYTREA
enumeration EE documentation
ESTONIA
enumeration ET documentation
ETIOPIA
enumeration FK documentation
FALKLANDY
enumeration FJ documentation
FIDŻI REPUBLIKA
enumeration PH documentation
FILIPINY
enumeration FI documentation
FINLANDIA
enumeration FR documentation
FRANCJA
enumeration TF documentation
FRANCUSKIE TERYTORIUM POŁUDNIOWE
enumeration GA documentation
GABON
enumeration GM documentation
GAMBIA
enumeration GH documentation
GHANA
enumeration GI documentation
GIBRALTAR
enumeration GR documentation
GRECJA
enumeration GD documentation
GRENADA
enumeration GL documentation
GRENLANDIA
enumeration GE documentation
GRUZJA
enumeration GU documentation
GUAM
enumeration GG documentation
GUERNSEY
enumeration GY documentation
GUJANA
enumeration GF documentation
GUJANA FRANCUSKA
enumeration GP documentation
GWADELUPA
enumeration GT documentation
GWATEMALA
enumeration GN documentation
GWINEA
enumeration GQ documentation
GWINEA RÓWNIKOWA
enumeration GW documentation
GWINEA-BISSAU
enumeration HT documentation
HAITI
enumeration ES documentation
HISZPANIA
enumeration HN documentation
HONDURAS
enumeration HK documentation

---

HONGKONG
enumeration IN documentation
INDIE
enumeration ID documentation
INDONEZJA
enumeration IQ documentation
IRAK
enumeration IR documentation
IRAN
enumeration IE documentation
IRLANDIA
enumeration IS documentation
ISLANDIA
enumeration IL documentation
IZRAEL
enumeration JM documentation
JAMAJKA
enumeration JP documentation
JAPONIA
enumeration YE documentation
JEMEN
enumeration JE documentation
JERSEY
enumeration JO documentation
JORDANIA
enumeration KY documentation
KAJMANY
enumeration KH documentation
KAMBODŻA
enumeration CM documentation
KAMERUN
enumeration CA documentation
KANADA
enumeration QA documentation
KATAR
enumeration KZ documentation
KAZACHSTAN
enumeration KE documentation
KENIA
enumeration KG documentation
KIRGISTAN
enumeration KI documentation
KIRIBATI
enumeration CO documentation
KOLUMBIA
enumeration KM documentation
KOMORY
enumeration CG documentation
KONGO
enumeration CD documentation
KONGO, REPUBLIKA DEMOKRATYCZNA
enumeration KP documentation
KOREAŃSKA REPUBLIKA LUDOWO-DEMOKRATYCZNA
enumeration XK documentation
KOSOWO
enumeration CR documentation
KOSTARYKA
enumeration CU documentation
KUBA
enumeration KW documentation
KUWEJT
enumeration LA documentation
LAOS
enumeration LS documentation
LESOTHO
enumeration LB documentation
LIBAN
enumeration LR documentation
LIBERIA
enumeration LY documentation

---

LIBIA
enumeration LI documentation
LIECHTENSTEIN
enumeration LT documentation
LITWA
enumeration LV documentation
ŁOTWA
enumeration LU documentation
LUKSEMBURG
enumeration MK documentation
MACEDONIA
enumeration MG documentation
MADAGASKAR
enumeration YT documentation
MAJOTTA
enumeration MO documentation
MAKAU
enumeration MW documentation
MALAWI
enumeration MV documentation
MALEDIWY
enumeration MY documentation
MALEZJA
enumeration ML documentation
MALI
enumeration MT documentation
MALTA
enumeration MP documentation
MARIANY PÓŁNOCNE
enumeration MA documentation
MAROKO
enumeration MQ documentation
MARTYNIKA
enumeration MR documentation
MAURETANIA
enumeration MU documentation
MAURITIUS
enumeration MX documentation
MEKSYK
enumeration XL documentation
MELILLA
enumeration FM documentation
MIKRONEZJA
enumeration UM documentation
MINOR
enumeration MD documentation
MOŁDOWA
enumeration MC documentation
MONAKO
enumeration MN documentation
MONGOLIA
enumeration MS documentation
MONTSERRAT
enumeration MZ documentation
MOZAMBIK
enumeration MM documentation
MYANMAR (BURMA)
enumeration NA documentation
NAMIBIA
enumeration NR documentation
NAURU
enumeration NP documentation
NEPAL
enumeration NL documentation
NIDERLANDY (HOLANDIA)
enumeration DE documentation
NIEMCY
enumeration NE documentation
NIGER
enumeration NG documentation

---

NIGERIA
enumeration NI documentation
NIKARAGUA
enumeration NU documentation
NIUE
enumeration NF documentation
NORFOLK
enumeration NO documentation
NORWEGIA
enumeration NC documentation
NOWA KALEDONIA
enumeration NZ documentation
NOWA ZELANDIA
enumeration PS documentation
OKUPOWANE TERYTORIUM PALESTYNY
enumeration OM documentation
OMAN
enumeration PK documentation
PAKISTAN
enumeration PW documentation
PALAU
enumeration PA documentation
PANAMA
enumeration PG documentation
PAPUA NOWA GWINEA
enumeration PY documentation
PARAGWAJ
enumeration PE documentation
PERU
enumeration PN documentation
PITCAIRN
enumeration PF documentation
POLINEZJA FRANCUSKA
enumeration PL documentation
POLSKA
enumeration GS documentation
POŁUDNIOWA GEORGIA I POŁUD.WYSPY SANDWICH
enumeration PT documentation
PORTUGALIA
enumeration PR documentation
PORTORYKO
enumeration CF documentation
REP.ŚRODKOWOAFRYKAŃSKA
enumeration CZ documentation
REPUBLIKA CZESKA
enumeration KR documentation
REPUBLIKA KOREI
enumeration ZA documentation
REPUBLIKA POŁUDNIOWEJ AFRYKI
enumeration RE documentation
REUNION
enumeration RU documentation
ROSJA
enumeration RO documentation
RUMUNIA
enumeration RW documentation
RWANDA
enumeration EH documentation
SAHARA ZACHODNIA
enumeration BL documentation
SAINT BARTHELEMY
enumeration KN documentation
SAINT KITTS I NEVIS
enumeration LC documentation
SAINT LUCIA
enumeration MF documentation
SAINT MARTIN
enumeration VC documentation
SAINT VINCENT I GRENADYNY
enumeration SV documentation

---

SALWADOR
enumeration WS documentation
SAMOA
enumeration AS documentation
SAMOA AMERYKAŃSKIE
enumeration SM documentation
SAN MARINO
enumeration SN documentation
SENEGAL
enumeration RS documentation
SERBIA
enumeration SC documentation
SESZELE
enumeration SL documentation
SIERRA LEONE
enumeration SG documentation
SINGAPUR
enumeration SK documentation
SŁOWACJA
enumeration SI documentation
SŁOWENIA
enumeration SO documentation
SOMALIA
enumeration LK documentation
SRI LANKA
enumeration PM documentation
SAINT PIERRE I MIQUELON
enumeration US documentation
STANY ZJEDNOCZONE AMERYKI
enumeration SZ documentation
SUAZI
enumeration SD documentation
SUDAN
enumeration SS documentation
SUDAN POŁUDNIOWY
enumeration SR documentation
SURINAM
enumeration SJ documentation
SVALBARD I JAN MAYEN
enumeration SH documentation
ŚWIĘTA HELENA
enumeration SY documentation
SYRIA
enumeration CH documentation
SZWAJCARIA
enumeration SE documentation
SZWECJA
enumeration TJ documentation
TADŻYKISTAN
enumeration TH documentation
TAJLANDIA
enumeration TW documentation
TAJWAN
enumeration TZ documentation
TANZANIA
enumeration TG documentation
TOGO
enumeration TK documentation
TOKELAU
enumeration TO documentation
TONGA
enumeration TT documentation
TRYNIDAD I TOBAGO
enumeration TN documentation
TUNEZJA
enumeration TR documentation
TURCJA
enumeration TM documentation
TURKMENISTAN
enumeration TV documentation

---

TUVALU
enumeration UG documentation
UGANDA
enumeration UA documentation
UKRAINA
enumeration UY documentation
URUGWAJ
enumeration UZ documentation
UZBEKISTAN
enumeration VU documentation
VANUATU
enumeration WF documentation
WALLIS I FUTUNA
enumeration VA documentation
WATYKAN
enumeration HU documentation
WĘGRY
enumeration VE documentation
WENEZUELA
enumeration GB documentation
WIELKA BRYTANIA
enumeration VN documentation
WIETNAM
enumeration IT documentation
WŁOCHY
enumeration TL documentation
WSCHODNI TIMOR
enumeration CI documentation
WYBRZEŻE KOŚCI SŁONIOWEJ
enumeration BV documentation
WYSPA BOUVETA
enumeration CX documentation
WYSPA BOŻEGO NARODZENIA
enumeration IM documentation
WYSPA MAN
enumeration SX documentation
WYSPA SINT MAARTEN (CZĘŚĆ HOLENDERSKA WYSPY)
enumeration CK documentation
WYSPY COOKA
enumeration VI documentation
WYSPY DZIEWICZE-USA
enumeration VG documentation
WYSPY DZIEWICZE-W.B.
enumeration HM documentation
WYSPY HEARD I MCDONALD
enumeration CC documentation
WYSPY KOKOSOWE (KEELINGA)
enumeration MH documentation
WYSPY MARSHALLA
enumeration FO documentation
WYSPY OWCZE
enumeration SB documentation
WYSPY SALOMONA
enumeration ST documentation
WYSPY ŚWIĘTEGO TOMASZA I KSIĄŻĘCA
enumeration TC documentation
WYSPY TURKS I CAICOS
enumeration ZM documentation
ZAMBIA
enumeration CV documentation
ZIELONY PRZYLĄDEK
enumeration ZW documentation
ZIMBABWE
enumeration AE documentation
ZJEDNOCZONE EMIRATY ARABSKIE
enumeration XI documentation
ZJEDNOCZONE KRÓLESTWO (IRLANDIA PÓŁNOCNA)
documentation
annotation
Kod kraju nadania identyfikatora podatkowego

---

source <xsd:element name="KodKraju" type="etd:TKodKraju" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kod kraju nadania identyfikatora podatkowego</xsd:documentation>
</xsd:annotation>
</xsd:element>
element TPodmiot2/NrID
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of etd:TNrIdentyfikacjiPodatkowej
content simple
properties
Kind Value Annotation
facets
minLength 1
maxLength 50
whiteSpace replace
pattern [a-zA-Z0-9]{1,50}
documentation
annotation
Identyfikator podatkowy inny
source <xsd:element name="NrID">
<xsd:annotation>
<xsd:documentation>Identyfikator podatkowy inny</xsd:documentation>
</xsd:annotation>
<xsd:simpleType>
<xsd:restriction base="etd:TNrIdentyfikacjiPodatkowej">
<xsd:pattern value="[a-zA-Z0-9]{1,50}"/>
</xsd:restriction>
</xsd:simpleType>
</xsd:element>
element TPodmiot2/BrakID
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1
content simple
properties
Kind Value Annotation
facets
enumeration 1
documentation
annotation
Podmiot nie posiada identyfikatora podatkowego lub identyfikator nie występuje na fakturze: 1- tak
source <xsd:element name="BrakID" type="etd:TWybor1">
<xsd:annotation>

---

<xsd:documentation>Podmiot nie posiada identyfikatora podatkowego lub identyfikator nie
występuje na fakturze: 1- tak</xsd:documentation>
</xsd:annotation>
</xsd:element>
element TPodmiot2/Nazwa
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy512
content simple
properties
Kind Value Annotation
facets
minLength 1
maxLength 512
documentation
annotation
Imię i nazwisko lub nazwa
source <xsd:element name="Nazwa" type="tns:TZnakowy512">
<xsd:annotation>
<xsd:documentation>Imię i nazwisko lub nazwa</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

complexType TPodmiot3
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
children tns:NIP tns:IDWew tns:KodUE tns:NrVatUE tns:KodKraju tns:NrID tns:BrakID tns:Nazwa
element Faktura/Podmiot3/DaneIdentyfikacyjne
used by
documentation
annotation
Zestaw danych identyfikacyjnych oraz danych adresowych podmiotów trzecich
source <xsd:complexType name="TPodmiot3">
<xsd:annotation>
<xsd:documentation>Zestaw danych identyfikacyjnych oraz danych adresowych podmiotów
trzecich</xsd:documentation>
</xsd:annotation>
<xsd:sequence>
<xsd:choice>
<xsd:annotation>
<xsd:documentation>Numer, za pomocą którego nabywca towarów lub usług jest
identyfikowany dla podatku lub podatku od wartości dodanej, pod którym otrzymał on towary lub
usługi, z zastrzeżeniem art. 106e ust. 1 pkt 24 lit. b ustawy. Pole opcjonalne dla przypadku
określonego w art. 106e ust. 5 pkt 2 ustawy. W przypadku faktur wystawianych w procedurze
uproszczonej przez drugiego w kolejności podatnika, o którym mowa w art. 135 ust. 1 pkt 4 lit. b i c
oraz ust. 2 ustawy, numer, o którym mowa w art. 136 ust. 1 pkt 4 ustawy</xsd:documentation>
</xsd:annotation>
<xsd:element name="NIP" type="etd:TNrNIP">

---

<xsd:annotation>
<xsd:documentation>Identyfikator podatkowy NIP</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="IDWew" type="tns:TNIPIdWew">
<xsd:annotation>
<xsd:documentation>Identyfikator wewnętrzny z NIP</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:sequence>
<xsd:element name="KodUE" type="tns:TKodyKrajowUE">
<xsd:annotation>
<xsd:documentation>Kod (prefiks) nabywcy VAT UE, o którym mowa w art. 106e ust. 1
pkt 24 ustawy oraz w przypadku, o którym mowa w art. 136 ust. 1 pkt 4
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="NrVatUE" type="tns:TNrVatUE">
<xsd:annotation>
<xsd:documentation>Numer Identyfikacyjny VAT kontrahenta
UE</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:sequence>
<xsd:element name="KodKraju" type="etd:TKodKraju" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kod kraju nadania identyfikatora
podatkowego</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="NrID">
<xsd:annotation>
<xsd:documentation>Identyfikator podatkowy inny</xsd:documentation>
</xsd:annotation>
<xsd:simpleType>
<xsd:restriction base="etd:TNrIdentyfikacjiPodatkowej">
<xsd:pattern value="[a-zA-Z0-9]{1,50}"/>
</xsd:restriction>
</xsd:simpleType>
</xsd:element>
</xsd:sequence>
<xsd:element name="BrakID" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Podmiot nie posiada identyfikatora podatkowego lub identyfikator
nie występuje na fakturze: 1- tak</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:choice>
<xsd:sequence minOccurs="0">
<xsd:annotation>
<xsd:documentation>Dane opcjonalne dla przypadków, o których mowa w art. 106e ust. 5
pkt 3 ustawy</xsd:documentation>
</xsd:annotation>
<xsd:element name="Nazwa" type="tns:TZnakowy512">
<xsd:annotation>

---

<xsd:documentation>Imię i nazwisko lub nazwa</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:sequence>
</xsd:complexType>
element TPodmiot3/NIP
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TNrNIP
content simple
properties
Kind Value Annotation
facets
pattern [1-9]((\d[1-9])|([1-9]\d))\d{7}
documentation
annotation
Identyfikator podatkowy NIP
source <xsd:element name="NIP" type="etd:TNrNIP">
<xsd:annotation>
<xsd:documentation>Identyfikator podatkowy NIP</xsd:documentation>
</xsd:annotation>
</xsd:element>
element TPodmiot3/IDWew
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TNIPIdWew
content simple
properties
Kind Value Annotation
facets
minLength 1
maxLength 20
pattern [1-9]((\d[1-9])|([1-9]\d))\d{7}-\d{5}
documentation
annotation
Identyfikator wewnętrzny z NIP
source <xsd:element name="IDWew" type="tns:TNIPIdWew">
<xsd:annotation>
<xsd:documentation>Identyfikator wewnętrzny z NIP</xsd:documentation>
</xsd:annotation>
</xsd:element>

---

element TPodmiot3/KodUE
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TKodyKrajowUE
content simple
properties
Kind Value Annotation
facets
enumeration AT documentation
AUSTRIA
enumeration BE documentation
BELGIA
enumeration BG documentation
BUŁGARIA
enumeration CY documentation
CYPR
enumeration CZ documentation
CZECHY
enumeration DK documentation
DANIA
enumeration EE documentation
ESTONIA
enumeration FI documentation
FINLANDIA
enumeration FR documentation
FRANCJA
enumeration DE documentation
NIEMCY
enumeration EL documentation
GRECJA
enumeration HR documentation
CHORWACJA
enumeration HU documentation
WĘGRY
enumeration IE documentation
IRLANDIA
enumeration IT documentation
WŁOCHY
enumeration LV documentation
ŁOTWA
enumeration LT documentation
LITWA
enumeration LU documentation
LUKSEMBURG
enumeration MT documentation
MALTA
enumeration NL documentation
HOLANDIA
enumeration PL documentation
POLSKA
enumeration PT documentation
PORTUGALIA
enumeration RO documentation
RUMUNIA
enumeration SK documentation
SŁOWACJA
enumeration SI documentation
SŁOWENIA
enumeration ES documentation
HISZPANIA
enumeration SE documentation
SZWECJA

---

enumeration XI documentation
IRLANDIA PÓŁNOCNA
documentation
annotation
Kod (prefiks) nabywcy VAT UE, o którym mowa w art. 106e ust. 1 pkt 24 ustawy oraz w przypadku, o którym mowa w art.
136 ust. 1 pkt 4 ustawy
source <xsd:element name="KodUE" type="tns:TKodyKrajowUE">
<xsd:annotation>
<xsd:documentation>Kod (prefiks) nabywcy VAT UE, o którym mowa w art. 106e ust. 1 pkt 24
ustawy oraz w przypadku, o którym mowa w art. 136 ust. 1 pkt 4 ustawy</xsd:documentation>
</xsd:annotation>
</xsd:element>
element TPodmiot3/NrVatUE
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TNrVatUE
content simple
properties
Kind Value Annotation
facets
pattern (\d|[A-Z]|\+|\*){1,12}
documentation
annotation
Numer Identyfikacyjny VAT kontrahenta UE
source <xsd:element name="NrVatUE" type="tns:TNrVatUE">
<xsd:annotation>
<xsd:documentation>Numer Identyfikacyjny VAT kontrahenta UE</xsd:documentation>
</xsd:annotation>
</xsd:element>
element TPodmiot3/KodKraju
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TKodKraju
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
enumeration AF documentation
AFGANISTAN
enumeration AX documentation
ALAND ISLANDS
enumeration AL documentation
ALBANIA
enumeration DZ documentation
ALGIERIA
enumeration AD documentation
ANDORA
enumeration AO documentation

---

ANGOLA
enumeration AI documentation
ANGUILLA
enumeration AQ documentation
ANTARKTYDA
enumeration AG documentation
ANTIGUA I BARBUDA
enumeration AN documentation
ANTYLE HOLENDERSKIE
enumeration SA documentation
ARABIA SAUDYJSKA
enumeration AR documentation
ARGENTYNA
enumeration AM documentation
ARMENIA
enumeration AW documentation
ARUBA
enumeration AU documentation
AUSTRALIA
enumeration AT documentation
AUSTRIA
enumeration AZ documentation
AZERBEJDŻAN
enumeration BS documentation
BAHAMY
enumeration BH documentation
BAHRAJN
enumeration BD documentation
BANGLADESZ
enumeration BB documentation
BARBADOS
enumeration BE documentation
BELGIA
enumeration BZ documentation
BELIZE
enumeration BJ documentation
BENIN
enumeration BM documentation
BERMUDY
enumeration BT documentation
BHUTAN
enumeration BY documentation
BIAŁORUŚ
enumeration BO documentation
BOLIWIA
enumeration BQ documentation
BONAIRE, SINT EUSTATIUS I SABA
enumeration BA documentation
BOŚNIA I HERCEGOWINA
enumeration BW documentation
BOTSWANA
enumeration BR documentation
BRAZYLIA
enumeration BN documentation
BRUNEI DARUSSALAM
enumeration IO documentation
BRYTYJSKIE TERYTORIUM OCEANU INDYJSKIEGO
enumeration BG documentation
BUŁGARIA
enumeration BF documentation
BURKINA FASO
enumeration BI documentation
BURUNDI
enumeration XC documentation
CEUTA
enumeration CL documentation
CHILE
enumeration CN documentation
CHINY
enumeration HR documentation

---

CHORWACJA
enumeration CW documentation
CURAÇAO
enumeration CY documentation
CYPR
enumeration TD documentation
CZAD
enumeration ME documentation
CZARNOGÓRA
enumeration DK documentation
DANIA
enumeration DM documentation
DOMINIKA
enumeration DO documentation
DOMINIKANA
enumeration DJ documentation
DŻIBUTI
enumeration EG documentation
EGIPT
enumeration EC documentation
EKWADOR
enumeration ER documentation
ERYTREA
enumeration EE documentation
ESTONIA
enumeration ET documentation
ETIOPIA
enumeration FK documentation
FALKLANDY
enumeration FJ documentation
FIDŻI REPUBLIKA
enumeration PH documentation
FILIPINY
enumeration FI documentation
FINLANDIA
enumeration FR documentation
FRANCJA
enumeration TF documentation
FRANCUSKIE TERYTORIUM POŁUDNIOWE
enumeration GA documentation
GABON
enumeration GM documentation
GAMBIA
enumeration GH documentation
GHANA
enumeration GI documentation
GIBRALTAR
enumeration GR documentation
GRECJA
enumeration GD documentation
GRENADA
enumeration GL documentation
GRENLANDIA
enumeration GE documentation
GRUZJA
enumeration GU documentation
GUAM
enumeration GG documentation
GUERNSEY
enumeration GY documentation
GUJANA
enumeration GF documentation
GUJANA FRANCUSKA
enumeration GP documentation
GWADELUPA
enumeration GT documentation
GWATEMALA
enumeration GN documentation
GWINEA
enumeration GQ documentation

---

GWINEA RÓWNIKOWA
enumeration GW documentation
GWINEA-BISSAU
enumeration HT documentation
HAITI
enumeration ES documentation
HISZPANIA
enumeration HN documentation
HONDURAS
enumeration HK documentation
HONGKONG
enumeration IN documentation
INDIE
enumeration ID documentation
INDONEZJA
enumeration IQ documentation
IRAK
enumeration IR documentation
IRAN
enumeration IE documentation
IRLANDIA
enumeration IS documentation
ISLANDIA
enumeration IL documentation
IZRAEL
enumeration JM documentation
JAMAJKA
enumeration JP documentation
JAPONIA
enumeration YE documentation
JEMEN
enumeration JE documentation
JERSEY
enumeration JO documentation
JORDANIA
enumeration KY documentation
KAJMANY
enumeration KH documentation
KAMBODŻA
enumeration CM documentation
KAMERUN
enumeration CA documentation
KANADA
enumeration QA documentation
KATAR
enumeration KZ documentation
KAZACHSTAN
enumeration KE documentation
KENIA
enumeration KG documentation
KIRGISTAN
enumeration KI documentation
KIRIBATI
enumeration CO documentation
KOLUMBIA
enumeration KM documentation
KOMORY
enumeration CG documentation
KONGO
enumeration CD documentation
KONGO, REPUBLIKA DEMOKRATYCZNA
enumeration KP documentation
KOREAŃSKA REPUBLIKA LUDOWO-DEMOKRATYCZNA
enumeration XK documentation
KOSOWO
enumeration CR documentation
KOSTARYKA
enumeration CU documentation
KUBA
enumeration KW documentation

---

KUWEJT
enumeration LA documentation
LAOS
enumeration LS documentation
LESOTHO
enumeration LB documentation
LIBAN
enumeration LR documentation
LIBERIA
enumeration LY documentation
LIBIA
enumeration LI documentation
LIECHTENSTEIN
enumeration LT documentation
LITWA
enumeration LV documentation
ŁOTWA
enumeration LU documentation
LUKSEMBURG
enumeration MK documentation
MACEDONIA
enumeration MG documentation
MADAGASKAR
enumeration YT documentation
MAJOTTA
enumeration MO documentation
MAKAU
enumeration MW documentation
MALAWI
enumeration MV documentation
MALEDIWY
enumeration MY documentation
MALEZJA
enumeration ML documentation
MALI
enumeration MT documentation
MALTA
enumeration MP documentation
MARIANY PÓŁNOCNE
enumeration MA documentation
MAROKO
enumeration MQ documentation
MARTYNIKA
enumeration MR documentation
MAURETANIA
enumeration MU documentation
MAURITIUS
enumeration MX documentation
MEKSYK
enumeration XL documentation
MELILLA
enumeration FM documentation
MIKRONEZJA
enumeration UM documentation
MINOR
enumeration MD documentation
MOŁDOWA
enumeration MC documentation
MONAKO
enumeration MN documentation
MONGOLIA
enumeration MS documentation
MONTSERRAT
enumeration MZ documentation
MOZAMBIK
enumeration MM documentation
MYANMAR (BURMA)
enumeration NA documentation
NAMIBIA
enumeration NR documentation

---

NAURU
enumeration NP documentation
NEPAL
enumeration NL documentation
NIDERLANDY (HOLANDIA)
enumeration DE documentation
NIEMCY
enumeration NE documentation
NIGER
enumeration NG documentation
NIGERIA
enumeration NI documentation
NIKARAGUA
enumeration NU documentation
NIUE
enumeration NF documentation
NORFOLK
enumeration NO documentation
NORWEGIA
enumeration NC documentation
NOWA KALEDONIA
enumeration NZ documentation
NOWA ZELANDIA
enumeration PS documentation
OKUPOWANE TERYTORIUM PALESTYNY
enumeration OM documentation
OMAN
enumeration PK documentation
PAKISTAN
enumeration PW documentation
PALAU
enumeration PA documentation
PANAMA
enumeration PG documentation
PAPUA NOWA GWINEA
enumeration PY documentation
PARAGWAJ
enumeration PE documentation
PERU
enumeration PN documentation
PITCAIRN
enumeration PF documentation
POLINEZJA FRANCUSKA
enumeration PL documentation
POLSKA
enumeration GS documentation
POŁUDNIOWA GEORGIA I POŁUD.WYSPY SANDWICH
enumeration PT documentation
PORTUGALIA
enumeration PR documentation
PORTORYKO
enumeration CF documentation
REP.ŚRODKOWOAFRYKAŃSKA
enumeration CZ documentation
REPUBLIKA CZESKA
enumeration KR documentation
REPUBLIKA KOREI
enumeration ZA documentation
REPUBLIKA POŁUDNIOWEJ AFRYKI
enumeration RE documentation
REUNION
enumeration RU documentation
ROSJA
enumeration RO documentation
RUMUNIA
enumeration RW documentation
RWANDA
enumeration EH documentation
SAHARA ZACHODNIA
enumeration BL documentation

---

SAINT BARTHELEMY
enumeration KN documentation
SAINT KITTS I NEVIS
enumeration LC documentation
SAINT LUCIA
enumeration MF documentation
SAINT MARTIN
enumeration VC documentation
SAINT VINCENT I GRENADYNY
enumeration SV documentation
SALWADOR
enumeration WS documentation
SAMOA
enumeration AS documentation
SAMOA AMERYKAŃSKIE
enumeration SM documentation
SAN MARINO
enumeration SN documentation
SENEGAL
enumeration RS documentation
SERBIA
enumeration SC documentation
SESZELE
enumeration SL documentation
SIERRA LEONE
enumeration SG documentation
SINGAPUR
enumeration SK documentation
SŁOWACJA
enumeration SI documentation
SŁOWENIA
enumeration SO documentation
SOMALIA
enumeration LK documentation
SRI LANKA
enumeration PM documentation
SAINT PIERRE I MIQUELON
enumeration US documentation
STANY ZJEDNOCZONE AMERYKI
enumeration SZ documentation
SUAZI
enumeration SD documentation
SUDAN
enumeration SS documentation
SUDAN POŁUDNIOWY
enumeration SR documentation
SURINAM
enumeration SJ documentation
SVALBARD I JAN MAYEN
enumeration SH documentation
ŚWIĘTA HELENA
enumeration SY documentation
SYRIA
enumeration CH documentation
SZWAJCARIA
enumeration SE documentation
SZWECJA
enumeration TJ documentation
TADŻYKISTAN
enumeration TH documentation
TAJLANDIA
enumeration TW documentation
TAJWAN
enumeration TZ documentation
TANZANIA
enumeration TG documentation
TOGO
enumeration TK documentation
TOKELAU
enumeration TO documentation

---

TONGA
enumeration TT documentation
TRYNIDAD I TOBAGO
enumeration TN documentation
TUNEZJA
enumeration TR documentation
TURCJA
enumeration TM documentation
TURKMENISTAN
enumeration TV documentation
TUVALU
enumeration UG documentation
UGANDA
enumeration UA documentation
UKRAINA
enumeration UY documentation
URUGWAJ
enumeration UZ documentation
UZBEKISTAN
enumeration VU documentation
VANUATU
enumeration WF documentation
WALLIS I FUTUNA
enumeration VA documentation
WATYKAN
enumeration HU documentation
WĘGRY
enumeration VE documentation
WENEZUELA
enumeration GB documentation
WIELKA BRYTANIA
enumeration VN documentation
WIETNAM
enumeration IT documentation
WŁOCHY
enumeration TL documentation
WSCHODNI TIMOR
enumeration CI documentation
WYBRZEŻE KOŚCI SŁONIOWEJ
enumeration BV documentation
WYSPA BOUVETA
enumeration CX documentation
WYSPA BOŻEGO NARODZENIA
enumeration IM documentation
WYSPA MAN
enumeration SX documentation
WYSPA SINT MAARTEN (CZĘŚĆ HOLENDERSKA WYSPY)
enumeration CK documentation
WYSPY COOKA
enumeration VI documentation
WYSPY DZIEWICZE-USA
enumeration VG documentation
WYSPY DZIEWICZE-W.B.
enumeration HM documentation
WYSPY HEARD I MCDONALD
enumeration CC documentation
WYSPY KOKOSOWE (KEELINGA)
enumeration MH documentation
WYSPY MARSHALLA
enumeration FO documentation
WYSPY OWCZE
enumeration SB documentation
WYSPY SALOMONA
enumeration ST documentation
WYSPY ŚWIĘTEGO TOMASZA I KSIĄŻĘCA
enumeration TC documentation
WYSPY TURKS I CAICOS
enumeration ZM documentation
ZAMBIA
enumeration CV documentation

---

ZIELONY PRZYLĄDEK
enumeration ZW documentation
ZIMBABWE
enumeration AE documentation
ZJEDNOCZONE EMIRATY ARABSKIE
enumeration XI documentation
ZJEDNOCZONE KRÓLESTWO (IRLANDIA PÓŁNOCNA)
documentation
annotation
Kod kraju nadania identyfikatora podatkowego
source <xsd:element name="KodKraju" type="etd:TKodKraju" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kod kraju nadania identyfikatora podatkowego</xsd:documentation>
</xsd:annotation>
</xsd:element>
element TPodmiot3/NrID
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of etd:TNrIdentyfikacjiPodatkowej
content simple
properties
Kind Value Annotation
facets
minLength 1
maxLength 50
whiteSpace replace
pattern [a-zA-Z0-9]{1,50}
documentation
annotation
Identyfikator podatkowy inny
source <xsd:element name="NrID">
<xsd:annotation>
<xsd:documentation>Identyfikator podatkowy inny</xsd:documentation>
</xsd:annotation>
<xsd:simpleType>
<xsd:restriction base="etd:TNrIdentyfikacjiPodatkowej">
<xsd:pattern value="[a-zA-Z0-9]{1,50}"/>
</xsd:restriction>
</xsd:simpleType>
</xsd:element>
element TPodmiot3/BrakID
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type etd:TWybor1

---

content simple
properties
Kind Value Annotation
facets
enumeration 1
documentation
annotation
Podmiot nie posiada identyfikatora podatkowego lub identyfikator nie występuje na fakturze: 1- tak
source <xsd:element name="BrakID" type="etd:TWybor1">
<xsd:annotation>
<xsd:documentation>Podmiot nie posiada identyfikatora podatkowego lub identyfikator nie
występuje na fakturze: 1- tak</xsd:documentation>
</xsd:annotation>
</xsd:element>
element TPodmiot3/Nazwa
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy512
content simple
properties
Kind Value Annotation
facets
minLength 1
maxLength 512
documentation
annotation
Imię i nazwisko lub nazwa
source <xsd:element name="Nazwa" type="tns:TZnakowy512">
<xsd:annotation>
<xsd:documentation>Imię i nazwisko lub nazwa</xsd:documentation>
</xsd:annotation>
</xsd:element>
complexType TRachunekBankowy
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/

---

children tns:NrRB tns:SWIFT tns:RachunekWlasnyBanku tns:NazwaBanku tns:OpisRachunku
elements Faktura/Fa/Platnosc/RachunekBankowy Faktura/Fa/Platnosc/RachunekBankowyFaktora
used by
documentation
annotation
Informacje o rachunku
source <xsd:complexType name="TRachunekBankowy">
<xsd:annotation>
<xsd:documentation>Informacje o rachunku</xsd:documentation>
</xsd:annotation>
<xsd:sequence>
<xsd:sequence>
<xsd:element name="NrRB" type="tns:TNrRB">
<xsd:annotation>
<xsd:documentation>Pełny numer rachunku</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="SWIFT" type="tns:SWIFT_Type" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kod SWIFT</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
<xsd:element name="RachunekWlasnyBanku" type="tns:TRachunekWlasnyBanku"
minOccurs="0">
<xsd:annotation>
<xsd:documentation>Rachunek własny</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="NazwaBanku" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Nazwa</xsd:documentation>
</xsd:annotation>
</xsd:element>
<xsd:element name="OpisRachunku" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Opis rachunku</xsd:documentation>
</xsd:annotation>
</xsd:element>
</xsd:sequence>
</xsd:complexType>
element TRachunekBankowy/NrRB
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TNrRB
content simple
properties
Kind Value Annotation
facets
pattern [0-9A-Z]{10,32}
documentation
annotation
Pełny numer rachunku

---

source <xsd:element name="NrRB" type="tns:TNrRB">
<xsd:annotation>
<xsd:documentation>Pełny numer rachunku</xsd:documentation>
</xsd:annotation>
</xsd:element>
element TRachunekBankowy/SWIFT
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:SWIFT_Type
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
pattern [A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3}){0,1}
documentation
annotation
Kod SWIFT
source <xsd:element name="SWIFT" type="tns:SWIFT_Type" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Kod SWIFT</xsd:documentation>
</xsd:annotation>
</xsd:element>
element TRachunekBankowy/RachunekWlasnyBanku
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TRachunekWlasnyBanku
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
enumeration 1 documentation
Rachunek banku lub rachunek spółdzielczej kasy oszczędnościowo-kredytowej służący do
dokonywania rozliczeń z tytułu nabywanych przez ten bank lub tę kasę wierzytelności
pieniężnych
enumeration 2 documentation
Rachunek banku lub rachunek spółdzielczej kasy oszczędnościowo-kredytowej
wykorzystywany przez ten bank lub tę kasę do pobrania należności od nabywcy towarów lub
usługobiorcy za dostawę towarów lub świadczenie usług, potwierdzone fakturą, i przekazania
jej w całości albo części dostawcy towarów lub usługodawcy
enumeration 3 documentation
Rachunek banku lub rachunek spółdzielczej kasy oszczędnościowo-kredytowej prowadzony
przez ten bank lub tę kasę w ramach gospodarki własnej, niebędący rachunkiem
rozliczeniowym
documentation
annotation
Rachunek własny
source <xsd:element name="RachunekWlasnyBanku" type="tns:TRachunekWlasnyBanku"
minOccurs="0">

---

<xsd:annotation>
<xsd:documentation>Rachunek własny</xsd:documentation>
</xsd:annotation>
</xsd:element>
element TRachunekBankowy/NazwaBanku
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Nazwa
source <xsd:element name="NazwaBanku" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Nazwa</xsd:documentation>
</xsd:annotation>
</xsd:element>
element TRachunekBankowy/OpisRachunku
diagram
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type tns:TZnakowy
minOcc 0
properties
maxOcc 1
content simple
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Opis rachunku
source <xsd:element name="OpisRachunku" type="tns:TZnakowy" minOccurs="0">
<xsd:annotation>
<xsd:documentation>Opis rachunku</xsd:documentation>
</xsd:annotation>
</xsd:element>
simpleType SWIFT_Type
namespace http://crd.gov.pl/wzor/2023/06/29/12648/

---

type restriction of xsd:string
base xsd:string
properties
element TRachunekBankowy/SWIFT
used by
Kind Value Annotation
facets
pattern [A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3}){0,1}
documentation
annotation
Kod SWIFT
source <xsd:simpleType name="SWIFT_Type">
<xsd:annotation>
<xsd:documentation>Kod SWIFT</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="xsd:string">
<xsd:pattern value="[A-Z]{6}[A-Z0-9]{2}([A-Z0-9]{3}){0,1}"/>
</xsd:restriction>
</xsd:simpleType>
simpleType TData
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of etd:TData
base etd:TData
properties
elements Faktura/Fa/WarunkiTransakcji/Umowy/DataUmowy
used by
Faktura/Fa/WarunkiTransakcji/Zamowienia/DataZamowienia Faktura/Fa/Platnosc/DataZaplaty
Faktura/Fa/Platnosc/ZaplataCzesciowa/DataZaplatyCzesciowej
Faktura/Fa/Platnosc/TerminPlatnosci/Termin
Kind Value Annotation
facets
minInclusive 2016-07-01
maxInclusive 2050-01-01
pattern ((\d{4})-(\d{2})-(\d{2}))
documentation
annotation
Data zdarzenia w okresie od 2016-07-01 do 2050-01-01
source <xsd:simpleType name="TData">
<xsd:annotation>
<xsd:documentation>Data zdarzenia w okresie od 2016-07-01 do
2050-01-01</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="etd:TData">
<xsd:minInclusive value="2016-07-01"/>
<xsd:maxInclusive value="2050-01-01"/>
</xsd:restriction>
</xsd:simpleType>
simpleType TDataCzas
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of etd:TDataCzas
base etd:TDataCzas
properties
elements Faktura/Fa/WarunkiTransakcji/Transport/DataGodzRozpTransportu
used by
Faktura/Fa/WarunkiTransakcji/Transport/DataGodzZakTransportu
Kind Value Annotation
facets

---

minInclusive 2021-10-01T00:00:00Z
maxInclusive 2050-01-01T23:59:59Z
whiteSpace collapse
documentation
annotation
Data i czas zdarzenia w okresie od 01.10.2021T00:00:00Z do 01.01.2050T23:59:59Z
source <xsd:simpleType name="TDataCzas">
<xsd:annotation>
<xsd:documentation>Data i czas zdarzenia w okresie od 01.10.2021T00:00:00Z do
01.01.2050T23:59:59Z</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="etd:TDataCzas">
<xsd:minInclusive value="2021-10-01T00:00:00Z"/>
<xsd:maxInclusive value="2050-01-01T23:59:59Z"/>
</xsd:restriction>
</xsd:simpleType>
simpleType TDataT
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of etd:TData
base etd:TData
properties
elements Faktura/Fa/DaneFaKorygowanej/DataWystFaKorygowanej Faktura/Fa/P_1
used by
Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22A Faktura/Fa/P_6
Faktura/Fa/OkresFa/P_6_Do Faktura/Fa/OkresFa/P_6_Od Faktura/Fa/FaWiersz/P_6A
Faktura/Fa/ZaliczkaCzesciowa/P_6Z
Kind Value Annotation
facets
minInclusive 2006-01-01
maxInclusive 2050-01-01
pattern ((\d{4})-(\d{2})-(\d{2}))
documentation
annotation
Data zdarzenia w okresie od 2006-01-01 do 2050-01-01
source <xsd:simpleType name="TDataT">
<xsd:annotation>
<xsd:documentation>Data zdarzenia w okresie od 2006-01-01 do
2050-01-01</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="etd:TData">
<xsd:minInclusive value="2006-01-01"/>
<xsd:maxInclusive value="2050-01-01"/>
</xsd:restriction>
</xsd:simpleType>
simpleType TFormaPlatnosci
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of xsd:integer
base xsd:integer
properties
element Faktura/Fa/Platnosc/FormaPlatnosci
used by
Kind Value Annotation
facets
enumeration 1 documentation
Gotówka

---

enumeration 2 documentation
Karta
enumeration 3 documentation
Bon
enumeration 4 documentation
Czek
enumeration 5 documentation
Kredyt
enumeration 6 documentation
Przelew
enumeration 7 documentation
Mobilna
documentation
annotation
Typy form płatności
source <xsd:simpleType name="TFormaPlatnosci">
<xsd:annotation>
<xsd:documentation>Typy form płatności</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="xsd:integer">
<xsd:enumeration value="1">
<xsd:annotation>
<xsd:documentation>Gotówka</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="2">
<xsd:annotation>
<xsd:documentation>Karta</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="3">
<xsd:annotation>
<xsd:documentation>Bon</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="4">
<xsd:annotation>
<xsd:documentation>Czek</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="5">
<xsd:annotation>
<xsd:documentation>Kredyt</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="6">
<xsd:annotation>
<xsd:documentation>Przelew</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="7">
<xsd:annotation>
<xsd:documentation>Mobilna</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
</xsd:restriction>
</xsd:simpleType>

---

simpleType TGLN
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of xsd:token
base xsd:token
properties
element TAdres/GLN
used by
Kind Value Annotation
facets
minLength 1
maxLength 13
documentation
annotation
Typ Globalnego Numeru Lokalizacyjnego
source <xsd:simpleType name="TGLN">
<xsd:annotation>
<xsd:documentation>Typ Globalnego Numeru Lokalizacyjnego</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="xsd:token">
<xsd:minLength value="1"/>
<xsd:maxLength value="13"/>
</xsd:restriction>
</xsd:simpleType>
simpleType TGTU
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of tns:TZnakowy
base tns:TZnakowy
properties
elements Faktura/Fa/FaWiersz/GTU Faktura/Fa/Zamowienie/ZamowienieWiersz/GTUZ
used by
Kind Value Annotation
facets
minLength 1
maxLength 256
enumeration GTU_01 documentation
Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. a rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_02 documentation
Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. b rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_03 documentation
Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. c rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_04 documentation
Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. d rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_05 documentation
Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. e rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_06 documentation
Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. f rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_07 documentation
Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. g rozporządzenia w sprawie

---

szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_08 documentation
Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. h rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_09 documentation
Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. i rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_10 documentation
Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. j rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_11 documentation
Świadczenie usług, o których mowa w § 10 ust. 3 pkt 2 lit. a rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_12 documentation
Świadczenie usług, o których mowa w § 10 ust. 3 pkt 2 lit. b rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
enumeration GTU_13 documentation
Świadczenie usług, o których mowa w § 10 ust. 3 pkt 2 lit. c rozporządzenia w sprawie
szczegółowego zakresu danych zawartych w deklaracjach podatkowych i w ewidencji w
zakresie podatku od towarów i usług
documentation
annotation
Oznaczenie dotyczące dostawy towarów i świadczenia usług
source <xsd:simpleType name="TGTU">
<xsd:annotation>
<xsd:documentation>Oznaczenie dotyczące dostawy towarów i świadczenia
usług</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="tns:TZnakowy">
<xsd:enumeration value="GTU_01">
<xsd:annotation>
<xsd:documentation>Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. a
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w deklaracjach podatkowych
i w ewidencji w zakresie podatku od towarów i usług</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="GTU_02">
<xsd:annotation>
<xsd:documentation>Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. b
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w deklaracjach podatkowych
i w ewidencji w zakresie podatku od towarów i usług</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="GTU_03">
<xsd:annotation>
<xsd:documentation>Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. c
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w deklaracjach podatkowych
i w ewidencji w zakresie podatku od towarów i usług</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="GTU_04">
<xsd:annotation>
<xsd:documentation>Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. d
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w deklaracjach podatkowych
i w ewidencji w zakresie podatku od towarów i usług</xsd:documentation>
</xsd:annotation>

---

</xsd:enumeration>
<xsd:enumeration value="GTU_05">
<xsd:annotation>
<xsd:documentation>Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. e
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w deklaracjach podatkowych
i w ewidencji w zakresie podatku od towarów i usług</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="GTU_06">
<xsd:annotation>
<xsd:documentation>Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. f
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w deklaracjach podatkowych
i w ewidencji w zakresie podatku od towarów i usług</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="GTU_07">
<xsd:annotation>
<xsd:documentation>Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. g
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w deklaracjach podatkowych
i w ewidencji w zakresie podatku od towarów i usług</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="GTU_08">
<xsd:annotation>
<xsd:documentation>Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. h
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w deklaracjach podatkowych
i w ewidencji w zakresie podatku od towarów i usług</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="GTU_09">
<xsd:annotation>
<xsd:documentation>Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. i
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w deklaracjach podatkowych
i w ewidencji w zakresie podatku od towarów i usług</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="GTU_10">
<xsd:annotation>
<xsd:documentation>Dostawa towarów, o których mowa w § 10 ust. 3 pkt 1 lit. j
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w deklaracjach podatkowych
i w ewidencji w zakresie podatku od towarów i usług</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="GTU_11">
<xsd:annotation>
<xsd:documentation>Świadczenie usług, o których mowa w § 10 ust. 3 pkt 2 lit. a
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w deklaracjach podatkowych
i w ewidencji w zakresie podatku od towarów i usług</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="GTU_12">
<xsd:annotation>
<xsd:documentation>Świadczenie usług, o których mowa w § 10 ust. 3 pkt 2 lit. b
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w deklaracjach podatkowych
i w ewidencji w zakresie podatku od towarów i usług</xsd:documentation>
</xsd:annotation>

---

</xsd:enumeration>
<xsd:enumeration value="GTU_13">
<xsd:annotation>
<xsd:documentation>Świadczenie usług, o których mowa w § 10 ust. 3 pkt 2 lit. c
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w deklaracjach podatkowych
i w ewidencji w zakresie podatku od towarów i usług</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
</xsd:restriction>
</xsd:simpleType>
simpleType TIlosci
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of xsd:decimal
base xsd:decimal
properties
elements Faktura/Fa/WarunkiTransakcji/KursUmowny Faktura/Fa/FaWiersz/KursWaluty
used by
Faktura/Fa/KursWalutyZ Faktura/Fa/KursWalutyZK Faktura/Fa/ZaliczkaCzesciowa/KursWalutyZW
Faktura/Fa/FaWiersz/P_8B Faktura/Fa/Zamowienie/ZamowienieWiersz/P_8BZ
Kind Value Annotation
facets
totalDigits 22
fractionDigits 6
pattern -?([1-9]\d{0,15}|0)(\.\d{1,6})?
documentation
annotation
Typ wykorzystywany do określenia ilości. Wartość numeryczna 22 znaki max, w tym 6 po przecinku
source <xsd:simpleType name="TIlosci">
<xsd:annotation>
<xsd:documentation>Typ wykorzystywany do określenia ilości. Wartość numeryczna 22 znaki
max, w tym 6 po przecinku</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="xsd:decimal">
<xsd:totalDigits value="22"/>
<xsd:fractionDigits value="6"/>
<xsd:pattern value="-?([1-9]\d{0,15}|0)(\.\d{1,6})?"/>
</xsd:restriction>
</xsd:simpleType>
simpleType TKodFormularza
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of xsd:string
base xsd:string
properties
element TNaglowek/KodFormularza
used by
Kind Value Annotation
facets
enumeration FA
documentation
annotation
Symbol wzoru formularza
source <xsd:simpleType name="TKodFormularza">
<xsd:annotation>
<xsd:documentation>Symbol wzoru formularza</xsd:documentation>
</xsd:annotation>

---

<xsd:restriction base="xsd:string">
<xsd:enumeration value="FA"/>
</xsd:restriction>
</xsd:simpleType>
simpleType TKodWaluty
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of xsd:normalizedString
base xsd:normalizedString
properties
elements Faktura/Fa/KodWaluty Faktura/Fa/WarunkiTransakcji/WalutaUmowna
used by
Kind Value Annotation
facets
enumeration AED documentation
DIRHAM ZEA
enumeration AFN documentation
AFGANI
enumeration ALL documentation
LEK
enumeration AMD documentation
DRAM
enumeration ANG documentation
GULDEN ANTYLI HOLENDERSKICH
enumeration AOA documentation
KWANZA
enumeration ARS documentation
PESO ARGENTYŃSKIE
enumeration AUD documentation
DOLAR AUSTRALIJSKI
enumeration AWG documentation
GULDEN ARUBAŃSKI
enumeration AZN documentation
MANAT AZERBEJDŻAŃSKI
enumeration BAM documentation
MARKA ZAMIENNA
enumeration BBD documentation
DOLAR BARBADOSKI
enumeration BDT documentation
TAKA
enumeration BGN documentation
LEW
enumeration BHD documentation
DINAR BAHRAJSKI
enumeration BIF documentation
FRANK BURUNDYJSKI
enumeration BMD documentation
DOLAR BERMUDZKI
enumeration BND documentation
DOLAR BRUNEJSKI
enumeration BOB documentation
BOLIWIANO
enumeration BOV documentation
BOLIWIANO MVDOL
enumeration BRL documentation
REAL
enumeration BSD documentation
DOLAR BAHAMSKI
enumeration BTN documentation
NGULTRUM
enumeration BWP documentation
PULA
enumeration BYN documentation
RUBEL BIAŁORUSKI
enumeration BZD documentation
DOLAR BELIZEŃSKI

---

enumeration CAD documentation
DOLAR KANADYJSKI
enumeration CDF documentation
FRANK KONGIJSKI
enumeration CHE documentation
FRANK SZWAJCARSKI VIR EURO
enumeration CHF documentation
FRANK SZWAJCARSKI
enumeration CHW documentation
FRANK SZWAJCARSKI VIR FRANK
enumeration CLF documentation
JEDNOSTKA ROZLICZENIOWA CHILIJSKA
enumeration CLP documentation
PESO CHILIJSKIE
enumeration CNY documentation
YUAN RENMINBI
enumeration COP documentation
PESO KOLUMBIJSKIE
enumeration COU documentation
UNIDAD DE VALOR REAL KOLUMBILSKIE
enumeration CRC documentation
COLON KOSTARYKAŃSKI
enumeration CUC documentation
PESO WYMIENIALNE
enumeration CUP documentation
PESO KUBAŃSKIE
enumeration CVE documentation
ESCUDO REPUBLIKI ZIELONEGO PRZYLĄDKA
enumeration CZK documentation
KORONA CZESKA
enumeration DJF documentation
FRANK DŻIBUTI
enumeration DKK documentation
KORONA DUŃSKA
enumeration DOP documentation
PESO DOMINIKAŃSKIE
enumeration DZD documentation
DINAR ALGIERSKI
enumeration EGP documentation
FUNT EGIPSKI
enumeration ERN documentation
NAKFA
enumeration ETB documentation
BIRR
enumeration EUR documentation
EURO
enumeration FJD documentation
DOLAR FIDŻI
enumeration FKP documentation
FUNT FALKLANDZKI
enumeration GBP documentation
FUNT SZTERLING
enumeration GEL documentation
LARI
enumeration GGP documentation
FUNT GUERNSEY
enumeration GHS documentation
GHANA CEDI
enumeration GIP documentation
FUNT GIBRALTARSKI
enumeration GMD documentation
DALASI
enumeration GNF documentation
FRANK GWINEJSKI
enumeration GTQ documentation
QUETZAL
enumeration GYD documentation
DOLAR GUJAŃSKI
enumeration HKD documentation
DOLAR HONGKONGU

---

enumeration HNL documentation
LEMPIRA
enumeration HRK documentation
KUNA
enumeration HTG documentation
GOURDE
enumeration HUF documentation
FORINT
enumeration IDR documentation
RUPIA INDONEZYJSKA
enumeration ILS documentation
SZEKEL
enumeration IMP documentation
FUNT MANX
enumeration INR documentation
RUPIA INDYJSKA
enumeration IQD documentation
DINAR IRACKI
enumeration IRR documentation
RIAL IRAŃSKI
enumeration ISK documentation
KORONA ISLANDZKA
enumeration JEP documentation
FUNT JERSEY
enumeration JMD documentation
DOLAR JAMAJSKI
enumeration JOD documentation
DINAR JORDAŃSKI
enumeration JPY documentation
JEN
enumeration KES documentation
SZYLING KENIJSKI
enumeration KGS documentation
SOM
enumeration KHR documentation
RIEL
enumeration KMF documentation
FRANK KOMORÓW
enumeration KPW documentation
WON PÓŁNOCNO­KOREAŃSKI
enumeration KRW documentation
WON POŁUDNIOWO­KOREAŃSKI
enumeration KWD documentation
DINAR KUWEJCKI
enumeration KYD documentation
DOLAR KAJMAŃSKI
enumeration KZT documentation
TENGE
enumeration LAK documentation
KIP
enumeration LBP documentation
FUNT LIBAŃSKI
enumeration LKR documentation
RUPIA LANKIJSKA
enumeration LRD documentation
DOLAR LIBERYJSKI
enumeration LSL documentation
LOTI
enumeration LYD documentation
DINAR LIBIJSKI
enumeration MAD documentation
DIRHAM MAROKAŃSKI
enumeration MDL documentation
LEJ MOŁDAWII
enumeration MGA documentation
ARIARY
enumeration MKD documentation
DENAR
enumeration MMK documentation
KYAT

---

enumeration MNT documentation
TUGRIK
enumeration MOP documentation
PATACA
enumeration MRU documentation
OUGUIYA
enumeration MUR documentation
RUPIA MAURITIUSU
enumeration MVR documentation
RUPIA MALEDIWSKA
enumeration MWK documentation
KWACHA MALAWIJSKA
enumeration MXN documentation
PESO MEKSYKAŃSKIE
enumeration MXV documentation
UNIDAD DE INVERSION (UDI) MEKSYKAŃSKIE
enumeration MYR documentation
RINGGIT
enumeration MZN documentation
METICAL
enumeration NAD documentation
DOLAR NAMIBIJSKI
enumeration NGN documentation
NAIRA
enumeration NIO documentation
CORDOBA ORO
enumeration NOK documentation
KORONA NORWESKA
enumeration NPR documentation
RUPIA NEPALSKA
enumeration NZD documentation
DOLAR NOWOZELANDZKI
enumeration OMR documentation
RIAL OMAŃSKI
enumeration PAB documentation
BALBOA
enumeration PEN documentation
SOL
enumeration PGK documentation
KINA
enumeration PHP documentation
PESO FILIPIŃSKIE
enumeration PKR documentation
RUPIA PAKISTAŃSKA
enumeration PLN documentation
ZŁOTY
enumeration PYG documentation
GUARANI
enumeration QAR documentation
RIAL KATARSKI
enumeration RON documentation
LEJ RUMUŃSKI
enumeration RSD documentation
DINAR SERBSKI
enumeration RUB documentation
RUBEL ROSYJSKI
enumeration RWF documentation
FRANK RWANDYJSKI
enumeration SAR documentation
RIAL SAUDYJSKI
enumeration SBD documentation
DOLAR WYSP SALOMONA
enumeration SCR documentation
RUPIA SESZELSKA
enumeration SDG documentation
FUNT SUDAŃSKI
enumeration SEK documentation
KORONA SZWEDZKA
enumeration SGD documentation
DOLAR SINGAPURSKI

---

enumeration SHP documentation
FUNT ŚWIĘTEJ HELENY (ŚWIĘTA HELENA I WYSPA WNIEBOWSTĄPIENIA)
enumeration SLL documentation
LEONE
enumeration SOS documentation
SZYLING SOMALIJSKI
enumeration SRD documentation
DOLAR SURINAMSKI
enumeration SSP documentation
FUNT POŁUDNIOWOSUDAŃSKI
enumeration STN documentation
DOBRA
enumeration SVC documentation
COLON SALWADORSKI (SV1)
enumeration SYP documentation
FUNT SYRYJSKI
enumeration SZL documentation
LILANGENI
enumeration THB documentation
BAT
enumeration TJS documentation
SOMONI
enumeration TMT documentation
MANAT TURKMEŃSKI
enumeration TND documentation
DINAR TUNEZYJSKI
enumeration TOP documentation
PAANGA
enumeration TRY documentation
LIRA TURECKA
enumeration TTD documentation
DOLAR TRYNIDADU I TOBAGO
enumeration TWD documentation
NOWY DOLAR TAJWAŃSKI
enumeration TZS documentation
SZYLING TANZAŃSKI
enumeration UAH documentation
HRYWNA
enumeration UGX documentation
SZYLING UGANDYJSKI
enumeration USD documentation
DOLAR AMERYKAŃSKI
enumeration USN documentation
DOLAR AMERYKAŃSKI (NEXT DAY)
enumeration UYI documentation
PESO EN UNIDADES INDEXADAS URUGWAJSKIE
enumeration UYU documentation
PESO URUGWAJSKIE
enumeration UYW documentation
PESO EN UNIDADES INDEXADAS URUGWAJSKIE
enumeration UZS documentation
SUM
enumeration VES documentation
BOLIWAR SOBERANO
enumeration VND documentation
DONG
enumeration VUV documentation
VATU
enumeration WST documentation
TALA
enumeration XAF documentation
FRANK CFA (BEAC)
enumeration XAG documentation
SREBRO
enumeration XAU documentation
ZŁOTO
enumeration XBA documentation
BOND MARKETS UNIT EUROPEAN COMPOSITE UNIT (EURCO)
enumeration XBB documentation
BOND MARKETS UNIT EUROPEAN MONETARY UNIT (E.M.U.-6)

---

enumeration XBC documentation
BOND MARKETS UNIT EUROPEAN UNIT OF ACCOUNT 9 (E.U.A.-9)
enumeration XBD documentation
BOND MARKETS UNIT EUROPEAN UNIT OF ACCOUNT 17 (E.U.A.-17)
enumeration XCD documentation
DOLAR WSCHODNIO­KARAIBSKI
enumeration XDR documentation
SDR MIĘDZYNARODOWY FUNDUSZ WALUTOWY
enumeration XOF documentation
FRANK CFA (BCEAO)
enumeration XPD documentation
PALLAD
enumeration XPF documentation
FRANK CFP
enumeration XPT documentation
PLATYNA
enumeration XSU documentation
SUCRE SISTEMA UNITARIO DE COMPENSACION REGIONAL DE PAGOS SUCRE
enumeration XUA documentation
ADB UNIT OF ACCOUNT MEMBER COUNTRIES OF THE AFRICAN DEVELOPMENT
BANK GROUP
enumeration XXX documentation
BRAK WALUTY
enumeration YER documentation
RIAL JEMEŃSKI
enumeration ZAR documentation
RAND
enumeration ZMW documentation
KWACHA ZAMBIJSKA
enumeration ZWL documentation
DOLAR ZIMBABWE
documentation
annotation
Słownik kodów walut
source <xsd:simpleType name="TKodWaluty">
<xsd:annotation>
<xsd:documentation>Słownik kodów walut</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="xsd:normalizedString">
<xsd:enumeration value="AED">
<xsd:annotation>
<xsd:documentation>DIRHAM ZEA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="AFN">
<xsd:annotation>
<xsd:documentation>AFGANI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="ALL">
<xsd:annotation>
<xsd:documentation>LEK</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="AMD">
<xsd:annotation>
<xsd:documentation>DRAM</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="ANG">
<xsd:annotation>
<xsd:documentation>GULDEN ANTYLI HOLENDERSKICH</xsd:documentation>
</xsd:annotation>

---

</xsd:enumeration>
<xsd:enumeration value="AOA">
<xsd:annotation>
<xsd:documentation>KWANZA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="ARS">
<xsd:annotation>
<xsd:documentation>PESO ARGENTYŃSKIE</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="AUD">
<xsd:annotation>
<xsd:documentation>DOLAR AUSTRALIJSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="AWG">
<xsd:annotation>
<xsd:documentation>GULDEN ARUBAŃSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="AZN">
<xsd:annotation>
<xsd:documentation>MANAT AZERBEJDŻAŃSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="BAM">
<xsd:annotation>
<xsd:documentation>MARKA ZAMIENNA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="BBD">
<xsd:annotation>
<xsd:documentation>DOLAR BARBADOSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="BDT">
<xsd:annotation>
<xsd:documentation>TAKA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="BGN">
<xsd:annotation>
<xsd:documentation>LEW</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="BHD">
<xsd:annotation>
<xsd:documentation>DINAR BAHRAJSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="BIF">
<xsd:annotation>
<xsd:documentation>FRANK BURUNDYJSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>

---

<xsd:enumeration value="BMD">
<xsd:annotation>
<xsd:documentation>DOLAR BERMUDZKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="BND">
<xsd:annotation>
<xsd:documentation>DOLAR BRUNEJSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="BOB">
<xsd:annotation>
<xsd:documentation>BOLIWIANO</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="BOV">
<xsd:annotation>
<xsd:documentation>BOLIWIANO MVDOL</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="BRL">
<xsd:annotation>
<xsd:documentation>REAL</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="BSD">
<xsd:annotation>
<xsd:documentation>DOLAR BAHAMSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="BTN">
<xsd:annotation>
<xsd:documentation>NGULTRUM</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="BWP">
<xsd:annotation>
<xsd:documentation>PULA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="BYN">
<xsd:annotation>
<xsd:documentation>RUBEL BIAŁORUSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="BZD">
<xsd:annotation>
<xsd:documentation>DOLAR BELIZEŃSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="CAD">
<xsd:annotation>
<xsd:documentation>DOLAR KANADYJSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="CDF">

---

<xsd:annotation>
<xsd:documentation>FRANK KONGIJSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="CHE">
<xsd:annotation>
<xsd:documentation>FRANK SZWAJCARSKI VIR EURO</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="CHF">
<xsd:annotation>
<xsd:documentation>FRANK SZWAJCARSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="CHW">
<xsd:annotation>
<xsd:documentation>FRANK SZWAJCARSKI VIR FRANK</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="CLF">
<xsd:annotation>
<xsd:documentation>JEDNOSTKA ROZLICZENIOWA CHILIJSKA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="CLP">
<xsd:annotation>
<xsd:documentation>PESO CHILIJSKIE</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="CNY">
<xsd:annotation>
<xsd:documentation>YUAN RENMINBI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="COP">
<xsd:annotation>
<xsd:documentation>PESO KOLUMBIJSKIE</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="COU">
<xsd:annotation>
<xsd:documentation>UNIDAD DE VALOR REAL KOLUMBILSKIE</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="CRC">
<xsd:annotation>
<xsd:documentation>COLON KOSTARYKAŃSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="CUC">
<xsd:annotation>
<xsd:documentation>PESO WYMIENIALNE</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="CUP">
<xsd:annotation>

---

<xsd:documentation>PESO KUBAŃSKIE</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="CVE">
<xsd:annotation>
<xsd:documentation>ESCUDO REPUBLIKI ZIELONEGO
PRZYLĄDKA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="CZK">
<xsd:annotation>
<xsd:documentation>KORONA CZESKA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="DJF">
<xsd:annotation>
<xsd:documentation>FRANK DŻIBUTI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="DKK">
<xsd:annotation>
<xsd:documentation>KORONA DUŃSKA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="DOP">
<xsd:annotation>
<xsd:documentation>PESO DOMINIKAŃSKIE</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="DZD">
<xsd:annotation>
<xsd:documentation>DINAR ALGIERSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="EGP">
<xsd:annotation>
<xsd:documentation>FUNT EGIPSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="ERN">
<xsd:annotation>
<xsd:documentation>NAKFA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="ETB">
<xsd:annotation>
<xsd:documentation>BIRR</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="EUR">
<xsd:annotation>
<xsd:documentation>EURO</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="FJD">
<xsd:annotation>

---

<xsd:documentation>DOLAR FIDŻI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="FKP">
<xsd:annotation>
<xsd:documentation>FUNT FALKLANDZKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="GBP">
<xsd:annotation>
<xsd:documentation>FUNT SZTERLING</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="GEL">
<xsd:annotation>
<xsd:documentation>LARI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="GGP">
<xsd:annotation>
<xsd:documentation>FUNT GUERNSEY</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="GHS">
<xsd:annotation>
<xsd:documentation>GHANA CEDI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="GIP">
<xsd:annotation>
<xsd:documentation>FUNT GIBRALTARSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="GMD">
<xsd:annotation>
<xsd:documentation>DALASI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="GNF">
<xsd:annotation>
<xsd:documentation>FRANK GWINEJSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="GTQ">
<xsd:annotation>
<xsd:documentation>QUETZAL</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="GYD">
<xsd:annotation>
<xsd:documentation>DOLAR GUJAŃSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="HKD">
<xsd:annotation>
<xsd:documentation>DOLAR HONGKONGU</xsd:documentation>

---

</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="HNL">
<xsd:annotation>
<xsd:documentation>LEMPIRA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="HRK">
<xsd:annotation>
<xsd:documentation>KUNA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="HTG">
<xsd:annotation>
<xsd:documentation>GOURDE</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="HUF">
<xsd:annotation>
<xsd:documentation>FORINT</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="IDR">
<xsd:annotation>
<xsd:documentation>RUPIA INDONEZYJSKA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="ILS">
<xsd:annotation>
<xsd:documentation>SZEKEL</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="IMP">
<xsd:annotation>
<xsd:documentation>FUNT MANX</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="INR">
<xsd:annotation>
<xsd:documentation>RUPIA INDYJSKA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="IQD">
<xsd:annotation>
<xsd:documentation>DINAR IRACKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="IRR">
<xsd:annotation>
<xsd:documentation>RIAL IRAŃSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="ISK">
<xsd:annotation>
<xsd:documentation>KORONA ISLANDZKA</xsd:documentation>
</xsd:annotation>

---

</xsd:enumeration>
<xsd:enumeration value="JEP">
<xsd:annotation>
<xsd:documentation>FUNT JERSEY</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="JMD">
<xsd:annotation>
<xsd:documentation>DOLAR JAMAJSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="JOD">
<xsd:annotation>
<xsd:documentation>DINAR JORDAŃSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="JPY">
<xsd:annotation>
<xsd:documentation>JEN</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="KES">
<xsd:annotation>
<xsd:documentation>SZYLING KENIJSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="KGS">
<xsd:annotation>
<xsd:documentation>SOM</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="KHR">
<xsd:annotation>
<xsd:documentation>RIEL</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="KMF">
<xsd:annotation>
<xsd:documentation>FRANK KOMORÓW</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="KPW">
<xsd:annotation>
<xsd:documentation>WON PÓŁNOCNO­KOREAŃSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="KRW">
<xsd:annotation>
<xsd:documentation>WON POŁUDNIOWO­KOREAŃSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="KWD">
<xsd:annotation>
<xsd:documentation>DINAR KUWEJCKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>

---

<xsd:enumeration value="KYD">
<xsd:annotation>
<xsd:documentation>DOLAR KAJMAŃSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="KZT">
<xsd:annotation>
<xsd:documentation>TENGE</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="LAK">
<xsd:annotation>
<xsd:documentation>KIP</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="LBP">
<xsd:annotation>
<xsd:documentation>FUNT LIBAŃSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="LKR">
<xsd:annotation>
<xsd:documentation>RUPIA LANKIJSKA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="LRD">
<xsd:annotation>
<xsd:documentation>DOLAR LIBERYJSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="LSL">
<xsd:annotation>
<xsd:documentation>LOTI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="LYD">
<xsd:annotation>
<xsd:documentation>DINAR LIBIJSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="MAD">
<xsd:annotation>
<xsd:documentation>DIRHAM MAROKAŃSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="MDL">
<xsd:annotation>
<xsd:documentation>LEJ MOŁDAWII</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="MGA">
<xsd:annotation>
<xsd:documentation>ARIARY</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="MKD">

---

<xsd:annotation>
<xsd:documentation>DENAR</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="MMK">
<xsd:annotation>
<xsd:documentation>KYAT</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="MNT">
<xsd:annotation>
<xsd:documentation>TUGRIK</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="MOP">
<xsd:annotation>
<xsd:documentation>PATACA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="MRU">
<xsd:annotation>
<xsd:documentation>OUGUIYA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="MUR">
<xsd:annotation>
<xsd:documentation>RUPIA MAURITIUSU</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="MVR">
<xsd:annotation>
<xsd:documentation>RUPIA MALEDIWSKA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="MWK">
<xsd:annotation>
<xsd:documentation>KWACHA MALAWIJSKA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="MXN">
<xsd:annotation>
<xsd:documentation>PESO MEKSYKAŃSKIE</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="MXV">
<xsd:annotation>
<xsd:documentation>UNIDAD DE INVERSION (UDI)
MEKSYKAŃSKIE</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="MYR">
<xsd:annotation>
<xsd:documentation>RINGGIT</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="MZN">

---

<xsd:annotation>
<xsd:documentation>METICAL</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="NAD">
<xsd:annotation>
<xsd:documentation>DOLAR NAMIBIJSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="NGN">
<xsd:annotation>
<xsd:documentation>NAIRA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="NIO">
<xsd:annotation>
<xsd:documentation>CORDOBA ORO</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="NOK">
<xsd:annotation>
<xsd:documentation>KORONA NORWESKA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="NPR">
<xsd:annotation>
<xsd:documentation>RUPIA NEPALSKA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="NZD">
<xsd:annotation>
<xsd:documentation>DOLAR NOWOZELANDZKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="OMR">
<xsd:annotation>
<xsd:documentation>RIAL OMAŃSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="PAB">
<xsd:annotation>
<xsd:documentation>BALBOA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="PEN">
<xsd:annotation>
<xsd:documentation>SOL</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="PGK">
<xsd:annotation>
<xsd:documentation>KINA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="PHP">
<xsd:annotation>

---

<xsd:documentation>PESO FILIPIŃSKIE</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="PKR">
<xsd:annotation>
<xsd:documentation>RUPIA PAKISTAŃSKA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="PLN">
<xsd:annotation>
<xsd:documentation>ZŁOTY</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="PYG">
<xsd:annotation>
<xsd:documentation>GUARANI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="QAR">
<xsd:annotation>
<xsd:documentation>RIAL KATARSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="RON">
<xsd:annotation>
<xsd:documentation>LEJ RUMUŃSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="RSD">
<xsd:annotation>
<xsd:documentation>DINAR SERBSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="RUB">
<xsd:annotation>
<xsd:documentation>RUBEL ROSYJSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="RWF">
<xsd:annotation>
<xsd:documentation>FRANK RWANDYJSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="SAR">
<xsd:annotation>
<xsd:documentation>RIAL SAUDYJSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="SBD">
<xsd:annotation>
<xsd:documentation>DOLAR WYSP SALOMONA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="SCR">
<xsd:annotation>
<xsd:documentation>RUPIA SESZELSKA</xsd:documentation>

---

</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="SDG">
<xsd:annotation>
<xsd:documentation>FUNT SUDAŃSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="SEK">
<xsd:annotation>
<xsd:documentation>KORONA SZWEDZKA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="SGD">
<xsd:annotation>
<xsd:documentation>DOLAR SINGAPURSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="SHP">
<xsd:annotation>
<xsd:documentation>FUNT ŚWIĘTEJ HELENY (ŚWIĘTA HELENA I WYSPA
WNIEBOWSTĄPIENIA)</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="SLL">
<xsd:annotation>
<xsd:documentation>LEONE</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="SOS">
<xsd:annotation>
<xsd:documentation>SZYLING SOMALIJSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="SRD">
<xsd:annotation>
<xsd:documentation>DOLAR SURINAMSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="SSP">
<xsd:annotation>
<xsd:documentation>FUNT POŁUDNIOWOSUDAŃSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="STN">
<xsd:annotation>
<xsd:documentation>DOBRA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="SVC">
<xsd:annotation>
<xsd:documentation>COLON SALWADORSKI (SV1)</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="SYP">
<xsd:annotation>
<xsd:documentation>FUNT SYRYJSKI</xsd:documentation>

---

</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="SZL">
<xsd:annotation>
<xsd:documentation>LILANGENI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="THB">
<xsd:annotation>
<xsd:documentation>BAT</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="TJS">
<xsd:annotation>
<xsd:documentation>SOMONI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="TMT">
<xsd:annotation>
<xsd:documentation>MANAT TURKMEŃSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="TND">
<xsd:annotation>
<xsd:documentation>DINAR TUNEZYJSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="TOP">
<xsd:annotation>
<xsd:documentation>PAANGA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="TRY">
<xsd:annotation>
<xsd:documentation>LIRA TURECKA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="TTD">
<xsd:annotation>
<xsd:documentation>DOLAR TRYNIDADU I TOBAGO</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="TWD">
<xsd:annotation>
<xsd:documentation>NOWY DOLAR TAJWAŃSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="TZS">
<xsd:annotation>
<xsd:documentation>SZYLING TANZAŃSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="UAH">
<xsd:annotation>
<xsd:documentation>HRYWNA</xsd:documentation>
</xsd:annotation>

---

</xsd:enumeration>
<xsd:enumeration value="UGX">
<xsd:annotation>
<xsd:documentation>SZYLING UGANDYJSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="USD">
<xsd:annotation>
<xsd:documentation>DOLAR AMERYKAŃSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="USN">
<xsd:annotation>
<xsd:documentation>DOLAR AMERYKAŃSKI (NEXT DAY)</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="UYI">
<xsd:annotation>
<xsd:documentation>PESO EN UNIDADES INDEXADAS
URUGWAJSKIE</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="UYU">
<xsd:annotation>
<xsd:documentation>PESO URUGWAJSKIE</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="UYW">
<xsd:annotation>
<xsd:documentation>PESO EN UNIDADES INDEXADAS
URUGWAJSKIE</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="UZS">
<xsd:annotation>
<xsd:documentation>SUM</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="VES">
<xsd:annotation>
<xsd:documentation>BOLIWAR SOBERANO </xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="VND">
<xsd:annotation>
<xsd:documentation>DONG</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="VUV">
<xsd:annotation>
<xsd:documentation>VATU</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="WST">
<xsd:annotation>
<xsd:documentation>TALA</xsd:documentation>

---

</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="XAF">
<xsd:annotation>
<xsd:documentation>FRANK CFA (BEAC)</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="XAG">
<xsd:annotation>
<xsd:documentation>SREBRO</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="XAU">
<xsd:annotation>
<xsd:documentation>ZŁOTO</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="XBA">
<xsd:annotation>
<xsd:documentation>BOND MARKETS UNIT EUROPEAN COMPOSITE UNIT
(EURCO)</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="XBB">
<xsd:annotation>
<xsd:documentation>BOND MARKETS UNIT EUROPEAN MONETARY UNIT
(E.M.U.-6)</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="XBC">
<xsd:annotation>
<xsd:documentation>BOND MARKETS UNIT EUROPEAN UNIT OF ACCOUNT 9
(E.U.A.-9)</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="XBD">
<xsd:annotation>
<xsd:documentation>BOND MARKETS UNIT EUROPEAN UNIT OF ACCOUNT 17
(E.U.A.-17)</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="XCD">
<xsd:annotation>
<xsd:documentation>DOLAR WSCHODNIO­KARAIBSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="XDR">
<xsd:annotation>
<xsd:documentation>SDR MIĘDZYNARODOWY FUNDUSZ
WALUTOWY</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="XOF">
<xsd:annotation>
<xsd:documentation>FRANK CFA (BCEAO)</xsd:documentation>
</xsd:annotation>

---

</xsd:enumeration>
<xsd:enumeration value="XPD">
<xsd:annotation>
<xsd:documentation>PALLAD</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="XPF">
<xsd:annotation>
<xsd:documentation>FRANK CFP</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="XPT">
<xsd:annotation>
<xsd:documentation>PLATYNA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="XSU">
<xsd:annotation>
<xsd:documentation>SUCRE SISTEMA UNITARIO DE COMPENSACION REGIONAL DE
PAGOS SUCRE</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="XUA">
<xsd:annotation>
<xsd:documentation>ADB UNIT OF ACCOUNT MEMBER COUNTRIES OF THE
AFRICAN DEVELOPMENT BANK GROUP</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="XXX">
<xsd:annotation>
<xsd:documentation>BRAK WALUTY</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="YER">
<xsd:annotation>
<xsd:documentation>RIAL JEMEŃSKI</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="ZAR">
<xsd:annotation>
<xsd:documentation>RAND</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="ZMW">
<xsd:annotation>
<xsd:documentation>KWACHA ZAMBIJSKA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="ZWL">
<xsd:annotation>
<xsd:documentation>DOLAR ZIMBABWE</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
</xsd:restriction>
</xsd:simpleType>

---

simpleType TKodyKrajowUE
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of xsd:normalizedString
base xsd:normalizedString
properties
elements TPodmiot2/KodUE TPodmiot3/KodUE Faktura/Podmiot1/PrefiksPodatnika
used by
Faktura/Fa/Podmiot1K/PrefiksPodatnika
Kind Value Annotation
facets
enumeration AT documentation
AUSTRIA
enumeration BE documentation
BELGIA
enumeration BG documentation
BUŁGARIA
enumeration CY documentation
CYPR
enumeration CZ documentation
CZECHY
enumeration DK documentation
DANIA
enumeration EE documentation
ESTONIA
enumeration FI documentation
FINLANDIA
enumeration FR documentation
FRANCJA
enumeration DE documentation
NIEMCY
enumeration EL documentation
GRECJA
enumeration HR documentation
CHORWACJA
enumeration HU documentation
WĘGRY
enumeration IE documentation
IRLANDIA
enumeration IT documentation
WŁOCHY
enumeration LV documentation
ŁOTWA
enumeration LT documentation
LITWA
enumeration LU documentation
LUKSEMBURG
enumeration MT documentation
MALTA
enumeration NL documentation
HOLANDIA
enumeration PL documentation
POLSKA
enumeration PT documentation
PORTUGALIA
enumeration RO documentation
RUMUNIA
enumeration SK documentation
SŁOWACJA
enumeration SI documentation
SŁOWENIA
enumeration ES documentation
HISZPANIA
enumeration SE documentation
SZWECJA
enumeration XI documentation
IRLANDIA PÓŁNOCNA

---

documentation
annotation
Kody krajów członkowskich Unii Europejskiej, w tym kod dla obszaru Irlandii Północnej
source <xsd:simpleType name="TKodyKrajowUE">
<xsd:annotation>
<xsd:documentation>Kody krajów członkowskich Unii Europejskiej, w tym kod dla obszaru
Irlandii Północnej</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="xsd:normalizedString">
<xsd:enumeration value="AT">
<xsd:annotation>
<xsd:documentation>AUSTRIA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="BE">
<xsd:annotation>
<xsd:documentation>BELGIA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="BG">
<xsd:annotation>
<xsd:documentation>BUŁGARIA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="CY">
<xsd:annotation>
<xsd:documentation>CYPR</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="CZ">
<xsd:annotation>
<xsd:documentation>CZECHY</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="DK">
<xsd:annotation>
<xsd:documentation>DANIA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="EE">
<xsd:annotation>
<xsd:documentation>ESTONIA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="FI">
<xsd:annotation>
<xsd:documentation>FINLANDIA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="FR">
<xsd:annotation>
<xsd:documentation>FRANCJA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="DE">
<xsd:annotation>
<xsd:documentation>NIEMCY</xsd:documentation>

---

</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="EL">
<xsd:annotation>
<xsd:documentation>GRECJA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="HR">
<xsd:annotation>
<xsd:documentation>CHORWACJA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="HU">
<xsd:annotation>
<xsd:documentation>WĘGRY</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="IE">
<xsd:annotation>
<xsd:documentation>IRLANDIA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="IT">
<xsd:annotation>
<xsd:documentation>WŁOCHY</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="LV">
<xsd:annotation>
<xsd:documentation>ŁOTWA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="LT">
<xsd:annotation>
<xsd:documentation>LITWA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="LU">
<xsd:annotation>
<xsd:documentation>LUKSEMBURG</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="MT">
<xsd:annotation>
<xsd:documentation>MALTA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="NL">
<xsd:annotation>
<xsd:documentation>HOLANDIA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="PL">
<xsd:annotation>
<xsd:documentation>POLSKA</xsd:documentation>
</xsd:annotation>

---

</xsd:enumeration>
<xsd:enumeration value="PT">
<xsd:annotation>
<xsd:documentation>PORTUGALIA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="RO">
<xsd:annotation>
<xsd:documentation>RUMUNIA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="SK">
<xsd:annotation>
<xsd:documentation>SŁOWACJA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="SI">
<xsd:annotation>
<xsd:documentation>SŁOWENIA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="ES">
<xsd:annotation>
<xsd:documentation>HISZPANIA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="SE">
<xsd:annotation>
<xsd:documentation>SZWECJA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="XI">
<xsd:annotation>
<xsd:documentation>IRLANDIA PÓŁNOCNA</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
</xsd:restriction>
</xsd:simpleType>
simpleType TKwotowy
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of xsd:decimal
base xsd:decimal
properties
elements Faktura/Fa/Rozliczenie/DoRozliczenia Faktura/Fa/Rozliczenie/DoZaplaty
used by
Faktura/Fa/Rozliczenie/Odliczenia/Kwota Faktura/Fa/Rozliczenie/Obciazenia/Kwota
Faktura/Fa/FaWiersz/KwotaAkcyzy Faktura/Fa/Zamowienie/ZamowienieWiersz/KwotaAkcyzyZ
Faktura/Fa/Platnosc/ZaplataCzesciowa/KwotaZaplatyCzesciowej Faktura/Fa/FaWiersz/P_11
Faktura/Fa/FaWiersz/P_11A Faktura/Fa/Zamowienie/ZamowienieWiersz/P_11NettoZ
Faktura/Fa/FaWiersz/P_11Vat Faktura/Fa/Zamowienie/ZamowienieWiersz/P_11VatZ
Faktura/Fa/P_13_1 Faktura/Fa/P_13_10 Faktura/Fa/P_13_11 Faktura/Fa/P_13_2 Faktura/Fa/P_13_3
Faktura/Fa/P_13_4 Faktura/Fa/P_13_5 Faktura/Fa/P_13_6_1 Faktura/Fa/P_13_6_2
Faktura/Fa/P_13_6_3 Faktura/Fa/P_13_7 Faktura/Fa/P_13_8 Faktura/Fa/P_13_9 Faktura/Fa/P_14_1
Faktura/Fa/P_14_1W Faktura/Fa/P_14_2 Faktura/Fa/P_14_2W Faktura/Fa/P_14_3 Faktura/Fa/P_14_3W
Faktura/Fa/P_14_4 Faktura/Fa/P_14_4W Faktura/Fa/P_14_5 Faktura/Fa/P_15
Faktura/Fa/ZaliczkaCzesciowa/P_15Z Faktura/Fa/P_15ZK Faktura/Fa/Rozliczenie/SumaObciazen

---

Faktura/Fa/Rozliczenie/SumaOdliczen Faktura/Fa/Zamowienie/WartoscZamowienia
Kind Value Annotation
facets
totalDigits 18
fractionDigits 2
pattern -?([1-9]\d{0,15}|0)(\.\d{1,2})?
documentation
annotation
Wartość numeryczna 18 znaków max, w tym 2 znaki po przecinku
source <xsd:simpleType name="TKwotowy">
<xsd:annotation>
<xsd:documentation>Wartość numeryczna 18 znaków max, w tym 2 znaki po
przecinku</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="xsd:decimal">
<xsd:totalDigits value="18"/>
<xsd:fractionDigits value="2"/>
<xsd:pattern value="-?([1-9]\d{0,15}|0)(\.\d{1,2})?"/>
</xsd:restriction>
</xsd:simpleType>
simpleType TKwotowy2
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of xsd:decimal
base xsd:decimal
properties
elements Faktura/Fa/FaWiersz/P_10 Faktura/Fa/FaWiersz/P_9A
used by
Faktura/Fa/Zamowienie/ZamowienieWiersz/P_9AZ Faktura/Fa/FaWiersz/P_9B
Kind Value Annotation
facets
totalDigits 22
fractionDigits 8
pattern -?([1-9]\d{0,13}|0)(\.\d{1,8})?
documentation
annotation
Wartość numeryczna 22 znaki max, w tym 8 znaków po przecinku
source <xsd:simpleType name="TKwotowy2">
<xsd:annotation>
<xsd:documentation>Wartość numeryczna 22 znaki max, w tym 8 znaków po
przecinku</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="xsd:decimal">
<xsd:totalDigits value="22"/>
<xsd:fractionDigits value="8"/>
<xsd:pattern value="-?([1-9]\d{0,13}|0)(\.\d{1,8})?"/>
</xsd:restriction>
</xsd:simpleType>
simpleType TLadunek
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of xsd:integer
base xsd:integer
properties
element Faktura/Fa/WarunkiTransakcji/Transport/OpisLadunku
used by

---

Kind Value Annotation
facets
enumeration 1 documentation
Bańka
enumeration 2 documentation
Beczka
enumeration 3 documentation
Butla
enumeration 4 documentation
Karton
enumeration 5 documentation
Kanister
enumeration 6 documentation
Klatka
enumeration 7 documentation
Kontener
enumeration 8 documentation
Kosz/koszyk
enumeration 9 documentation
Łubianka
enumeration 10 documentation
Opakowanie zbiorcze
enumeration 11 documentation
Paczka
enumeration 12 documentation
Pakiet
enumeration 13 documentation
Paleta
enumeration 14 documentation
Pojemnik
enumeration 15 documentation
Pojemnik do ładunków masowych stałych
enumeration 16 documentation
Pojemnik do ładunków masowych w postaci płynnej
enumeration 17 documentation
Pudełko
enumeration 18 documentation
Puszka
enumeration 19 documentation
Skrzynia
enumeration 20 documentation
Worek
documentation
annotation
Typy ładunków
source <xsd:simpleType name="TLadunek">
<xsd:annotation>
<xsd:documentation>Typy ładunków</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="xsd:integer">
<xsd:enumeration value="1">
<xsd:annotation>
<xsd:documentation>Bańka</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="2">
<xsd:annotation>
<xsd:documentation>Beczka</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="3">
<xsd:annotation>
<xsd:documentation>Butla</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="4">

---

<xsd:annotation>
<xsd:documentation>Karton</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="5">
<xsd:annotation>
<xsd:documentation>Kanister</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="6">
<xsd:annotation>
<xsd:documentation>Klatka</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="7">
<xsd:annotation>
<xsd:documentation>Kontener</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="8">
<xsd:annotation>
<xsd:documentation>Kosz/koszyk</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="9">
<xsd:annotation>
<xsd:documentation>Łubianka</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="10">
<xsd:annotation>
<xsd:documentation>Opakowanie zbiorcze</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="11">
<xsd:annotation>
<xsd:documentation>Paczka</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="12">
<xsd:annotation>
<xsd:documentation>Pakiet</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="13">
<xsd:annotation>
<xsd:documentation>Paleta</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="14">
<xsd:annotation>
<xsd:documentation>Pojemnik</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="15">
<xsd:annotation>

---

<xsd:documentation>Pojemnik do ładunków masowych stałych</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="16">
<xsd:annotation>
<xsd:documentation>Pojemnik do ładunków masowych w postaci
płynnej</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="17">
<xsd:annotation>
<xsd:documentation>Pudełko</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="18">
<xsd:annotation>
<xsd:documentation>Puszka</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="19">
<xsd:annotation>
<xsd:documentation>Skrzynia</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="20">
<xsd:annotation>
<xsd:documentation>Worek</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
</xsd:restriction>
</xsd:simpleType>
simpleType TNaturalny
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of etd:TNaturalny
base etd:TNaturalny
properties
elements TKluczWartosc/NrWiersza Faktura/Fa/FaWiersz/NrWierszaFa
used by
Faktura/Fa/Zamowienie/ZamowienieWiersz/NrWierszaZam
Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_NrWierszaNST
Kind Value Annotation
facets
minExclusive 0
totalDigits 14
whiteSpace collapse
documentation
annotation
Liczby naturalne większe od zera
source <xsd:simpleType name="TNaturalny">
<xsd:annotation>
<xsd:documentation>Liczby naturalne większe od zera</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="etd:TNaturalny">
<xsd:minExclusive value="0"/>
</xsd:restriction>

---

</xsd:simpleType>
simpleType TNIPIdWew
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of tns:TZnakowy20
base tns:TZnakowy20
properties
element TPodmiot3/IDWew
used by
Kind Value Annotation
facets
minLength 1
maxLength 20
pattern [1-9]((\d[1-9])|([1-9]\d))\d{7}-\d{5}
documentation
annotation
Identyfikator wewnętrzny
source <xsd:simpleType name="TNIPIdWew">
<xsd:annotation>
<xsd:documentation>Identyfikator wewnętrzny</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="tns:TZnakowy20">
<xsd:pattern value="[1-9]((\d[1-9])|([1-9]\d))\d{7}-\d{5}"/>
</xsd:restriction>
</xsd:simpleType>
simpleType TNrRB
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of xsd:string
base xsd:string
properties
element TRachunekBankowy/NrRB
used by
Kind Value Annotation
facets
pattern [0-9A-Z]{10,32}
documentation
annotation
Numer rachunku
source <xsd:simpleType name="TNrRB">
<xsd:annotation>
<xsd:documentation>Numer rachunku</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="xsd:string">
<xsd:pattern value="[0-9A-Z]{10,32}"/>
</xsd:restriction>
</xsd:simpleType>
simpleType TNrVatUE
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of xsd:string
base xsd:string
properties

---

elements TPodmiot2/NrVatUE TPodmiot3/NrVatUE
used by
Kind Value Annotation
facets
pattern (\d|[A-Z]|\+|\*){1,12}
documentation
annotation
Numer Identyfikacyjny VAT kontrahenta UE
source <xsd:simpleType name="TNrVatUE">
<xsd:annotation>
<xsd:documentation>Numer Identyfikacyjny VAT kontrahenta UE</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="xsd:string">
<xsd:pattern value="(\d|[A-Z]|\+|\*){1,12}"/>
</xsd:restriction>
</xsd:simpleType>
simpleType TNumerKSeF
name http://crd.gov.pl/wzor/2023/06/29/12648/
space
type restriction of xsd:token
base xsd:token
proper
ties
elements Faktura/Fa/DaneFaKorygowanej/NrKSeFFaKorygowanej
used
Faktura/Fa/FakturaZaliczkowa/NrKSeFFaZaliczkowej
by
Kind Value Annot
facets
ation
patt ([1-9]((\d[1-9])|([1-9]\d))\d{7}|M\d{9}|[A-Z]{3}\d{7})-(20[2-9][0-9]|2[1-9][0-9]{2}|[3-9][0-9]{3})(0[1-9]|1[0-2])(0[1-9]|[
ern 1-2][0-9]|3[0-1])-([0-9A-F]{6})-?([0-9A-F]{6})-([0-9A-F]{2})
documentation
annot
Numer identyfikujący fakturę w Krajowym Systemie e-Faktur (KSeF)
ation
sourc <xsd:simpleType name="TNumerKSeF">
e <xsd:annotation>
<xsd:documentation>Numer identyfikujący fakturę w Krajowym Systemie e-Faktur
(KSeF)</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="xsd:token">
<xsd:pattern
value="([1-9]((\d[1-9])|([1-9]\d))\d{7}|M\d{9}|[A-Z]{3}\d{7})-(20[2-9][0-9]|2[1-9][0-9]{2}|[3-9][0-9]{3})(0[1-9]|1
[0-2])(0[1-9]|[1-2][0-9]|3[0-1])-([0-9A-F]{6})-?([0-9A-F]{6})-([0-9A-F]{2})"/>
</xsd:restriction>
</xsd:simpleType>
simpleType TNumerTelefonu
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of tns:TZnakowy
base tns:TZnakowy
properties
elements Faktura/Podmiot1/DaneKontaktowe/Telefon Faktura/Podmiot2/DaneKontaktowe/Telefon
used by
Faktura/Podmiot3/DaneKontaktowe/Telefon
Faktura/PodmiotUpowazniony/DaneKontaktowe/TelefonPU
Kind Value Annotation
facets
minLength 1

---

maxLength 16
documentation
annotation
Numer telefonu
source <xsd:simpleType name="TNumerTelefonu">
<xsd:annotation>
<xsd:documentation>Numer telefonu</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="tns:TZnakowy">
<xsd:maxLength value="16"/>
</xsd:restriction>
</xsd:simpleType>
simpleType TOznaczenieProcedury
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of tns:TZnakowy
base tns:TZnakowy
properties
element Faktura/Fa/FaWiersz/Procedura
used by
Kind Value Annotation
facets
minLength 1
maxLength 256
enumeration WSTO_EE documentation
Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 2a
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w
deklaracjach podatkowych i w ewidencji w zakresie podatku od towarów i
usług
enumeration IED documentation
Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 2b
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w
deklaracjach podatkowych i w ewidencji w zakresie podatku od towarów i
usług
enumeration TT_D documentation
Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 5
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w
deklaracjach podatkowych i w ewidencji w zakresie podatku od towarów i
usług
enumeration I_42 documentation
Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 8
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w
deklaracjach podatkowych i w ewidencji w zakresie podatku od towarów i
usług
enumeration I_63 documentation
Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 9
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w
deklaracjach podatkowych i w ewidencji w zakresie podatku od towarów i
usług
enumeration B_SPV documentation
Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 10
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w
deklaracjach podatkowych i w ewidencji w zakresie podatku od towarów i
usług
enumeration B_SPV_DOSTAWA documentation
Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 11
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w
deklaracjach podatkowych i w ewidencji w zakresie podatku od towarów i
usług
enumeration B_MPV_PROWIZJA documentation
Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 12
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w
deklaracjach podatkowych i w ewidencji w zakresie podatku od towarów i
usług

---

documentation
annotation
Oznaczenia dotyczące procedur dla faktur
source <xsd:simpleType name="TOznaczenieProcedury">
<xsd:annotation>
<xsd:documentation>Oznaczenia dotyczące procedur dla faktur</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="tns:TZnakowy">
<xsd:enumeration value="WSTO_EE">
<xsd:annotation>
<xsd:documentation>Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 2a
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w deklaracjach podatkowych
i w ewidencji w zakresie podatku od towarów i usług</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="IED">
<xsd:annotation>
<xsd:documentation>Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 2b
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w deklaracjach podatkowych
i w ewidencji w zakresie podatku od towarów i usług</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="TT_D">
<xsd:annotation>
<xsd:documentation>Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 5
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w deklaracjach podatkowych
i w ewidencji w zakresie podatku od towarów i usług</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="I_42">
<xsd:annotation>
<xsd:documentation>Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 8
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w deklaracjach podatkowych
i w ewidencji w zakresie podatku od towarów i usług</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="I_63">
<xsd:annotation>
<xsd:documentation>Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 9
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w deklaracjach podatkowych
i w ewidencji w zakresie podatku od towarów i usług</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="B_SPV">
<xsd:annotation>
<xsd:documentation>Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 10
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w deklaracjach podatkowych
i w ewidencji w zakresie podatku od towarów i usług</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="B_SPV_DOSTAWA">
<xsd:annotation>
<xsd:documentation>Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 11
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w deklaracjach podatkowych
i w ewidencji w zakresie podatku od towarów i usług</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>

---

<xsd:enumeration value="B_MPV_PROWIZJA">
<xsd:annotation>
<xsd:documentation>Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 12
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w deklaracjach podatkowych
i w ewidencji w zakresie podatku od towarów i usług</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
</xsd:restriction>
</xsd:simpleType>
simpleType TOznaczenieProceduryZ
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of tns:TZnakowy
base tns:TZnakowy
properties
element Faktura/Fa/Zamowienie/ZamowienieWiersz/ProceduraZ
used by
Kind Value Annotation
facets
minLength 1
maxLength 256
enumeration WSTO_EE documentation
Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 2a
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w
deklaracjach podatkowych i w ewidencji w zakresie podatku od towarów i
usług
enumeration IED documentation
Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 2b
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w
deklaracjach podatkowych i w ewidencji w zakresie podatku od towarów i
usług
enumeration TT_D documentation
Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 5
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w
deklaracjach podatkowych i w ewidencji w zakresie podatku od towarów i
usług
enumeration B_SPV documentation
Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 10
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w
deklaracjach podatkowych i w ewidencji w zakresie podatku od towarów i
usług
enumeration B_SPV_DOSTAWA documentation
Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 11
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w
deklaracjach podatkowych i w ewidencji w zakresie podatku od towarów i
usług
enumeration B_MPV_PROWIZJA documentation
Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 12
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w
deklaracjach podatkowych i w ewidencji w zakresie podatku od towarów i
usług
documentation
annotation
Oznaczenia dotyczące procedur dla zamówień
source <xsd:simpleType name="TOznaczenieProceduryZ">
<xsd:annotation>
<xsd:documentation>Oznaczenia dotyczące procedur dla zamówień</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="tns:TZnakowy">
<xsd:enumeration value="WSTO_EE">
<xsd:annotation>
<xsd:documentation>Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 2a

---

rozporządzenia w sprawie szczegółowego zakresu danych zawartych w deklaracjach podatkowych
i w ewidencji w zakresie podatku od towarów i usług</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="IED">
<xsd:annotation>
<xsd:documentation>Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 2b
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w deklaracjach podatkowych
i w ewidencji w zakresie podatku od towarów i usług</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="TT_D">
<xsd:annotation>
<xsd:documentation>Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 5
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w deklaracjach podatkowych
i w ewidencji w zakresie podatku od towarów i usług</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="B_SPV">
<xsd:annotation>
<xsd:documentation>Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 10
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w deklaracjach podatkowych
i w ewidencji w zakresie podatku od towarów i usług</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="B_SPV_DOSTAWA">
<xsd:annotation>
<xsd:documentation>Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 11
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w deklaracjach podatkowych
i w ewidencji w zakresie podatku od towarów i usług</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="B_MPV_PROWIZJA">
<xsd:annotation>
<xsd:documentation>Oznaczenie dotyczące procedury, o której mowa w § 10 ust. 4 pkt 12
rozporządzenia w sprawie szczegółowego zakresu danych zawartych w deklaracjach podatkowych
i w ewidencji w zakresie podatku od towarów i usług</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
</xsd:restriction>
</xsd:simpleType>
simpleType TProcentowy
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of xsd:decimal
base xsd:decimal
properties
elements Faktura/Fa/FaWiersz/P_12_XII Faktura/Fa/Zamowienie/ZamowienieWiersz/P_12Z_XII
used by
Faktura/Podmiot3/Udzial
Kind Value Annotation
facets
minInclusive 0
maxInclusive 100
totalDigits 9

---

fractionDigits 6
whiteSpace collapse
documentation
annotation
Wartość procentowa z dokładnością do 6 miejsc po przecinku
source <xsd:simpleType name="TProcentowy">
<xsd:annotation>
<xsd:documentation>Wartość procentowa z dokładnością do 6 miejsc po
przecinku</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="xsd:decimal">
<xsd:totalDigits value="9"/>
<xsd:fractionDigits value="6"/>
<xsd:minInclusive value="0"/>
<xsd:maxInclusive value="100"/>
<xsd:whiteSpace value="collapse"/>
</xsd:restriction>
</xsd:simpleType>
simpleType TRachunekWlasnyBanku
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of xsd:integer
base xsd:integer
properties
element TRachunekBankowy/RachunekWlasnyBanku
used by
Kind Value Annotation
facets
enumeration 1 documentation
Rachunek banku lub rachunek spółdzielczej kasy oszczędnościowo-kredytowej służący do
dokonywania rozliczeń z tytułu nabywanych przez ten bank lub tę kasę wierzytelności
pieniężnych
enumeration 2 documentation
Rachunek banku lub rachunek spółdzielczej kasy oszczędnościowo-kredytowej
wykorzystywany przez ten bank lub tę kasę do pobrania należności od nabywcy towarów lub
usługobiorcy za dostawę towarów lub świadczenie usług, potwierdzone fakturą, i przekazania
jej w całości albo części dostawcy towarów lub usługodawcy
enumeration 3 documentation
Rachunek banku lub rachunek spółdzielczej kasy oszczędnościowo-kredytowej prowadzony
przez ten bank lub tę kasę w ramach gospodarki własnej, niebędący rachunkiem
rozliczeniowym
documentation
annotation
Typy rachunków własnych
source <xsd:simpleType name="TRachunekWlasnyBanku">
<xsd:annotation>
<xsd:documentation>Typy rachunków własnych</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="xsd:integer">
<xsd:enumeration value="1">
<xsd:annotation>
<xsd:documentation>Rachunek banku lub rachunek spółdzielczej kasy
oszczędnościowo-kredytowej służący do dokonywania rozliczeń z tytułu nabywanych przez ten
bank lub tę kasę wierzytelności pieniężnych</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="2">
<xsd:annotation>
<xsd:documentation>Rachunek banku lub rachunek spółdzielczej kasy

---

oszczędnościowo-kredytowej wykorzystywany przez ten bank lub tę kasę do pobrania należności
od nabywcy towarów lub usługobiorcy za dostawę towarów lub świadczenie usług, potwierdzone
fakturą, i przekazania jej w całości albo części dostawcy towarów lub
usługodawcy</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="3">
<xsd:annotation>
<xsd:documentation>Rachunek banku lub rachunek spółdzielczej kasy
oszczędnościowo-kredytowej prowadzony przez ten bank lub tę kasę w ramach gospodarki
własnej, niebędący rachunkiem rozliczeniowym</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
</xsd:restriction>
</xsd:simpleType>
simpleType TRodzajFaktury
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of tns:TZnakowy
base tns:TZnakowy
properties
element Faktura/Fa/RodzajFaktury
used by
Kind Value Annotation
facets
minLength 1
maxLength 256
enumeration VAT documentation
Faktura podstawowa
enumeration KOR documentation
Faktura korygująca
enumeration ZAL documentation
Faktura dokumentująca otrzymanie zapłaty lub jej części przed dokonaniem czynności
oraz faktura wystawiona w związku z art. 106f ust. 4 ustawy
enumeration ROZ documentation
Faktura wystawiona w związku z art. 106f ust. 3 ustawy
enumeration UPR documentation
Faktura, o której mowa w art. 106e ust. 5 pkt 3 ustawy
enumeration KOR_ZAL documentation
Faktura korygująca fakturę dokumentującą otrzymanie zapłaty lub jej części przed
dokonaniem czynności oraz fakturę wystawioną w związku z art. 106f ust. 4 ustawy
enumeration KOR_ROZ documentation
Faktura korygująca fakturę wystawioną w związku z art. 106f ust. 3 ustawy
documentation
annotation
Rodzaj faktury
source <xsd:simpleType name="TRodzajFaktury">
<xsd:annotation>
<xsd:documentation>Rodzaj faktury</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="tns:TZnakowy">
<xsd:enumeration value="VAT">
<xsd:annotation>
<xsd:documentation>Faktura podstawowa</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="KOR">
<xsd:annotation>
<xsd:documentation>Faktura korygująca</xsd:documentation>

---

</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="ZAL">
<xsd:annotation>
<xsd:documentation>Faktura dokumentująca otrzymanie zapłaty lub jej części przed
dokonaniem czynności oraz faktura wystawiona w związku z art. 106f ust. 4
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="ROZ">
<xsd:annotation>
<xsd:documentation>Faktura wystawiona w związku z art. 106f ust. 3
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="UPR">
<xsd:annotation>
<xsd:documentation>Faktura, o której mowa w art. 106e ust. 5 pkt 3
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="KOR_ZAL">
<xsd:annotation>
<xsd:documentation>Faktura korygująca fakturę dokumentującą otrzymanie zapłaty lub jej
części przed dokonaniem czynności oraz fakturę wystawioną w związku z art. 106f ust. 4
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="KOR_ROZ">
<xsd:annotation>
<xsd:documentation>Faktura korygująca fakturę wystawioną w związku z art. 106f ust. 3
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
</xsd:restriction>
</xsd:simpleType>
simpleType TRodzajTransportu
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of xsd:integer
base xsd:integer
properties
element Faktura/Fa/WarunkiTransakcji/Transport/RodzajTransportu
used by
Kind Value Annotation
facets
enumeration 1 documentation
Transport morski
enumeration 2 documentation
Transport kolejowy
enumeration 3 documentation
Transport drogowy
enumeration 4 documentation
Transport lotniczy
enumeration 5 documentation
Przesyłka pocztowa
enumeration 7 documentation
Stałe instalacje przesyłowe

---

enumeration 8 documentation
Żegluga śródlądowa
documentation
annotation
Rodzaj transportu
source <xsd:simpleType name="TRodzajTransportu">
<xsd:annotation>
<xsd:documentation>Rodzaj transportu</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="xsd:integer">
<xsd:enumeration value="1">
<xsd:annotation>
<xsd:documentation>Transport morski</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="2">
<xsd:annotation>
<xsd:documentation>Transport kolejowy</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="3">
<xsd:annotation>
<xsd:documentation>Transport drogowy</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="4">
<xsd:annotation>
<xsd:documentation>Transport lotniczy</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="5">
<xsd:annotation>
<xsd:documentation>Przesyłka pocztowa</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="7">
<xsd:annotation>
<xsd:documentation>Stałe instalacje przesyłowe</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="8">
<xsd:annotation>
<xsd:documentation>Żegluga śródlądowa</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
</xsd:restriction>
</xsd:simpleType>
simpleType TRolaPodmiotu3
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of xsd:integer
base xsd:integer
properties
element Faktura/Podmiot3/Rola
used by

---

Kind Value Annotation
facets
enumeration 1 documentation
Faktor - w przypadku, gdy na fakturze występują dane faktora
enumeration 2 documentation
Odbiorca - w przypadku, gdy na fakturze występują dane jednostek wewnętrznych,
oddziałów, wyodrębnionych w ramach nabywcy, które same nie stanowią nabywcy w
rozumieniu ustawy
enumeration 3 documentation
Podmiot pierwotny - w przypadku, gdy na fakturze występują dane podmiotu będącego w
stosunku do podatnika podmiotem przejętym lub przekształconym, który świadczył usługę lub
dokonywał dostawy. Z wyłączeniem przypadków, o których mowa w art. 106j ust.2 pkt 3
ustawy, gdy dane te wykazywane są w części Podmiot1K
enumeration 4 documentation
Dodatkowy nabywca - w przypadku, gdy na fakturze występują dane kolejnych (innych niż
wymieniony w części Podmiot2) nabywców
enumeration 5 documentation
Wystawca faktury - w przypadku, gdy na fakturze występują dane podmiotu wystawiającego
fakturę w imieniu podatnika. Nie dotyczy przypadku, gdy wystawcą faktury jest nabywca
enumeration 6 documentation
Dokonujący płatności - w przypadku, gdy na fakturze występują dane podmiotu regulującego
zobowiązanie w miejsce nabywcy
enumeration 7 documentation
Jednostka samorządu terytorialnego - wystawca
enumeration 8 documentation
Jednostka samorządu terytorialnego - odbiorca
enumeration 9 documentation
Członek grupy VAT - wystawca
enumeration 10 documentation
Członek grupy VAT - odbiorca
documentation
annotation
Rola podmiotu trzeciego
source <xsd:simpleType name="TRolaPodmiotu3">
<xsd:annotation>
<xsd:documentation>Rola podmiotu trzeciego</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="xsd:integer">
<xsd:enumeration value="1">
<xsd:annotation>
<xsd:documentation>Faktor - w przypadku, gdy na fakturze występują dane
faktora</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="2">
<xsd:annotation>
<xsd:documentation>Odbiorca - w przypadku, gdy na fakturze występują dane jednostek
wewnętrznych, oddziałów, wyodrębnionych w ramach nabywcy, które same nie stanowią nabywcy
w rozumieniu ustawy</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="3">
<xsd:annotation>
<xsd:documentation>Podmiot pierwotny - w przypadku, gdy na fakturze występują dane
podmiotu będącego w stosunku do podatnika podmiotem przejętym lub przekształconym, który
świadczył usługę lub dokonywał dostawy. Z wyłączeniem przypadków, o których mowa w art. 106j
ust.2 pkt 3 ustawy, gdy dane te wykazywane są w części Podmiot1K</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="4">
<xsd:annotation>
<xsd:documentation>Dodatkowy nabywca - w przypadku, gdy na fakturze występują dane
kolejnych (innych niż wymieniony w części Podmiot2) nabywców</xsd:documentation>
</xsd:annotation>

---

</xsd:enumeration>
<xsd:enumeration value="5">
<xsd:annotation>
<xsd:documentation>Wystawca faktury - w przypadku, gdy na fakturze występują dane
podmiotu wystawiającego fakturę w imieniu podatnika. Nie dotyczy przypadku, gdy wystawcą
faktury jest nabywca</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="6">
<xsd:annotation>
<xsd:documentation>Dokonujący płatności - w przypadku, gdy na fakturze występują dane
podmiotu regulującego zobowiązanie w miejsce nabywcy</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="7">
<xsd:annotation>
<xsd:documentation>Jednostka samorządu terytorialnego -
wystawca</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="8">
<xsd:annotation>
<xsd:documentation>Jednostka samorządu terytorialnego - odbiorca</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="9">
<xsd:annotation>
<xsd:documentation>Członek grupy VAT - wystawca</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="10">
<xsd:annotation>
<xsd:documentation>Członek grupy VAT - odbiorca</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
</xsd:restriction>
</xsd:simpleType>
simpleType TRolaPodmiotuUpowaznionego
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of xsd:integer
base xsd:integer
properties
element Faktura/PodmiotUpowazniony/RolaPU
used by
Kind Value Annotation
facets
enumeration 1 documentation
Organ egzekucyjny - w przypadku, o którym mowa w art. 106c pkt 1 ustawy
enumeration 2 documentation
Komornik sądowy - w przypadku, o którym mowa w art. 106c pkt 2 ustawy
enumeration 3 documentation
Przedstawiciel podatkowy - w przypadku, gdy na fakturze występują dane przedstawiciela
podatkowego, o którym mowa w przepisach art. 18a - 18d ustawy
documentation
annotation
Rola podmiotu upoważnionego

---

source <xsd:simpleType name="TRolaPodmiotuUpowaznionego">
<xsd:annotation>
<xsd:documentation>Rola podmiotu upoważnionego</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="xsd:integer">
<xsd:enumeration value="1">
<xsd:annotation>
<xsd:documentation>Organ egzekucyjny - w przypadku, o którym mowa w art. 106c pkt 1
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="2">
<xsd:annotation>
<xsd:documentation>Komornik sądowy - w przypadku, o którym mowa w art. 106c pkt 2
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="3">
<xsd:annotation>
<xsd:documentation>Przedstawiciel podatkowy - w przypadku, gdy na fakturze występują
dane przedstawiciela podatkowego, o którym mowa w przepisach art. 18a - 18d
ustawy</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
</xsd:restriction>
</xsd:simpleType>
simpleType TStatusInfoPodatnika
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of xsd:integer
base xsd:integer
properties
element Faktura/Podmiot1/StatusInfoPodatnika
used by
Kind Value Annotation
facets
enumeration 1 documentation
Podatnik znajdujący się w stanie likwidacji
enumeration 2 documentation
Podatnik, który jest w trakcie postępowania restrukturyzacyjnego
enumeration 3 documentation
Podatnik znajdujący się w stanie upadłości
enumeration 4 documentation
Przedsiębiorstwo w spadku
documentation
annotation
Status podatnika
source <xsd:simpleType name="TStatusInfoPodatnika">
<xsd:annotation>
<xsd:documentation>Status podatnika</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="xsd:integer">
<xsd:enumeration value="1">
<xsd:annotation>
<xsd:documentation>Podatnik znajdujący się w stanie likwidacji</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>

---

<xsd:enumeration value="2">
<xsd:annotation>
<xsd:documentation>Podatnik, który jest w trakcie postępowania
restrukturyzacyjnego</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="3">
<xsd:annotation>
<xsd:documentation>Podatnik znajdujący się w stanie upadłości</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="4">
<xsd:annotation>
<xsd:documentation>Przedsiębiorstwo w spadku</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
</xsd:restriction>
</xsd:simpleType>
simpleType TStawkaPodatku
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of tns:TZnakowy
base tns:TZnakowy
properties
elements Faktura/Fa/FaWiersz/P_12 Faktura/Fa/Zamowienie/ZamowienieWiersz/P_12Z
used by
Kind Value Annotation
facets
minLength 1
maxLength 256
enumeration 23
enumeration 22
enumeration 8
enumeration 7
enumeration 5
enumeration 4
enumeration 3
enumeration 0
enumeration zw documentation
zwolnione od podatku
enumeration oo documentation
odwrotne obciążenie
enumeration np documentation
niepodlegające opodatkowaniu- dostawy towarów oraz świadczenia usług poza terytorium
kraju
documentation
annotation
Stawka podatku
source <xsd:simpleType name="TStawkaPodatku">
<xsd:annotation>
<xsd:documentation>Stawka podatku</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="tns:TZnakowy">
<xsd:enumeration value="23"/>
<xsd:enumeration value="22"/>
<xsd:enumeration value="8"/>

---

<xsd:enumeration value="7"/>
<xsd:enumeration value="5"/>
<xsd:enumeration value="4"/>
<xsd:enumeration value="3"/>
<xsd:enumeration value="0"/>
<xsd:enumeration value="zw">
<xsd:annotation>
<xsd:documentation>zwolnione od podatku</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="oo">
<xsd:annotation>
<xsd:documentation>odwrotne obciążenie</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="np">
<xsd:annotation>
<xsd:documentation>niepodlegające opodatkowaniu- dostawy towarów oraz świadczenia
usług poza terytorium kraju</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
</xsd:restriction>
</xsd:simpleType>
simpleType TTypKorekty
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of xsd:integer
base xsd:integer
properties
element Faktura/Fa/TypKorekty
used by
Kind Value Annotation
facets
enumeration 1 documentation
Korekta skutkująca w dacie ujęcia faktury pierwotnej
enumeration 2 documentation
Korekta skutkująca w dacie wystawienia faktury korygującej
enumeration 3 documentation
Korekta skutkująca w dacie innej, w tym gdy dla różnych pozycji faktury korygującej daty te
są różne
documentation
annotation
Typ skutku korekty w ewidencji dla podatku od towarów i usług
source <xsd:simpleType name="TTypKorekty">
<xsd:annotation>
<xsd:documentation>Typ skutku korekty w ewidencji dla podatku od towarów i
usług</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="xsd:integer">
<xsd:enumeration value="1">
<xsd:annotation>
<xsd:documentation>Korekta skutkująca w dacie ujęcia faktury
pierwotnej</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="2">
<xsd:annotation>
<xsd:documentation>Korekta skutkująca w dacie wystawienia faktury

---

korygującej</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
<xsd:enumeration value="3">
<xsd:annotation>
<xsd:documentation>Korekta skutkująca w dacie innej, w tym gdy dla różnych pozycji
faktury korygującej daty te są różne</xsd:documentation>
</xsd:annotation>
</xsd:enumeration>
</xsd:restriction>
</xsd:simpleType>
simpleType TZnakowy
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of xsd:token
base xsd:token
properties
elements Faktura/Stopka/Rejestry/BDO Faktura/Fa/WarunkiTransakcji/Transport/JednostkaOpakowania
used by
TKluczWartosc/Klucz TRachunekBankowy/NazwaBanku Faktura/Podmiot1/NrEORI
Faktura/Podmiot2/NrEORI Faktura/Podmiot3/NrEORI Faktura/PodmiotUpowazniony/NrEORI
Faktura/Fa/DaneFaKorygowanej/NrFaKorygowanej Faktura/Fa/NrFaKorygowany
Faktura/Fa/FakturaZaliczkowa/NrFaZaliczkowej Faktura/Podmiot2/NrKlienta
Faktura/Podmiot3/NrKlienta Faktura/Fa/WarunkiTransakcji/NrPartiiTowaru
Faktura/Fa/WarunkiTransakcji/Umowy/NrUmowy
Faktura/Fa/WarunkiTransakcji/Zamowienia/NrZamowienia
Faktura/Fa/WarunkiTransakcji/Transport/NrZleceniaTransportu Faktura/Fa/OkresFaKorygowanej
Faktura/Fa/Platnosc/OpisPlatnosci TRachunekBankowy/OpisRachunku
Faktura/Podmiot3/OpisRoli Faktura/Fa/Adnotacje/Zwolnienie/P_19A
Faktura/Fa/Adnotacje/Zwolnienie/P_19B Faktura/Fa/Adnotacje/Zwolnienie/P_19C Faktura/Fa/P_1M
Faktura/Fa/P_2 Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22B
Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22B1
Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22B2
Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22B3
Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22B4
Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22BK
Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22BMD
Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22BMK
Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22BNR
Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22BRP
Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22BT
Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22C
Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22C1
Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22D
Faktura/Fa/Adnotacje/NoweSrodkiTransportu/NowySrodekTransportu/P_22D1
Faktura/Fa/FaWiersz/P_7 Faktura/Fa/Zamowienie/ZamowienieWiersz/P_7Z
Faktura/Fa/FaWiersz/P_8A Faktura/Fa/Zamowienie/ZamowienieWiersz/P_8AZ
Faktura/Stopka/Rejestry/PelnaNazwa Faktura/Fa/Rozliczenie/Odliczenia/Powod
Faktura/Fa/Rozliczenie/Obciazenia/Powod Faktura/Fa/PrzyczynaKorekty TNaglowek/SystemInfo
Faktura/Fa/Platnosc/TerminPlatnosci/TerminOpis TKluczWartosc/Wartosc
Faktura/Fa/WarunkiTransakcji/WarunkiDostawy Faktura/Fa/Platnosc/Skonto/WarunkiSkonta
Faktura/Fa/Platnosc/Skonto/WysokoscSkonta Faktura/Fa/WZ
simpleTypes TGTU TNumerTelefonu TOznaczenieProcedury TOznaczenieProceduryZ TRodzajFaktury
TStawkaPodatku
Kind Value Annotation
facets
minLength 1
maxLength 256
documentation
annotation
Typ znakowy ograniczony do 256 znaków
source <xsd:simpleType name="TZnakowy">
<xsd:annotation>

---

<xsd:documentation>Typ znakowy ograniczony do 256 znaków</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="xsd:token">
<xsd:minLength value="1"/>
<xsd:maxLength value="256"/>
</xsd:restriction>
</xsd:simpleType>
simpleType TZnakowy20
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of xsd:token
base xsd:token
properties
elements Faktura/Fa/FaWiersz/GTIN Faktura/Fa/Zamowienie/ZamowienieWiersz/GTINZ
used by
simpleType TNIPIdWew
Kind Value Annotation
facets
minLength 1
maxLength 20
documentation
annotation
Typ znakowy ograniczony do 20 znaków
source <xsd:simpleType name="TZnakowy20">
<xsd:annotation>
<xsd:documentation>Typ znakowy ograniczony do 20 znaków</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="xsd:token">
<xsd:minLength value="1"/>
<xsd:maxLength value="20"/>
</xsd:restriction>
</xsd:simpleType>
simpleType TZnakowy50
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of xsd:token
base xsd:token
properties
elements Faktura/Fa/FaWiersz/CN Faktura/Fa/Zamowienie/ZamowienieWiersz/CNZ
used by
Faktura/Podmiot2/IDNabywcy Faktura/Podmiot3/IDNabywcy Faktura/Fa/Podmiot2K/IDNabywcy
Faktura/Fa/FaWiersz/Indeks Faktura/Fa/Zamowienie/ZamowienieWiersz/IndeksZ
Faktura/Fa/WarunkiTransakcji/Transport/OpisInnegoLadunku
Faktura/Fa/WarunkiTransakcji/Transport/OpisInnegoTransportu Faktura/Fa/FaWiersz/PKOB
Faktura/Fa/Zamowienie/ZamowienieWiersz/PKOBZ Faktura/Fa/FaWiersz/PKWiU
Faktura/Fa/Zamowienie/ZamowienieWiersz/PKWiUZ Faktura/Fa/FaWiersz/UU_ID
Faktura/Fa/Zamowienie/ZamowienieWiersz/UU_IDZ
Kind Value Annotation
facets
minLength 1
maxLength 50
documentation
annotation
Typ znakowy ograniczony do 50 znaków
source <xsd:simpleType name="TZnakowy50">
<xsd:annotation>
<xsd:documentation>Typ znakowy ograniczony do 50 znaków</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="xsd:token">

---

<xsd:minLength value="1"/>
<xsd:maxLength value="50"/>
</xsd:restriction>
</xsd:simpleType>
simpleType TZnakowy512
namespace http://crd.gov.pl/wzor/2023/06/29/12648/
type restriction of xsd:token
base xsd:token
properties
elements TAdres/AdresL1 TAdres/AdresL2 TPodmiot1/Nazwa TPodmiot2/Nazwa TPodmiot3/Nazwa
used by
Kind Value Annotation
facets
minLength 1
maxLength 512
documentation
annotation
Typ znakowy ograniczony do 512 znaków
source <xsd:simpleType name="TZnakowy512">
<xsd:annotation>
<xsd:documentation>Typ znakowy ograniczony do 512 znaków</xsd:documentation>
</xsd:annotation>
<xsd:restriction base="xsd:token">
<xsd:minLength value="1"/>
<xsd:maxLength value="512"/>
</xsd:restriction>
</xsd:simpleType>
XML Schema documentation generated by XMLSpy Schema Editor http://www.altova.com/xmlspy