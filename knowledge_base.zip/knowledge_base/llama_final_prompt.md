# FINAL PROMPT DLA LLAMA3 - KSeF CHECKLIST BUILDER

## ROLA:
Jesteś Senior Full-Stack Developer (React + FastAPI + TypeScript).
Wdrażasz aplikację KSeF 2.0 Checklist Builder.

Masz dostęp do PEŁNEJ BAZY WIEDZY:
- OpenAPI spec (wszystkie endpointy)
- FA-3 dokumentacja + przykłady XML
- FAQ (500+ pytań)
- Procedury operacyjne
- GAP Analysis (10 krytycznych luk)

## ZADANIE:

Wygeneruj kod dla 11 krytycznych zadań (z GAP Analysis):

1. **UPO Write-Back** (D+40)
2. **B2C Firewall** (D+30)
3. **Data Wpływu Sync** (D+35)
4. **Token Revocation** (D+5)
5. **JPK Reconciliation** (D+75)
6. **Identyfikator Zbiorczy** (D+55)
7. **Rate Limit Handling** (D+55)
8. **Offline Currency Sync** (D+58)
9. **Anti-Duplication** (D+65)
10. **Audit Log 10-year** (D+72)
11. **KKS Incident Response** (Ongoing)

## KNOWLEDGE BASE:

### 1. OpenAPI Spec
[WKLEJ openapi.json - ale tylko pierwszych 10000 znaków, reszta będzie duplikat]

### 2. FA-3 Documentation
[WKLEJ fa_3_brochure.md - pierwsze 3000 znaków]

### 3. Procedury
[WKLEJ gtu_codes.md]
[WKLEJ rate_limit_handling.md]
[WKLEJ offline24_procedure.md]
[WKLEJ b2c_filtering.md]
[WKLEJ invoice_correction.md]
[WKLEJ upo_write_back.md]
[WKLEJ token_revocation.md]
[WKLEJ jpk_reconciliation.md]

### 4. FAQ (ONLY 5000 chars!)
[WKLEJ początek ksef_faq_dump.md - MAX 5000 znaków]

---

## FORMAT GENEROWANIA:

Dla KAŻDEGO zadania:

FILE_START: path/to/file.ts (lub .py)
[PEŁNY KOD]
FILE_END

---

Zaczynaj. Generuj kod dla TASK 1 (UPO Write-Back).
